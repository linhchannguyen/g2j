<?php

namespace  App\API\Internal\HotelPricing;

use App\Helpers\LoggingHelper;
use App\Providers\GuzzleClientServiceProvider;
use Exception;

class HotelPricing
{
    const GET_HOTEL_PRICE_ANY_TIME = 'v1/getHotelPrice';

    protected $timeout = 60;

    protected $host;

    public function __construct(string $host)
    {
        $this->host = $host;
    }

    public function getHotelPriceAnyTimeList($startDate, $endDate, $flashSale, $hotelSnList)
    {
        $response = [];
        try {
            $headers = [
                'Content-Type'  => 'application/json',
                'Cache-Control' => 'no-cache',
            ];
            $options = [
                'base_uri' => $this->host,
                'headers'  => $headers,
                'timeout'  => 1,
            ];

            $client = app('GuzzleClient', [
                'service' => GuzzleClientServiceProvider::SERVICE['GOLANG'],
            ])($options);

            $dataJson = json_encode([
                'startDate'   => $startDate,
                'endDate'     => $endDate,
                'flashSale'   => $flashSale,
                'hotelSnList' => $hotelSnList,

            ]);
            $response = $client->request(
                'GET',
                self::GET_HOTEL_PRICE_ANY_TIME,
                [
                    'body' => $dataJson,
                ]
            );
            $response = (string)$response->getBody() ? json_decode((string)$response->getBody(), true)['data'] : [];
        } catch (Exception $exception) {
            LoggingHelper::logException($exception);
        }

        return $response;
    }
}