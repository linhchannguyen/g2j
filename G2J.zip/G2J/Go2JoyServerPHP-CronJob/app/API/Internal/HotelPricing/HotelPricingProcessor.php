<?php

namespace App\API\Internal\HotelPricing;

use App\DTOs\Internal\HotelPricing\GetHotelPriceAnyTimeListOutputDTO;

class HotelPricingProcessor
{
    protected $config;

    protected $hotelPricingAPI;

    public function __construct()
    {
        $this->config = config('golang');

        $this->hotelPricingAPI = new HotelPricing(
            $this->config['host'] ?? null
        );
    }

    public function getHotelPriceAnyTimeList($startDate, $endDate, $flashSale, $hotelSnList): GetHotelPriceAnyTimeListOutputDTO
    {
        $hotelList = $this->hotelPricingAPI->getHotelPriceAnyTimeList($startDate, $endDate, $flashSale, $hotelSnList);

        return GetHotelPriceAnyTimeListOutputDTO::assemble($hotelList);
    }
}