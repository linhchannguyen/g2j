<?php

namespace App\API\External\ElasticSearch;

interface ElasticSearchProcessorInterface
{
    public function setupDataElasticSearch();


}
