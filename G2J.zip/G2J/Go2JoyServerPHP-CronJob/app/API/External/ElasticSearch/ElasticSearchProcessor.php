<?php

namespace App\API\External\ElasticSearch;

use App\API\External\ElasticSearch\ElasticSearchProcessorInterface;
use App\Constants\Globals\Pagination;
use App\Constants\Hotel;
use App\Libraries\ElasticSearch\ElasticSearchAPI;
use App\Models\Hashtag;
use App\Models\Province;
use App\Repositories\Interfaces\HashtagRepositoryInterface;
use App\Repositories\Interfaces\DistrictRepositoryInterface;
use App\Repositories\Interfaces\ProvinceRepositoryInterface;
use App\Services\Web\SA\HotelService;
use Illuminate\Support\Facades\DB;

class ElasticSearchProcessor implements ElasticSearchProcessorInterface
{

    protected $elasticSearchAPI;

    protected $hashtagRepository;

    protected $districtRepository;

    protected $provinceRepository;

    protected $hotelService;

    public function __construct(HashtagRepositoryInterface $hashtagRepository,
                                DistrictRepositoryInterface $districtRepository,
                                ProvinceRepositoryInterface $provinceRepository,
                                HotelService $hotelService)
    {
        $domain = config('elasticsearch.domain');
        $this->elasticSearchAPI = new ElasticSearchAPI($domain);
        $this->hashtagRepository = $hashtagRepository;
        $this->districtRepository = $districtRepository;
        $this->provinceRepository = $provinceRepository;
        $this->hotelService = $hotelService;
    }

    public function setupDataElasticSearch()
    {
        $hashtagData = DB::table(Hashtag::TABLE_NAME)->get(['*']);
        $provinceData = DB::table(Province::TABLE_NAME)->get(['*']);
        $districtData = $this->districtRepository->findAllDistrictWithProvinceName();
        $hotelData = $this->hotelService->index(null, null, null, null, null, null, null, null, [Hotel::STATUS['DISPLAYED'], Hotel::STATUS['CONTRACTED'], Hotel::STATUS['TRIAL'], Hotel::STATUS['SUSPENDED']], array(['H.NAME', 'ASC']), Pagination::LIMIT['NO_LIMIT']);
        return $this->elasticSearchAPI->initialDataElasticSearch($hotelData, $provinceData, $districtData, $hashtagData);
    }
}
