<?php

namespace App\API\External\Mail;

use Exception;

interface MailProcessorInterface
{
    /**
     * @param array $toAddresses
     * @param string $subject
     * @param string $bodyHtml
     * @param array|null $attachFiles
     * @param bool $ccMail
     * @return array
     *
     * @throws Exception
     */
    public function send(array $toAddresses,
                         string $subject,
                         string $bodyHtml,
                         array $attachFiles = null,
                         bool $ccMail = false
    ): array;
}
