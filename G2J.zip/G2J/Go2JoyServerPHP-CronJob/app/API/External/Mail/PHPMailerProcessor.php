<?php

namespace App\API\External\Mail;

use App\Constants\Globals\Environment as EnvironmentConst;
use App\Helpers\LoggingHelper;
use PHPMailer\PHPMailer\Exception;
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;

class PHPMailerProcessor implements MailProcessorInterface
{
    /** @var string */
    protected $username;

    /** @var string */
    protected $password;

    /** @var string */
    protected $fromAddress;

    /** @var string */
    protected $fromName;

    const SUPPORT_EMAIL_ADDRESS = "support@go2joy.vn";

    /**
     * PHPMailerProcessor constructor.
     *
     * @param string|null $fromAddress
     * @param string|null $fromName
     */
    public function __construct(?string $fromAddress = null, ?string $fromName = null)
    {
        $this->username = config('phpmailer.username');
        $this->password = config('phpmailer.password');
        $this->fromAddress = $fromAddress ?? config('phpmailer.from.address');
        $this->fromName = $fromName ?? config('phpmailer.from.name');
    }

    /**
     * @param array $toAddresses
     * @param string $subject
     * @param string $bodyHtml
     * @param array|null $attachFiles
     * @param bool $ccMail
     * @return array
     *
     * @throws Exception
     */
    public function send(array $toAddresses,
                         string $subject,
                         string $bodyHtml,
                         array $attachFiles = null,
                         bool $ccMail = false
    ): array {
        $mail = new PHPMailer();
        $mail->isSMTP();

        //Enable SMTP debugging
        // SMTP::DEBUG_OFF = off (for production use)
        // SMTP::DEBUG_CLIENT = client messages
        // SMTP::DEBUG_SERVER = client and server messages
        $mail->SMTPDebug = SMTP::DEBUG_OFF;
        //echo (extension_loaded('openssl')?'SSL loaded':'SSL not loaded')."\n";

        //Set the hostname of the mail server
        $mail->Host = config('phpmailer.host');
        //$mail->Port = 25;

        // SMTPS
        //$mail->Port = 465;
        //$mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;

        // for authenticated TLS
        $mail->Port = config('phpmailer.port');
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;

        $mail->SMTPOptions = array(
            "ssl" => array(
                "verify_peer"       => false,
                "verify_peer_name"  => false,
                "allow_self_signed" => true,
            ),
        );
        //$mail->SMTPSecure = false;

        $mail->SMTPAutoTLS = true;
        //$mail->SMTPAutoTLS = false;
        $mail->SMTPAuth = true;

        //Username to use for SMTP authentication - use full email address
        $mail->Username = $this->username;
        $mail->Password = $this->password;

        $mail->CharSet = PHPMailer::CHARSET_UTF8;
        $mail->Encoding = PHPMailer::ENCODING_BASE64;

        //Set who the message is to be sent from
        $mail->setFrom($this->fromAddress, $this->fromName);

        //Set who the message is to be sent to
        foreach ($toAddresses as $address) {
            $mail->addAddress($address);
        }

        $mail->isHTML();
        $mail->Subject = $subject;
        $mail->Body = $bodyHtml;
        //Add cc mail support Go2Joy tracking send mail
        if ($ccMail && app()->environment(EnvironmentConst::PRODUCTION)) {
            $mail->addCC(self::SUPPORT_EMAIL_ADDRESS);
        }
        //Replace the plain text body with one created manually
        //$mail->AltBody = 'This is a plain-text message body';

        //Attach files
        if ($attachFiles != null) {
            foreach ($attachFiles as $attachFile) {
                $fileName = $attachFile['fileName'];
                $filePath = $attachFile['filePath'];
                $mail->addAttachment($filePath, $fileName);
            }
        }

        //send the message, check for errors
        $error = null;
        $errorEmails = [];
        $isSuccess = $mail->send();

        //if ($mail->SMTPDebug != SMTP::DEBUG_OFF)
        //echo ($result) ? "Send email success.\n" : "Send email failed. (" . $mail->ErrorInfo . ")\n";

        if (!$isSuccess) {
            $error = $mail->ErrorInfo;
            $errorSplit = explode(":", $error);
            foreach ($errorSplit as $err) {
                $pos = strpos($err, '@');
                if ($pos !== false) {
                    $errorEmails[] = trim($err);
                }
            }
        }
        LoggingHelper::logMail($toAddresses, $subject, $bodyHtml, $attachFiles, $error, $errorEmails);
        return [$error, $errorEmails];
    }
}
