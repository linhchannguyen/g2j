<?php

namespace App\API\External\Logging;

interface LoggingProcessorInterface
{
    public function write(string $log);
}
