<?php

namespace App\API\External\Logging;

use App\Helpers\LoggingHelper;
use Exception;
use Fluent\Logger\FluentLogger;

class FluentdLoggingProcessor implements LoggingProcessorInterface
{
    protected $logger = null;

    protected $config = [];

    public function __construct()
    {
        $this->config = config('fluentd');
        if (is_null($this->logger)) {
            $host = "{$this->config['protocol']}://{$this->config['host']}";
            $port = $this->config['port'];
            $this->logger = FluentLogger::open($host, $port, array("persistent" => true));
        }
    }

    public function write(string $log)
    {
        try {
            $log = json_decode($log, true);
            return $this->logger->post($this->config['tag'], $log);
        } catch (Exception $exception) {
            LoggingHelper::logException($exception);
            $this->logger->close();
            $this->logger = null;
            throw $exception;
        }
    }
}
