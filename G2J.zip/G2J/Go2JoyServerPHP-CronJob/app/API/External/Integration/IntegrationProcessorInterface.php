<?php

namespace App\API\External\Integration;

use App\DTOs\DTO;

interface IntegrationProcessorInterface
{
    public function getCityList(DTO $dto): DTO;

    public function getAreaList(DTO $dto): DTO;

    public function fetchHotel(DTO $dto): DTO;

    public function pullHotel(DTO $dto): DTO;

    public function pullHotelFacility(DTO $dto): DTO;

    public function pullHotelImage(DTO $dto): DTO;

    public function pullRoomTypeFacility(DTO $dto): DTO;

    public function pullRoomType(DTO $dto): DTO;

    public function pullFacility(DTO $dto);

    public function pullBooking(DTO $dto);

    public function precheck(DTO $dto): DTO;

    public function getBookingDetail($dto);

    public function cancelBooking($dto);
}