<?php

namespace App\API\External\Integration\Agoda;

use App\Constants\Globals\Integration;
use App\Constants\Partners\Agoda as AgodaConst;
use App\Helpers\ConvertHelper;
use App\Helpers\GenerateHelper;
use App\Libraries\DataStructures\Agoda\BookDetails;
use App\Libraries\DataStructures\Agoda\ConfirmCancelDetails;
use App\Libraries\DataStructures\Agoda\Criteria;
use App\Libraries\DataStructures\Agoda\CustomerDetail;
use App\Libraries\DataStructures\Agoda\Features;
use App\Libraries\DataStructures\Agoda\PrecheckDetails;
use App\Providers\GuzzleClientServiceProvider;
use Exception;
use SimpleXMLElement;

class Agoda
{
    /** @var int */
    const BOOKING_TIMEOUT = 1800;

    /** @var string */
    protected $siteId;

    /** @var string */
    protected $apiKey;

    /**
     * @var float
     * Use 0 to set indefinitely (the default behavior)
     */
    protected $timeout = 120;

    /**
     * API URL.
     *
     * @var string
     */
    protected $apiUrl;

    /**
     * Feed URL.
     *
     * @var string
     */
    protected $feedUrl;

    /**
     * API services URL.
     *
     * @var string
     */
    protected $apiServicesUrl;

    /**
     * API secure URL.
     *
     * @var string
     */
    protected $apiSecureUrl;

    #region List of endpoints of Agoda API
    const SEARCH_API_ENDPOINT = '/api/v4/property/availability';
    const PRECHECK_API_ENDPOINT = '/api/v2/prebooking/precheck';
    const BOOK_API_ENDPOINT = '/api/v4/book';
    const BOOKING_LIST_API_ENDPOINT = '/api/v4/bookingreport/booklist';
    const BOOKING_DETAIL_API_ENDPOINT = '/api/v4/bookingreport/bookingdetail';
    const SPECIAL_REQUEST_API_ENDPOINT = '/api/v4/postbooking/specialrequest';
    const CANCEL_API_ENDPOINT = '/api/v4/postBooking/cancel';
    const CONFIRM_CANCEL_API_ENDPOINT = '/api/v4/postbooking/confirmcancel';
    #endregion List of endpoints of Agoda API

    #region List of endpoints of Agoda data feed
    const HOTEL_FEED_ENDPOINT = '/datafeeds/feed/getfeed?feed_id=5';
    const CITY_FEED_ENDPOINT = '/datafeeds/feed/getfeed?feed_id=3';
    const COUNTRY_FEED_ENDPOINT = '/datafeeds/feed/getfeed?feed_id=2';
    const CONTINENT_FEED_ENDPOINT = '/datafeeds/feed/getfeed?feed_id=1';
    const AREA_FEED_ENDPOINT = '/datafeeds/feed/getfeed?feed_id=4';
    const HOTEL_ADDRESSES_FEED_ENDPOINT = '/datafeeds/feed/getfeed?feed_id=18';
    const FULL_HOTEL_INFORMATION_FEED_ENDPOINT = '/datafeeds/feed/getfeed?feed_id=19';
    const OTHER_INFO_PER_HOTEL_FEED_ENDPOINT = '/datafeeds/feed/getfeed?feed_id=10';
    const HOTEL_DESCRIPTIONS_FEED_ENDPOINT = '/datafeeds/feed/getfeed?feed_id=17';
    const LOCAL_INFORMATION_FEED_ENDPOINT = '/datafeeds/feed/getfeed?feed_id=31';
    const FACILITIES_PER_HOTEL_FEED_ENDPOINT = '/datafeeds/feed/getfeed?feed_id=9';
    const FACILITIES_PER_ROOM_TYPE_PER_HOTEL_FEED_ENDPOINT = '/datafeeds/feed/getfeed?feed_id=14';
    const PICTURES_PER_HOTEL_FEED_ENDPOINT = '/datafeeds/feed/getfeed?feed_id=7';
    const ROOMTYPES_PER_HOTEL_FEED_ENDPOINT = '/datafeeds/feed/getfeed?feed_id=6';
    const HOTEL_HAVE_INFORMATION_UPDATE_FEED_ENDPOINT = '/datafeeds/feed/getfeed?feed_id=32';
    #endregion List of endpoints of Agoda data feed

    /**
     * Agoda constructor.
     *
     * @param string $siteId
     * @param string $apiKey
     * @param string $apiUrl
     * @param string $feedUrl
     * @param string $apiServicesUrl
     * @param string $apiSecureUrl
     */
    public function __construct(string $siteId, string $apiKey, string $apiUrl, string $feedUrl, string $apiServicesUrl, string $apiSecureUrl)
    {
        $this->siteId = $siteId;
        $this->apiKey = $apiKey;
        $this->apiUrl = $apiUrl;
        $this->feedUrl = $feedUrl;
        $this->apiServicesUrl = $apiServicesUrl;
        $this->apiSecureUrl = $apiSecureUrl;
    }

    #region Agoda API

    /**
     * @param Criteria $criteria
     * @param Features $features
     *
     * @return array
     * @throws Exception
     */
    public function searchAPI(Criteria $criteria, Features $features): array
    {
        if ($criteria->getChildren() > 0 && count($criteria->getChildrenAges()) == 0) {
            throw new Exception("At least one children age when have enter a number of children");
        }

        $headers = [
            'Content-Type'    => 'application/json; charset=UTF-8',
            'Accept-Encoding' => 'gzip, deflate, br',
            'Authorization'   => "$this->siteId:$this->apiKey",
        ];
        $options = [
            'base_uri' => $this->apiUrl,
            'headers'  => $headers,
            'timeout'  => $this->timeout,
        ];

        $searchForm = [
            "waitTime" => $this->timeout,
            "criteria" => [
                "propertyIds"  => $criteria->getPropertyIds(),
                "checkIn"      => $criteria->getCheckIn(),
                "checkOut"     => $criteria->getCheckOut(),
                "rooms"        => $criteria->getRooms(),
                "adults"       => $criteria->getAdults(),
                "children"     => $criteria->getChildren(),
                "childrenAges" => $criteria->getChildrenAges(),
                "language"     => $criteria->getLanguage(),
                "currency"     => $criteria->getCurrency(),
                "userCountry"  => $criteria->getUserCountry(),
            ],
            "features" => [
                "ratesPerProperty" => $features->getRatesPerProperty(),
                "extra"            => $features->getExtra(),
            ],
        ];

        $client = app('GuzzleClient', [
            'service'  => GuzzleClientServiceProvider::SERVICE['INTEGRATION'],
            'provider' => Integration::PARTNER['AGODA'],
        ])($options);
        $response = $client->request(
            'POST',
            self::SEARCH_API_ENDPOINT,
            [
                'body' => json_encode($searchForm),
            ]
        );

        return ConvertHelper::toJsonResponse($response);
    }

    /**
     * @param PrecheckDetails $precheckDetail
     *
     * @return array
     * @throws Exception
     */
    public function precheckAPI(PrecheckDetails $precheckDetail): array
    {
        $searchId = $precheckDetail->getSearchId();
        $hotelId = $precheckDetail->getHotel()->getId();
        $rooms = $precheckDetail->getHotel()->getRooms();
        $checkInDate = $precheckDetail->getHotel()->getCheckInDate();
        $checkOutDate = $precheckDetail->getHotel()->getCheckOutDate();
        $userCountry = $precheckDetail->getHotel()->getCountry();
        $tag = $precheckDetail->getHotel()->getTag();
        $allowDuplication = $precheckDetail->getAllowDuplication();

        $precheckDetailsForm = [
            "precheckDetails" => [
                "searchId"         => $searchId,
                "allowDuplication" => $allowDuplication,
                "checkIn"          => $checkInDate,
                "checkOut"         => $checkOutDate,
                "property"         => [
                    "propertyId" => $hotelId,
                    "rooms"      => [],
                ],
                "language"         => AgodaConst::LANGUAGE_CODE['VIETNAMESE'],
                "userCountry"      => $userCountry,
            ],
        ];

        if (!empty($tag)) {
            $precheckDetailsForm["precheckDetails"]["tag"] = $tag;
        }

        foreach ($rooms as $room) {
            /* @var PrecheckDetails\Hotel\Room $room */
            $paymentModel = $room->getPaymentModel();
            $roomBlockId = $room->getBlockId();
            $inclusive = $room->getRate()->getInclusive();
            $currency = $room->getCurrency();
            $numOfRooms = $room->getCount();
            $numOfAdults = $room->getAdults();
            $numOfChildren = $room->getChildren();
            $childrenAgesList = $room->getAgeChildrenList();
            $childrenAges = [];
            if (!empty($childrenAgesList)) {
                foreach ($childrenAgesList as $childrenAge) {
                    /* @var PrecheckDetails\Hotel\Room\Children $childrenAge */
                    $childrenAges[] = $childrenAge->getAge();
                }
            }

            $precheckDetailsForm['precheckDetails']['property']['rooms'][] = [
                "currency"     => $currency,
                "paymentModel" => $paymentModel,
                "blockId"      => $roomBlockId,
                "count"        => $numOfRooms,
                "adults"       => $numOfAdults,
                "children"     => $numOfChildren,
                "childrenAges" => $childrenAges,
                "rate"         => [
                    "inclusive" => $inclusive,
                ],
            ];
        }

        $headers = [
            'Content-Type'    => 'application/json; charset=UTF-8',
            'Accept-Encoding' => 'gzip, deflate, br',
            'Authorization'   => "$this->siteId:$this->apiKey",
        ];
        $options = [
            'base_uri'   => $this->apiServicesUrl,
            'headers'    => $headers,
            'timeout'    => $this->timeout,
            'exceptions' => false, //For Guzzle 5.3
        ];

        $client = app('GuzzleClient', [
            'service'  => GuzzleClientServiceProvider::SERVICE['INTEGRATION'],
            'provider' => Integration::PARTNER['AGODA'],
        ])($options);
        $response = $client->request(
            'POST',
            self::PRECHECK_API_ENDPOINT,
            [
                'body' => json_encode($precheckDetailsForm),
            ]
        );

        return ConvertHelper::toJsonResponse($response);
    }

    /**
     * @param BookDetails $bookDetails
     *
     * @return array|null
     * @throws Exception
     */
    public function bookAPI(BookDetails $bookDetails): ?array
    {
        $searchId = $bookDetails->getSearchId();
        $hotelId = $bookDetails->getHotel()->getId();
        $checkInDate = $bookDetails->getHotel()->getCheckInDate();
        $checkOutDate = $bookDetails->getHotel()->getCheckOutDate();
        $userCountry = $bookDetails->getHotel()->getCountry();
        $tag = $bookDetails->getHotel()->getTag();
        $allowDuplication = $bookDetails->getAllowDuplication();

        $room = $bookDetails->getHotel()->getRoom();
        $paymentModel = $room->getModel();
        $roomBlockId = $room->getBlockId();
        $currency = $room->getCurrency();
        $inclusive = $room->getRate()->getInclusive();

        $numOfRooms = $room->getCount();
        $numOfAdults = $room->getAdults();
        $numOfChildren = $room->getChildren();
        $specialRequest = $room->getSpecialRequest();
        $guestDetails = $room->getGuestDetails();

        $customerLanguage = $bookDetails->getCustomer()->getLanguage();
        $customerTitle = $bookDetails->getCustomer()->getTitle();
        $customerFirstName = $bookDetails->getCustomer()->getFirstName();
        $customerLastName = $bookDetails->getCustomer()->getLastName();
        $customerEmail = $bookDetails->getCustomer()->getEmail();
        $customerNewsletter = $bookDetails->getCustomer()->getNewsletter();

        $phone = $bookDetails->getCustomer()->getPhone();
        $phoneCountryCode = $phone->getCountryCode();
        $phoneAreaCode = $phone->getAreaCode();
        $phoneNumber = $phone->getNumber();

        $cardType = $bookDetails->getCreditCardInfo()->getType();
        $cardNumber = $bookDetails->getCreditCardInfo()->getNumber();
        $cardExpiryDate = $bookDetails->getCreditCardInfo()->getExpiryDate();
        $cardCvc = $bookDetails->getCreditCardInfo()->getCvc();
        $cardHolderName = $bookDetails->getCreditCardInfo()->getHolderName();
        $cardCountryOfIssue = $bookDetails->getCreditCardInfo()->getCountryOfIssue();
        $cardIssuingBank = $bookDetails->getCreditCardInfo()->getIssuingBank();

        $guestDetailsForm = [];
        foreach ($guestDetails as $guestDetail) {
            /* @var  BookDetails\Hotel\Room\GuestDetail $guestDetail */
            $primary = $guestDetail->getPrimary();
            $title = $guestDetail->getTitle();
            $firstName = $guestDetail->getFirstName();
            $lastName = $guestDetail->getLastName();
            $countryOfPassport = $guestDetail->getCountryOfPassport();
            $gender = $guestDetail->getGender();
            $age = $guestDetail->getAge();
            $isChild = $guestDetail->isChild();

            $guestDetailsForm[] = [
                "title"              => $title,
                "firstName"          => $firstName,
                "lastName"           => $lastName,
                "countryOfResidence" => $countryOfPassport,
                "gender"             => $gender,
                "age"                => $age,
                "primary"            => $primary,
                "isChild"            => $isChild,
            ];
        }

        $bookingForm = [
            "waitTime"       => $this->timeout,
            "bookingDetails" => [
                "userCountry"      => $userCountry,
                "searchId"         => $searchId,
                "tag"              => $tag,
                "allowDuplication" => $allowDuplication,
                "checkIn"          => $checkInDate,
                "checkOut"         => $checkOutDate,
                "language"         => AgodaConst::LANGUAGE_CODE['VIETNAMESE'],
                "property"         => [
                    "propertyId"     => $hotelId,
                    "rooms"          => array(
                        [
                            "currency"     => $currency,
                            "paymentModel" => $paymentModel,
                            "blockId"      => $roomBlockId,
                            "count"        => $numOfRooms,
                            "adults"       => $numOfAdults,
                            "children"     => $numOfChildren,
                            "rate"         => [
                                "inclusive" => $inclusive,
                            ],
                            "guestDetails" => $guestDetailsForm,
                        ],
                    ),
                    "currency"       => $currency,
                    "paymentModel"   => $paymentModel,
                    "count"          => $numOfRooms,
                    "adults"         => $numOfAdults,
                    "children"       => $numOfChildren,
                    "specialRequest" => strval($specialRequest),
                ],
            ],
            "customerDetail" => [
                "language"   => $customerLanguage,
                "title"      => $customerTitle,
                "firstName"  => $customerFirstName,
                "lastName"   => $customerLastName,
                "email"      => $customerEmail,
                "phone"      => [
                    "countryCode" => $phoneCountryCode,
                    "areaCode"    => $phoneAreaCode,
                    "number"      => $phoneNumber,
                ],
                "newsletter" => $customerNewsletter,
            ],
            "paymentDetails" => [
                "creditCardInfo" => [
                    "cardType"       => $cardType,
                    "number"         => $cardNumber,
                    "expiryDate"     => $cardExpiryDate,
                    "cvc"            => $cardCvc,
                    "holderName"     => $cardHolderName,
                    "countryOfIssue" => $cardCountryOfIssue,
                    "issuingBank"    => $cardIssuingBank,
                ],
            ],
        ];

        $headers = [
            'Content-Type'    => 'application/json; charset=UTF-8',
            'Accept-Encoding' => 'gzip, deflate, br',
            'Authorization'   => "$this->siteId:$this->apiKey",
        ];
        $options = [
            'base_uri'   => $this->apiSecureUrl,
            'headers'    => $headers,
            'timeout'    => self::BOOKING_TIMEOUT,
            'exceptions' => false, //For Guzzle 5.3
            //'http_errors' => false, //For Guzzle 6
        ];

        $client = app('GuzzleClient', [
            'service'  => GuzzleClientServiceProvider::SERVICE['INTEGRATION'],
            'provider' => Integration::PARTNER['AGODA'],
        ])($options);
        $response = $client->request(
            'POST',
            self::BOOK_API_ENDPOINT,
            [
                'body' => json_encode($bookingForm),
            ]
        );

        return ConvertHelper::toJsonResponse($response);
    }

    /**
     * @param string $from
     * @param string $to
     *
     * @return array
     */
    public function bookingListByDateTimeAPI(string $from, string $to): array
    {
        $headers = [
            'Content-Type'    => 'application/json; charset=UTF-8',
            'Accept-Encoding' => 'gzip, deflate, br',
            'Authorization'   => "$this->siteId:$this->apiKey",
        ];
        $options = [
            'base_uri' => $this->apiSecureUrl,
            'headers'  => $headers,
            'timeout'  => $this->timeout,
        ];

        $bookingListForm = [
            "dateTimeRange" => [
                "from" => $from,
                "to"   => $to,
            ],
        ];

        $client = app('GuzzleClient', [
            'service'  => GuzzleClientServiceProvider::SERVICE['INTEGRATION'],
            'provider' => Integration::PARTNER['AGODA'],
        ])($options);
        $response = $client->request(
            'POST',
            self::BOOKING_LIST_API_ENDPOINT,
            [
                'body' => json_encode($bookingListForm),
            ]
        );

        return ConvertHelper::toJsonResponse($response);
    }

    /**
     * @param array $tagList
     *
     * @return array
     */
    public function bookingListByTagAPI(array $tagList): array
    {
        $headers = [
            'Content-Type'    => 'application/json; charset=UTF-8',
            'Accept-Encoding' => 'gzip, deflate, br',
            'Authorization'   => "$this->siteId:$this->apiKey",
        ];
        $options = [
            'base_uri' => $this->apiSecureUrl,
            'headers'  => $headers,
            'timeout'  => $this->timeout,
        ];

        $bookingListForm = [
            "tags" => $tagList,
        ];

        $client = app('GuzzleClient', [
            'service'  => GuzzleClientServiceProvider::SERVICE['INTEGRATION'],
            'provider' => Integration::PARTNER['AGODA'],
        ])($options);
        $response = $client->request(
            'POST',
            self::BOOKING_LIST_API_ENDPOINT,
            [
                'body' => json_encode($bookingListForm),
            ]
        );

        return ConvertHelper::toJsonResponse($response);
    }

    /**
     * @param array $bookingIdList
     *
     * @return array
     */
    public function bookingDetailAPI(array $bookingIdList): array
    {
        $headers = [
            'Content-Type'    => 'application/json; charset=UTF-8',
            'Accept-Encoding' => 'gzip, deflate, br',
            'Authorization'   => "$this->siteId:$this->apiKey",
        ];
        $options = [
            'base_uri'   => $this->apiSecureUrl,
            'headers'    => $headers,
            'timeout'    => $this->timeout,
            'exceptions' => false, //For Guzzle 5.3
        ];

        $bookingDetailForm = [
            'bookingIds' => $bookingIdList
        ];

        $client = app('GuzzleClient', [
            'service'  => GuzzleClientServiceProvider::SERVICE['INTEGRATION'],
            'provider' => Integration::PARTNER['AGODA'],
        ])($options);
        $response = $client->request(
            'POST',
            self::BOOKING_DETAIL_API_ENDPOINT,
            [
                'body' => json_encode($bookingDetailForm),
            ]
        );

        return ConvertHelper::toJsonResponse($response);
    }

    /**
     * @param int $bookingId
     * @param string $specialRequest
     *
     * @return array
     * @throws Exception
     */
    public function specialRequestAPI(int $bookingId, string $specialRequest): array
    {
        $headers = [
            'Content-Type'    => 'application/json; charset=UTF-8',
            'Accept-Encoding' => 'gzip, deflate, br',
            'Authorization'   => "$this->siteId:$this->apiKey",
        ];
        $options = [
            'base_uri' => $this->apiSecureUrl,
            'headers'  => $headers,
            'timeout'  => $this->timeout,
        ];

        $specialRequestForm = [
            "bookingId"      => $bookingId,
            "specialRequest" => $specialRequest,
        ];

        $client = app('GuzzleClient', [
            'service'  => GuzzleClientServiceProvider::SERVICE['INTEGRATION'],
            'provider' => Integration::PARTNER['AGODA'],
        ])($options);
        $response = $client->request(
            'POST',
            self::SPECIAL_REQUEST_API_ENDPOINT,
            [
                'body' => json_encode($specialRequestForm),
            ]
        );

        return ConvertHelper::toJsonResponse($response);
    }

    /**
     * @param int $bookingId
     *
     * @return array
     */
    public function requestCancelAPI(int $bookingId): array
    {
        $headers = [
            'Content-Type'    => 'application/json; charset=UTF-8',
            'Accept-Encoding' => 'gzip, deflate, br',
            'Authorization'   => "$this->siteId:$this->apiKey",
        ];
        $options = [
            'base_uri'   => $this->apiSecureUrl,
            'headers'    => $headers,
            'timeout'    => $this->timeout,
            'exceptions' => false, //For Guzzle 5.3
        ];

        $cancellationRequestForm = [
            "bookingId" => $bookingId,
        ];

        $client = app('GuzzleClient', [
            'service'  => GuzzleClientServiceProvider::SERVICE['INTEGRATION'],
            'provider' => Integration::PARTNER['AGODA'],
        ])($options);
        $response = $client->request(
            'POST',
            self::CANCEL_API_ENDPOINT,
            [
                'body' => json_encode($cancellationRequestForm),
            ]
        );

        return ConvertHelper::toJsonResponse($response);
    }

    /**
     * @param ConfirmCancelDetails $confirmCancelDetails
     *
     * @return array
     */
    public function confirmRequestCancelAPI(ConfirmCancelDetails $confirmCancelDetails): array
    {
        $bookingId = $confirmCancelDetails->getBookingId();
        $reference = $confirmCancelDetails->getReference();
        $cancelReason = $confirmCancelDetails->getCancelReason();
        $currency = $confirmCancelDetails->getCurrency();
        $inclusive = $confirmCancelDetails->getInclusive();
        $headers = [
            'Content-Type'    => 'application/json; charset=UTF-8',
            'Accept-Encoding' => 'gzip, deflate, br',
            'Authorization'   => "$this->siteId:$this->apiKey",
        ];
        $options = [
            'base_uri'   => $this->apiSecureUrl,
            'headers'    => $headers,
            'timeout'    => $this->timeout,
            'exceptions' => false, //For Guzzle 5.3
        ];

        $confirmCancellationRequestForm = [
            "bookingId"    => $bookingId,
            "reference"    => $reference,
            "cancelReason" => $cancelReason,
            "refundRate"   => [
                "currency"  => $currency,
                "inclusive" => $inclusive,
            ],
        ];

        $client = app('GuzzleClient', [
            'service'  => GuzzleClientServiceProvider::SERVICE['INTEGRATION'],
            'provider' => Integration::PARTNER['AGODA'],
        ])($options);
        $response = $client->request(
            'POST',
            self::CONFIRM_CANCEL_API_ENDPOINT,
            [
                'body' => json_encode($confirmCancellationRequestForm),
            ]
        );

        return ConvertHelper::toJsonResponse($response);
    }
    #endregion Agoda API

    #region Agoda data feed
    /**
     * @param string $hotelId
     * @param string $languageId
     *
     * @return array
     * @throws Exception
     */
    public function facilitiesPerHotelFeed($hotelId, $languageId = AgodaConst::LANGUAGE_ID['VIETNAMESE'])
    {
        $headers = [
            'Content-Type'    => 'application/json; charset=UTF-8',
            'Accept-Encoding' => 'gzip, deflate, br',
        ];
        $options = [
            'base_uri' => $this->feedUrl,
            'headers'  => $headers,
            'timeout'  => $this->timeout,
        ];

        $siteId = AgodaConst::DATA_FEED['SITE_ID'];
        $token = AgodaConst::DATA_FEED['TOKEN'];
        if (app()->environment('production')) {
            $siteId = $this->siteId;
        }

        $queryParams = [
            'site_id'      => $siteId,
            'token'        => $token,
            'mhotel_id'    => $hotelId,
            'olanguage_id' => $languageId,
        ];

        $url = GenerateHelper::queryString(self::FACILITIES_PER_HOTEL_FEED_ENDPOINT, $queryParams);

        $client = app('GuzzleClient', [
            'service'  => GuzzleClientServiceProvider::SERVICE['INTEGRATION'],
            'provider' => Integration::PARTNER['AGODA'],
        ])($options);
        $response = $client->request('GET', $url);

        return ConvertHelper::toJsonResponse($response);
    }

    /**
     * @param string $hotelId
     * @param string $languageId
     *
     * @return array
     * @throws Exception
     */
    public function facilitiesPerRoomtypePerHotelFeed($hotelId, $languageId = AgodaConst::LANGUAGE_ID['VIETNAMESE'])
    {
        $headers = [
            'Content-Type'    => 'application/json; charset=UTF-8',
            'Accept-Encoding' => 'gzip, deflate, br',
        ];
        $options = [
            'base_uri' => $this->feedUrl,
            'headers'  => $headers,
            'timeout'  => $this->timeout,
        ];

        $siteId = AgodaConst::DATA_FEED['SITE_ID'];
        $token = AgodaConst::DATA_FEED['TOKEN'];
        if (app()->environment('production')) {
            $siteId = $this->siteId;
        }

        $queryParams = [
            'site_id'      => $siteId,
            'token'        => $token,
            'mhotel_id'    => $hotelId,
            'olanguage_id' => $languageId,
        ];

        $url = GenerateHelper::queryString(self::FACILITIES_PER_ROOM_TYPE_PER_HOTEL_FEED_ENDPOINT, $queryParams);

        $client = app('GuzzleClient', [
            'service'  => GuzzleClientServiceProvider::SERVICE['INTEGRATION'],
            'provider' => Integration::PARTNER['AGODA'],
        ])($options);
        $response = $client->request('GET', $url);

        return ConvertHelper::toJsonResponse($response);
    }

    /**
     * @param string $hotelId
     * @param string $languageId
     *
     * @return array
     * @throws Exception
     */
    public function picturesPerHotel($hotelId, $languageId = AgodaConst::LANGUAGE_ID['VIETNAMESE'])
    {
        $headers = [
            'Content-Type'    => 'application/json; charset=UTF-8',
            'Accept-Encoding' => 'gzip, deflate, br',
        ];
        $options = [
            'base_uri' => $this->feedUrl,
            'headers'  => $headers,
            'timeout'  => $this->timeout,
        ];

        $siteId = AgodaConst::DATA_FEED['SITE_ID'];
        $token = AgodaConst::DATA_FEED['TOKEN'];
        if (app()->environment('production')) {
            $siteId = $this->siteId;
        }

        $queryParams = [
            'site_id'      => $siteId,
            'token'        => $token,
            'mhotel_id'    => $hotelId,
            'olanguage_id' => $languageId,
        ];

        $url = GenerateHelper::queryString(self::PICTURES_PER_HOTEL_FEED_ENDPOINT, $queryParams);

        $client = app('GuzzleClient', [
            'service'  => GuzzleClientServiceProvider::SERVICE['INTEGRATION'],
            'provider' => Integration::PARTNER['AGODA'],
        ])($options);
        $response = $client->request('GET', $url);

        return ConvertHelper::toJsonResponse($response);
    }

    /**
     * @param string $cityId
     * @param string $areaId
     * @param string $hotelId
     * @param string $languageId
     * @param string $currency
     *
     * @return array
     * @throws Exception
     */
    public function hotelFeed($cityId, $areaId = AgodaConst::ALL, $hotelId = AgodaConst::ALL, $languageId = AgodaConst::LANGUAGE_ID['VIETNAMESE'], $currency = AgodaConst::CURRENCY_CODE['VIETNAMESE_DONG'])
    {
        $headers = [
            'Content-Type'    => 'application/json; charset=UTF-8',
            'Accept-Encoding' => 'gzip, deflate, br',
        ];
        $options = [
            'base_uri' => $this->feedUrl,
            'headers'  => $headers,
            'timeout'  => $this->timeout,
        ];

        $siteId = AgodaConst::DATA_FEED['SITE_ID'];
        $token = AgodaConst::DATA_FEED['TOKEN'];
        if (app()->environment('production')) {
            $siteId = $this->siteId;
        }

        $queryParams = [
            'site_id'      => $siteId,
            'token'        => $token,
            'mcity_id'     => $cityId,
            'olanguage_id' => $languageId,
            'ocurrency'    => $currency,
        ];
        if ($areaId != AgodaConst::ALL) {
            $queryParams['oarea_id'] = $areaId;
        }
        if ($hotelId != AgodaConst::ALL) {
            $queryParams['ohotel_id'] = $hotelId;
        }

        $url = GenerateHelper::queryString(self::HOTEL_FEED_ENDPOINT, $queryParams);

        $client = app('GuzzleClient', [
            'service'  => GuzzleClientServiceProvider::SERVICE['INTEGRATION'],
            'provider' => Integration::PARTNER['AGODA'],
        ])($options);
        $response = $client->request('GET', $url);

        return ConvertHelper::toJsonResponse($response);
    }

    /**
     * @param string $hotelId
     * @param string $languageId
     * @param string $currency
     *
     * @return array
     * @throws Exception
     */
    public function fullHotelInformationFeed($hotelId, $languageId = AgodaConst::LANGUAGE_ID['VIETNAMESE'], $currency = AgodaConst::CURRENCY_CODE['VIETNAMESE_DONG'])
    {
        $headers = [
            'Content-Type'    => 'application/json; charset=UTF-8',
            'Accept-Encoding' => 'gzip, deflate, br',
        ];
        $options = [
            'base_uri' => $this->feedUrl,
            'headers'  => $headers,
            'timeout'  => $this->timeout,
        ];

        $siteId = AgodaConst::DATA_FEED['SITE_ID'];
        $token = AgodaConst::DATA_FEED['TOKEN'];
        if (app()->environment('production')) {
            $siteId = $this->siteId;
        }

        $queryParams = [
            'site_id'      => $siteId,
            'token'        => $token,
            'mhotel_id'    => $hotelId,
            'olanguage_id' => $languageId,
            'ocurrency'    => $currency,
        ];

        $url = GenerateHelper::queryString(self::FULL_HOTEL_INFORMATION_FEED_ENDPOINT, $queryParams);

        $client = app('GuzzleClient', [
            'service'  => GuzzleClientServiceProvider::SERVICE['INTEGRATION'],
            'provider' => Integration::PARTNER['AGODA'],
        ])($options);
        $response = $client->request('GET', $url);

        return ConvertHelper::toJsonResponse($response);
    }

    /**
     * @param string $hotelId
     * @param string $languageId
     *
     * @return array
     * @throws Exception
     */
    public function otherInfoPerHotelFeed($hotelId, $languageId = AgodaConst::LANGUAGE_ID['VIETNAMESE'])
    {
        $headers = [
            'Content-Type'    => 'application/json; charset=UTF-8',
            'Accept-Encoding' => 'gzip, deflate, br',
        ];
        $options = [
            'base_uri' => $this->feedUrl,
            'headers'  => $headers,
            'timeout'  => $this->timeout,
        ];

        $siteId = AgodaConst::DATA_FEED['SITE_ID'];
        $token = AgodaConst::DATA_FEED['TOKEN'];
        if (app()->environment('production')) {
            $siteId = $this->siteId;
        }

        $queryParams = [
            'site_id'      => $siteId,
            'token'        => $token,
            'mhotel_id'    => $hotelId,
            'olanguage_id' => $languageId,
        ];

        $url = GenerateHelper::queryString(self::OTHER_INFO_PER_HOTEL_FEED_ENDPOINT, $queryParams);

        $client = app('GuzzleClient', [
            'service'  => GuzzleClientServiceProvider::SERVICE['INTEGRATION'],
            'provider' => Integration::PARTNER['AGODA'],
        ])($options);
        $response = $client->request('GET', $url);

        return ConvertHelper::toJsonResponse($response);
    }

    /**
     * @param string $cityId
     * @param string $areaId
     * @param string $hotelId
     * @param string $languageId
     *
     * @return array
     * @throws Exception
     */
    public function hotelDescriptionsFeed($cityId, $areaId = AgodaConst::ALL, $hotelId = AgodaConst::ALL, $languageId = AgodaConst::LANGUAGE_ID['VIETNAMESE'])
    {
        $headers = [
            'Content-Type'    => 'application/json; charset=UTF-8',
            'Accept-Encoding' => 'gzip, deflate, br',
        ];
        $options = [
            'base_uri' => $this->feedUrl,
            'headers'  => $headers,
            'timeout'  => $this->timeout,
        ];

        $siteId = AgodaConst::DATA_FEED['SITE_ID'];
        $token = AgodaConst::DATA_FEED['TOKEN'];
        if (app()->environment('production')) {
            $siteId = $this->siteId;
        }

        $queryParams = [
            'site_id'      => $siteId,
            'token'        => $token,
            'mcity_id'     => $cityId,
            'olanguage_id' => $languageId,
        ];
        if ($areaId != AgodaConst::ALL) {
            $queryParams['oarea_id'] = $areaId;
        }
        if ($hotelId != AgodaConst::ALL) {
            $queryParams['ohotel_id'] = $hotelId;
        }

        $url = GenerateHelper::queryString(self::HOTEL_DESCRIPTIONS_FEED_ENDPOINT, $queryParams);

        $client = app('GuzzleClient', [
            'service'  => GuzzleClientServiceProvider::SERVICE['INTEGRATION'],
            'provider' => Integration::PARTNER['AGODA'],
        ])($options);
        $response = $client->request('GET', $url);

        return ConvertHelper::toJsonResponse($response);
    }

    /**
     * @param string $hotelId
     * @param string $languageId
     *
     * @return array
     * @throws Exception
     */
    public function localInformationFeed($hotelId, $languageId = AgodaConst::LANGUAGE_ID['VIETNAMESE'])
    {
        $headers = [
            'Content-Type'    => 'application/json; charset=UTF-8',
            'Accept-Encoding' => 'gzip, deflate, br',
        ];
        $options = [
            'base_uri' => $this->feedUrl,
            'headers'  => $headers,
            'timeout'  => $this->timeout,
        ];

        $siteId = AgodaConst::DATA_FEED['SITE_ID'];
        $token = AgodaConst::DATA_FEED['TOKEN'];
        if (app()->environment('production')) {
            $siteId = $this->siteId;
        }

        $queryParams = [
            'site_id'      => $siteId,
            'token'        => $token,
            'mhotel_id'    => $hotelId,
            'olanguage_id' => $languageId,
        ];

        $url = GenerateHelper::queryString(self::LOCAL_INFORMATION_FEED_ENDPOINT, $queryParams);

        $client = app('GuzzleClient', [
            'service'  => GuzzleClientServiceProvider::SERVICE['INTEGRATION'],
            'provider' => Integration::PARTNER['AGODA'],
        ])($options);
        $response = $client->request('GET', $url);

        return ConvertHelper::toJsonResponse($response);
    }

    /**
     * @param string $hotelId
     * @param string $languageId
     *
     * @return array
     * @throws Exception
     */
    public function roomTypesPerHotel($hotelId, $languageId = AgodaConst::LANGUAGE_ID['VIETNAMESE'])
    {
        $headers = [
            'Content-Type'    => 'application/json; charset=UTF-8',
            'Accept-Encoding' => 'gzip, deflate, br',
        ];
        $options = [
            'base_uri' => $this->feedUrl,
            'headers'  => $headers,
            'timeout'  => $this->timeout,
        ];

        $siteId = AgodaConst::DATA_FEED['SITE_ID'];
        $token = AgodaConst::DATA_FEED['TOKEN'];
        if (app()->environment('production')) {
            $siteId = $this->siteId;
        }

        $queryParams = [
            'site_id'      => $siteId,
            'token'        => $token,
            'mhotel_id'    => $hotelId,
            'olanguage_id' => $languageId,
        ];

        $url = GenerateHelper::queryString(self::ROOMTYPES_PER_HOTEL_FEED_ENDPOINT, $queryParams);

        $client = app('GuzzleClient', [
            'service'  => GuzzleClientServiceProvider::SERVICE['INTEGRATION'],
            'provider' => Integration::PARTNER['AGODA'],
        ])($options);
        $response = $client->request('GET', $url);

        return ConvertHelper::toJsonResponse($response);
    }

    /**
     * @param string $cityId
     * @param string $languageId
     *
     * @return array
     * @throws Exception
     */
    public function areaFeed($cityId = AgodaConst::ALL, $languageId = AgodaConst::LANGUAGE_ID['VIETNAMESE'])
    {
        $headers = [
            'Content-Type'    => 'application/json; charset=UTF-8',
            'Accept-Encoding' => 'gzip, deflate, br',
        ];
        $options = [
            'base_uri' => $this->feedUrl,
            'headers'  => $headers,
            'timeout'  => $this->timeout,
        ];

        $siteId = AgodaConst::DATA_FEED['SITE_ID'];
        $token = AgodaConst::DATA_FEED['TOKEN'];
        if (app()->environment('production')) {
            $siteId = $this->siteId;
        }

        $queryParams = [
            'site_id'      => $siteId,
            'token'        => $token,
            'olanguage_id' => $languageId,
        ];
        if ($cityId != AgodaConst::ALL) {
            $queryParams['ocity_id'] = $cityId;
        }

        $url = GenerateHelper::queryString(self::AREA_FEED_ENDPOINT, $queryParams);

        $client = app('GuzzleClient', [
            'service'  => GuzzleClientServiceProvider::SERVICE['INTEGRATION'],
            'provider' => Integration::PARTNER['AGODA'],
        ])($options);
        $response = $client->request('GET', $url);

        return ConvertHelper::toJsonResponse($response);
    }

    /**
     * @param string $countryId
     * @param string $languageId
     *
     * @return array
     * @throws Exception
     */
    public function cityFeed($countryId = AgodaConst::COUNTRY_ID['VIETNAM'], $languageId = AgodaConst::LANGUAGE_ID['VIETNAMESE'])
    {
        $headers = [
            'Content-Type'    => 'application/json; charset=UTF-8',
            'Accept-Encoding' => 'gzip, deflate, br',
        ];
        $options = [
            'base_uri' => $this->feedUrl,
            'headers'  => $headers,
            'timeout'  => $this->timeout,
        ];

        $siteId = AgodaConst::DATA_FEED['SITE_ID'];
        $token = AgodaConst::DATA_FEED['TOKEN'];
        if (app()->environment('production')) {
            $siteId = $this->siteId;
        }

        $queryParams = [
            'site_id'      => $siteId,
            'token'        => $token,
            'ocountry_id'  => $countryId,
            'olanguage_id' => $languageId,
        ];

        $url = GenerateHelper::queryString(self::CITY_FEED_ENDPOINT, $queryParams);

        $client = app('GuzzleClient', [
            'service'  => GuzzleClientServiceProvider::SERVICE['INTEGRATION'],
            'provider' => Integration::PARTNER['AGODA'],
        ])($options);
        $response = $client->request('GET', $url);

        return ConvertHelper::toJsonResponse($response);
    }

    /**
     * @param string $regionId
     * @param string $languageId
     *
     * @return SimpleXMLElement
     * @throws Exception
     */
    public function countryFeed($regionId = AgodaConst::REGION_ID['ASIA'], $languageId = AgodaConst::LANGUAGE_ID['VIETNAMESE'])
    {
        $headers = [
            'Content-Type'    => 'application/xml; charset=UTF-8',
            'Accept-Encoding' => 'gzip, deflate, br',
        ];
        $options = [
            'base_uri' => $this->feedUrl,
            'headers'  => $headers,
            'timeout'  => $this->timeout,
        ];

        $siteId = AgodaConst::DATA_FEED['SITE_ID'];
        $token = AgodaConst::DATA_FEED['TOKEN'];
        if (app()->environment('production')) {
            $siteId = $this->siteId;
        }

        $queryParams = [
            'site_id'      => $siteId,
            'token'        => $token,
            'oregion_id'   => $regionId,
            'olanguage_id' => $languageId,
        ];

        $url = GenerateHelper::queryString(self::COUNTRY_FEED_ENDPOINT, $queryParams);

        $client = app('GuzzleClient', [
            'service'  => GuzzleClientServiceProvider::SERVICE['INTEGRATION'],
            'provider' => Integration::PARTNER['AGODA'],
        ])($options);
        $response = $client->request('GET', $url);

        return ConvertHelper::toXmlResponse($response);
    }

    /**
     * @param string $languageId
     *
     * @return SimpleXMLElement
     * @throws Exception
     */
    public function continentFeed($languageId = AgodaConst::LANGUAGE_ID['VIETNAMESE'])
    {
        $headers = [
            'Content-Type'    => 'application/xml; charset=UTF-8',
            'Accept-Encoding' => 'gzip, deflate, br',
        ];
        $options = [
            'base_uri' => $this->feedUrl,
            'headers'  => $headers,
            'timeout'  => $this->timeout,
        ];

        $siteId = AgodaConst::DATA_FEED['SITE_ID'];
        $token = AgodaConst::DATA_FEED['TOKEN'];
        if (app()->environment('production')) {
            $siteId = $this->siteId;
        }

        $queryParams = [
            'site_id'      => $siteId,
            'token'        => $token,
            'olanguage_id' => $languageId,
        ];

        $url = GenerateHelper::queryString(self::CONTINENT_FEED_ENDPOINT, $queryParams);

        $client = app('GuzzleClient', [
            'service'  => GuzzleClientServiceProvider::SERVICE['INTEGRATION'],
            'provider' => Integration::PARTNER['AGODA'],
        ])($options);
        $response = $client->request('GET', $url);

        return ConvertHelper::toXmlResponse($response);
    }

    /**
     * @param string $cityId
     * @param string $areaId
     * @param string $hotelId
     *
     * @return SimpleXMLElement
     * @throws Exception
     */
    public function hotelAddressesFeed($cityId, $areaId = AgodaConst::ALL, $hotelId = AgodaConst::ALL)
    {
        $headers = [
            'Content-Type'    => 'application/xml; charset=UTF-8',
            'Accept-Encoding' => 'gzip, deflate, br',
        ];
        $options = [
            'base_uri' => $this->feedUrl,
            'headers'  => $headers,
            'timeout'  => $this->timeout,
        ];

        $siteId = AgodaConst::DATA_FEED['SITE_ID'];
        $token = AgodaConst::DATA_FEED['TOKEN'];
        if (app()->environment('production')) {
            $siteId = $this->siteId;
        }

        $queryParams = [
            'site_id'  => $siteId,
            'token'    => $token,
            'mcity_id' => $cityId,
        ];

        if ($areaId != AgodaConst::ALL) {
            $queryParams['oarea_id'] = $areaId;
        }

        if ($hotelId != AgodaConst::ALL) {
            $queryParams['ohotel_id'] = $hotelId;
        }

        $url = GenerateHelper::queryString(self::HOTEL_ADDRESSES_FEED_ENDPOINT, $queryParams);

        $client = app('GuzzleClient', [
            'service'  => GuzzleClientServiceProvider::SERVICE['INTEGRATION'],
            'provider' => Integration::PARTNER['AGODA'],
        ])($options);
        $response = $client->request('GET', $url);

        return ConvertHelper::toXmlResponse($response);
    }

    /**
     * @param string $date
     * @param int $typeId
     *
     * @return array
     * @throws Exception
     */
    public function hotelHaveInformationUpdateFeed(string $date, int $typeId): array
    {
        $headers = [
            'Content-Type'    => 'application/json; charset=UTF-8',
            'Accept-Encoding' => 'gzip, deflate, br',
        ];
        $options = [
            'base_uri' => $this->feedUrl,
            'headers'  => $headers,
            'timeout'  => $this->timeout,
        ];

        $queryParams = [
            'apiKey'  => $this->apiKey,
            'mdate'   => $date,
            'mtypeid' => $typeId,
        ];

        $url = GenerateHelper::queryString(self::HOTEL_HAVE_INFORMATION_UPDATE_FEED_ENDPOINT, $queryParams);

        $client = app('GuzzleClient', [
            'service'  => GuzzleClientServiceProvider::SERVICE['INTEGRATION'],
            'provider' => Integration::PARTNER['AGODA'],
        ])($options);
        $response = $client->request('GET', $url);

        return ConvertHelper::toJsonResponse($response);
    }
    #endregion Agoda data feed
}