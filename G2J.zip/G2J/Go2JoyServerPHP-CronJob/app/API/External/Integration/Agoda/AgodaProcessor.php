<?php

namespace App\API\External\Integration\Agoda;

use App\API\External\Integration\IntegrationProcessorInterface;
use App\Constants\Partners\Agoda as AgodaConst;
use App\DTOs\DTO;
use App\DTOs\Integration\Agoda\CancelBookingInputDTO;
use App\DTOs\Integration\Agoda\CancelBookingOutputDTO;
use App\DTOs\Integration\Agoda\CreateBookingInputDTO;
use App\DTOs\Integration\Agoda\CreateBookingOutputDTO;
use App\DTOs\Integration\Agoda\FetchHotelInputDTO;
use App\DTOs\Integration\Agoda\FetchHotelOutputDTO;
use App\DTOs\Integration\Agoda\GetAreaListInputDTO;
use App\DTOs\Integration\Agoda\GetAreaListOutputDTO;
use App\DTOs\Integration\Agoda\GetBookingDetailInputDTO;
use App\DTOs\Integration\Agoda\GetBookingDetailOutputDTO;
use App\DTOs\Integration\Agoda\GetCityListInputDTO;
use App\DTOs\Integration\Agoda\GetCityListOutputDTO;
use App\DTOs\Integration\Agoda\GetHotelDetailInputDTO;
use App\DTOs\Integration\Agoda\GetHotelDetailOutputDTO;
use App\DTOs\Integration\Agoda\GetHotelHaveInfoUpdateInputDTO;
use App\DTOs\Integration\Agoda\GetHotelHaveInfoUpdateOutputDTO;
use App\DTOs\Integration\Agoda\PrecheckInputDTO;
use App\DTOs\Integration\Agoda\PrecheckOutputDTO;
use App\DTOs\Integration\Agoda\PullHotelFacilityInputDTO;
use App\DTOs\Integration\Agoda\PullHotelFacilityOutputDTO;
use App\DTOs\Integration\Agoda\PullHotelImageInputDTO;
use App\DTOs\Integration\Agoda\PullHotelImageOutputDTO;
use App\DTOs\Integration\Agoda\PullHotelInputDTO;
use App\DTOs\Integration\Agoda\PullHotelOutputDTO;
use App\DTOs\Integration\Agoda\PullRoomTypeFacilityInputDTO;
use App\DTOs\Integration\Agoda\PullRoomTypeFacilityOutputDTO;
use App\DTOs\Integration\Agoda\PullRoomTypeInputDTO;
use App\DTOs\Integration\Agoda\PullRoomTypeOutputDTO;
use App\Helpers\ConvertHelper;
use App\Libraries\DataStructures\Agoda\ConfirmCancelDetails;
use App\Libraries\DataStructures\Agoda\Criteria;
use App\Libraries\DataStructures\Agoda\ErrorMessage;
use App\Libraries\DataStructures\Agoda\Features;
use Exception;

class AgodaProcessor implements IntegrationProcessorInterface
{
    /** @var array */
    protected $config;

    /** @var Agoda */
    protected $agodaAPI;

    /**
     * AgodaProcessor constructor.
     *
     * @param array $config
     */
    public function __construct(array $config)
    {
        $this->config = $config;

        $this->agodaAPI = new Agoda(
            $this->config['siteId'] ?? null,
            $this->config['apiKey'] ?? null,
            $this->config['apiUrl'] ?? null,
            $this->config['feedUrl'] ?? null,
            $this->config['apiServicesUrl'] ?? null,
            $this->config['apiSecureUrl'] ?? null
        );
    }

    /**
     * @param GetCityListInputDTO $dto
     *
     * @return GetCityListOutputDTO
     * @throws Exception
     */
    public function getCityList(DTO $dto): DTO
    {
        $response = $this->agodaAPI->cityFeed($dto->getCountryId(), $dto->getLanguageId());
        $cityList = $response['cityFeed']['cities']['city'] ?? [];
        return GetCityListOutputDTO::assemble($cityList);
    }

    /**
     * @param GetAreaListInputDTO $dto
     *
     * @return GetAreaListOutputDTO
     * @throws Exception
     */
    public function getAreaList(DTO $dto): DTO
    {
        $response = $this->agodaAPI->areaFeed($dto->getCityId(), $dto->getLanguageId());
        $areaList = $response['areaFeed']['areas']['area'] ?? [];
        return GetAreaListOutputDTO::assemble($areaList);
    }

    /**
     * @param FetchHotelInputDTO $dto
     *
     * @return FetchHotelOutputDTO
     * @throws Exception
     */
    public function fetchHotel(DTO $dto): DTO
    {
        $response = $this->agodaAPI->hotelFeed($dto->getCityId(), $dto->getAreaId(), $dto->getHotelId(), $dto->getLanguageId(), $dto->getCurrency());
        $hotelList = $response['hotelInformationFeed']['hotelInformations']['hotelInformation'] ?? [];
        return FetchHotelOutputDTO::assemble($hotelList);
    }

    /**
     * @param PullHotelInputDTO $dto
     *
     * @return PullHotelOutputDTO
     * @throws Exception
     */
    public function pullHotel(DTO $dto): DTO
    {
        // Prepare data
        $fullHotelInformationResponse = $this->agodaAPI->fullHotelInformationFeed($dto->getHotelId(), AgodaConst::LANGUAGE_ID['VIETNAMESE'], $dto->getCurrency());
        $address = $fullHotelInformationResponse['hotelFullFeed']['addresses']['address'] ?? [];
        $facility = $fullHotelInformationResponse['hotelFullFeed']['facilities']['facility'] ?? [];

        sleep(5);

        $otherInfoPerHotelResponse = $this->agodaAPI->otherInfoPerHotelFeed($dto->getHotelId(), $dto->getLanguageId());
        $otherInfo = $otherInfoPerHotelResponse['hotelInfoFeed']['hotelInfos']['hotelInfo'] ?? [];

        sleep(5);

        $viHotel = current($fullHotelInformationResponse['hotelFullFeed']['hotels']['hotel'] ?? []);
        $cityId = $viHotel['cityId'];
        $hotelResponse = $this->agodaAPI->hotelFeed($cityId, AgodaConst::ALL, $dto->getHotelId(), AgodaConst::LANGUAGE_ID['ENGLISH'], $dto->getCurrency());
        $enHotel = current($hotelResponse['hotelInformationFeed']['hotelInformations']['hotelInformation'] ?? []) ;
        $hotel = [
            'en' => $enHotel,
            'vi' => $viHotel,
        ];

        sleep(5);

        $localInformationResponse = $this->agodaAPI->localInformationFeed($dto->getHotelId(), AgodaConst::LANGUAGE_ID['ENGLISH']);
        $enLocalInformation = $localInformationResponse['localInformationFeed'] ?? [];

        sleep(5);

        $localInformationResponse = $this->agodaAPI->localInformationFeed($dto->getHotelId(), AgodaConst::LANGUAGE_ID['VIETNAMESE']);
        $viLocalInformation = $localInformationResponse['localInformationFeed'] ?? [];
        $localInformation = [
            'en' => $enLocalInformation,
            'vi' => $viLocalInformation,
        ];

        sleep(5);

        $hotelDescriptionsResponse = $this->agodaAPI->hotelDescriptionsFeed($cityId, AgodaConst::ALL, $dto->getHotelId(), AgodaConst::LANGUAGE_ID['ENGLISH']);
        $enDescription = current($hotelDescriptionsResponse['hotelDescriptionFeed']['hotelDescriptions']['hotelDescription'] ?? []);

        sleep(5);

        $hotelDescriptionsResponse = $this->agodaAPI->hotelDescriptionsFeed($cityId, AgodaConst::ALL, $dto->getHotelId(), AgodaConst::LANGUAGE_ID['VIETNAMESE']);
        $viDescription = current($hotelDescriptionsResponse['hotelDescriptionFeed']['hotelDescriptions']['hotelDescription'] ?? []);
        $description = [
            'en' => $enDescription,
            'vi' => $viDescription,
        ];

        $languagesSpoken = [];
        foreach ($facility as $item) {
            if ($item['propertyGroupDescription'] === 'Languages spoken') {
                $languagesSpoken[] = $item;
            }
        }

        $hotelInfo = [
            'hotel'            => $hotel,
            'address'          => $address,
            'description'      => $description,
            'languagesSpoken'  => $languagesSpoken,
            'localInformation' => $localInformation,
            'otherInfo'        => $otherInfo,
        ];

        return PullHotelOutputDTO::assemble($hotelInfo);
    }

    /**
     * @param PullHotelFacilityInputDTO $dto
     *
     * @return PullHotelFacilityOutputDTO
     * @throws Exception
     */
    public function pullHotelFacility(DTO $dto): DTO
    {
        $response = $this->agodaAPI->facilitiesPerHotelFeed($dto->getHotelId(), $dto->getLanguageId());
        $hotelFacilityList = $response['facilityFeed']['facilities']['facility'] ?? [];
        return PullHotelFacilityOutputDTO::assemble($hotelFacilityList);
    }

    /**
     * @param PullHotelImageInputDTO $dto
     *
     * @return PullHotelImageOutputDTO
     * @throws Exception
     */
    public function pullHotelImage(DTO $dto): DTO
    {
        $response = $this->agodaAPI->picturesPerHotel($dto->getHotelId(), $dto->getLanguageId());
        $hotelImageList = $response['pictureFeed']['pictures']['picture'] ?? [];
        return PullHotelImageOutputDTO::assemble($hotelImageList);
    }

    /**
     * @param PullRoomTypeFacilityInputDTO $dto
     *
     * @return PullRoomTypeFacilityOutputDTO
     * @throws Exception
     */
    public function pullRoomTypeFacility(DTO $dto): DTO
    {
        $response = $this->agodaAPI->facilitiesPerRoomtypePerHotelFeed($dto->getHotelId(), $dto->getLanguageId());
        $roomTypFacilityList = $response['roomTypeFacilityFeed']['roomTypeFacilities']['roomTypeFacility'] ?? [];
        return PullRoomTypeFacilityOutputDTO::assemble($roomTypFacilityList);
    }

    /**
     * @param PullRoomTypeInputDTO $dto
     *
     * @return PullRoomTypeOutputDTO
     * @throws Exception
     */
    public function pullRoomType(DTO $dto): DTO
    {
        $viResponse = $this->agodaAPI->roomTypesPerHotel($dto->getHotelId(), AgodaConst::LANGUAGE_ID['VIETNAMESE']);
        $enResponse = $this->agodaAPI->roomTypesPerHotel($dto->getHotelId(), AgodaConst::LANGUAGE_ID['ENGLISH']);
        $viRoomType = $viResponse['roomtypeFeed']['roomtypes']['roomtypes'] ?? [];
        $enRoomType = $enResponse['roomtypeFeed']['roomtypes']['roomtypes'] ?? [];
        $roomTypeList = [
            'en' => $enRoomType,
            'vi' => $viRoomType,
        ];
        return PullRoomTypeOutputDTO::assemble($roomTypeList);
    }

    public function pullFacility(DTO $dto)
    {
        // TODO: Implement pullFacility() method.
    }

    public function pullBooking(DTO $dto)
    {
        // TODO: Implement pullBooking() method.
    }

    /**
     * @param PrecheckInputDTO $dto
     *
     * @return PrecheckOutputDTO
     * @throws Exception
     */
    public function precheck(DTO $dto): DTO
    {
        $precheckResponse = $this->agodaAPI->precheckAPI($dto->getPrecheckDetails());
        $precheckOutputDTO = new PrecheckOutputDTO();
        return $precheckOutputDTO->assemble($precheckResponse);
    }

    /**
     * @param CreateBookingInputDTO $dto
     *
     * @return CreateBookingOutputDTO
     * @throws Exception
     */
    public function createBooking(DTO $dto): DTO
    {
        $bookResponse = $this->agodaAPI->bookAPI($dto->getBookDetails());
        $createBookingOutputDTO = new CreateBookingOutputDTO();
        if (empty($bookResponse)) {
            return $createBookingOutputDTO;
        }
        return $createBookingOutputDTO->assemble($bookResponse);
    }

    /**
     * @param GetBookingDetailInputDTO $dto
     *
     * @return GetBookingDetailOutputDTO
     */
    public function getBookingDetail($dto): DTO
    {
        $bookingDetailResponse = $this->agodaAPI->bookingDetailAPI([$dto->getBookingId()]);
        $getBookingDetailOutputDTO = new GetBookingDetailOutputDTO();
        return $getBookingDetailOutputDTO->assemble($bookingDetailResponse);
    }

    /**
     * @param CancelBookingInputDTO $dto
     *
     * @return CancelBookingOutputDTO
     */
    public function cancelBooking($dto): DTO
    {
        $requestCancelResponse = $this->agodaAPI->requestCancelAPI($dto->getBookingId());
        $cancelBookingOutputDTO = new CancelBookingOutputDTO();

        $errorMessage = new ErrorMessage();
        if ($requestCancelResponse['errorMessage'] ?? null) {
            $cancelBookingOutputDTO->setRawData(json_encode([
                'requestCancelResponse' => $requestCancelResponse,
                'confirmCancelResponse' => null,
            ]));
            $errorMessage->setId($requestCancelResponse['errorMessage']['id']);
            $errorMessage->setSubId($requestCancelResponse['errorMessage']['subId'] ?? null);
            $errorMessage->setMessage($requestCancelResponse['errorMessage']['message']);
            $cancelBookingOutputDTO->setErrorMessage($errorMessage);
            return $cancelBookingOutputDTO;
        }

        $inclusive = 0;
        foreach ($requestCancelResponse['cancellationSummary']['refundRate'] as $refundRate) {
            if ($refundRate['currency'] == AgodaConst::CURRENCY_CODE['VIETNAMESE_DONG']) {
                $inclusive = $refundRate['inclusive'];
                break;
            }
        }

        $confirmCancelDetails = new ConfirmCancelDetails();
        $confirmCancelDetails->setBookingId(intval($requestCancelResponse['cancellationSummary']['bookingId']));
        $confirmCancelDetails->setReference(intval($requestCancelResponse['cancellationSummary']['reference']));
        $confirmCancelDetails->setCancelReason(AgodaConst::REASON['NONE']);
        $confirmCancelDetails->setCurrency(AgodaConst::CURRENCY_CODE['VIETNAMESE_DONG']);
        $confirmCancelDetails->setInclusive($inclusive);
        $confirmCancelResponse = $this->agodaAPI->confirmRequestCancelAPI($confirmCancelDetails);
        if ($confirmCancelResponse['errorMessage'] ?? null) {
            $cancelBookingOutputDTO->setRawData(json_encode([
                'requestCancelResponse' => $requestCancelResponse,
                'confirmCancelResponse' => $confirmCancelResponse,
            ]));
            $errorMessage->setId($confirmCancelResponse['errorMessage']['id']);
            $errorMessage->setSubId($confirmCancelResponse['errorMessage']['subId'] ?? null);
            $errorMessage->setMessage($confirmCancelResponse['errorMessage']['message']);
            $cancelBookingOutputDTO->setErrorMessage($errorMessage);
            return $cancelBookingOutputDTO;
        }

        return $cancelBookingOutputDTO->assemble(
            $inclusive,
            $requestCancelResponse,
            $confirmCancelResponse
        );
    }

    /**
     * @param GetHotelDetailInputDTO $getHotelDetailInputDTO
     *
     * @return GetHotelDetailOutputDTO
     * @throws Exception
     */
    public function getHotelDetail(GetHotelDetailInputDTO $getHotelDetailInputDTO): GetHotelDetailOutputDTO
    {
        $criteria = new Criteria();
        $criteria->setPropertyIds($getHotelDetailInputDTO->getHotelIdList());
        $criteria->setCheckIn($getHotelDetailInputDTO->getCheckIn());
        $criteria->setCheckOut($getHotelDetailInputDTO->getCheckOut());
        $criteria->setRooms($getHotelDetailInputDTO->getNumOfRoom());
        $criteria->setAdults($getHotelDetailInputDTO->getNumOfAdults());
        $criteria->setChildren($getHotelDetailInputDTO->getNumOfChildren());
        $criteria->setChildrenAges($getHotelDetailInputDTO->getChildrenAgesList());
        $criteria->setLanguage($getHotelDetailInputDTO->getLanguage());
        $criteria->setCurrency($getHotelDetailInputDTO->getCurrency());
        $criteria->setUserCountry($getHotelDetailInputDTO->getUserCountry());

        $features = new Features();
        // Single HID with 'ratesPerProperty' = 1: 1 (Chỉ 1 hotel ID với 1 phòng giá thấp nhất)
        // Single HID with 'ratesPerProperty' > 1: 100 (Chỉ 1 hotel ID với nhiều phòng)
        // 2-30 HIDs with 'ratesPerProperty' = 1: 1 (2-30 hotel ID với 1 phòng giá thấp nhất)
        // 2-30 HIDs with 'ratesPerProperty' > 1: 25 (2-30 hotel ID với nhiều phòng)
        // 31-100 HIDs with 'ratesPerProperty' = 1: 1 (31-100 hotel ID với 1 phòng giá thấp nhất)
        $features->setRatesPerProperty(25);
        $features->setExtra([
            AgodaConst::EXTRA['DAILY_RATE'],
            AgodaConst::EXTRA['BENEFIT_DETAIL'],
            AgodaConst::EXTRA['PROMOTION_DETAIL'],
            AgodaConst::EXTRA['RATE_DETAIL'],
            AgodaConst::EXTRA['CONTENT'],
            AgodaConst::EXTRA['CANCELLATION_DETAIL'],
            AgodaConst::EXTRA['SURCHARGE_DETAIL'],
        ]);

        $searchResponse = $this->agodaAPI->searchAPI($criteria, $features);
        $getHotelDetailOutputDTO = new GetHotelDetailOutputDTO();
        return $getHotelDetailOutputDTO->assemble($searchResponse);
    }

    /**
     * @param GetHotelHaveInfoUpdateInputDTO $getHotelHaveInfoUpdateInputDTO
     *
     * @return GetHotelHaveInfoUpdateOutputDTO
     * @throws Exception
     */
    public function getHotelHaveInfoUpdate(GetHotelHaveInfoUpdateInputDTO $getHotelHaveInfoUpdateInputDTO): GetHotelHaveInfoUpdateOutputDTO
    {
        $response = $this->agodaAPI->hotelHaveInformationUpdateFeed($getHotelHaveInfoUpdateInputDTO->getDate(), $getHotelHaveInfoUpdateInputDTO->getTypeId());
        $changedHotelFeed = $response['changedHotelFeed'];

        return GetHotelHaveInfoUpdateOutputDTO::assemble($changedHotelFeed);
    }
}