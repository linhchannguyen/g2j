<?php

namespace App\API\External\Notification;

use App\Helpers\ConvertHelper;
use App\Helpers\LoggingHelper;
use Exception;
use Google\Service\FirebaseCloudMessaging;
use Google_Client;
use Google_Exception;
use GuzzleHttp\Exception\ClientException;
use Illuminate\Support\Facades\Cache;
use Symfony\Component\HttpFoundation\Response;

class FireBaseNotificationAPI
{
    const FCM_ACCESS_TOKEN = 'fcm_access_token';
    const FCM_ACCESS_TOKEN_PARTNER = 'fcm_access_token_partner';
    const END_POINT = 'messages:send';
    const NOT_FOUND = 'NOT_FOUND';
    const UNREGISTERED = 'UNREGISTERED';

    public $urlSend;

    public $projectId;

    public $partnerProjectId;

    public $pathCredentialG2J;

    public $pathCredentialG2JPartner;

    public function __construct($urlSend, $projectId, $partnerProjectId, $pathCredentialG2J, $pathCredentialG2JPartner)
    {
        $this->urlSend = $urlSend;
        $this->projectId = $projectId;
        $this->partnerProjectId = $partnerProjectId;
        $this->pathCredentialG2J = $pathCredentialG2J;
        $this->pathCredentialG2JPartner = $pathCredentialG2JPartner;
    }

    public function sendTo($tokens, $notification, $payloadData, $partner)
    {
        $downstreamResponse = [
            'numberTokensSuccess' => 0,
            'numberTokensFailure' => 0,
            'tokensFailure'       => [],
            'reasonsFailure'      => [],
            'tokensSuccess'       => [],
        ];
        $accessToken = $this->getAccessToken($partner);
        $url = $partner ? $this->partnerProjectId : $this->projectId;
        $headers = [
            'Content-Type'  => 'application/json',
            'Cache-Control' => 'no-cache',
            'Authorization' => 'Bearer ' . $accessToken,
        ];
        $options = [
            'base_uri' => $this->urlSend . DIRECTORY_SEPARATOR,
            'headers'  => $headers,
            'timeout'  => 10,
        ];

        foreach ($tokens as $token) {
            $client = app('GuzzleClient', [])($options);

            $payload = $this->_buildPayload($token, $notification, $payloadData);
            try {
                $responseGuzzle = $client->request(
                    'POST',
                    $url . DIRECTORY_SEPARATOR . self::END_POINT,
                    [
                        'body' => $payload,
                    ]
                );
                if ($responseGuzzle->getStatusCode() == Response::HTTP_UNAUTHORIZED) {
                    //Retry get access Token because token is expired
                    $accessToken = $this->getAccessToken($partner);
                    $headers['Authorization'] = 'Bearer ' . $accessToken;
                } else {
                    $this->_downstreamResponse($downstreamResponse, $responseGuzzle, $token);
                }
            } catch (Exception $exception) {
                if ($exception instanceof ClientException) {
                    $responseException = json_decode($exception->getResponse()->getBody());
                    $downstreamResponse['numberTokensFailure']++;
                    if (!empty($responseException) && $responseException->error->status == self::NOT_FOUND) {
                        $downstreamResponse['tokensFailure'][] = $token;
                    } else {
                        // Lưu thông tin trả về nếu gửi thông báo bị lỗi khác lỗi token hết hạn
                        $downstreamResponse['reasonsFailure'][] = [
                            'token'    => $token,
                            'response' => $responseException,
                        ];
                    }
                } else {
                    LoggingHelper::logFunction('LOGGING_FIRE_BASE_EXCEPTION', json_encode($exception));
                }

            }
        }

        return ConvertHelper::arrayToJson($downstreamResponse);
    }

    private function getAccessToken($partner)
    {
        $path = $this->pathCredentialG2J;
        $key = self::FCM_ACCESS_TOKEN;
        if ($partner) {
            $path = $this->pathCredentialG2JPartner;
            $key = self::FCM_ACCESS_TOKEN_PARTNER;
        }

        $client = new Google_Client();
        try {
            $client->setAuthConfig($path);
            $client->addScope(FirebaseCloudMessaging::CLOUD_PLATFORM);

            $savedTokenJson = $this->readSavedToken($key);

            if ($savedTokenJson) {
                // the token exists, set it to the client and check if it's still valid
                $client->setAccessToken($savedTokenJson);
                $accessToken = $savedTokenJson;
                if ($client->isAccessTokenExpired()) {
                    // the token is expired, generate a new token and set it to the client
                    $accessToken = $this->generateToken($client, $key);
                    $client->setAccessToken($accessToken);
                }
            } else {
                // the token doesn't exist, generate a new token and set it to the client
                $accessToken = $this->generateToken($client, $key);
                $client->setAccessToken($accessToken);
            }

            return $accessToken["access_token"];

        } catch (Google_Exception $e) {
        }

        return false;
    }

    private function readSavedToken($key)
    {
        if (Cache::store('redis')->has($key)) {
            return json_decode(Cache::store('redis')->get($key), true);
        };

        return false;
    }

    private function generateToken($client, $key)
    {
        $client->fetchAccessTokenWithAssertion();
        $accessToken = $client->getAccessToken();

        $tokenJson = json_encode($accessToken);
        Cache::store('redis')->forever($key, $tokenJson);

        return $accessToken;
    }

    private function _buildPayload($token, $notification, $payloadData)
    {
        return json_encode([
            'message' => [
                'token'        => $token,
                'notification' => $notification,
                'data'         => $payloadData,
                'android'      => [
                    'ttl' => '1200s',
                ],
                'apns'         => [
                    'headers' => [
                        'apns-expiration' => '1200',
                    ],
                    'payload' => [
                        'aps' => [
                            'mutable-content' => 1,
                        ],
                    ],
                ],
            ],
        ]);
    }

    private function _downstreamResponse(&$downstreamResponse, $responseGuzzle, $token)
    {
        if ($responseGuzzle->getStatusCode() == Response::HTTP_OK) {
            $downstreamResponse['numberTokensSuccess']++;
            $downstreamResponse['tokensSuccess'][] = $token;

        } else {
            $downstreamResponse['numberTokensFailure']++;
            $downstreamResponse['tokensFailure'][] = $token;
        }
    }

    public function sendToTopic($topics, $notification, $payloadData, $partner)
    {
        $downstreamResponseTopic = [
            'topicsSuccess' => [],
            'topicsFailure' => [],
        ];

        $accessToken = $this->getAccessToken($partner);
        $headers = [
            'Content-Type'  => 'application/json',
            'Cache-Control' => 'no-cache',
            'Authorization' => 'Bearer ' . $accessToken,
        ];
        $url = $partner ? $this->partnerProjectId : $this->projectId;

        $options = [
            'base_uri' => $this->urlSend . DIRECTORY_SEPARATOR,
            'headers'  => $headers,
            'timeout'  => 10,
        ];

        foreach ($topics as $topic) {
            $payloadTopic = $this->_buildPayloadTopic($topic, $notification, $payloadData);

            $client = app('GuzzleClient', [])($options);
            try {
                $responseGuzzle = $client->request(
                    'POST',
                    $url . DIRECTORY_SEPARATOR . self::END_POINT,
                    [
                        'body' => $payloadTopic,
                    ]
                );
                if ($responseGuzzle->getStatusCode() == Response::HTTP_UNAUTHORIZED) {
                    //Retry get access Token because token is expired
                    $accessToken = $this->getAccessToken($partner);
                    $headers['Authorization'] = 'Bearer ' . $accessToken;
                } else {
                    $this->_downstreamResponseTopic($downstreamResponseTopic, $responseGuzzle, $topic);
                }
            } catch (Exception $exception) {
                LoggingHelper::logException($exception);
            }
        }

        return ConvertHelper::arrayToJson($downstreamResponseTopic);
    }

    private function _buildPayloadTopic($topic, $notification, $payloadData)
    {
        return json_encode([
            'message' => [
                'topic'        => $topic,
                'notification' => $notification,
                'data'         => $payloadData,
                'android'      => [
                    'ttl' => '1200s',
                ],
                'apns'         => [
                    'headers' => [
                        'apns-expiration' => '1200',
                    ],
                    'payload' => [
                        'aps' => [
                            'mutable-content' => 1,
                        ],
                    ],
                ],
            ],
        ]);

    }

    private function _downstreamResponseTopic(&$downstreamResponseTopic, $responseGuzzle, $topic)
    {
        if ($responseGuzzle->getStatusCode() == Response::HTTP_OK) {
            $downstreamResponseTopic['topicsSuccess'][] = $topic;
        } else {
            $downstreamResponseTopic['topicsFailure'][] = $topic;
        }
    }

    public function buildNotification($title, $body, $image)
    {
        return [
            'title' => $title,
            'body'  => $body,
            'image' => $image,
        ];
    }
}