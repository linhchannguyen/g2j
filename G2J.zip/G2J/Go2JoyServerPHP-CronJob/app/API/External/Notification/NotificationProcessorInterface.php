<?php

namespace App\API\External\Notification;

interface NotificationProcessorInterface
{
    public function sendNotificationToDevices(array $tokens, $data, $os);

    public function sendNotificationToTopics(array $topics, $data, $os);

    public function sendNotificationToPartnerDevices(array $tokens, $data, $os);

    public function sendNotificationToPartnerTopic(array $topics, $data, $os);
}