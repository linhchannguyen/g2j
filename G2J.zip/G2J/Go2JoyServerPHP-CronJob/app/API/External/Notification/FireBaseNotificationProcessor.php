<?php

namespace App\API\External\Notification;

use App\Constants\MobileDevice as MobileDeviceConst;

class FireBaseNotificationProcessor implements NotificationProcessorInterface
{
    public $fireBaseNotificationAPI;

    public function __construct()
    {
        $this->fireBaseNotificationAPI = new FireBaseNotificationAPI(
            config('fcm.url.send'),
            config('fcm.project_id'),
            config('fcm.partner_project_id'),
            config('fcm.google_credential_go2joy'),
            config('fcm.google_credential_go2joy_partner')
        );
    }

    public function sendNotificationToDevices(array $tokens, $data, $os)
    {
        $notification = null;
        if (MobileDeviceConst::OS['IOS'] == $os) {
            $notification = $this->fireBaseNotificationAPI->buildNotification($data['title'], $data['body'], $data['iconUrl']);
        }
        $payloadData = [
            'message' => json_encode($data),
        ];

        return $this->fireBaseNotificationAPI->sendTo($tokens, $notification, $payloadData, false);
    }

    public function sendNotificationToTopics(array $topics, $data, $os)
    {
        $notification = null;
        if (MobileDeviceConst::OS['IOS'] == $os) {
            $notification = $this->fireBaseNotificationAPI->buildNotification($data['title'], $data['body'], $data['iconUrl']);
        }
        $payloadData = [
            'message' => json_encode($data),
        ];

        return $this->fireBaseNotificationAPI->sendToTopic($topics, $notification, $payloadData, false);
    }

    public function sendNotificationToPartnerDevices(array $tokens, $data, $os)
    {
        $notification = null;
        if (MobileDeviceConst::OS['IOS'] == $os) {
            $notification = $this->fireBaseNotificationAPI->buildNotification($data['title'], $data['body']['content'], $data['iconUrl']);
        }
        $payloadData = array_map('strval', array_filter($data['body']));

        return $this->fireBaseNotificationAPI->sendTo($tokens, $notification, $payloadData, true);
    }

    public function sendNotificationToPartnerTopic(array $topics, $data, $os)
    {
        $notification = null;
        if (MobileDeviceConst::OS['IOS'] == $os) {
            $notification = $this->fireBaseNotificationAPI->buildNotification($data['title'], $data['body']['content'], $data['iconUrl']);
        }
        $payloadData = array_map('strval', array_filter($data['body']));

        return $this->fireBaseNotificationAPI->sendTo($topics, $notification, $payloadData, true);
    }
}