<?php

namespace App\API\External\SMS;

use App\Constants\AppUser as AppUserConst;
use App\Helpers\LoggingHelper;
use App\Libraries\SpeedSMS\SpeedSMSAPI;
use App\Libraries\SpeedSMS\TwoFactorAPI;
use App\Models\SMSLog;

class SpeedSMSProcessor implements SMSProcessorInterface
{
    const MAX_SEND_ONE_TIME = 100;

    protected $speedSMSAPI;
    protected $twoFactorAPI;

    public function __construct()
    {
        $speedSMSToken = config('speedsms.access_token');
        $this->speedSMSAPI = new SpeedSMSAPI($speedSMSToken);
        $this->twoFactorAPI = new TwoFactorAPI($speedSMSToken);
    }

    public function getAccountInfo()
    {
        return $this->speedSMSAPI->getUserInfo();
    }

    public function sendSMS($phone, $content, $smsType, $sender, $sendSMSSn = null)
    {

        $response = $this->speedSMSAPI->sendSMS($phone, $content,  $smsType, $sender);
        $response['type'] = AppUserConst::SMS_TYPE['SMS'];

        // Log request & response send SMS
        LoggingHelper::logSMS($phone, $content, $smsType, $sender, $response);

        // Log response send SMS if have passed param sendSMSSn
        if (!empty($sendSMSSn)) {
            $content = json_encode($response);
            $tranId = $response['data']['tranId'] ?? $response['data']['campaignId'] ?? null;

            $smsLog = new SMSLog();
            $smsLog->{SMSLog::COL_SEND_SMS_SN} = $sendSMSSn;
            $smsLog->{SMSLog::COL_CONTENT} = $content;
            $smsLog->{SMSLog::COL_TRAN_ID} = $tranId;
            $smsLog->save();
        }

        return $response;
    }

    public function sendVoice($phone, $content)
    {
        // $content contain OTP code only
        $response = $this->speedSMSAPI->sendVoice($phone, $content);
        $response['type'] = AppUserConst::SMS_TYPE['VOICE'];
        return $response;
    }

    public function createPIN($phone, $content, $appId)
    {
        $result = $this->twoFactorAPI->pinCreate($phone, $content, $appId);
        var_dump($result);
    }

    public function verifyPIN($phone, $pinCode, $appId)
    {
        $result = $this->twoFactorAPI->pinVerify($phone, $pinCode, $appId);
        var_dump($result);
    }
}
