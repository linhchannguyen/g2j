<?php

namespace App\API\External\SMS;

interface SMSProcessorInterface
{
    public function getAccountInfo();

    public function sendSMS($phone, $content, $smsType, $sender, $sendSMSSn = null);

    public function sendVoice($phone, $content);
}
