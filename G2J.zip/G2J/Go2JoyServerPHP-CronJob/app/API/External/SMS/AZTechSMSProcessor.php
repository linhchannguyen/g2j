<?php

namespace App\API\External\SMS;

use App\Helpers\LoggingHelper;
use App\Constants\AppUser as AppUserConst;
use App\Libraries\AZTechSMS\AZTechSMSAPI;
use App\Models\SMSLog;

class AZTechSMSProcessor implements SMSProcessorInterface
{

    protected $azTechSMSAPI;

    public function __construct()
    {
        $azTechSMSToken = config('aztechsms.access_token');
        $this->azTechSMSAPI = new AZTechSMSAPI($azTechSMSToken);
    }

    public function getAccountInfo()
    {

    }
    public function sendSMS($phone, $content, $smsType, $sender, $sendSMSSn = null)
    {

        $response = $this->azTechSMSAPI->sendSMS($phone, $content,  $smsType, $sender);
        $response['type'] = AppUserConst::SMS_TYPE['SMS'];
        // Log request & response send SMS
        LoggingHelper::logSMS($phone, $content, $smsType, $sender, $response);

        if (!empty($sendSMSSn)) {
            $content = json_encode($response);
            $smsLog = new SMSLog();
            $smsLog->{SMSLog::COL_SEND_SMS_SN} = $sendSMSSn;
            $smsLog->{SMSLog::COL_CONTENT} = $content;
            $smsLog->{SMSLog::COL_TRAN_ID} = null;
            $smsLog->save();
        }
        return $response;
    }

    public function sendVoice($phone, $content)
    {
    }

}