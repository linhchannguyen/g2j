<?php

namespace App\API\External\Payment\ZaloPay;

use App\API\External\Payment\PaymentProcessorInterface;
use App\Constants\Globals\Code;
use App\Constants\Globals\Payment;
use App\Forms\Others\Payment\ResultForm\PaymentResultForm;
use App\Helpers\ConvertHelper;
use App\Models\UserBooking;
use Exception;
use Illuminate\Support\Carbon;

class ZaloPayProcessor implements PaymentProcessorInterface
{
    protected $config;

    protected $zaloPayAPI;

    public function __construct($config)
    {
        $this->config = $config;
        $this->zaloPayAPI = new ZaloPay(
            $this->config['app_id'],
            $this->config['key1'],
            $this->config['key2'],
            $this->config['endpoint'],
            $this->config['check_order_payment_status_url'],
            $this->config['refund_url'],
            $this->config['check_refund_status_url'],
            $this->config['callback_url']
        );
    }

    public function createPaymentRequest($inputs)
    {
        return $this->zaloPayAPI->createOrder($inputs);
    }

    public function getPaymentResult($inputs)
    {
        $result = $this->zaloPayAPI->checkOrderPaymentStatus($inputs);
        $result['paymentProvider'] = $inputs['paymentProvider'];
        $result['platform'] = $inputs['platform'];
        $result['transactionId'] = $inputs['transactionId'];
        $result['pspTransactionId'] = $inputs['pspTransactionId'];
        $result['bookingNo'] = $inputs['userBooking']->{UserBooking::COL_BOOKING_NO};

        return $result;
    }

    public function getPaymentStatus($inputs): array
    {
        $response = $this->zaloPayAPI->checkOrderPaymentStatus($inputs);

        if ($response['return_code'] == Payment::ZALO_PAY_RETURN_CODE['SUCCESS']) {
            return [$inputs['pspTransactionId'], Payment::PAYMENT_STATUS['SUCCESSFUL']];
        }
        if ($response['return_code'] == Payment::ZALO_PAY_RETURN_CODE['PROCESSING']) {
            return [null, Payment::PAYMENT_STATUS['AWAITING']];
        }

        return [null, Payment::PAYMENT_STATUS['FAILED']];
    }

    public function listenCallback(array $query, array $body, array $headers): PaymentResultForm
    {
        // Get all input data from ZaloPay
        $inputs = array_merge($query, $body, $headers);
        try {
            $mac = hash_hmac("sha256", $inputs["data"], $this->config['key2']);
            $requestMAC = $inputs["mac"];
            $dataJson = json_decode($inputs["data"]);
            $embedData = json_decode($dataJson->embed_data);
            // kiểm tra callback hợp lệ (đến từ ZaloPay server)
            if (strcmp($mac, $requestMAC) != 0) {
                // callback không hợp lệ
                $data = [
                    'return_code'      => -1,
                    'return_message'   => "mac not equal",
                    'transactionId'    => $embedData->transactionId,
                    'pspTransactionId' => $dataJson->app_trans_id,
                ];

                $resultForm = new PaymentResultForm();
                $resultForm->setCode(Code::FAIL);
                $resultForm->setData($data);
                $resultForm->setError([
                    ConvertHelper::createMessageError($data['return_code'], $data['return_message']),
                ]);

                return $resultForm;

            } else {
                // thanh toán thành công
                $resultForm = new PaymentResultForm();
                $data = [
                    'return_code'      => 1,
                    'return_message'   => "success",
                    'transactionId'    => $embedData->transactionId,
                    'pspTransactionId' => $dataJson->app_trans_id,
                ];
                $resultForm->setData($data);

                return $resultForm->buildSuccessPaymentForm();
            }
        } catch (Exception $e) {
            $data = [
                'return_code'      => 0,
                'return_message'   => $e->getMessage(),
                'transactionId'    => $embedData->transactionId,
                'pspTransactionId' => $dataJson->app_trans_id,
            ];

            $resultForm = new PaymentResultForm();
            $resultForm->setCode(Code::FAIL);
            $resultForm->setData($data);
            $resultForm->setError([
                ConvertHelper::createMessageError(Code::INVALID_IPN, "This transaction could be hacked, please check your signature and returned signature!"),
            ]);

            return $resultForm;
        }
    }

    public function refund($inputs)
    {
        $result = null;
        $orderStatus = $this->zaloPayAPI->getOrderStatus($inputs);
        if ($orderStatus['return_code'] == Payment::ZALO_PAY_RETURN_CODE['SUCCESS']) {
            $result['paymentProvider'] = $inputs['paymentProvider'];
            $result['platform'] = $inputs['platform'];
            $result['pspTransactionId'] = $inputs['pspTransactionId'];
            $result['bookingNo'] = $inputs['userBooking']->{UserBooking::COL_BOOKING_NO};

            $mRefundId = $inputs['rfTransactionId'];
            $zpTransId = $orderStatus['zp_trans_id'];
            if (empty($mRefundId)) {
                // Generate new mRefundId based on current date time
                $ymd = Carbon::now()->format('ymd');
                $mRefundId = $ymd . '_' . $this->config['app_id'] . '_' . $inputs['transactionId'];
            }

            $refundStatus = $this->zaloPayAPI->getRefundStatus($inputs, $mRefundId);
            if ($refundStatus['return_code'] == Payment::ZALO_PAY_RETURN_CODE['FAIL']) {
                #region Retry refund order if failed or transaction not exists
                $this->zaloPayAPI->refundOrder($inputs, $zpTransId, $mRefundId);
                #endregion Retry refund order if failed or transaction not exists

                // Retry get refund status
                $refundStatus = $this->zaloPayAPI->getRefundStatus($inputs, $mRefundId);
            }

            // Override transaction id because ZaloPay required by us format
            $result['transactionId'] = $mRefundId;
            $result['return_code'] = $refundStatus['return_code'];
            $result['return_message'] = $refundStatus['return_message'];
            $result['sub_return_code'] = $refundStatus['sub_return_code'];
            $result['sub_return_message'] = $refundStatus['sub_return_message'];
        }

        return $result;
    }
}
