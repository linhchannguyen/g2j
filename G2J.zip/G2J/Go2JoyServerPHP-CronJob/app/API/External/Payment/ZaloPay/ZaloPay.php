<?php

namespace App\API\External\Payment\ZaloPay;

use App\Constants\Globals\Payment as PaymentConst;
use App\Models\UserBooking;
use App\Providers\GuzzleClientServiceProvider;

class ZaloPay
{
    protected $appId;

    protected $key1;

    protected $key2;

    protected $endpoint;

    protected $checkOrderPaymentStatusUrl;

    protected $refundUrl;

    protected $checkRefundStatusUrl;

    protected $callbackUrl;

    public function __construct($appId, $key1, $key2, $endpoint, $checkOrderPaymentStatusUrl, $refundUrl, $checkRefundStatusUrl, $callbackUrl)
    {
        $this->appId = $appId;
        $this->key1 = $key1;
        $this->key2 = $key2;
        $this->endpoint = $endpoint;
        $this->checkOrderPaymentStatusUrl = $checkOrderPaymentStatusUrl;
        $this->refundUrl = $refundUrl;
        $this->checkRefundStatusUrl = $checkRefundStatusUrl;
        $this->callbackUrl = $callbackUrl;
    }

    public function createOrder($params)
    {
        $embedData = '{"amount":"' . $params['userBooking']->{UserBooking::COL_AMOUNT_FROM_USER} . '",
        "description":"' . $params['userBooking']->{UserBooking::COL_BOOKING_NO} . '",
        "userName":"' . $params['userBooking']->{UserBooking::COL_MOBILE} . '",
        "transactionId":"' . $params['transactionId'] . '"}';
        if ($params['platform'] == PaymentConst::PLATFORM['WEB']) {
            $embedData = '{"amount":"' . $params['userBooking']->{UserBooking::COL_AMOUNT_FROM_USER} . '",
            "description":"' . $params['userBooking']->{UserBooking::COL_BOOKING_NO} . '",
            "userName":"' . $params['userBooking']->{UserBooking::COL_MOBILE} . '",
            "redirecturl":"' . config('zalopay.redirect_url') . '",
            "transactionId":"' . $params['transactionId'] . '"}';
        }

        $appTransId = date("ymd") . "_" . $params['transactionId'];
        $items = '[]'; // Merchant's data

        $order = [
            "app_id"       => $this->appId,
            "app_time"     => round(microtime(true) * 1000), // milliseconds
            "app_trans_id" => $appTransId,
            "app_user"     => $params['userBooking']->{UserBooking::COL_MOBILE},
            "item"         => $items,
            "embed_data"   => $embedData,
            "amount"       => $params['userBooking']->{UserBooking::COL_AMOUNT_FROM_USER},
            "callback_url" => config('zalopay.callback_url_app_v2'),
            "description"  => "Go2Joy - Thanh toán đơn hàng #{$params['userBooking']->{UserBooking::COL_BOOKING_NO}}",
            "bank_code"    => "zalopayapp",
        ];
        if ($params['platform'] == PaymentConst::PLATFORM['WEB']) {
            $order = [
                "app_id"       => $this->appId,
                "app_time"     => round(microtime(true) * 1000), // miliseconds
                "app_trans_id" => $appTransId,
                "app_user"     => $params['userBooking']->{UserBooking::COL_MOBILE},
                "item"         => $items,
                "embed_data"   => $embedData,
                "amount"       => $params['userBooking']->{UserBooking::COL_AMOUNT_FROM_USER},
                "callback_url" => config('zalopay.callback_url_web_v2'),
                "description"  => "Go2Joy - Thanh toán đơn hàng #{$params['userBooking']->{UserBooking::COL_BOOKING_NO}}",
                "bank_code"    => "zalopayapp",
            ];
        }

        // appid|app_trans_id|appuser|amount|apptime|embeddata|item
        $data = $order["app_id"] . "|" . $order["app_trans_id"] . "|" . $order["app_user"] . "|" . $order["amount"] . "|" . $order["app_time"] . "|" . $order["embed_data"] . "|" . $order["item"];
        $order["mac"] = hash_hmac("sha256", $data, $this->key1);

        $headers = ['Content-Type' => 'application/x-www-form-urlencoded'];
        $options = [
            'headers' => $headers,
        ];

        $client = app('GuzzleClient', [
            'service'  => GuzzleClientServiceProvider::SERVICE['PAYMENT'],
            'provider' => $params['paymentProvider'],
        ])($options);

        $response = $client->request(
            'POST',
            $this->endpoint,
            [
                'form_params' => $order,
            ]
        );

        return (string)$response->getBody() ? json_decode((string)$response->getBody(), true) : [];
    }

    public function checkOrderPaymentStatus($params)
    {
        $appTransId = $params['pspTransactionId'];  // Input your app_trans_id
        $data = $this->appId . "|" . $appTransId . "|" . $this->key1; // app_id|app_trans_id|key1
        $query = [
            "app_id"       => $this->appId,
            "app_trans_id" => $appTransId,
            "mac"          => hash_hmac("sha256", $data, $this->key1),
        ];

        $headers = ['Content-Type' => 'application/x-www-form-urlencoded'];
        $options = [
            'headers' => $headers,
        ];

        $client = app('GuzzleClient', [
            'service'  => GuzzleClientServiceProvider::SERVICE['PAYMENT'],
            'provider' => $params['paymentProvider'],
        ])($options);

        $response = $client->request(
            'POST',
            $this->checkOrderPaymentStatusUrl,
            [
                'form_params' => $query,
            ]
        );
        return (string)$response->getBody() ? json_decode((string)$response->getBody(), true) : [];
    }

    public function getOrderStatus($params)
    {
        $appTransId = $params['pspTransactionId'];  // Input your app_trans_id
        $data = $this->appId.'|'.$appTransId.'|'.$this->key1; // app_id|app_trans_id|key1
        $formParams = [
            'app_id'       => $this->appId,
            'app_trans_id' => $appTransId,
            'mac'          => hash_hmac("sha256", $data, $this->key1),
        ];

        $headers = ['Content-Type' => 'application/x-www-form-urlencoded'];
        $options = [
            'headers' => $headers,
        ];

        $client = app('GuzzleClient', [
            'service'  => GuzzleClientServiceProvider::SERVICE['PAYMENT'],
            'provider' => $params['paymentProvider'],
        ])($options);

        $response = $client->request(
            'POST',
            $this->checkOrderPaymentStatusUrl,
            [
                'form_params' => $formParams,
            ]
        );

        return (string)$response->getBody() ? json_decode((string)$response->getBody(), true) : [];
    }

    public function refundOrder($params, $zpTransId, $mRefundId)
    {
        $formParams = [
            "app_id"      => $this->appId,
            "m_refund_id" => $mRefundId,
            "timestamp"   => round(microtime(true) * 1000), // milliseconds
            "zp_trans_id" => $zpTransId,
            "amount"      => $params['refundAmount'],
            "description" => "Go2Joy - Hoàn tiền đơn hàng #{$params['userBooking']->{UserBooking::COL_BOOKING_NO}}",
        ];

        // app_id|zp_trans_id|amount|description|timestamp
        $data = $formParams["app_id"] . "|" . $zpTransId . "|" . $formParams["amount"] . "|" . $formParams["description"] . "|" . $formParams["timestamp"];
        $formParams["mac"] = hash_hmac("sha256", $data, $this->key1);

        $headers = ['Content-Type' => 'application/x-www-form-urlencoded'];
        $options = [
            'headers' => $headers,
        ];

        $client = app('GuzzleClient', [
            'service'  => GuzzleClientServiceProvider::SERVICE['PAYMENT'],
            'provider' => $params['paymentProvider'],
        ])($options);

        $response = $client->request(
            'POST',
            $this->refundUrl,
            [
                'form_params' => $formParams,
            ]
        );

        return (string)$response->getBody() ? json_decode((string)$response->getBody(), true) : [];
    }

    public function getRefundStatus($params, $mRefundId)
    {
        $timestamp = round(microtime(true) * 1000); // milliseconds
        $data = $this->appId."|".$mRefundId."|".$timestamp; // app_id|m_refund_id|timestamp
        $formParams = [
            "app_id"      => $this->appId,
            "timestamp"   => $timestamp,
            "m_refund_id" => $mRefundId,
            "mac"         => hash_hmac("sha256", $data, $this->key1),
        ];

        $headers = ['Content-Type' => 'application/x-www-form-urlencoded'];
        $options = [
            'headers' => $headers,
        ];

        $client = app('GuzzleClient', [
            'service'  => GuzzleClientServiceProvider::SERVICE['PAYMENT'],
            'provider' => $params['paymentProvider'],
        ])($options);

        $response = $client->request(
            'POST',
            $this->checkRefundStatusUrl,
            [
                'form_params' => $formParams,
            ]
        );

        return (string)$response->getBody() ? json_decode((string)$response->getBody(), true) : [];
    }
}
