<?php

namespace App\API\External\Payment\EPay;

use App\Constants\Globals\Payment;
use App\Constants\VnptPayment;
use App\Helpers\ConvertHelper;
use App\Helpers\DateTimeHelper;
use App\Providers\GuzzleClientServiceProvider;
use Throwable;

class EPay
{
    protected $merId;
    protected $domain;
    protected $headCss;
    protected $headJs;
    protected $encodeKey;
    protected $checkTransUrl;
    protected $cancelTransUrl;
    protected $cancelPassword;
    protected $redirectUrl;
    protected $ipnUrl;

    /**
     * @var float
     * Use 0 to set indefinitely (the default behavior)
     */
    protected $timeout = 0;

    /**
     * EPay constructor.
     */
    public function __construct($merId,
                                $domain,
                                $headCss,
                                $headJs,
                                $encodeKey,
                                $checkTransUrl,
                                $cancelTransUrl,
                                $cancelPassword,
                                $redirectUrl,
                                $ipnUrl)
    {
        $this->merId = $merId;
        $this->domain = $domain;
        $this->headCss = $headCss;
        $this->headJs = $headJs;
        $this->encodeKey = $encodeKey;
        $this->checkTransUrl = $checkTransUrl;
        $this->cancelTransUrl = $cancelTransUrl;
        $this->cancelPassword = $cancelPassword;
        $this->redirectUrl = $redirectUrl;
        $this->ipnUrl = $ipnUrl;
    }

    /**
     * @param array $params
     *
     * @return array|mixed
     */
    public function createOrder($params)
    {
        return $this->_buildCreateOrderForm($params);
    }

    /**
     * @param $params
     * @return array
     */
    private function _buildCreateOrderForm($params)
    {
        $payType = VnptPayment::PAY_TYPE_BY_PROVIDER[$params['paymentMethod']];
        $timeStamp = DateTimeHelper::getMiliSecond();
        $invoiceNo = $params['bookingNo'];
        $merTrxId = $params['transactionId'];
        $description = 'TT Hoa Don: ' . $invoiceNo;
        $plainTxtToken = $timeStamp . $merTrxId . $this->merId . $params['amountFromUser'] . $this->encodeKey;
        $token = hash('sha256', $plainTxtToken);
        $ipnUrl = "$this->ipnUrl?provider={$params['paymentProvider']}&platform={$params['platform']}";

        $roomTypeName = $params['roomTypeName'] ?? '';
        $lang = VnptPayment::LANG_STR[$params['lang']];
        $template = VnptPayment::TEMPLATE_PAYMENT;

        $template = view($template)->with([
            'headCss'         => $this->headCss,
            'headJs'          => $this->headJs,
            'invoiceNo'       => $invoiceNo,
            'currency'        => VnptPayment::CURRENCY['VND'],
            'goodsNm'         => $roomTypeName,
            'receiverCountry' => VnptPayment::COUNTRY['VN'],
            'description'     => $description,
            'callBackUrl'     => $this->redirectUrl,
            'notiUrl'         => $ipnUrl,
            'merId'           => $this->merId,
            'reqDomain'       => $this->domain,
            'userLanguage'    => $lang,
            'merchantToken'   => $token,
            'payToken'        => '',
            'timeStamp'       => $timeStamp,
            'merTrxId'        => $merTrxId,
            'userFee'         => 0,
            'payType'         => $payType,
            'payOption'       => VnptPayment::PAY_OPTION['NORMAL'],
            'userId'          => 'guest',
            'goodsAmount'     => $params['totalAmount'],
            'amount'          => $params['amountFromUser'],
            'userIP'          => '',
        ]);
        $html = '';
        try {
            $html = $template->render();
        } catch (Throwable $e) {
        }
        return [$html, $this->domain];
    }

    /**
     * @param $params
     *
     * @return array|mixed
     */
    public function queryOrder($params)
    {
        $form = $this->_buildQueryOrderForm($params);
        $client = app('GuzzleClient', [
            'service'  => GuzzleClientServiceProvider::SERVICE['PAYMENT'],
            'provider' => Payment::PAYMENT_PROVIDER['EPAY'],
        ])([]);
        $url = $this->checkTransUrl . '?' . $form;
        $queryResponse = (string)$client->request('POST', $url)->getBody();
        return ConvertHelper::toStdClass($queryResponse);
    }

    /**
     * @param array $params
     * @return string
     */
    private function _buildQueryOrderForm($params)
    {
        $transactionId = $params['transactionId'];
        $timeStamp = DateTimeHelper::getMiliSecond();
        $dataToken = $timeStamp . $transactionId . $this->merId . $this->encodeKey;
        $merchantToken = hash('sha256', $dataToken);
        return ('merId=' . $this->merId . '&merTrxId=' . $transactionId . '&merchantToken=' . $merchantToken . '&timeStamp=' . $timeStamp);
    }

    /**
     * @param array $params
     *
     * @return array|mixed
     */
    public function refundOrder($params)
    {
        $queryResponse = $this->queryOrder(['transactionId' => $params['refTransactionId']]);
        if (Payment::EPAY_AIOV2_ERROR_CODE['SUCCESSFUL'] == $queryResponse->resultCd) {
            $params['refTransactionId'] = $queryResponse->data->trxId;
            $params['payType'] = VnptPayment::PAY_TYPE_BY_PROVIDER[$params['payType']];

            $refundOrderForm = $this->_buildRefundOrderForm($params);
            $client = app('GuzzleClient', [
                'service'  => GuzzleClientServiceProvider::SERVICE['PAYMENT'],
                'provider' => Payment::PAYMENT_PROVIDER['EPAY'],
            ])([]);
            $url = $this->cancelTransUrl . '?' . $refundOrderForm;
            $refundResponse = (string)$client->request('POST', $url)->getBody();
            return ConvertHelper::toStdClass($refundResponse);
        }
        return ConvertHelper::toStdClass($queryResponse);
    }

    /**
     * @param array $params
     * @return string
     */
    private function _buildRefundOrderForm($params)
    {
        $timeStamp = DateTimeHelper::getMiliSecond();
        $cancelPw = urlencode($this->cancelPassword);
        $dataToken = $timeStamp . $params['transactionId'] . $params['refTransactionId'] . $this->merId . $params['refundAmount'] . $this->encodeKey;
        $merchantToken = hash('sha256', $dataToken);
        return ('trxId=' . $params['refTransactionId'] . '&merId=' . $this->merId . '&merTrxId=' . $params['transactionId'] . '&amount=' . $params['refundAmount'] . '&payType=' . $params['payType'] . '&cancelMsg=' . ($params['cancelMsg'] ?? 'refund'). '&timeStamp=' . $timeStamp . '&merchantToken=' . $merchantToken . '&cancelPw=' . $cancelPw);
    }
}
