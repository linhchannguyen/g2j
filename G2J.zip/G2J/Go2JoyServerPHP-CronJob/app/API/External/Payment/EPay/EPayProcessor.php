<?php

namespace App\API\External\Payment\EPay;

use App\API\External\Payment\PaymentProcessorInterface;
use App\Constants\Globals\Code;
use App\Constants\Globals\Payment;
use App\Forms\Others\Payment\ResultForm\PaymentResultForm;
use App\Helpers\ConvertHelper;
use App\Services\Others\PaymentServiceV2;

class EPayProcessor implements PaymentProcessorInterface
{
    /** @var array */
    protected $config;

    /** @var EPay */
    protected $ePayAPI;

    /**
     * EPayProcessor constructor.
     *
     * @param array $config
     */
    public function __construct($config)
    {
        $this->config = $config;

        $this->ePayAPI = new EPay(
            $this->config['merId'] ?? null,
            $this->config['domain'] ?? null,
            $this->config['headCss'] ?? null,
            $this->config['headJs'] ?? null,
            $this->config['encodeKey'] ?? null,
            $this->config['checkTransUrl'] ?? null,
            $this->config['cancelTransUrl'] ?? null,
            $this->config['cancelPassword'] ?? null,
            $this->config['redirectUrl'] ?? null,
            $this->config['ipnUrl'] ?? null
        );
    }

    /**
     * @param $inputs
     *
     * @return array|mixed
     */
    public function createPaymentRequest($inputs)
    {
        $response = $this->ePayAPI->createOrder($inputs);
        #region Process PSP logic
        $paymentInfo = $response;
        #endregion Process PSP logic

        return $paymentInfo;
    }

    /**
     * @param $inputs
     *
     * @return array|mixed
     */
    public function getPaymentResult($inputs)
    {
        $response = $this->ePayAPI->queryOrder($inputs);

        #region Process PSP logic
        // EPay Not any logic to process so return raw response data
        $paymentResult = $response;
        #endregion Process PSP logic

        return $paymentResult;
    }

    public function getPaymentStatus($inputs): array
    {
        $response = $this->ePayAPI->queryOrder($inputs);
        $ePayErrorCode = $response->resultCd;
        if ($ePayErrorCode == Payment::EPAY_AIOV2_ERROR_CODE['SUCCESSFUL']) {
            if (property_exists($response, 'data')) {
                if ($response->data->status == Payment::EPAY_AIOV2_STATUS['TRANSACTION_NOT_FOUND']) {
                    return [null, Payment::PAYMENT_STATUS['FAILED']];
                }

                if ($response->data->status == Payment::EPAY_AIOV2_STATUS['PAYMENT']) {
                    $pspTransactionId = $response->data->trxId;
                    return [$pspTransactionId, Payment::PAYMENT_STATUS['SUCCESSFUL']];
                }
            }
        }

        if ($ePayErrorCode == Payment::EPAY_AIOV2_ERROR_CODE['PENDING']) {
            return [null, Payment::PAYMENT_STATUS['AWAITING']];
        }

        return [null, Payment::PAYMENT_STATUS['FAILED']];
    }

    /**
     * @param array $query
     * @param array $body
     * @param array $headers
     *
     * @return PaymentResultForm
     */
    public function listenCallback(array $query, array $body, array $headers): PaymentResultForm
    {
        // Get all input data from EPay
        $inputs = array_merge($query, $body, $headers);
        $resultCd = $inputs['resultCd'] ?? null;
        $resultMsg = $inputs['resultMsg'] ?? null;
        $trxId = $inputs['trxId'] ?? null;
        $merTrxId = $inputs['merTrxId'] ?? null;
        $status = $inputs['status'];

        // Only accept IPN message from payment processing
        if ($status == Payment::EPAY_AIOV2_STATUS['PAYMENT']) {
            $params['transactionId'] = $merTrxId;
            $params['paymentProvider'] = $inputs['provider'];
            $checkData = $this->ePayAPI->queryOrder($params);
            $resultForm = new PaymentResultForm();
            if (!empty($checkData)) {
                if ($checkData->resultCd == Payment::EPAY_AIOV2_ERROR_CODE['SUCCESSFUL'] && $checkData->data->status == Payment::EPAY_AIOV2_STATUS['PAYMENT']) {
                    $data = [
                        'transactionId'    => $merTrxId,
                        'pspTransactionId' => $trxId,
                    ];
                    $resultForm->setData($data);

                    return $resultForm->buildSuccessPaymentForm();
                } else {
                    $resultForm->setCode(Code::FAIL);
                    $resultForm->setData($inputs);
                    $resultForm->setError([
                        ConvertHelper::createMessageError($resultCd, $resultMsg)
                    ]);

                    return $resultForm;
                }
            } else {
                $resultForm->setCode(Code::FAIL);
                $resultForm->setData($inputs);
                $resultForm->setError([
                    ConvertHelper::createMessageError(Code::INVALID_IPN, "This transaction could be hacked, please check your signature and returned signature!")
                ]);

                return $resultForm;
            }
        }

        $resultForm = new PaymentResultForm();
        $resultForm->setCode(Code::FAIL);
        $resultForm->setData($inputs);
        $resultForm->setError([
            ConvertHelper::createMessageError(Code::INVALID_IPN, "Only accept IPN message from payment processing!")
        ]);
        return $resultForm;
    }

    /**
     * @param array $inputs
     */
    public function refund($inputs)
    {
        $response = $this->ePayAPI->refundOrder($inputs);
        #region Process PSP logic
        $refundResult = $response;
        #endregion Process PSP logic

        return $refundResult;
    }
}
