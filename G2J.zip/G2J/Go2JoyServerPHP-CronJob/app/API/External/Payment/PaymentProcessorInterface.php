<?php

namespace App\API\External\Payment;

use App\Forms\Others\Payment\ResultForm\PaymentResultForm;

interface PaymentProcessorInterface
{
    /**
     * @param array $inputs
     *
     * @return mixed
     */
    public function createPaymentRequest(array $inputs);

    /**
     * @param array $inputs
     *
     * @return mixed
     */
    public function getPaymentResult(array $inputs);

    /**
     * @param array $inputs
     *
     * @return array
     */
    public function getPaymentStatus(array $inputs): array;

    /**
     * @param array $query
     * @param array $body
     * @param array $headers
     *
     * @return PaymentResultForm
     */
    public function listenCallback(array $query, array $body, array $headers): PaymentResultForm;

    /**
     * @param array $inputs
     *
     * @return mixed
     */
    public function refund(array $inputs);
}
