<?php

namespace App\API\External\Payment\MoMo;

use App\Constants\Globals\Payment as PaymentConst;
use App\Constants\MongoDB\LogExternalPaymentAPI;
use App\Helpers\LoggingHelper;
use App\Models\UserBooking;
use App\Providers\GuzzleClientServiceProvider;
use Carbon\Carbon;

class MoMo
{
    protected $domain;
    protected $accessKey;
    protected $secretKey;
    protected $partnerCode;
    protected $redirectUrl;
    protected $ipnUrl;

    /**
     * @var float
     * Use 0 to set indefinitely (the default behavior)
     */
    protected $timeout = 0;

    #region List of apis of MoMo
    const CREATE_ORDER = '/v2/gateway/api/create';
    const QUERY_ORDER = '/v2/gateway/api/query';
    const REFUND_ORDER = '/v2/gateway/api/refund';
    #endregion List of apis of MoMo

    /**
     * MoMo constructor.
     */
    public function __construct($domain, $accessKey, $secretKey, $partnerCode, $redirectUrl, $ipnUrl)
    {
        $this->domain = $domain;
        $this->accessKey = $accessKey;
        $this->secretKey = $secretKey;
        $this->partnerCode = $partnerCode;
        $this->redirectUrl = $redirectUrl;
        $this->ipnUrl = $ipnUrl;
    }

    /**
     * @param array $params
     *
     * @return array|mixed
     */
    public function createOrder($params)
    {
        $headers = ['Content-Type' => 'application/json; charset=UTF-8'];
        $options = [
            'base_uri' => $this->domain,
            'headers'  => $headers,
            'timeout'  => $this->timeout,
        ];
        $form = $this->_buildCreateOrderForm($params);

        $client = app('GuzzleClient', [
            'service'  => GuzzleClientServiceProvider::SERVICE['PAYMENT'],
            'provider' => $params['paymentProvider'],
        ])($options);
        $response = $client->request(
            'POST',
            self::CREATE_ORDER,
            [
                'json' => $form,
            ]
        );
        return (string)$response->getBody() ? json_decode((string)$response->getBody(), true) : [];
    }

    /**
     * @param $params
     *
     * @return array
     */
    private function _buildCreateOrderForm($params)
    {
        $userBooking = $params['userBooking'];

        $form = [];
        $form['partnerCode'] = $this->partnerCode;
        $form['requestId'] = $params['transactionId'];
        $form['amount'] = (string)$userBooking->{UserBooking::COL_AMOUNT_FROM_USER};
        $form['orderId'] = (string)$userBooking->{UserBooking::COL_BOOKING_NO};
        $form['orderInfo'] = PaymentConst::GO2JOY;
        $form['redirectUrl'] = $this->redirectUrl;
        $form['ipnUrl'] = "$this->ipnUrl?provider={$params['paymentProvider']}&platform={$params['platform']}";
        $form['requestType'] = PaymentConst::MOMO_AIOV2_REQUEST_TYPE['CAPTURE_WALLET'];
        $form['extraData'] = base64_encode("");
        $form['lang'] = 'en';

        $signature = $this->_generateCreateOrderSignature($form);
        $form['signature'] = $signature;

        return $form;
    }

    /**
     * @param array $params
     */
    private function _generateCreateOrderSignature($params)
    {
        $rawSignature = $this->_buildCreateOrderRawSignature($params);
        $paramsJoined = [];
        foreach($rawSignature as $key => $value) {
            $paramsJoined[] = "$key=$value";
        }
        $data = implode('&', $paramsJoined);
        return hash_hmac('sha256', $data, $this->secretKey);
    }

    /**
     * @param array $params
     *
     * @return array
     */
    private function _buildCreateOrderRawSignature($params)
    {
        $rawSignature = [];
        $rawSignature['accessKey'] = $this->accessKey;
        $rawSignature['amount'] = $params['amount'];
        $rawSignature['extraData'] = $params['extraData'];
        $rawSignature['ipnUrl'] = $params['ipnUrl'];
        $rawSignature['orderId'] = $params['orderId'];
        $rawSignature['orderInfo'] = $params['orderInfo'];
        $rawSignature['partnerCode'] = $params['partnerCode'];
        $rawSignature['redirectUrl'] = $params['redirectUrl'];
        $rawSignature['requestId'] = $params['requestId'];
        $rawSignature['requestType'] = $params['requestType'];
        // Sort key by a-z
        ksort($rawSignature);
        return $rawSignature;
    }

    /**
     * @param $params
     *
     * @return array|mixed
     */
    public function queryOrder($params)
    {
        $headers = ['Content-Type' => 'application/json; charset=UTF-8'];
        $options = [
            'base_uri' => $this->domain,
            'headers'  => $headers,
            'timeout'  => $this->timeout,
        ];
        $form = $this->_buildQueryOrderForm($params);

        $client = app('GuzzleClient', [
            'service'  => GuzzleClientServiceProvider::SERVICE['PAYMENT'],
            'provider' => $params['paymentProvider'],
        ])($options);

        $response = $client->request(
            'POST',
            self::QUERY_ORDER,
            [
                'json' => $form,
            ]
        );

        return (string)$response->getBody() ? json_decode((string)$response->getBody(), true) : [];
    }

    /**
     * @param $params
     *
     * @return array
     */
    private function _buildQueryOrderForm($params)
    {
        $userBooking = $params['userBooking'];

        $form = [];
        $form['partnerCode'] = $this->partnerCode;
        $form['requestId'] = $params['transactionId'];
        $form['orderId'] = (string)$userBooking->{UserBooking::COL_BOOKING_NO};
        $form['lang'] = 'en';

        $signature = $this->_generateQueryOrderSignature($form);
        $form['signature'] = $signature;

        return $form;
    }

    /**
     * @param array $params
     */
    private function _generateQueryOrderSignature($params)
    {
        $rawSignature = $this->_buildQueryOrderRawSignature($params);
        $paramsJoined = [];
        foreach($rawSignature as $key => $value) {
            $paramsJoined[] = "$key=$value";
        }
        $data = implode('&', $paramsJoined);
        return hash_hmac('sha256', $data, $this->secretKey);
    }

    /**
     * @param array $params
     *
     * @return array
     */
    private function _buildQueryOrderRawSignature($params)
    {
        $rawSignature = [];
        $rawSignature['accessKey'] = $this->accessKey;
        $rawSignature['orderId'] = $params['orderId'];
        $rawSignature['partnerCode'] = $params['partnerCode'];
        $rawSignature['requestId'] = $params['requestId'];
        // Sort key by a-z
        ksort($rawSignature);
        return $rawSignature;
    }

    /**
     * @param $params
     *
     * @return array|mixed
     */
    public function refundOrder($params)
    {
        $headers = ['Content-Type' => 'application/json; charset=UTF-8'];
        $options = [
            'base_uri' => $this->domain,
            'headers'  => $headers,
            'timeout'  => $this->timeout,
        ];
        $form = $this->_buildRefundOrderForm($params);

        $client = app('GuzzleClient', [
            'service'  => GuzzleClientServiceProvider::SERVICE['PAYMENT'],
            'provider' => $params['paymentProvider'],
        ])($options);

        $response = $client->request(
            'POST',
            self::REFUND_ORDER,
            [
                'json' => $form,
            ]
        );

        return (string)$response->getBody() ? json_decode((string)$response->getBody(), true) : [];
    }

    /**
     * @param $params
     *
     * @return array
     */
    private function _buildRefundOrderForm($params)
    {
        $now = Carbon::now()->timestamp;
        $userBooking = $params['userBooking'];

        $form = [];
        $form['partnerCode'] = $this->partnerCode;
        $bookingNo = (string)$userBooking->{UserBooking::COL_BOOKING_NO};
        $form['orderId'] = "RF-$bookingNo-$now";
        $transactionId = sprintf('%s-%s', $params['transactionId'], $now);
        $form['requestId'] = $transactionId;
        $form['amount'] = (string)$params['refundAmount'];
        $form['transId'] = $params['pspTransactionId'];
        $form['description'] = "";

        $signature = $this->_generateRefundOrderSignature($form);
        $form['signature'] = $signature;

        return $form;
    }

    /**
     * @param array $params
     */
    private function _generateRefundOrderSignature($params)
    {
        $rawSignature = $this->_buildRefundOrderRawSignature($params);
        $paramsJoined = [];
        foreach($rawSignature as $key => $value) {
            $paramsJoined[] = "$key=$value";
        }
        $data = implode('&', $paramsJoined);
        return hash_hmac('sha256', $data, $this->secretKey);
    }

    /**
     * @param array $params
     *
     * @return array
     */
    private function _buildRefundOrderRawSignature($params)
    {
        $rawSignature = [];
        $rawSignature['accessKey'] = $this->accessKey;
        $rawSignature['amount'] = $params['amount'];
        $rawSignature['description'] = $params['description'];
        $rawSignature['orderId'] = $params['orderId'];
        $rawSignature['partnerCode'] = $params['partnerCode'];
        $rawSignature['requestId'] = $params['requestId'];
        $rawSignature['transId'] = $params['transId'];
        // Sort key by a-z
        ksort($rawSignature);
        return $rawSignature;
    }
}
