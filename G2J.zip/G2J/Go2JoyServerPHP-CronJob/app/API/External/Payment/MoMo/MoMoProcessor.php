<?php

namespace App\API\External\Payment\MoMo;

use App\API\External\Payment\PaymentProcessorInterface;
use App\Constants\Globals\Code;
use App\Constants\Globals\Payment;
use App\Forms\Others\Payment\ResultForm\PaymentResultForm;
use App\Helpers\ConvertHelper;

class MoMoProcessor implements PaymentProcessorInterface
{
    /** @var array */
    protected $config;

    /** @var MoMo */
    protected $momoAPI;

    /**
     * MoMoProcessor constructor.
     *
     * @param array $config
     */
    public function __construct($config)
    {
        $this->config = $config;

        $this->momoAPI = new MoMo(
            $this->config['domain'] ?? null,
            $this->config['accessKey'] ?? null,
            $this->config['secretKey'] ?? null,
            $this->config['partnerCode'] ?? null,
            $this->config['redirectUrl'] ?? null,
            $this->config['ipnUrl'] ?? null
        );
    }

    /**
     * @param $inputs
     *
     * @return array|mixed
     */
    public function createPaymentRequest($inputs)
    {
        $response = $this->momoAPI->createOrder($inputs);

        #region Process PSP logic
        // MoMo Not any logic to process so return raw response data
        $paymentInfo = $response;
        #endregion Process PSP logic

        return $paymentInfo;
    }

    /**
     * @param $inputs
     *
     * @return array|mixed
     */
    public function getPaymentResult($inputs)
    {
        $response = $this->momoAPI->queryOrder($inputs);

        #region Process PSP logic
        // MoMo Not any logic to process so return raw response data
        $paymentResult = $response;
        #endregion Process PSP logic

        return $paymentResult;
    }

    /**
     * @param $inputs
     *
     * @return array
     */
    public function getPaymentStatus($inputs): array
    {
        $response = $this->momoAPI->queryOrder($inputs);

        $resultCode = $response['resultCode'];
        switch ($resultCode) {
            case Payment::MOMO_AIOV2_ERROR_CODE['SUCCESSFUL']: {
                $pspTransactionId = $response['transId'];
                return [$pspTransactionId, Payment::PAYMENT_STATUS['SUCCESSFUL']];
            }
            case Payment::MOMO_AIOV2_ERROR_CODE['TRANSACTION_HAS_BEEN_INITIATED']: {
                return [null, Payment::PAYMENT_STATUS['AWAITING']];
            }
            default: {
                return [null, Payment::PAYMENT_STATUS['FAILED']];
            }
        }
    }

    /**
     * @param array $query
     * @param array $body
     * @param array $headers
     *
     * @return PaymentResultForm
     */
    public function listenCallback(array $query, array $body, array $headers): PaymentResultForm
    {
        // Get all input data from MoMo
        $inputs = array_merge($query, $body, $headers);
        $partnerCode = $inputs["partnerCode"];
        $orderId = $inputs["orderId"];
        $requestId = $inputs["requestId"];
        $amount = $inputs["amount"];
        $orderInfo = $inputs["orderInfo"];
        $orderType = $inputs["orderType"];
        $transId = $inputs["transId"];
        $resultCode = $inputs["resultCode"];
        $message = $inputs["message"];
        $payType = $inputs["payType"];
        $responseTime = $inputs["responseTime"];
        $extraData = $inputs["extraData"];
        $momoSignature = $inputs["signature"];

        // Build raw signature
        $rawSignature["transId"] = $transId;
        $rawSignature["accessKey"] = $this->config['accessKey'];
        $rawSignature["amount"] = $amount;
        $rawSignature["extraData"] = $extraData;
        $rawSignature["message"] = $message;
        $rawSignature["orderId"] = $orderId;
        $rawSignature["orderInfo"] = $orderInfo;
        $rawSignature["orderType"] = $orderType;
        $rawSignature["partnerCode"] = $partnerCode;
        $rawSignature["payType"] = $payType;
        $rawSignature["requestId"] = $requestId;
        $rawSignature["responseTime"] = $responseTime;
        $rawSignature["resultCode"] = $resultCode;

        // Sort key by a-z
        ksort($rawSignature);

        // Checksum
        $paramsJoined = [];
        foreach($rawSignature as $key => $value) {
            $paramsJoined[] = "$key=$value";
        }
        $data = implode('&', $paramsJoined);
        $partnerSignature = hash_hmac('sha256', $data, $this->config['secretKey']);
        $resultForm = new PaymentResultForm();
        if ($momoSignature == $partnerSignature) {
            if ($resultCode == Payment::MOMO_AIOV2_ERROR_CODE['SUCCESSFUL']) {
                $data = [
                    'transactionId'    => $requestId,
                    'pspTransactionId' => $transId,
                ];
                $resultForm->setData($data);
                return $resultForm->buildSuccessPaymentForm();
            } else {
                $resultForm->setCode(Code::FAIL);
                $resultForm->setData($inputs);
                $resultForm->setError([
                    ConvertHelper::createMessageError($resultCode, $message)
                ]);
                return $resultForm;
            }
        } else {
            $resultForm->setCode(Code::FAIL);
            $resultForm->setData($inputs);
            $resultForm->setError([
                ConvertHelper::createMessageError(Code::INVALID_IPN, "This transaction could be hacked, please check your signature and returned signature!")
            ]);
            return $resultForm;
        }
    }

    /**
     * @param array $inputs
     */
    public function refund($inputs)
    {
        $response = $this->momoAPI->refundOrder($inputs);

        #region Process PSP logic
        // MoMo Not any logic to process so return raw response data
        $refundResult = $response;
        #endregion Process PSP logic

        return $refundResult;
    }
}
