<?php

namespace App\API\External\Payment\ShopeePay;

use App\API\External\Payment\PaymentProcessorInterface;
use App\Constants\Globals\Code;
use App\Constants\Globals\Payment;
use App\Forms\Others\Payment\ResultForm\PaymentResultForm;
use App\Helpers\ConvertHelper;
use App\Models\UserBooking;
use Illuminate\Support\Facades\Hash;

class ShopeePayProcessor implements PaymentProcessorInterface
{
    /** @var ShopeePay */
    protected $shoppePayAPI;

    /** @var string */
    protected $appId;

    /** @var string */
    protected $appKey;

    /** @var string */
    protected $appReturnUrl;

    /** @var string */
    protected $webId;

    /** @var string */
    protected $webKey;

    /** @var string */
    protected $webReturnUrl;

    /**
     * ShopeePayProcessor constructor.
     *
     * @param array $config
     */
    public function __construct(array $config)
    {
        $this->appId = $config['appId'] ?? null;
        $this->appKey = $config['appKey'] ?? null;
        $this->appReturnUrl = $config['appReturnUrl'] ?? null;
        $this->webId = $config['webId'] ?? null;
        $this->webKey = $config['webKey'] ?? null;
        $this->webReturnUrl = $config['webReturnUrl'] ?? null;

        $this->shoppePayAPI = new ShopeePay(
            $config['merchantExtId'] ?? null,
            $config['storeExtId'] ?? null,
            $config['domain'] ?? null
        );
    }

    /**
     * @param array $inputs
     *
     * @return array|null
     */
    public function createPaymentRequest(array $inputs): ?array
    {
        // Expire in x minutes based on payment expired of payment service
        $paymentExpired = config('go2joy.pending_payment_timeout');
        $userBooking = $inputs['userBooking'];
        $transactionId = $inputs['transactionId'];
        $amount = $userBooking->{UserBooking::COL_AMOUNT_FROM_USER};

        $platform = $inputs['platform'];
        switch($platform) {
            case Payment::PLATFORM['APP']: {
                $this->shoppePayAPI->setClientId($this->appId);
                $this->shoppePayAPI->setSecretKey($this->appKey);
                return $this->shoppePayAPI->createOrder($transactionId, $amount, $this->appReturnUrl, $paymentExpired);
            }
            case Payment::PLATFORM['WEB']: {
                $this->shoppePayAPI->setClientId($this->webId);
                $this->shoppePayAPI->setSecretKey($this->webKey);
                return $this->shoppePayAPI->createDynamicQR($transactionId, $amount, $paymentExpired);
            }
            default: return null;
        }
    }

    /**
     * @param array $inputs
     *
     * @return array|null
     */
    public function getPaymentResult(array $inputs): ?array
    {
        $userBooking = $inputs['userBooking'];
        $transactionId = $inputs['transactionId'];
        $amount = $userBooking->{UserBooking::COL_AMOUNT_FROM_USER};

        $platform = $inputs['platform'];
        switch($platform) {
            case Payment::PLATFORM['APP']: {
                $this->shoppePayAPI->setClientId($this->appId);
                $this->shoppePayAPI->setSecretKey($this->appKey);
                return $this->shoppePayAPI->checkTransactionStatus($transactionId, $amount, ShopeePay::TRANSACTION_TYPE['PAYMENT']);
            }
            case Payment::PLATFORM['WEB']: {
                $this->shoppePayAPI->setClientId($this->webId);
                $this->shoppePayAPI->setSecretKey($this->webKey);
                return $this->shoppePayAPI->checkTransactionStatus($transactionId, $amount, ShopeePay::TRANSACTION_TYPE['PAYMENT']);
            }
            default: return null;
        }
    }

    public function getPaymentStatus(array $inputs): array
    {
        $userBooking = $inputs['userBooking'];
        $transactionId = $inputs['transactionId'];
        $amount = $userBooking->{UserBooking::COL_AMOUNT_FROM_USER};

        $platform = $inputs['platform'];
        switch($platform) {
            case Payment::PLATFORM['APP']: {
                $this->shoppePayAPI->setClientId($this->appId);
                $this->shoppePayAPI->setSecretKey($this->appKey);
                $response = $this->shoppePayAPI->checkTransactionStatus($transactionId, $amount, ShopeePay::TRANSACTION_TYPE['PAYMENT']);
                break;
            }
            case Payment::PLATFORM['WEB']: {
                $this->shoppePayAPI->setClientId($this->webId);
                $this->shoppePayAPI->setSecretKey($this->webKey);
                $response = $this->shoppePayAPI->checkTransactionStatus($transactionId, $amount, ShopeePay::TRANSACTION_TYPE['PAYMENT']);
                break;
            }
            default: $response = null;
        }

        if ($response['errcode'] == ShopeePay::ERRCODE['SUCCESS']) {
            $transactionStatus = $response['transaction']['status'] ?? null;
            if (!empty($transactionStatus)) {
                if ($transactionStatus == ShopeePay::TRANSACTION_STATUS['SUCCESSFUL']) {
                    $pspTransactionId = $response['transaction']['transaction_sn'];
                    return [$pspTransactionId, Payment::PAYMENT_STATUS['SUCCESSFUL']];
                }

                if ($transactionStatus == ShopeePay::TRANSACTION_STATUS['PROCESSING']) {
                    return [null, Payment::PAYMENT_STATUS['AWAITING']];
                }
            }
        }

        return [null, Payment::PAYMENT_STATUS['FAILED']];
    }

    /**
     * @param array $inputs
     *
     * @return array|null
     */
    public function refund(array $inputs): ?array
    {
        $userBooking = $inputs['userBooking'];
        $userBookingTransactionId = $userBooking->{UserBooking::COL_TRANSACTION_ID};
        $transactionId = $inputs['transactionId']; // Refund transaction id
        $refundAmount = $inputs['refundAmount'];

        $platform = $inputs['platform'];
        switch($platform) {
            case Payment::PLATFORM['APP']: {
                $this->shoppePayAPI->setClientId($this->appId);
                $this->shoppePayAPI->setSecretKey($this->appKey);
                return $this->shoppePayAPI->createRefund($userBookingTransactionId, $refundAmount, ShopeePay::TRANSACTION_TYPE['PAYMENT'], $transactionId);
            }
            case Payment::PLATFORM['WEB']: {
                $this->shoppePayAPI->setClientId($this->webId);
                $this->shoppePayAPI->setSecretKey($this->webKey);
                return $this->shoppePayAPI->createRefund($userBookingTransactionId, $refundAmount, ShopeePay::TRANSACTION_TYPE['PAYMENT'], $transactionId);
            }
            default: return null;
        }
    }

    /**
     * @param array $query
     * @param array $body
     * @param array $headers
     *
     * @return PaymentResultForm
     */
    public function listenCallback(array $query, array $body, array $headers): PaymentResultForm
    {
        $transactionStatus = $body['transaction_status'];

        $clientId = reset($headers['x-airpay-clientid']);
        switch ($clientId) {
            case $this->appId: {
                $secretKey = $this->appKey;
                break;
            }
            case $this->webId: {
                $secretKey = $this->webKey;
                break;
            }
            default: $secretKey = null;
        }
        $shopeePaySignature = reset($headers['x-airpay-req-h']);

        // Build raw signature
        $rawSignature = $body;
        $rawSignature = ConvertHelper::toJson($rawSignature);
        $partnerSignature = base64_encode(hash_hmac('sha256', $rawSignature, $secretKey, true));
        if ($shopeePaySignature == $partnerSignature) {
            if ($transactionStatus == ShopeePay::TRANSACTION_STATUS['SUCCESSFUL']) {
                $transactionId = $body['reference_id'];
                $pspTransactionId = $body['transaction_sn'];
                $resultForm = new PaymentResultForm();
                $data = [
                    'transactionId'    => $transactionId,
                    'pspTransactionId' => $pspTransactionId,
                ];
                $resultForm->setCode(Code::SUCCESS);
                $resultForm->setData($data);
                return $resultForm->buildSuccessPaymentForm();
            }
        }

        $resultForm = new PaymentResultForm();
        $resultForm->setCode(Code::FAIL);
        $resultForm->setData($body);
        return $resultForm;
    }
}
