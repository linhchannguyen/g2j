<?php

namespace App\API\External\Payment\ShopeePay;

use App\Constants\Globals\Payment as PaymentConst;
use App\Helpers\ConvertHelper;
use App\Models\UserBooking;
use App\Providers\GuzzleClientServiceProvider;
use Carbon\Carbon;

class ShopeePay
{
    /** @var string */
    protected $clientId;

    /** @var string */
    protected $secretKey;

    /** @var string */
    protected $merchantExtId;

    /** @var string */
    protected $storeExtId;

    /** @var string */
    protected $domain;

    /**
     * @var float
     * Use 0 to set indefinitely (the default behavior)
     */
    protected $timeout = 0;

    #region List of apis of ShopeePay
    const CREATE_ORDER = '/v3/merchant-host/order/create';
    const CREATE_DYNAMIC_QR = '/v3/merchant-host/qr/create';
    const CHECK_TRANSACTION_STATUS = '/v3/merchant-host/transaction/check';
    const CREATE_REFUND = '/v3/merchant-host/transaction/refund/create-new';
    #endregion List of apis of ShopeePay

    #region Constants
    const COUNTRY = 'VN';
    const CURRENCY = 'VND';
    const PLATFORM_TYPE = array(
        'PC'         => 'pc',
        'APP'        => 'app',
        'MOBILE_WEB' => 'mweb',
    );
    const TRANSACTION_TYPE = array(
        'PAYMENT' => 13,
        'REFUND'  => 15,
    );
    const TRANSACTION_STATUS = array(
        'SUCCESSFUL' => 3,
        'PROCESSING' => 2,
        'FAILED'     => 4,
    );
    const ERRCODE = array(
        'SUCCESS' => 0,
    );
    #endregion Constants

    /**
     * @return string
     */
    public function getClientId(): string
    {
        return $this->clientId;
    }

    /**
     * @param string $clientId
     */
    public function setClientId(string $clientId): void
    {
        $this->clientId = $clientId;
    }

    /**
     * @return string
     */
    public function getSecretKey(): string
    {
        return $this->secretKey;
    }

    /**
     * @param string $secretKey
     */
    public function setSecretKey(string $secretKey): void
    {
        $this->secretKey = $secretKey;
    }

    /**
     * ShopeePay constructor.
     */
    public function __construct($merchantExtId, $storeExtId, $domain)
    {
        $this->merchantExtId = $merchantExtId;
        $this->storeExtId = $storeExtId;
        $this->domain = $domain;
    }

    /**
     * @param string $paymentReferenceId
     * @param int $amount
     * @param string $returnUrl
     * @param int $paymentExpired
     *
     * @return array
     */
    public function createOrder(string $paymentReferenceId, int $amount, string $returnUrl, int $paymentExpired): array
    {
        $body = [
            'request_id'           => strval(Carbon::now()->getTimestampMs()),
            'payment_reference_id' => $paymentReferenceId,
            'merchant_ext_id'      => $this->merchantExtId,
            'store_ext_id'         => $this->storeExtId,
            'amount'               => $amount * 100,
            'currency'             => self::CURRENCY,
            'return_url'           => $returnUrl,
            'platform_type'        => self::PLATFORM_TYPE['APP'],
            'expiry_time'          => Carbon::now()->addSeconds($paymentExpired)->timestamp,
            'additional_info'      => '',
        ];

        return $this->_execute($body, self::CREATE_ORDER);
    }

    /**
     * @param string $paymentReferenceId
     * @param int $amount
     * @param int $paymentExpired
     *
     * @return array
     */
    public function createDynamicQR(string $paymentReferenceId, int $amount, int $paymentExpired): array
    {
        $body = [
            'request_id'           => strval(Carbon::now()->getTimestampMs()),
            'amount'               => $amount * 100,
            'currency'             => self::CURRENCY,
            'merchant_ext_id'      => $this->merchantExtId,
            'store_ext_id'         => $this->storeExtId,
            'payment_reference_id' => $paymentReferenceId,
            'expiry_time'          => Carbon::now()->addSeconds($paymentExpired)->timestamp,
            'additional_info'      => '',
        ];

        return $this->_execute($body, self::CREATE_DYNAMIC_QR);
    }

    /**
     * @param string $paymentReferenceId
     * @param int $amount
     * @param int $transactionType
     *
     * @return array
     */
    public function checkTransactionStatus(string $paymentReferenceId, int $amount, int $transactionType): array
    {
        $body = [
            'request_id'       => strval(Carbon::now()->getTimestampMs()),
            'reference_id'     => $paymentReferenceId,
            'transaction_type' => $transactionType,
            'merchant_ext_id'  => $this->merchantExtId,
            'store_ext_id'     => $this->storeExtId,
            'amount'           => $amount * 100,
        ];

        return $this->_execute($body, self::CHECK_TRANSACTION_STATUS);
    }

    /**
     * @param string $paymentReferenceId
     * @param int $amount
     * @param int $transactionType
     * @param string $refundReferenceId
     *
     * @return array
     */
    public function createRefund(string $paymentReferenceId, int $amount, int $transactionType, string $refundReferenceId): array
    {
        $body = [
            'request_id'          => strval(Carbon::now()->getTimestampMs()),
            'reference_id'        => $paymentReferenceId,
            'transaction_type'    => $transactionType,
            'refund_reference_id' => $refundReferenceId,
            'merchant_ext_id'     => $this->merchantExtId,
            'store_ext_id'        => $this->storeExtId,
            'amount'              => $amount * 100,
        ];

        return $this->_execute($body, self::CREATE_REFUND);
    }

    /**
     * @param array $body
     * @param string $url
     *
     * @return array
     */
    private function _execute(array $body, string $url): array
    {
        // Create body json
        $body = ConvertHelper::toJson($body);

        // Header request
        $headers = [
            'Content-Type'      => 'application/json',
            'X-Airpay-ClientId' => $this->clientId,
            'X-Airpay-Req-H'    => base64_encode(hash_hmac('sha256', $body, $this->secretKey, true)),
        ];
        $options = [
            'base_uri' => $this->domain,
            'headers'  => $headers,
            'timeout'  => $this->timeout,
        ];

        $client = app('GuzzleClient', [
            'service'  => GuzzleClientServiceProvider::SERVICE['PAYMENT'],
            'provider' => PaymentConst::PAYMENT_PROVIDER['SHOPEE_PAY'],
        ])($options);

        $response = $client->request('POST', $url, [
            'body' => $body,
        ]);

        return (string)$response->getBody() ? json_decode((string)$response->getBody(), true) : [];
    }
}
