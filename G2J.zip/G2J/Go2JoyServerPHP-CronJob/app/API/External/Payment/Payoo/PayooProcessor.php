<?php

namespace App\API\External\Payment\Payoo;

use App\API\External\Payment\PaymentProcessorInterface;
use App\Constants\Globals\Code;
use App\Forms\Others\Payment\ResultForm\PaymentResultForm;
use App\Helpers\ConvertHelper;
use App\Models\UserBooking;
use DOMDocument;
use stdClass;
use function GuzzleHttp\json_decode;
use function GuzzleHttp\json_encode;

class PayooProcessor implements PaymentProcessorInterface
{
    /** @var array */
    protected $config;

    /** @var Payoo */
    protected $payooAPI;

    const STATE_PAYMENT_PROCESSING = "PAYMENT_PROCESSING";
	const STATE_PAYMENT_RECEIVED = "PAYMENT_RECEIVED";
    const STATE_NOTIFY_RECEIVED = "NOTIFY_RECEIVED";

    /**
     * PayooProcessor constructor.
     *
     * @param array $config
     */
    public function __construct($config)
    {
        $this->config = $config;

        $this->payooAPI = new Payoo(
            $this->config['url'] ?? null,
            $this->config['userName'] ?? null,
            $this->config['password'] ?? null,
            $this->config['signature'] ?? null,
            $this->config['secretKey'] ?? null,
            $this->config['shopId'] ?? null,
            $this->config['notifyUrl'] ?? null,
            $this->config['ip'] ?? null,
            $this->config['checksumKey'] ?? null
        );
    }

    public function createPaymentRequest($userBooking)
    {
        $detailBooking = $userBooking['userBooking'];
        $billingCode = json_decode($this->payooAPI->getBillingCode($userBooking)['ResponseData']);

        return [
            'bookingNo' => $detailBooking->{UserBooking::COL_BOOKING_NO},
            'billingCode' => $billingCode->BillingCode ?? null,
            'transactionId' => $userBooking['transactionId'],
        ];
    }

    /**
     * @param $inputs
     *
     * @return void
     */
    public function getPaymentResult($inputs)
    {
        //
    }

    /**
     * @param array $query
     * @param array $body
     * @param array $headers
     *
     * @return PaymentResultForm
     */
    public function listenCallback(array $query, array $body, array $headers): PaymentResultForm
    {
        // Get all input data from Payoo
        $inputs = array_merge($query, $body, $headers);
        $notifyData = $inputs['NotifyData'];
        $notifyData = json_decode(json_encode(simplexml_load_string($notifyData)));
        $data = $notifyData->Data;
        $signature = $notifyData->Signature;
        $keyFields = $notifyData->KeyFields;

        $resultForm = new PaymentResultForm();

        $paymentNotify = $this->_getPaymentNotify($data);
        if ($paymentNotify->State == self::STATE_PAYMENT_PROCESSING) {
            $resultForm->setCode(Code::FAIL);
            $resultForm->setError(['Update order status is failed. The transaction in "'. self::STATE_PAYMENT_PROCESSING .'" state']);
        }

        $secretKey = $this->config['secretKey'];
        $isValid = $this->_verifyChecksum($paymentNotify, $keyFields, $secretKey, $signature);
        if ($isValid) {
            $_data = [
                'transactionId'    => $paymentNotify->OrderNo,
                'pspTransactionId' => $paymentNotify->BillingCode,
                'state'            => self::STATE_NOTIFY_RECEIVED,
            ];
            $resultForm->setData($_data);

            return $resultForm->buildSuccessPaymentForm();
        }

        $resultForm->setCode(Code::FAIL);
        $resultForm->setError([
            ConvertHelper::createMessageError(Code::INVALID_IPN, "This transaction could be hacked, please check your signature and returned signature!"),
        ]);

        return $resultForm;
    }

    /**
     * @param string $dataResponse
     *
     * @return stdClass
     */
    private function _getPaymentNotify($dataResponse)
    {
        $data = new stdClass();
        if (trim($dataResponse) == "") {
            return $data;
        }

        $doc = new DOMDocument(); // PHP5
        $dataValue = base64_decode($dataResponse);
        $doc->loadXML($dataValue);

        if ($this->_readNodeValue($doc, "BillingCode") != "") {
            $data->OrderNo = $this->_readNodeValue($doc, "OrderNo");
            $orderCashAmount = $this->_readNodeValue($doc, "OrderCashAmount");
            if (!empty($orderCashAmount)) {
                $data->OrderCashAmount = $orderCashAmount;
            } else {
                $data->OrderCashAmount = 0;
            }
            $data->State = $this->_readNodeValue($doc, "State");
            $data->PaymentMethod = $this->_readNodeValue($doc, "PaymentMethod");
            $data->BillingCode = $this->_readNodeValue($doc, "BillingCode");
            $data->PaymentExpireDate = $this->_readNodeValue($doc, "PaymentExpireDate");

            $shopID = $this->_readNodeValue($doc, "ShopId");
            if (!empty($shopID)) {
                $data->ShopID = $shopID;
            } else {
                $data->ShopID = 0;
            }

            $shippingDays = $this->_readNodeValue($doc, "OrderShipDays");
            if (!empty($shippingDays)) {
                $data->ShippingDays = $shippingDays;
            } else {
                $data->ShippingDays = 0;
            }
        } else {
            $data->Session = $this->_readNodeValue($doc, "session");
            $data->BusinessUsername = $this->_readNodeValue($doc, "username");

            $shopID = $this->_readNodeValue($doc, "shop_id");
            if (!empty($shopID)) {
                $data->ShopID = $shopID;
            } else {
                $data->ShopID = 0;
            }

            $data->ShopTitle = $this->_readNodeValue($doc, "shop_title");
            $data->ShopDomain = $this->_readNodeValue($doc, "shop_domain");
            $data->ShopBackUrl = $this->_readNodeValue($doc, "shop_back_url");
            $data->OrderNo = $this->_readNodeValue($doc, "order_no");

            $orderCashAmount = $this->_readNodeValue($doc, "order_cash_amount");
            if (!empty($orderCashAmount)) {
                $data->OrderCashAmount = $orderCashAmount;
            } else {
                $data->OrderCashAmount = 0;
            }

            $data->StartShippingDate = $this->_readNodeValue($doc, "order_ship_date");

            $shippingDays = $this->_readNodeValue($doc, "order_ship_days");
            if (!empty($shippingDays)) {
                $data->ShippingDays = $shippingDays;
            } else {
                $data->ShippingDays = 0;
            }

            $data->OrderDescription = urldecode(($this->_readNodeValue($doc, "order_description")));
            $data->NotifyUrl = $this->_readNodeValue($doc, "notify_url");
            $data->State = $this->_readNodeValue($doc, "State");
            $data->PaymentMethod = $this->_readNodeValue($doc, "PaymentMethod");
            $data->PaymentExpireDate = $this->_readNodeValue($doc, "validity_time");
        }

        return $data;
    }

    /**
     * @param stdClass $data
     * @param string $keyFields
     * @param string $checksumKey
     * @param string $signature
     *
     * @return bool
     */
    private function _verifyChecksum($data, $keyFields, $checksumKey, $signature)
    {
        $strData = $checksumKey;

        if (!empty($keyFields)) {
            $arrKeys = explode('|', $keyFields);
            for ($i = 0; $i < count($arrKeys); $i++) {
                $strData .= '|' . $data->{$arrKeys[$i]};
            }
        }
        $go2joySignature = strtoupper(hash('sha512', $strData));
        $payooSignature = strtoupper($signature);
        if ($go2joySignature != $payooSignature) {
            return false;
        }

        return true;
    }

    /**
     * @param DOMDocument $doc
     * @param string $tagName
     *
     * @return string
     */
    private function _readNodeValue($doc, $tagName)
    {
        $nodeList = $doc->getElementsByTagname($tagName);
        $tempNode = $nodeList->item(0);
        if ($tempNode == null) {
            return '';
        }

        return $tempNode->nodeValue;
    }

    public function getPaymentStatus(array $inputs): int
    {
        // TODO: Implement getPaymentStatus() method.
    }

    public function refund(array $inputs)
    {
        // TODO: Implement refund() method.
    }
}
