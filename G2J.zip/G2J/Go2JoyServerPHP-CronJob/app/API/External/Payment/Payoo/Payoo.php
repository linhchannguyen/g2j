<?php

namespace App\API\External\Payment\Payoo;

use App\Constants\PaymentTransaction as PaymentTransactionConst;
use App\Helpers\ConvertHelper;
use App\Helpers\DateTimeHelper;
use App\Models\PaymentTransaction;
use App\Models\UserBooking;
use App\Providers\GuzzleClientServiceProvider;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;
use function GuzzleHttp\json_encode;

class Payoo
{
    protected $url;

    protected $userName;

    protected $password;

    protected $signature;

    protected $secretKey;

    protected $notifyUrl;

    protected $shopId;

    protected $partnerCode;

    protected $redirectUrl;

    protected $ip;

    protected $checksumKey;

    /**
     * @var float
     * Use 0 to set indefinitely (the default behavior)
     */
    protected $timeout = 0;

    #region list of APIs of Payoo
    const GET_BILLING_CODE = '/BusinessRestAPI.svc/getBillingCode';
    #endregion list of APIs of Payoo

    /**
     * Payoo constructor.
     */
    public function __construct($url, $userName, $password, $signature, $secretKey, $shopId, $notifyUrl, $ip, $checksumKey)
    {
        $this->url = $url;
        $this->userName = $userName;
        $this->password = $password;
        $this->signature = $signature;
        $this->secretKey = $secretKey;
        $this->shopId = $shopId;
        $this->notifyUrl = $notifyUrl;
        $this->ip = $ip;
        $this->checksumKey = $checksumKey;
    }

    /**
     * @param $params
     *
     * @return array|mixed
     */
    public function refundOrder($params)
    {
        //
    }

    public function getBillingCode($params)
    {
        $headers = [
            'Content-Type'  => 'application/json',
            'Cache-Control' => 'no-cache',
            'Apiusername'   => $this->userName,
            'Apipassword'   => $this->password,
            'Apisignature'  => $this->signature,
        ];
        $options = [
            'base_uri' => $this->url,
            'headers'  => $headers,
            'timeout'  => $this->timeout,
        ];
        $form = $this->_buildGetBillingCode($params);

        $client = app('GuzzleClient', [
            'service'  => GuzzleClientServiceProvider::SERVICE['PAYMENT'],
            'provider' => $params['paymentProvider'],
        ])($options);

        $response = $client->request(
            'POST',
            self::GET_BILLING_CODE,
            [
                'json' => $form,
            ]
        );

        return (string)$response->getBody() ? json_decode((string)$response->getBody(), true) : [];
    }

    /**
     * @param $params
     *
     * @return array
     */
    private function _buildGetBillingCode($params)
    {
        $userBooking = $params['userBooking'];
        $transactionId = $this->createPaymentTransactionId($userBooking->{UserBooking::COL_SN});
        $description = urlencode('Cổng thanh toán trực tuyến Payoo trên Go2joy. Hóa đơn thực hiện:' . $transactionId . 'Số tiền:' . $userBooking->{UserBooking::COL_AMOUNT_FROM_USER});
        $infoEx = "<InfoEx><CustomerPhone>{$userBooking->{UserBooking::COL_MOBILE}}</CustomerPhone></InfoEx>";

        $form['BillingCode'] = null;
        $form['OrderNo'] = $transactionId;
        $form['ShopID'] = $this->shopId;
        $form['FromShipDate'] = Carbon::now()->format('d/m/Y');
        $form['ShipNumDay'] = '1';
        $form['Description'] = $description;
        $form['CyberCash'] = $userBooking->{UserBooking::COL_AMOUNT_FROM_USER};
        $form['PaymentExpireDate'] = Carbon::now()->addDays("+1")->format('YmdHms');
        $form['NotifyUrl'] = "$this->notifyUrl?provider={$params['paymentProvider']}&platform={$params['platform']}";
        $form['InfoEx'] = $infoEx;

        return array("RequestData" => json_encode($form), "Signature" => $this->_generateGetBillingCodeSignature($form));
    }

    /**
     * @param array $requestData
     *
     * @return false|string
     */
    private function _generateGetBillingCodeSignature($requestData)
    {
        return hash('sha512', $this->secretKey . json_encode($requestData));
    }

    public function createPaymentTransactionId($userBookingSn, $refund = false)
    {
        $transactionId = $this->_generateTransactionId();
        if ($refund) {
            return $transactionId;
        }
        if (empty($userBookingSn)) {
            return ConvertHelper::EMPTY;
        }
        if (DB::table(PaymentTransaction::TABLE_NAME)->insert([
            PaymentTransaction::COL_USER_BOOKING_SN => $userBookingSn,
            PaymentTransaction::COL_TRANSACTION_ID  => $transactionId,
        ])) {
            return $transactionId;
        }

        return ConvertHelper::EMPTY;
    }

    private function _generateTransactionId()
    {
        $millisecond = DateTimeHelper::getMiliSecond() + 10;

        return PaymentTransactionConst::PREFIX_TRANSACTION . $millisecond;
    }

    public function callApi($requestData, $signature, $apiName)
    {
        $headerRequest = array(
            'cache-control:no-cache',
            'apiusername:' . $this->userName,
            'apipassword:' . $this->password,
            'apisignature:' . $this->signature,
            'content-type:application/json',
        );

        $bodyData = json_encode(array("RequestData" => $requestData, "Signature" => $signature));

        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL            => $this->url . "/" . $apiName,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING       => "",
            CURLOPT_MAXREDIRS      => 10,
            CURLOPT_TIMEOUT        => 60,
            CURLOPT_SSL_VERIFYHOST => false,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_HTTP_VERSION   => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST  => "POST",
            CURLOPT_POSTFIELDS     => $bodyData,
            CURLOPT_HTTPHEADER     => $headerRequest,
        ));

        $response = curl_exec($curl);
        curl_close($curl);

        $responseData = (array)json_Decode($response, true);

        return $responseData["ResponseData"];
    }
}
