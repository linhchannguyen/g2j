<?php

namespace App\API\External\Tracking;

interface TrackingProcessorInterface
{
    public function trackingCheckin($events);
}
