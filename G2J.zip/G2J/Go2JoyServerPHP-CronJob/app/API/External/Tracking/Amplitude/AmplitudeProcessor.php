<?php

namespace App\API\External\Tracking\Amplitude;

use App\API\External\Tracking\TrackingProcessorInterface;
use App\Helpers\LoggingHelper;

class AmplitudeProcessor implements TrackingProcessorInterface
{
    protected $amplitudeAPI;

    public function __construct()
    {
        $apiKey = config('amplitude.api_key');
        $httpApi = config('amplitude.tracking_url');
        $this->amplitudeAPI = new Amplitude($apiKey, $httpApi);
    }

    public function trackingCheckin($events)
    {
        $response = $this->amplitudeAPI->logEvent($events);
        // Log request & response tracking
        LoggingHelper::logTracking($events, $response);
    }

    public function trackingUpdateBookingStatus($events)
    {
        $response = $this->amplitudeAPI->logEvent($events);
        // Log request & response tracking
        LoggingHelper::logTracking($events, $response);
    }
}
