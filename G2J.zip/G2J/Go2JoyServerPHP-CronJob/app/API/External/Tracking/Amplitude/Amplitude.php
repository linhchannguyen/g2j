<?php

namespace App\API\External\Tracking\Amplitude;

use App\Helpers\ConvertHelper;
use App\Helpers\LoggingHelper;
use Exception;

class Amplitude
{
    protected $apiKey;

    protected $httpApi;

    public function __construct($apiKey, $httpApi)
    {
        $this->apiKey = $apiKey;
        $this->httpApi = $httpApi;
    }

    public function logEvent($events)
    {
        $options['min_id_length'] = 1;
        $body = [
            "api_key"   => $this->apiKey,
            "events"    => $events,
            "options"   => $options,
        ];
        $body = ConvertHelper::toJson($body);

        //Header request
        $headers = [
            'Content-Type' => 'application/json',
        ];
        $options = [
            'headers' => $headers,
        ];

        //Call api
        $client = app('GuzzleClient', [])($options);
        try {
            $response = $client->request('POST', $this->httpApi, [
                'body' => $body,
            ]);
            return (string)$response->getBody() ? json_decode((string)$response->getBody(), true) : [];
        } catch (Exception $exception) {
            LoggingHelper::logException($exception);
        }
    }
}
