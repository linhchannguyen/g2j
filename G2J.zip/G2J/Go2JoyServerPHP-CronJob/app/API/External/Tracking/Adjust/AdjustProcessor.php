<?php

namespace App\API\External\Tracking\Adjust;

use App\Constants\Globals\Adjust as AdjustConst;
use App\Constants\Globals\Slack;
use App\Helpers\GenerateHelper;
use App\Helpers\LoggingHelper;
use Exception;

class AdjustProcessor
{
    protected $adjustAPI;

    public function __construct()
    {
        $authToken = config('adjust.adjust_auth_token');
        $httpApi = config('adjust.adjust_event_url');
        $appToken = config('adjust.adjust_app_token');
        $eventToken = config('adjust.adjust_event_token_checkin_success');
        $s2s = config('adjust.adjust_s2s');
        $this->adjustAPI = new Adjust($authToken, $httpApi, $appToken, $eventToken, $s2s);
    }

    public function trackingCheckin($data): void
    {
        try {
            $result = $this->adjustAPI->logEvent($data);
            // Log request & result tracking
            LoggingHelper::logAdjust(AdjustConst::EVENT_CHECKIN_SUCCESSFULLY, 'Sent', $result);
        } catch (Exception $exception) {
            $logMessage = GenerateHelper::logMessage('error', self::class, $exception->getMessage());
            LoggingHelper::toSlack(Slack::CHANNEL['BACKEND_MONITOR'], $logMessage);
        }
    }
}
