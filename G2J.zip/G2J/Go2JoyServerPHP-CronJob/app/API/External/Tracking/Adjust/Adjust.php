<?php

namespace App\API\External\Tracking\Adjust;

use App\Helpers\ConvertHelper;
use App\Helpers\GenerateHelper;

class Adjust
{
    protected $authToken;

    protected $httpApi;

    protected $appToken;

    protected $eventToken;

    protected $s2s;

    public function __construct($authToken, $httpApi, $appToken, $eventToken, $s2s)
    {
        $this->authToken = $authToken;
        $this->httpApi = $httpApi;
        $this->appToken = $appToken;
        $this->eventToken = $eventToken;
        $this->s2s = $s2s;
    }

    public function logEvent(array $data): array
    {
        $body["adid"] = $data['adid'];
        $body["s2s"] = $this->s2s;
        $body["app_token"] = $this->appToken;
        $body["event_token"] = $this->eventToken;
        $headers = [
            'Authorization' => 'Bearer ' . $this->authToken,
            'Content-Type'  => 'application/json; charset=UTF-8',
        ];
        $options = [
            'base_uri' => $this->httpApi,
            'headers'  => $headers,
        ];

        $queryParams = $body;
        $callback_params = "&callback_params=" . $data['callBackParameter'];
        $partner_params = "&partner_params=" . $data['callBackParameter'];
        $url = GenerateHelper::queryString("", $queryParams) . $callback_params . $partner_params;
        $client = app('GuzzleClient', [])($options);
        $response = $client->request('GET', $url);

        $response = ConvertHelper::toJsonResponse($response);
        $status = $response['status'] ?? "";

        if (strtolower($status) == 'ok') {
            return $data;
        }

        return [];
    }
}
