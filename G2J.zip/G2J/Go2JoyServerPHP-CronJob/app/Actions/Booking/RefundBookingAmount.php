<?php

namespace App\Actions\Booking;

use App\Constants\Globals\Payment as PaymentConst;
use App\Constants\UserBooking as UserBookingConst;
use App\DTOs\Booking\RefundBookingAmountInputDTO;
use App\DTOs\Booking\RefundBookingAmountOutputDTO;
use App\Helpers\LoggingHelper;
use App\Models\CancellationPolicy;
use App\Models\RefundingHistory;
use App\Models\UserBooking;
use App\Repositories\Interfaces\RefundingHistoryRepositoryInterface;
use App\Repositories\Interfaces\UserBookingRepositoryInterface;
use App\Services\Others\PaymentServiceV3;
use Exception;
use Illuminate\Support\Facades\DB;

class RefundBookingAmount
{
    const FILE_LANGUAGE_NAME = 'booking';

    /** @var UserBookingRepositoryInterface */
    protected $userBookingRepository;

    /** @var RefundingHistoryRepositoryInterface */
    protected $refundingHistoryRepository;

    /** @var PaymentServiceV3 */
    protected $paymentService;

    public function __construct()
    {
        $this->userBookingRepository = app(UserBookingRepositoryInterface::class);
        $this->refundingHistoryRepository = app(RefundingHistoryRepositoryInterface::class);
        $this->paymentService = app(PaymentServiceV3::class);
    }

    public function handle(RefundBookingAmountInputDTO $refundBookingAmountInputDTO): RefundBookingAmountOutputDTO
    {
        DB::connection('mysql')->beginTransaction();
        try {
            $acknowledged = false;
            $message = null;

            $userBooking = UserBooking::lockForUpdate()
                ->where(UserBooking::COL_SN, $refundBookingAmountInputDTO->getUserBookingSn())
                ->where(UserBooking::COL_BOOKING_STATUS, UserBookingConst::BOOKING_STATUS['CANCELLED'])
                ->first([
                    UserBooking::COL_PREPAY_AMOUNT,
                    UserBooking::COL_MILEAGE_POINT,
                    UserBooking::COL_AMOUNT_FROM_USER,
                    UserBooking::COL_PAYMENT_PROVIDER,
                    UserBooking::COL_DEVICE_TYPE,
                    UserBooking::COL_TRANSACTION_ID,
                ]);

            if (!empty($userBooking)) {
                $refundAmount = $userBooking->{UserBooking::COL_PREPAY_AMOUNT};
                $cancellationPolicy = CancellationPolicy::where(CancellationPolicy::COL_USER_BOOKING_SN, $refundBookingAmountInputDTO->getUserBookingSn())->first();
                if (!empty($cancellationPolicy)) {
                    $refundAmount = $cancellationPolicy->{CancellationPolicy::COL_REFUNDING_AMOUNT} ?? 0;

                    if (!empty($refundAmount)) {
                        $mileagePoint = $userBooking->{UserBooking::COL_MILEAGE_POINT} ?? 0;
                        $differenceAmount = abs($refundAmount - ($userBooking->{UserBooking::COL_AMOUNT_FROM_USER} + $mileagePoint));
                        if ($differenceAmount == 0 || $differenceAmount == 1) { // Only accept +- 1 VND
                            // Refunding amount to user = Amount of money refund by Agoda - number of points
                            $refundAmount = $refundAmount - $mileagePoint;
                        }
                    }
                }

                if ($refundAmount == 0) {
                    DB::connection('mysql')->commit();

                    return RefundBookingAmountOutputDTO::assemble(false, 'Non-refundable');
                }

                switch ($userBooking->{UserBooking::COL_PAYMENT_PROVIDER}) {
                    case UserBookingConst::PAYMENT_PROVIDER['MOMO']:
                        $deviceType = $userBooking->{UserBooking::COL_DEVICE_TYPE};
                        if ($deviceType == UserBookingConst::DEVICE_TYPE['MOBILE']) {
                            $inputs['platform'] = PaymentConst::PLATFORM['APP'];
                        } else {
                            $inputs['platform'] = PaymentConst::PLATFORM['WEB'];
                        }
                        $inputs['paymentProvider'] = PaymentConst::PAYMENT_PROVIDER['MOMO'];
                        $inputs['userBookingSn'] = $refundBookingAmountInputDTO->getUserBookingSn();
                        $inputs['refundAmount'] = $refundAmount;
                        $inputs['staffSn'] = $refundBookingAmountInputDTO->getStaffSn();
                        [$acknowledged, $message] = $this->paymentService->refund($inputs);
                        break;
                    case UserBookingConst::PAYMENT_PROVIDER['ZALO_PAY']:
                        $deviceType = $userBooking->{UserBooking::COL_DEVICE_TYPE};
                        if ($deviceType == UserBookingConst::DEVICE_TYPE['MOBILE']) {
                            $inputs['platform'] = PaymentConst::PLATFORM['APP'];
                        } else {
                            $inputs['platform'] = PaymentConst::PLATFORM['WEB'];
                        }
                        $inputs['paymentProvider'] = PaymentConst::PAYMENT_PROVIDER['ZALO_PAY'];
                        $inputs['userBookingSn'] = $refundBookingAmountInputDTO->getUserBookingSn();
                        $inputs['refundAmount'] = $refundAmount;
                        $inputs['staffSn'] = $refundBookingAmountInputDTO->getStaffSn();
                        [$acknowledged, $message] = $this->paymentService->refund($inputs);
                        break;
                    case UserBookingConst::PAYMENT_PROVIDER['EPAY_DC']:
                    case UserBookingConst::PAYMENT_PROVIDER['EPAY_IC']:
                        $deviceType = $userBooking->{UserBooking::COL_DEVICE_TYPE};
                        if ($deviceType == UserBookingConst::DEVICE_TYPE['MOBILE']) {
                            $inputs['platform'] = PaymentConst::PLATFORM['APP'];
                        } else {
                            $inputs['platform'] = PaymentConst::PLATFORM['WEB'];
                        }
                        $inputs['paymentProvider'] = PaymentConst::PAYMENT_PROVIDER['EPAY'];
                        $inputs['userBookingSn'] = $refundBookingAmountInputDTO->getUserBookingSn();
                        $inputs['refundAmount'] = $refundAmount;
                        $inputs['staffSn'] = $refundBookingAmountInputDTO->getStaffSn();

                        $inputs['payType'] = $userBooking->{UserBooking::COL_PAYMENT_PROVIDER};
                        $inputs['refTransactionId'] = $userBooking->{UserBooking::COL_TRANSACTION_ID};
                        [$acknowledged, $message] = $this->paymentService->refund($inputs);
                        break;
                    case UserBookingConst::PAYMENT_PROVIDER['SHOPEE_WALLET']:
                        $deviceType = $userBooking->{UserBooking::COL_DEVICE_TYPE};
                        if ($deviceType == UserBookingConst::DEVICE_TYPE['MOBILE']) {
                            $inputs['platform'] = PaymentConst::PLATFORM['APP'];
                        } else {
                            $inputs['platform'] = PaymentConst::PLATFORM['WEB'];
                        }
                        $inputs['paymentProvider'] = PaymentConst::PAYMENT_PROVIDER['SHOPEE_PAY'];
                        $inputs['userBookingSn'] = $refundBookingAmountInputDTO->getUserBookingSn();
                        $inputs['refundAmount'] = $refundAmount;
                        $inputs['staffSn'] = $refundBookingAmountInputDTO->getStaffSn();
                        [$acknowledged, $message] = $this->paymentService->refund($inputs);
                        break;
                }

                if ($acknowledged) {
                    $this->userBookingRepository->update([
                        UserBooking::COL_REFUNDED => $refundAmount
                    ], $refundBookingAmountInputDTO->getUserBookingSn());

                    $this->refundingHistoryRepository->create([
                        RefundingHistory::COL_USER_BOOKING_SN => $refundBookingAmountInputDTO->getUserBookingSn(),
                        RefundingHistory::COL_STAFF_SN        => $refundBookingAmountInputDTO->getStaffSn()
                    ]);
                }

            }

            DB::connection('mysql')->commit();

            return RefundBookingAmountOutputDTO::assemble($acknowledged, $message);

        } catch (Exception $exception) {
            LoggingHelper::logException($exception);
            DB::connection('mysql')->rollBack();
            return RefundBookingAmountOutputDTO::assemble(false, $exception->getMessage());
        }
    }
}
