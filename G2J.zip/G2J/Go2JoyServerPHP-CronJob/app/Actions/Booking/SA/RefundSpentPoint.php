<?php

namespace App\Actions\Booking\SA;

use App\Actions\Reward\PushNotificationPoint;
use App\Actions\Reward\RefundPoint;
use App\DTOs\Reward\PushNotificationPointInputDTO;
use App\DTOs\Reward\RefundPointInputDTO;
use App\DTOs\Web\SA\Booking\RefundSpentPointInputDTO;
use App\Repositories\Interfaces\BookingActionHistoryRepositoryInterface;

class RefundSpentPoint
{
    const FILE_LANGUAGE_NAME = 'sa/booking';

    /** @var BookingActionHistoryRepositoryInterface */
    protected $bookingActionHistoryRepository;

    /** @var RefundPoint */
    protected $refundPoint;

    public function __construct(
        BookingActionHistoryRepositoryInterface $bookingActionHistoryRepository,
        RefundPoint $refundPoint
    )
    {
        $this->bookingActionHistoryRepository = $bookingActionHistoryRepository;
        $this->refundPoint = $refundPoint;
    }

    public function handle(RefundSpentPointInputDTO $refundSpentPointInputDTO): void
    {
        $this->bookingActionHistoryRepository->maskAsRequestRefundPointAction($refundSpentPointInputDTO->getStaffSn(), $refundSpentPointInputDTO->getUserBookingSn());

        $refundPointInputDTO = new RefundPointInputDTO();
        $refundPointInputDTO->setUserBookingSn($refundSpentPointInputDTO->getUserBookingSn());
        $refundPointOutputDTO = $this->refundPoint->handle($refundPointInputDTO);
        $refundedPoint = $refundPointOutputDTO->getRefundedPoint();

        /** @var PushNotificationPoint $pushNotificationPoint */
        $pushNotificationPoint = app(PushNotificationPoint::class);
        $pushNotificationPointInputDTO = new PushNotificationPointInputDTO();
        $pushNotificationPointInputDTO->setMileagePointTransactionHistorySn($refundPointOutputDTO->getMileagePointTransactionHistorySn());
        $pushNotificationPoint->handle($pushNotificationPointInputDTO);

        if ($refundedPoint != 0) {
            $this->bookingActionHistoryRepository->maskAsSolvedRefundPointAction($refundPointInputDTO->getUserBookingSn());
        }
    }
}
