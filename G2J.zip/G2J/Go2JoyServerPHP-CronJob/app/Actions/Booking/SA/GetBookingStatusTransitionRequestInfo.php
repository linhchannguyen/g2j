<?php

namespace App\Actions\Booking\SA;

use App\Constants\Globals\Language as LanguageConst;
use App\Constants\UserBooking as UserBookingConst;
use App\DTOs\Web\SA\Booking\GetBookingStatusTransitionRequestInfoInputDTO;
use App\DTOs\Web\SA\Booking\GetBookingStatusTransitionRequestInfoOutputDTO;
use App\Helpers\CommonHelper;
use App\Models\BookingStatusTransitionRequest;
use App\Models\Language;
use App\Models\PaymentTransaction;
use App\Models\UserBooking;
use App\Repositories\Interfaces\BookingStatusTransitionRequestRepositoryInterface;
use App\Repositories\Interfaces\PaymentTransactionRepositoryInterface;
use App\Repositories\Interfaces\UserBookingRepositoryInterface;

class GetBookingStatusTransitionRequestInfo
{
    const FILE_LANGUAGE_NAME = 'sa/booking';

    /** @var BookingStatusTransitionRequestRepositoryInterface */
    protected $bookingStatusTransitionRequestRepository;

    /** @var UserBookingRepositoryInterface */
    protected $userBookingRepository;

    /** @var PaymentTransactionRepositoryInterface */
    protected $paymentTransactionRepository;

    public function __construct(
        BookingStatusTransitionRequestRepositoryInterface $bookingStatusTransitionRequestRepository,
        UserBookingRepositoryInterface $userBookingRepository,
        PaymentTransactionRepositoryInterface $paymentTransactionRepository
    )
    {
        $this->bookingStatusTransitionRequestRepository = $bookingStatusTransitionRequestRepository;
        $this->userBookingRepository = $userBookingRepository;
        $this->paymentTransactionRepository = $paymentTransactionRepository;
    }

    public function handle(GetBookingStatusTransitionRequestInfoInputDTO $getBookingStatusTransitionRequestInfoInputDTO): GetBookingStatusTransitionRequestInfoOutputDTO
    {
        $bookingStatusTransitionRequest = $this->bookingStatusTransitionRequestRepository->findBookingStatusTransitionRequest($getBookingStatusTransitionRequestInfoInputDTO->getBookingStatusTransitionRequestSn());

        if (empty($bookingStatusTransitionRequest)) {
            return new GetBookingStatusTransitionRequestInfoOutputDTO();
        }

        $changedBookingStatus = $bookingStatusTransitionRequest->{BookingStatusTransitionRequest::COL_CHANGED_BOOKING_STATUS};
        switch ($changedBookingStatus) {
            case UserBookingConst::BOOKING_STATUS['COMPLETED']: {
                $reason = json_decode($bookingStatusTransitionRequest->{BookingStatusTransitionRequest::COL_REASON}, true);
                $reasonText = $reason['reasonForComplete'];
                $bookingStatusTransitionRequest->{BookingStatusTransitionRequest::VAR_REASON_TEXT} = $reasonText;
                break;
            }
            case UserBookingConst::BOOKING_STATUS['NO_SHOW']: {
                $reason = json_decode($bookingStatusTransitionRequest->{BookingStatusTransitionRequest::COL_REASON}, true);
                $reasonText = $reason['reasonForNoShow'];
                $bookingStatusTransitionRequest->{BookingStatusTransitionRequest::VAR_REASON_TEXT} = $reasonText;
                break;
            }
            case UserBookingConst::BOOKING_STATUS['CANCELLED']: {
                $reason = json_decode($bookingStatusTransitionRequest->{BookingStatusTransitionRequest::COL_REASON}, true);
                $reasonCancelSn = $reason['reasonCancelSn'];
                $reasonCancelOther = $reason['reasonCancelOther'];

                if (!empty($reasonCancelOther)) {
                    $reasonText = $reasonCancelOther;
                } else {
                    $reasonForCancellation = CommonHelper::getLanguageByLanguageCode(LanguageConst::OBJECT_ID['REASON_CANCEL_BOOKING_CONTENT'], $reasonCancelSn, LanguageConst::LOCALE_TO_LANGUAGE_CODE[app()->getLocale()]);
                    $reasonText = $reasonForCancellation->{Language::COL_TEXT};
                }

                $bookingStatusTransitionRequest->{BookingStatusTransitionRequest::VAR_REASON_TEXT} = $reasonText;
                break;
            }
            default: $bookingStatusTransitionRequest->{BookingStatusTransitionRequest::VAR_REASON_TEXT} = null;
        }

        $userBooking = $this->userBookingRepository->findBookingDetail($bookingStatusTransitionRequest->{BookingStatusTransitionRequest::COL_USER_BOOKING_SN});

        $userBooking->{PaymentTransaction::COL_PAYMENT_STATUS} = CommonHelper::preCheckPaymentStatus(
            $userBooking->{UserBooking::COL_SN},
            $userBooking->{UserBooking::COL_BOOKING_STATUS},
            $userBooking->{UserBooking::COL_REFUNDED},
            $userBooking->{UserBooking::COL_PAYMENT_PROVIDER}
        );

        return GetBookingStatusTransitionRequestInfoOutputDTO::assemble($bookingStatusTransitionRequest, $userBooking);
    }
}
