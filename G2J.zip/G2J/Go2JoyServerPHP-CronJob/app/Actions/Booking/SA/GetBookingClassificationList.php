<?php

namespace App\Actions\Booking\SA;

use App\DTOs\Web\SA\Booking\GetBookingClassificationListOutputDTO;
use App\Models\BookingClassification;
use App\Repositories\Interfaces\BookingClassificationRepositoryInterface;

class GetBookingClassificationList
{
    const FILE_LANGUAGE_NAME = 'sa/booking';

    /** @var BookingClassificationRepositoryInterface */
    protected $bookingClassificationRepository;

    public function __construct(
        BookingClassificationRepositoryInterface $bookingClassificationRepository
    )
    {
        $this->bookingClassificationRepository = $bookingClassificationRepository;
    }

    public function handle(): GetBookingClassificationListOutputDTO
    {
        $bookingClassificationList = $this->bookingClassificationRepository->all([
            BookingClassification::COL_SN,
            BookingClassification::COL_NAME,
        ]);

        return GetBookingClassificationListOutputDTO::assemble($bookingClassificationList);
    }
}
