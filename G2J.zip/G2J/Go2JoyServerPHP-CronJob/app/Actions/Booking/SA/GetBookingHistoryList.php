<?php

namespace App\Actions\Booking\SA;

use App\Actions\User\SA\GetAppUserInfo;
use App\DTOs\Web\SA\Booking\GetBookingHistoryListInputDTO;
use App\DTOs\Web\SA\Booking\GetBookingHistoryListOutputDTO;
use App\DTOs\User\SA\GetAppUserInfoInputDTO;
use App\Repositories\Interfaces\UserBookingRepositoryInterface;

class GetBookingHistoryList
{
    const FILE_LANGUAGE_NAME = 'sa/booking';

    /** @var UserBookingRepositoryInterface */
    protected $userBookingRepository;

    /** @var GetAppUserInfo */
    protected $getAppUserInfo;

    public function __construct(
        UserBookingRepositoryInterface $userBookingRepository,
        GetAppUserInfo $getAppUserInfo
    )
    {
        $this->userBookingRepository = $userBookingRepository;
        $this->getAppUserInfo = $getAppUserInfo;
    }

    public function handle(GetBookingHistoryListInputDTO $getBookingHistoryListInputDTO): GetBookingHistoryListOutputDTO
    {
        $getAppUserInfoInputDTO = new GetAppUserInfoInputDTO();
        $getAppUserInfoInputDTO->setSn($getBookingHistoryListInputDTO->getAppUserSn());
        $getAppUserInfoOutputDTO = $this->getAppUserInfo->handle($getAppUserInfoInputDTO);
        if ($getAppUserInfoOutputDTO->isEmpty()) {
            return new GetBookingHistoryListOutputDTO();
        }

        $userBookingList = $this->userBookingRepository->findUserBookingByAppUserSn(
            $getBookingHistoryListInputDTO->getAppUserSn(),
            $getBookingHistoryListInputDTO->getRestrictedProvinceSnList(),
            $getBookingHistoryListInputDTO->getLimit()
        );

        if ($userBookingList->isEmpty()) {
            return new GetBookingHistoryListOutputDTO();
        }

        return GetBookingHistoryListOutputDTO::assemble($userBookingList);
    }
}
