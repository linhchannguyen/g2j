<?php

namespace App\Actions\Booking\SA;

use App\DTOs\Web\SA\Booking\GetBookingClassificationDetailInputDTO;
use App\DTOs\Web\SA\Booking\GetBookingClassificationDetailOutputDTO;
use App\Models\BookingClassification;
use App\Repositories\Interfaces\BookingClassificationRepositoryInterface;

class GetBookingClassificationDetail
{
    const FILE_LANGUAGE_NAME = 'sa/booking';

    /** @var BookingClassificationRepositoryInterface */
    protected $bookingClassificationRepository;

    public function __construct(
        BookingClassificationRepositoryInterface $bookingClassificationRepository
    )
    {
        $this->bookingClassificationRepository = $bookingClassificationRepository;
    }

    public function handle(GetBookingClassificationDetailInputDTO $getBookingClassificationDetailInputDTO): GetBookingClassificationDetailOutputDTO
    {
        $bookingClassification = $this->bookingClassificationRepository->findBookingClassificationDetail($getBookingClassificationDetailInputDTO->getOriginHotel(), $getBookingClassificationDetailInputDTO->getSourceBooking());

        return GetBookingClassificationDetailOutputDTO::assemble($bookingClassification);
    }
}
