<?php

namespace App\Actions\Booking\SA;

use App\DTOs\Web\SA\Booking\GetBookingListInputDTO;
use App\DTOs\Web\SA\Booking\GetBookingListOutputDTO;
use App\Helpers\ConvertHelper;
use App\Repositories\Interfaces\UserBookingRepositoryInterface;
use App\Constants\BookingActionHistory as BookingActionHistoryConst;
use App\Constants\Globals\HotelAction as HotelActionConst;
use App\Constants\Globals\Language as LanguageConst;
use App\Constants\Globals\Locale as LocaleConst;
use App\Constants\Globals\UserAction as UserActionConst;
use App\Constants\Hotel as HotelConst;
use App\Constants\PaymentTransaction as PaymentTransactionConst;
use App\Constants\UserBooking as UserBookingConst;
use App\Constants\UserBookingReasonCancel as UserBookingReasonCancelConst;
use App\Constants\UserBookingTransfer as UserBookingTransferConst;
use App\Helpers\CommonHelper;
use App\Models\AppUser;
use App\Models\BookingActionHistory;
use App\Models\BookingCancelReasonDetail;
use App\Models\BookingStatusHistory;
use App\Models\CancellationPolicy;
use App\Models\Hotel;
use App\Models\Language;
use App\Models\MileagePointTransactionHistory;
use App\Models\NoShowHistory;
use App\Models\PartnerTransaction;
use App\Models\PortalReasonCancellation;
use App\Models\Staff;
use App\Models\UserBooking;
use App\Models\UserBookingReasonCancel;
use App\Models\UserBookingTransfer;
use App\Repositories\Interfaces\BookingActionHistoryRepositoryInterface;
use App\Repositories\Interfaces\MileagePointTransactionHistoryRepositoryInterface;
use App\Repositories\Interfaces\NoShowHistoryRepositoryInterface;
use App\Repositories\Interfaces\StaffRepositoryInterface;
use Illuminate\Support\Carbon;
use stdClass;

class GetBookingList
{
    const FILE_LANGUAGE_NAME = 'sa/booking';

    /** @var UserBookingRepositoryInterface */
    protected $userBookingRepository;

    public function __construct(
        UserBookingRepositoryInterface $userBookingRepository
    )
    {
        $this->userBookingRepository = $userBookingRepository;
    }

    public function handle(GetBookingListInputDTO $getBookingListInputDTO): GetBookingListOutputDTO
    {
        [$originHotel, $sourceBooking] = ConvertHelper::splitSource($getBookingListInputDTO->getSource());
        $bookingList = $this->userBookingRepository->findHistoryReservationList(
            $getBookingListInputDTO->getProvinceSn(),
            $getBookingListInputDTO->getHotelStatus(),
            $getBookingListInputDTO->getHotelSn(),
            null,
            $getBookingListInputDTO->getAppUserSn(),
            $getBookingListInputDTO->getBookingStatus(),
            $getBookingListInputDTO->getPaymentStatus(),
            $getBookingListInputDTO->getWorkingStatus(),
            $getBookingListInputDTO->getStartDate(),
            $getBookingListInputDTO->getEndDate(),
            $getBookingListInputDTO->getType(),
            $getBookingListInputDTO->getDeviceType(),
            $getBookingListInputDTO->getLimit(),
            $getBookingListInputDTO->getStaffRestrictionSn(),
            $getBookingListInputDTO->getRefundType(),
            $sourceBooking,
            $originHotel
        );

        if ($bookingList->isEmpty()) {
            return new GetBookingListOutputDTO();
        }

        foreach ($bookingList as $userBooking) {
            $sn = $userBooking->{UserBooking::COL_SN} ?? null;
            $bookingStatus = $userBooking->{UserBooking::COL_BOOKING_STATUS} ?? null;

            $userBooking->paymentStatus = CommonHelper::preCheckPaymentStatus(
                $sn,
                $bookingStatus,
                $userBooking->{UserBooking::COL_REFUNDED},
                $userBooking->{UserBooking::COL_PAYMENT_PROVIDER}
            );

            $userBooking->lastUpdate = $userBooking->{UserBooking::COL_LAST_UPDATE} ?? null;
            $bookingStatusHistory = BookingStatusHistory::where(BookingStatusHistory::COL_USER_BOOKING_SN, $sn)
                ->where(BookingStatusHistory::COL_BOOKING_STATUS, $bookingStatus)
                ->first([BookingStatusHistory::COL_LAST_UPDATE]);
            if (!empty($bookingStatusHistory)) {
                $userBooking->lastUpdate = Carbon::parse($bookingStatusHistory->{BookingStatusHistory::COL_LAST_UPDATE})->toDateTimeString();
            }

            $userBooking->reasonForCancellation = null;
            if ($bookingStatus == UserBookingConst::BOOKING_STATUS['CANCELLED']) {
                $bookingCancelReasonDetail = BookingCancelReasonDetail::where(BookingCancelReasonDetail::COL_USER_BOOKING_SN, $sn)
                    ->first([
                        BookingCancelReasonDetail::COL_BOOKING_CANCEL_REASON_SN,
                        BookingCancelReasonDetail::COL_BOOKING_CANCEL_REASON_OTHER,
                    ]);
                if (!empty($bookingCancelReasonDetail)) {
                    $bookingCancelReasonOther = $bookingCancelReasonDetail->{BookingCancelReasonDetail::COL_BOOKING_CANCEL_REASON_OTHER};
                    if (!empty($bookingCancelReasonOther)) {
                        $userBooking->reasonForCancellation = $bookingCancelReasonOther;
                    } else {
                        $bookingCancelReasonSn = $bookingCancelReasonDetail->{BookingCancelReasonDetail::COL_BOOKING_CANCEL_REASON_SN};
                        $reasonForCancellation = CommonHelper::getLanguageByLanguageCode(LanguageConst::OBJECT_ID['REASON_CANCEL_BOOKING_CONTENT'], $bookingCancelReasonSn, LanguageConst::LOCALE_TO_LANGUAGE_CODE[app()->getLocale()]);
                        $userBooking->reasonForCancellation = $reasonForCancellation->{Language::COL_TEXT};
                    }
                }
            }

            $userBooking->reasonForNoShow = null;
            if (($bookingStatus == UserBookingConst::BOOKING_STATUS['AWAITING_GO2JOY_PROCESSING'] || $bookingStatus == UserBookingConst::BOOKING_STATUS['NO_SHOW'])
                && !empty($userBooking->{UserBooking::COL_REPORT}) // If have report value, status AWAITING_GO2JOY_PROCESSING from NoShow Request of hotel
            ) {
                $userBooking->reasonForNoShow = $userBooking->{UserBooking::COL_REPORT};
            }

            $userBooking->reasonForComplete = null;
            if (($bookingStatus == UserBookingConst::BOOKING_STATUS['COMPLETED'])
                && !empty($userBooking->{UserBooking::COL_REPORT})
            ) {
                $userBooking->reasonForComplete = $userBooking->{UserBooking::COL_REPORT};
            }

            $userBooking->appUserNickName = $userBooking->{AppUser::COL_NICK_NAME} ?? null;
            $userBooking->mobile = $userBooking->{UserBooking::COL_MOBILE};

            $commissionAmount = intval($userBooking->{UserBooking::COL_COMMISSION_AMOUNT} ?? 0);
            $commissionProductAmount = intval($userBooking->{UserBooking::COL_COMMISSION_PRODUCT_AMOUNT} ?? 0);
            $userBooking->totalCommissionAmount = $commissionAmount + $commissionProductAmount;
            $totalAmount = intval($userBooking->{UserBooking::COL_TOTAL_AMOUNT} ?? 0);
            $productValue = intval($userBooking->{UserBooking::COL_PRODUCT_VALUE} ?? 0);
            $amountFromUser = intval($userBooking->{UserBooking::COL_AMOUNT_FROM_USER} ?? 0);
            $redeemValue = intval($userBooking->{UserBooking::COL_REDEEM_VALUE} ?? 0);
            $fsGo2joyDiscount = intval($userBooking->{UserBooking::COL_FS_GO2JOY_DISCOUNT} ?? 0);
            $fsHotelDiscount = intval($userBooking->{UserBooking::COL_FS_HOTEL_DISCOUNT} ?? 0);
            $go2joyDiscount = intval($userBooking->{UserBooking::COL_GO2JOY_DISCOUNT} ?? 0);
            $hotelDiscount = intval($userBooking->{UserBooking::COL_HOTEL_DISCOUNT} ?? 0);
            $directDiscount = intval($userBooking->{UserBooking::COL_DIRECT_DISCOUNT} ?? 0);
            $promotionDiscount = intval($userBooking->{UserBooking::COL_PROMOTION_DISCOUNT} ?? 0);

            $prepayAmount = intval($userBooking->{UserBooking::COL_PREPAY_AMOUNT} ?? 0);
            $paymentProvider = $userBooking->{UserBooking::COL_PAYMENT_PROVIDER} ?? null;
            $refunded = $userBooking->{UserBooking::COL_REFUNDED} ?? null;

            $mileagePoint = intval($userBooking->{UserBooking::COL_MILEAGE_POINT} ?? 0);
            $userBooking->discountPrice = $totalAmount - $fsGo2joyDiscount - $redeemValue - $amountFromUser - $fsHotelDiscount - $directDiscount - $mileagePoint - $promotionDiscount;

            $origin = $userBooking->{Hotel::COL_ORIGIN} ?? null;

            $infoTransfer = json_decode($userBooking->{UserBooking::COL_INFO_TRANSFER}, true);
            $infoTransferTitle = trans('userBooking.transferTitle', [
                'bookingNo' => $userBooking->{UserBooking::COL_BOOKING_NO} ?? '',
                'roomTypeNameOld' => $infoTransfer['roomTypeNameOld'] ?? '',
                'hotelNameOld' => $infoTransfer['hotelNameOld'] ?? '',
                'roomTypeNameNew' => $infoTransfer['roomTypeNameNew'] ?? '',
                'hotelNameNew' => $infoTransfer['hotelNameNew'] ?? '',
            ]);
            $userBooking->infoTransfer = $infoTransfer ? $infoTransferTitle : null;

            $userBooking->roomTypeAmount = $totalAmount - $productValue;
            $userBooking->totalGo2joyDiscount = $go2joyDiscount + $mileagePoint + $promotionDiscount;
            $userBooking->totalHotelDiscount = $hotelDiscount + $fsHotelDiscount + $redeemValue + $directDiscount;
            $userBooking->sourceName = CommonHelper::getSourceBookingName($userBooking->{Hotel::COL_ORIGIN}, $userBooking->{UserBooking::COL_SOURCE});
            $userBooking->partnerUserBookingId = $userBooking->{UserBooking::COL_PARTNER_USER_BOOKING_ID} ?? null;
            if (empty($userBooking->partnerUserBookingId)) {
                $userBooking->partnerUserBookingId = $userBooking->{PartnerTransaction::COL_PARTNER_TRANSACTION_ID} ?? null;
            }

            $userBooking->refundingAmount = $prepayAmount;
            if ($userBooking->{Hotel::COL_ORIGIN} == HotelConst::ORIGIN['AGODA']) {
                // Amount of money will be refund by Agoda booking
                $userBooking->refundingAmount = $userBooking->{UserBooking::ALIAS_REFUNDING_AMOUNT} ?? null;

                if (!empty($userBooking->refundingAmount)) {
                    $mileagePoint = $userBooking->{UserBooking::COL_MILEAGE_POINT} ?? 0;
                    $differenceAmount = abs($userBooking->refundingAmount - ($userBooking->{UserBooking::COL_AMOUNT_FROM_USER} + $mileagePoint));
                    if ($differenceAmount == 0 || $differenceAmount == 1) { // Only accept +- 1 VND
                        // Refunding amount to user = Amount of money refund by Agoda - number of points
                        $userBooking->refundingAmount = $userBooking->refundingAmount - $mileagePoint;
                    }
                }
            }
            $userBooking->cancelDescription = null;
            if ($origin == HotelConst::ORIGIN['AGODA']) {
                $firstNameGuest = $userBooking->{UserBooking::ALIAS_FIRST_NAME_GUEST} ?? null;
                $lastNameGuest = $userBooking->{UserBooking::ALIAS_LAST_NAME_GUEST} ?? null;
                switch (true) {
                    case (!empty($firstNameGuest) && empty($lastNameGuest)):
                    {
                        $userBooking->appUserNickName = $firstNameGuest;
                        break;
                    }
                    case (empty($firstNameGuest) && !empty($lastNameGuest)):
                    {
                        $userBooking->appUserNickName = $lastNameGuest;
                        break;
                    }
                    case (!empty($firstNameGuest) && !empty($lastNameGuest)):
                    {
                        $userBooking->appUserNickName = sprintf("%s %s", $firstNameGuest, $lastNameGuest);
                        break;
                    }
                    default:
                    {
                        $userBooking->appUserNickName = null;
                    }
                }

                $userBooking->mobile = $userBooking->{UserBooking::ALIAS_MOBILE_GUEST} ?? null;

                $agodaCancelPolicy = CancellationPolicy::where(CancellationPolicy::COL_USER_BOOKING_SN, $sn)->first();
                if (!empty($agodaCancelPolicy)) {
                    $userBooking->cancelDescription = new stdClass();
                    $agodaCancelPolicyJsonData = json_decode($agodaCancelPolicy->{CancellationPolicy::COL_JSON_DATA});
                    $userBooking->cancelDescription->cancellationPolicyVi = $agodaCancelPolicy->{CancellationPolicy::COL_CONTENT};
                    $userBooking->cancelDescription->cancellationPolicyEn = $agodaCancelPolicy->{CancellationPolicy::COL_CONTENT_EN};
                    $userBooking->cancelDescription->freeCancellation = $agodaCancelPolicyJsonData->freeCancellation;
                    $userBooking->cancelDescription->cancelWithFeeFrom = $agodaCancelPolicyJsonData->cancelWithFeeFrom;
                    $userBooking->cancelDescription->cancelWithFeeTo = $agodaCancelPolicyJsonData->cancelWithFeeTo;
                    $userBooking->cancelDescription->nonRefundable = $agodaCancelPolicyJsonData->nonRefundable;
                    $userBooking->cancelDescription->cancelWithFeeAmount = $agodaCancelPolicyJsonData->cancelWithFeeAmount;
                }
            }

            $isRefunded = true;
            $refundAmountAgoda = $userBooking->{UserBooking::ALIAS_REFUNDING_AMOUNT} ?? null;
            if ($origin == HotelConst::ORIGIN['GO2JOY'] && empty($refunded) && !empty($prepayAmount) && $bookingStatus == UserBookingConst::BOOKING_STATUS['CANCELLED']) {
                $isRefunded = false;
            } elseif (
                $origin == HotelConst::ORIGIN['AGODA'] && empty($refunded) && !empty($prepayAmount)
                && $bookingStatus == UserBookingConst::BOOKING_STATUS['CANCELLED'] && intval($refundAmountAgoda) > 0
            ) {
                $isRefunded = false;
            }
            $userBooking->isRefunded = $isRefunded;

            // Check request cancel from MoMo
            $userBooking->portalReasonCancellation = null;
            $userBookingReasonCancel = UserBookingReasonCancel::with(['portalReasonCancellation'])
                ->where(UserBookingReasonCancel::COL_USER_BOOKING_SN, $sn)
                ->where(UserBookingReasonCancel::COL_STATUS, UserBookingReasonCancelConst::STATUS['NOT_YET'])
                ->first();
            if (
                ($bookingStatus == UserBookingConst::BOOKING_STATUS['AWAITING_CHECKIN']
                    || $bookingStatus == UserBookingConst::BOOKING_STATUS['COMPLETED']
                    || $bookingStatus == UserBookingConst::BOOKING_STATUS['AWAITING_GO2JOY_PROCESSING']
                    || $bookingStatus == UserBookingConst::BOOKING_STATUS['NO_SHOW']
                    || $bookingStatus == UserBookingConst::BOOKING_STATUS['RECEIVED']
                    || $bookingStatus == UserBookingConst::BOOKING_STATUS['AWAITING_USER_CONFIRMATION']
                ) && !empty($userBookingReasonCancel)
            ) {
                $portalReasonCancellation = $userBookingReasonCancel->portalReasonCancellation;
                if (!empty($portalReasonCancellation)) {
                    if (!empty($userBookingReasonCancel->{UserBookingReasonCancel::COL_PORTAL_REASON_CANCELLATION_OTHER})) {
                        $userBooking->portalReasonCancellation = $userBookingReasonCancel->{UserBookingReasonCancel::COL_PORTAL_REASON_CANCELLATION_OTHER};
                    } else {
                        $userBooking->portalReasonCancellation = app()->getLocale() == LocaleConst::ENGLISH ? $portalReasonCancellation->{PortalReasonCancellation::COL_NAME_EN} : $portalReasonCancellation->{PortalReasonCancellation::COL_NAME_VI};
                    }
                }
            }

            $userBooking->isTransferred = false;
            $userBooking->reasonForTransfer = null;
            $userBookingTransfer = UserBookingTransfer::where(UserBookingTransfer::COL_USER_BOOKING_SN, $sn)
                ->orderByDesc(UserBookingTransfer::COL_SN)
                ->first([
                    UserBookingTransfer::COL_STATUS,
                    UserBookingTransfer::COL_REASON_TRANSFER,
                    UserBookingTransfer::COL_USER_BOOKING_NEW,
                ]);
            if (!empty($userBookingTransfer)) {
                $userBookingNew = json_decode($userBookingTransfer->{UserBookingTransfer::COL_USER_BOOKING_NEW}, true);
                if ($userBookingNew['bookingStatus'] == $bookingStatus) {
                    $userBooking->reasonForTransfer = $userBookingTransfer->{UserBookingTransfer::COL_REASON_TRANSFER};
                }

                $userBookingTransferStatus = $userBookingTransfer->{UserBookingTransfer::COL_STATUS};
                if (in_array($userBookingTransferStatus, [
                    UserBookingTransferConst::STATUS['WAITING'],
                    UserBookingTransferConst::STATUS['CONFIRM'],
                ])) {
                    $userBooking->isTransferred = true;
                }
            }

            $userBooking->requiredApproval = false;
            $numOfRecord = BookingActionHistory::where(BookingActionHistory::COL_USER_BOOKING_SN, $sn)
                ->where(BookingActionHistory::COL_WORKING_STATUS, BookingActionHistoryConst::WORKING_STATUS['SOLVED'])
                ->count();
            if ($numOfRecord > 0) {
                $userBooking->requiredApproval = true;
            }

            $userBooking->noShowHistory = null;
            $noShowHistoryRepository = app(NoShowHistoryRepositoryInterface::class);
            $noShowHistory = $noShowHistoryRepository->findLastNoShowHistoryByUserBookingSn($sn);
            if (!empty($noShowHistory)) {
                $reason = $noShowHistory->{NoShowHistory::COL_REASON};
                $hotelAction = $noShowHistory->{NoShowHistory::COL_HOTEL_ACTION} ?? HotelActionConst::NOT_YET;
                $hotelActionTime = $noShowHistory->{NoShowHistory::COL_HOTEL_ACTION_TIME};
                $userAction = $noShowHistory->{NoShowHistory::COL_USER_ACTION} ?? UserActionConst::NOT_YET;
                $userActionTime = $noShowHistory->{NoShowHistory::COL_USER_ACTION_TIME} ?? null;
                $userBooking->noShowHistory = [
                    'hotelAction' => $hotelAction,
                    'hotelActionTime' => $hotelActionTime,
                    'userAction' => $userAction,
                    'userActionTime' => $userActionTime,
                    'reason' => $reason,
                ];
            }

            $userBooking->reasonForReceivedCancellation = null;
            if (
                isset($userBooking->{BookingActionHistory::COL_ACTION_TYPE}) &&
                $bookingStatus == UserBookingConst::BOOKING_STATUS['AWAITING_GO2JOY_PROCESSING']
                && $userBooking->{BookingActionHistory::COL_ACTION_TYPE} == BookingActionHistoryConst::ACTION_TYPE['CANCELLED']
            ) {
                $description = json_decode($userBooking->{BookingActionHistory::COL_DESCRIPTION} ?? null, true);
                $bookingCancelReasonOther = $description['bookingCancelReasonOther'] ?? null;
                $bookingCancelReasonNameByLanguage = $description['bookingCancelReasonNameByLanguage'] ?? null;
                $bookingCancelReasonNameByLanguageEn = null;
                $bookingCancelReasonNameByLanguageVi = null;
                if (!empty($bookingCancelReasonNameByLanguage)) {
                    $bookingCancelReasonNameByLanguageEn = $description['bookingCancelReasonNameByLanguage']['en'];
                    $bookingCancelReasonNameByLanguageVi = $description['bookingCancelReasonNameByLanguage']['vi'];
                }
                $reason = [
                    'en' => $bookingCancelReasonOther ?? $bookingCancelReasonNameByLanguageEn,
                    'vi' => $bookingCancelReasonOther ?? $bookingCancelReasonNameByLanguageVi,
                ];
                $reason = app()->getLocale() == LocaleConst::ENGLISH ? $reason['en'] : $reason['vi'];
                $userBooking->reasonForReceivedCancellation = $reason;
            }

            $userBooking->g2jHandleBooking = false;

            $expireTimeProcessingBooking = CommonHelper::getExpiredTimeProcessingBooking($userBooking)->timestamp;
            $now = Carbon::now()->timestamp;

            /** @var MileagePointTransactionHistoryRepositoryInterface $mileagePointTransactionHistoryRepository */
            $mileagePointTransactionHistoryRepository = app(MileagePointTransactionHistoryRepositoryInterface::class);
            $isExistsRefunded = $mileagePointTransactionHistoryRepository->haveRefundedPoint($sn);
            if (
                ($userBooking->paymentStatus == PaymentTransactionConst::PAYMENT_STATUS['SUCCESSFUL'] || ($userBooking->paymentStatus == PaymentTransactionConst::PAYMENT_STATUS['AWAITING'] && $paymentProvider == UserBookingConst::PAYMENT_PROVIDER['AT_HOTEL']))
                && $now <= $expireTimeProcessingBooking
                && in_array($bookingStatus, [
                    UserBookingConst::BOOKING_STATUS['AWAITING_CHECKIN'],
                    UserBookingConst::BOOKING_STATUS['COMPLETED'],
                    UserBookingConst::BOOKING_STATUS['CANCELLED'],
                    UserBookingConst::BOOKING_STATUS['NO_SHOW'],
                    UserBookingConst::BOOKING_STATUS['RECEIVED'],
                ])
                && !$isExistsRefunded
            ) {
                $userBooking->g2jHandleBooking = true;
            }

            $userBooking->isRefundedPoint = $isExistsRefunded;
            $userBooking->allowRefundPoint = true;
            if (!$userBooking->isRefundedPoint) {
                $createTime = $userBooking->{UserBooking::COL_CREATE_TIME};
                if (empty($createTime)) {
                    // Cover case $db variable not pass value of col CREATE_TIME
                    $createTime = UserBooking::where(UserBooking::COL_SN, $sn)->first([UserBooking::COL_CREATE_TIME])->{UserBooking::COL_CREATE_TIME};
                }
                // If booking use point in old flow, will not be show refund point button
                if (Carbon::parse($createTime)->timestamp <= Carbon::parse(config('go2joy.remake_reward_point_released_time'))->timestamp) {
                    $userBooking->allowRefundPoint = false;
                }
            }

            $userBooking->refundPointTime = null;
            $userBooking->staffRefundPointName = null;
            $userBooking->refundedPoint = 0;
            if ($isExistsRefunded) {
                $mileagePointTransactionHistory = $mileagePointTransactionHistoryRepository->findRefundedPointStatusViaUserBookingSn($sn);
                if (!empty($mileagePointTransactionHistory)) {
                    $userBooking->refundedPoint = $mileagePointTransactionHistory->{MileagePointTransactionHistory::COL_ACTUAL_POINT};
                }

                /** @var BookingActionHistoryRepositoryInterface $bookingActionHistoryRepository */
                $bookingActionHistoryRepository = app(BookingActionHistoryRepositoryInterface::class);
                $bookingActionHistory = $bookingActionHistoryRepository->findRefundPointAction($sn);
                if (!empty($bookingActionHistory)) {
                    $createTime = $bookingActionHistory->{BookingActionHistory::COL_CREATE_TIME};
                    $actionUserSn = $bookingActionHistory->{BookingActionHistory::COL_ACTION_USER_SN};

                    /** @var StaffRepositoryInterface $staffRepository */
                    $staffRepository = app(StaffRepositoryInterface::class);
                    $staff = $staffRepository->find($actionUserSn, [Staff::COL_USER_ID]);
                    $userId = $staff->{Staff::COL_USER_ID};
                    $userBooking->refundPointTime = Carbon::parse($createTime)->toDateTimeString();
                    $userBooking->staffRefundPointName = $userId;
                }
            }

            $userBooking->refundPointBooking = false;
            if ($userBooking->{UserBooking::COL_MILEAGE_POINT} > 0) {
                $userBooking->refundPointBooking = true;
            }
            if ($mileagePointTransactionHistoryRepository->isOldActivePoint($sn)) {
                $userBooking->refundPointBooking = false;
            }
        }

        return GetBookingListOutputDTO::assemble($bookingList);
    }
}
