<?php

namespace App\Actions\Booking\SA;

use App\DTOs\Web\SA\Booking\GetBookingDetailInputDTO;
use App\DTOs\Web\SA\Booking\GetBookingDetailOutputDTO;
use App\Helpers\CommonHelper;
use App\Constants\Coupon as CouponConst;
use App\Constants\Globals\Language as LanguageConst;
use App\Constants\Globals\Locale as LocaleConst;
use App\Constants\Globals\HotelAction as HotelActionConst;
use App\Constants\Globals\UserAction as UserActionConst;
use App\Constants\BookingActionHistory as BookingActionHistoryConst;
use App\Constants\Hotel as HotelConst;
use App\Constants\UserBookingTransfer as UserBookingTransferConst;
use App\Constants\PaymentTransaction as PaymentTransactionConst;
use App\Constants\Staff as StaffConst;
use App\Models\BookingStatusHistory;
use App\Models\PaymentTransaction;
use App\Models\UserBooking;
use App\Models\Language;
use App\Models\PartnerTransaction;
use App\Constants\UserBooking as UserBookingConst;
use App\Models\AppUser;
use App\Models\BookingActionHistory;
use App\Models\BookingCancelReasonDetail;
use App\Models\BookingDirectDiscountHistory;
use App\Models\CancellationPolicy;
use App\Models\Coupon;
use App\Models\Hotel;
use App\Models\MileagePointTransactionHistory;
use App\Models\NoShowHistory;
use App\Models\PortalReasonCancellation;
use App\Models\Promotion;
use App\Models\Staff;
use App\Models\UserBookingReasonCancel;
use App\Models\UserBookingTransfer;
use App\Repositories\Interfaces\BookingActionHistoryRepositoryInterface;
use App\Repositories\Interfaces\BookingCancelReasonDetailRepositoryInterface;
use App\Repositories\Interfaces\BookingStatusHistoryRepositoryInterface;
use App\Repositories\Interfaces\CancellationPolicyRepositoryInterface;
use App\Repositories\Interfaces\HotelProductRepositoryInterface;
use App\Repositories\Interfaces\MileagePointTransactionHistoryRepositoryInterface;
use App\Repositories\Interfaces\NoShowHistoryRepositoryInterface;
use App\Repositories\Interfaces\PartnerTransactionRepositoryInterface;
use App\Repositories\Interfaces\StaffRepositoryInterface;
use App\Repositories\Interfaces\UserBookingRepositoryInterface;
use App\Repositories\Interfaces\UserBookingTransferRepositoryInterface;
use Illuminate\Support\Carbon;
use stdClass;

class GetBookingDetail
{
    const FILE_LANGUAGE_NAME = 'sa/booking';

    /** @var UserBookingRepositoryInterface */
    protected $userBookingRepository;

    /** @var BookingStatusHistoryRepositoryInterface */
    protected $bookingStatusHistoryRepository;

    /** @var BookingCancelReasonDetailRepositoryInterface */
    protected $bookingCancelReasonDetailRepository;

    /** @var PartnerTransactionRepositoryInterface */
    protected $partnerTransactionRepository;

    /** @var CancellationPolicyRepositoryInterface */
    protected $cancellationPolicyRepository;

    /** @var UserBookingTransferRepositoryInterface */
    protected $userBookingTransferRepository;

    /** @var StaffRepositoryInterface */
    protected $staffRepository;

    /** @var HotelProductRepositoryInterface */
    protected $hotelProductRepository;

    /** @var NoShowHistoryRepositoryInterface */
    protected $noShowHistoryRepository;

    /** @var BookingActionHistoryRepositoryInterface */
    protected $bookingActionHistoryRepository;

    /** @var MileagePointTransactionHistoryRepositoryInterface */
    protected $mileagePointTransactionHistoryRepository;

    public function __construct(
        UserBookingRepositoryInterface                    $userBookingRepository,
        BookingStatusHistoryRepositoryInterface           $bookingStatusHistoryRepository,
        BookingCancelReasonDetailRepositoryInterface      $bookingCancelReasonDetailRepository,
        PartnerTransactionRepositoryInterface             $partnerTransactionRepository,
        CancellationPolicyRepositoryInterface             $cancellationPolicyRepository,
        UserBookingTransferRepositoryInterface            $userBookingTransferRepository,
        StaffRepositoryInterface                          $staffRepository,
        HotelProductRepositoryInterface                   $hotelProductRepository,
        NoShowHistoryRepositoryInterface                  $noShowHistoryRepository,
        BookingActionHistoryRepositoryInterface           $bookingActionHistoryRepository,
        MileagePointTransactionHistoryRepositoryInterface $mileagePointTransactionHistoryRepository
    )
    {
        $this->userBookingRepository = $userBookingRepository;
        $this->bookingStatusHistoryRepository = $bookingStatusHistoryRepository;
        $this->bookingCancelReasonDetailRepository = $bookingCancelReasonDetailRepository;
        $this->partnerTransactionRepository = $partnerTransactionRepository;
        $this->cancellationPolicyRepository = $cancellationPolicyRepository;
        $this->userBookingTransferRepository = $userBookingTransferRepository;
        $this->staffRepository = $staffRepository;
        $this->hotelProductRepository = $hotelProductRepository;
        $this->noShowHistoryRepository = $noShowHistoryRepository;
        $this->bookingActionHistoryRepository = $bookingActionHistoryRepository;
        $this->mileagePointTransactionHistoryRepository = $mileagePointTransactionHistoryRepository;
    }

    public function handle(GetBookingDetailInputDTO $getBookingDetailInputDTO): GetBookingDetailOutputDTO
    {
        $userBooking = $this->userBookingRepository->findBookingDetail($getBookingDetailInputDTO->getSn());
        if (empty($userBooking)) {
            return new GetBookingDetailOutputDTO();
        }

        $bookingStatusHistory = $this->bookingStatusHistoryRepository->findWhere([
            [BookingStatusHistory::COL_USER_BOOKING_SN, '=', $userBooking->{UserBooking::COL_SN}],
            [BookingStatusHistory::COL_BOOKING_STATUS, '=', $userBooking->{UserBooking::COL_BOOKING_STATUS}],
        ], [BookingStatusHistory::COL_LAST_UPDATE])->first();
        if (!empty($bookingStatusHistory)) {
            $userBooking->{UserBooking::COL_LAST_UPDATE} = Carbon::parse($bookingStatusHistory->{BookingStatusHistory::COL_LAST_UPDATE})->toDateTimeString();
        }

        $paymentStatus = CommonHelper::preCheckPaymentStatus(
            $userBooking->{UserBooking::COL_SN},
            $userBooking->{UserBooking::COL_BOOKING_STATUS},
            $userBooking->{UserBooking::COL_REFUNDED},
            $userBooking->{UserBooking::COL_PAYMENT_PROVIDER}
        );
        $userBooking->{PaymentTransaction::COL_PAYMENT_STATUS} = $paymentStatus;

        $userBooking->{UserBooking::VAR_REASON_FOR_CANCELLATION} = null;
        if ($userBooking->{UserBooking::COL_BOOKING_STATUS} == UserBookingConst::BOOKING_STATUS['CANCELLED']) {
            $bookingCancelReasonDetail = $this->bookingCancelReasonDetailRepository->findByField(BookingCancelReasonDetail::COL_USER_BOOKING_SN, $userBooking->{UserBooking::COL_SN}, [
                BookingCancelReasonDetail::COL_BOOKING_CANCEL_REASON_SN,
                BookingCancelReasonDetail::COL_BOOKING_CANCEL_REASON_OTHER,
            ])->first();
            if (!empty($bookingCancelReasonDetail)) {
                $bookingCancelReasonOther = $bookingCancelReasonDetail->{BookingCancelReasonDetail::COL_BOOKING_CANCEL_REASON_OTHER};
                if (!empty($bookingCancelReasonOther)) {
                    $userBooking->{UserBooking::VAR_REASON_FOR_CANCELLATION} = $bookingCancelReasonOther;
                } else {
                    $bookingCancelReasonSn = $bookingCancelReasonDetail->{BookingCancelReasonDetail::COL_BOOKING_CANCEL_REASON_SN};
                    $reasonForCancellation = CommonHelper::getLanguageByLanguageCode(LanguageConst::OBJECT_ID['REASON_CANCEL_BOOKING_CONTENT'], $bookingCancelReasonSn, LanguageConst::LOCALE_TO_LANGUAGE_CODE[app()->getLocale()]);
                    $userBooking->{UserBooking::VAR_REASON_FOR_CANCELLATION} = $reasonForCancellation->{Language::COL_TEXT};
                }
            }
        }

        $userBooking->{UserBooking::VAR_REASON_FOR_NO_SHOW} = null;
        if (($userBooking->{UserBooking::COL_BOOKING_STATUS} == UserBookingConst::BOOKING_STATUS['AWAITING_GO2JOY_PROCESSING'] || $userBooking->{UserBooking::COL_BOOKING_STATUS} == UserBookingConst::BOOKING_STATUS['NO_SHOW'])
            && !empty($userBooking->{UserBooking::COL_REPORT}) // If it has report value, status AWAITING_GO2JOY_PROCESSING from NoShow Request of hotel
        ) {
            $userBooking->{UserBooking::VAR_REASON_FOR_NO_SHOW} = $userBooking->{UserBooking::COL_REPORT};
        }

        $userBooking->{UserBooking::VAR_REASON_FOR_COMPLETE} = null;
        if (($userBooking->{UserBooking::COL_BOOKING_STATUS} == UserBookingConst::BOOKING_STATUS['COMPLETED'])
            && !empty($userBooking->{UserBooking::COL_REPORT})
        ) {
            $userBooking->{UserBooking::VAR_REASON_FOR_COMPLETE} = $userBooking->{UserBooking::COL_REPORT};
        }

        if (empty($userBooking->{UserBooking::COL_PARTNER_USER_BOOKING_ID})) {
            $userBooking->{UserBooking::COL_PARTNER_USER_BOOKING_ID} = $userBooking->{PartnerTransaction::COL_PARTNER_TRANSACTION_ID} ?? null;
        }

        $refundingAmount = $userBooking->{UserBooking::COL_PREPAY_AMOUNT};
        if ($userBooking->{Hotel::COL_ORIGIN} == HotelConst::ORIGIN['AGODA']) {
            // Amount of money will be refund by Agoda booking
            $refundingAmount = $userBooking->{UserBooking::ALIAS_REFUNDING_AMOUNT} ?? null;

            if (!empty($refundingAmount)) {
                // Refunding amount to user = Amount of money refund by Agoda - number of points
                $refundingAmount = $refundingAmount - ($userBooking->{UserBooking::COL_MILEAGE_POINT} ?? 0);
            }

            if (!empty($refundingAmount)) {
                $mileagePoint = $userBooking->{UserBooking::COL_MILEAGE_POINT} ?? 0;
                $differenceAmount = abs($refundingAmount - ($userBooking->{UserBooking::COL_AMOUNT_FROM_USER} + $mileagePoint));
                if ($differenceAmount == 0 || $differenceAmount == 1) { // Only accept +- 1 VND
                    // Refunding amount to user = Amount of money refund by Agoda - number of points
                    $refundingAmount = $refundingAmount - $mileagePoint;
                }
            }
        }
        $userBooking->{CancellationPolicy::COL_REFUNDING_AMOUNT} = $refundingAmount;

        $userBooking->{UserBooking::VAR_CANCEL_DESCRIPTION} = null;
        if ($userBooking->{Hotel::COL_ORIGIN} == HotelConst::ORIGIN['AGODA']) {
            $firstNameGuest = $userBooking->{UserBooking::ALIAS_FIRST_NAME_GUEST} ?? null;
            $lastNameGuest = $userBooking->{UserBooking::ALIAS_LAST_NAME_GUEST} ?? null;
            switch (true) {
                case (!empty($firstNameGuest) && empty($lastNameGuest)):
                {
                    $userBooking->{AppUser::COL_NICK_NAME} = $firstNameGuest;
                    break;
                }
                case (empty($firstNameGuest) && !empty($lastNameGuest)):
                {
                    $userBooking->{AppUser::COL_NICK_NAME} = $lastNameGuest;
                    break;
                }
                case (!empty($firstNameGuest) && !empty($lastNameGuest)):
                {
                    $userBooking->{AppUser::COL_NICK_NAME} = sprintf("%s %s", $firstNameGuest, $lastNameGuest);
                    break;
                }
                default:
                {
                    $userBooking->{AppUser::COL_NICK_NAME} = null;
                }
            }

            $userBooking->{UserBooking::COL_MOBILE} = $userBooking->{UserBooking::ALIAS_MOBILE_GUEST} ?? null;

            $agodaCancelPolicy = $this->cancellationPolicyRepository->findByField(CancellationPolicy::COL_USER_BOOKING_SN, $userBooking->{UserBooking::COL_SN}, [
                CancellationPolicy::COL_JSON_DATA,
                CancellationPolicy::COL_CONTENT,
                CancellationPolicy::COL_CONTENT_EN,
            ])->first();
            if (!empty($agodaCancelPolicy)) {
                $cancelDescription = new stdClass();
                $agodaCancelPolicyJsonData = json_decode($agodaCancelPolicy->{CancellationPolicy::COL_JSON_DATA});
                $cancelDescription->cancellationPolicyVi = $agodaCancelPolicy->{CancellationPolicy::COL_CONTENT};
                $cancelDescription->cancellationPolicyEn = $agodaCancelPolicy->{CancellationPolicy::COL_CONTENT_EN};
                $cancelDescription->freeCancellation = $agodaCancelPolicyJsonData->freeCancellation;
                $cancelDescription->cancelWithFeeFrom = $agodaCancelPolicyJsonData->cancelWithFeeFrom;
                $cancelDescription->cancelWithFeeTo = $agodaCancelPolicyJsonData->cancelWithFeeTo;
                $cancelDescription->nonRefundable = $agodaCancelPolicyJsonData->nonRefundable;
                $cancelDescription->cancelWithFeeAmount = $agodaCancelPolicyJsonData->cancelWithFeeAmount;

                $userBooking->{UserBooking::VAR_CANCEL_DESCRIPTION} = $cancelDescription;
            }
        }

        $isRefunded = false;
        if ($userBooking->{UserBooking::COL_REFUNDED} > 0 && $userBooking->{UserBooking::COL_PREPAY_AMOUNT} > 0) {
            $isRefunded = true;
        }
        $userBooking->{UserBooking::VAR_IS_REFUNDED} = $isRefunded;

        // Check request cancel from Partners (MoMo, ZaloPay, ...)
        $userBookingReasonCancel = UserBookingReasonCancel::with(['portalReasonCancellation'])->where(UserBookingReasonCancel::COL_USER_BOOKING_SN, $userBooking->{UserBooking::COL_SN})->first();
        if (($userBooking->{UserBooking::COL_BOOKING_STATUS} == UserBookingConst::BOOKING_STATUS['AWAITING_CHECKIN'] || $userBooking->{UserBooking::COL_BOOKING_STATUS} == UserBookingConst::BOOKING_STATUS['COMPLETED'])
            && !empty($userBookingReasonCancel)
        ) {
            $portalReasonCancellation = $userBookingReasonCancel->portalReasonCancellation;
            if (!empty($portalReasonCancellation)) {
                if (!empty($userBookingReasonCancel->{UserBookingReasonCancel::COL_PORTAL_REASON_CANCELLATION_OTHER})) {
                    $userBooking->{UserBooking::VAR_REASON_FOR_CANCELLATION} = $userBookingReasonCancel->{UserBookingReasonCancel::COL_PORTAL_REASON_CANCELLATION_OTHER};
                } else {
                    $userBooking->{UserBooking::VAR_REASON_FOR_CANCELLATION} = app()->getLocale() == LocaleConst::ENGLISH ? $portalReasonCancellation->{PortalReasonCancellation::COL_NAME_EN} : $portalReasonCancellation->{PortalReasonCancellation::COL_NAME_VI};
                }
            }
        }

        $userBooking->{UserBooking::VAR_IS_TRANSFERRED} = false;
        $userBooking->{UserBooking::VAR_REASON_FOR_TRANSFER} = null;
        $userBooking->{UserBooking::VAR_TRANSFER_TIME} = null;
        $userBooking->{UserBooking::VAR_STAFF_TRANSFER_NAME} = null;
        $userBookingTransfer = $this->userBookingTransferRepository->findLastTransferInfo($userBooking->{UserBooking::COL_SN});
        if (!empty($userBookingTransfer)) {
            $userBookingTransferStatus = $userBookingTransfer->{UserBookingTransfer::COL_STATUS};
            if (in_array($userBookingTransferStatus, [
                UserBookingTransferConst::STATUS['WAITING'],
                UserBookingTransferConst::STATUS['REJECT'],
            ])) {
                $userBooking->{UserBooking::VAR_IS_TRANSFERRED} = false;
            }

            if ($userBookingTransferStatus == UserBookingTransferConst::STATUS['CONFIRM']) {
                $userBooking->{UserBooking::VAR_IS_TRANSFERRED} = true;
                $userBooking->{UserBooking::VAR_REASON_FOR_TRANSFER} = $userBookingTransfer->{UserBookingTransfer::COL_REASON_TRANSFER};
                $userBooking->{UserBooking::VAR_TRANSFER_TIME} = $userBookingTransfer->{UserBookingTransfer::COL_CREATE_TIME};

                $staff = $this->staffRepository->find($userBookingTransfer->{UserBookingTransfer::COL_CREATE_STAFF_SN}, [Staff::COL_USER_ID]);
                $userBooking->{UserBooking::VAR_STAFF_TRANSFER_NAME} = $staff->{Staff::COL_USER_ID};
            }
        }

        $hotelProductList = Collect([]);
        $productValue = $userBooking->{UserBooking::COL_PRODUCT_VALUE};
        if (!empty($productValue)) {
            $hotelProductList = $this->hotelProductRepository->findByUserBookingSn($userBooking->{UserBooking::COL_SN});
        }

        $userBooking->{UserBooking::VAR_NO_SHOW_HISTORY} = null;
        $noShowHistory = $this->noShowHistoryRepository->findLastNoShowHistoryByUserBookingSn($userBooking->{UserBooking::COL_SN});
        if (!empty($noShowHistory)) {
            $reason = $noShowHistory->{NoShowHistory::COL_REASON};
            $hotelAction = $noShowHistory->{NoShowHistory::COL_HOTEL_ACTION} ?? HotelActionConst::NOT_YET;
            $hotelActionTime = $noShowHistory->{NoShowHistory::COL_HOTEL_ACTION_TIME};
            $userAction = $noShowHistory->{NoShowHistory::COL_USER_ACTION} ?? UserActionConst::NOT_YET;
            $userActionTime = $noShowHistory->{NoShowHistory::COL_USER_ACTION_TIME} ?? null;
            $userBooking->{UserBooking::VAR_NO_SHOW_HISTORY} = [
                'hotelAction' => $hotelAction,
                'hotelActionTime' => $hotelActionTime,
                'userAction' => $userAction,
                'userActionTime' => $userActionTime,
                'reason' => $reason,
            ];
        }

        $userBooking->{UserBooking::VAR_HOTEL_COUPON} = null;
        $userBooking->{UserBooking::VAR_GO2JOY_COUPON} = null;
        switch ($userBooking->{Coupon::COL_DISCOUNT_TYPE}) {
            case CouponConst::DISCOUNT_TYPE['GIFT']:
            case CouponConst::DISCOUNT_TYPE['HOURS']:
            {
                $userBooking->{UserBooking::VAR_HOTEL_COUPON} = [
                    'couponSn' => $userBooking->{Coupon::COL_COUPON_SN},
                    'promotionSn' => $userBooking->{Coupon::COL_PROMOTION_SN},
                    'couponName' => $userBooking->{Coupon::COL_COUPON_NAME},
                ];
                break;
            }
            case CouponConst::DISCOUNT_TYPE['MONEY']:
            case CouponConst::DISCOUNT_TYPE['PERCENT']:
            case CouponConst::DISCOUNT_TYPE['SAME_PRICE']:
            {
                $go2joyDiscount = $userBooking->{Promotion::COL_GO2JOY_DISCOUNT};
                $hotelDiscount = $userBooking->{Promotion::COL_HOTEL_DISCOUNT};
                if ($go2joyDiscount > 0) {
                    $userBooking->{UserBooking::VAR_GO2JOY_COUPON} = [
                        'couponSn' => $userBooking->{Coupon::COL_COUPON_SN},
                        'promotionSn' => $userBooking->{Coupon::COL_PROMOTION_SN},
                        'couponName' => $userBooking->{Coupon::COL_COUPON_NAME},
                    ];
                }
                if ($hotelDiscount > 0) {
                    $userBooking->{UserBooking::VAR_HOTEL_COUPON} = [
                        'couponSn' => $userBooking->{Coupon::COL_COUPON_SN},
                        'promotionSn' => $userBooking->{Coupon::COL_PROMOTION_SN},
                        'couponName' => $userBooking->{Coupon::COL_COUPON_NAME},
                    ];
                }

                break;
            }
        }

        $userBooking->{UserBooking::VAR_REQUIRED_APPROVAL} = $this->isRequiredApproval($userBooking->{UserBooking::COL_SN});

        $userBooking->{UserBooking::VAR_WORKING_STATUS} = null;
        $userBooking->{UserBooking::VAR_ACTION_TYPE} = null;
        $userBooking->{UserBooking::VAR_REASON_FOR_RECEIVED_CANCELLATION} = null;
        $userBooking->{BookingActionHistory::VAR_BOOKING_ACTION_HISTORY_CREATE_TIME} = null;
        $userBooking->{UserBooking::VAR_PREV_BOOKING_STATUS} = $userBooking->{UserBooking::COL_BOOKING_STATUS};
        $userBooking->{UserBooking::VAR_PREV_VIA_OBJECT} = $userBooking->{UserBooking::COL_VIA_OBJECT};
        $bookingActionHistorySn = $userBooking->{UserBooking::COL_BOOKING_ACTION_HISTORY_SN};
        if (!empty($bookingActionHistorySn)) {
            $lastBookingActionHistory = $this->bookingActionHistoryRepository->find($bookingActionHistorySn);

            $userBooking->{UserBooking::VAR_WORKING_STATUS} = $lastBookingActionHistory->{BookingActionHistory::COL_WORKING_STATUS};
            $userBooking->{UserBooking::VAR_ACTION_TYPE} = $lastBookingActionHistory->{BookingActionHistory::COL_ACTION_TYPE};

            $description = json_decode($lastBookingActionHistory->{BookingActionHistory::COL_DESCRIPTION}, true);
            $initialBookingStatus = $description['initialBookingStatus'];
            $initialViaObject = $description['initialViaObject'] ?? $userBooking->{UserBooking::COL_VIA_OBJECT};
            $userBooking->{UserBooking::VAR_PREV_BOOKING_STATUS} = $initialBookingStatus;
            $userBooking->{UserBooking::VAR_PREV_VIA_OBJECT} = $initialViaObject;

            $bookingCancelReasonOther = $description['bookingCancelReasonOther'] ?? null;
            $bookingCancelReasonNameByLanguage = $description['bookingCancelReasonNameByLanguage'] ?? null;
            $bookingCancelReasonNameByLanguageEn = null;
            $bookingCancelReasonNameByLanguageVi = null;
            if (!empty($bookingCancelReasonNameByLanguage)) {
                $bookingCancelReasonNameByLanguageEn = $description['bookingCancelReasonNameByLanguage']['en'];
                $bookingCancelReasonNameByLanguageVi = $description['bookingCancelReasonNameByLanguage']['vi'];
            }
            $reason = [
                'en' => $bookingCancelReasonOther ?? $bookingCancelReasonNameByLanguageEn,
                'vi' => $bookingCancelReasonOther ?? $bookingCancelReasonNameByLanguageVi,
            ];
            $reason = app()->getLocale() == LocaleConst::ENGLISH ? $reason['en'] : $reason['vi'];
            $bookingActionHistoryCreateTime = $lastBookingActionHistory->{BookingActionHistory::COL_CREATE_TIME};
            $userBooking->{UserBooking::VAR_REASON_FOR_RECEIVED_CANCELLATION} = $reason;
            $userBooking->{BookingActionHistory::VAR_BOOKING_ACTION_HISTORY_CREATE_TIME} = $bookingActionHistoryCreateTime;
        }

        $userBooking->{UserBooking::VAR_G2J_HANDLE_BOOKING} = false;
        $expireTimeProcessingBooking = CommonHelper::getExpiredTimeProcessingBooking($userBooking)->timestamp;
        $now = Carbon::now()->timestamp;
        $isExistsRefunded = $this->mileagePointTransactionHistoryRepository->haveRefundedPoint($userBooking->{UserBooking::COL_SN});
        if (
            ($userBooking->{PaymentTransaction::COL_PAYMENT_STATUS} == PaymentTransactionConst::PAYMENT_STATUS['SUCCESSFUL'] || ($userBooking->{PaymentTransaction::COL_PAYMENT_STATUS} == PaymentTransactionConst::PAYMENT_STATUS['AWAITING'] && $userBooking->{PaymentTransaction::COL_PAYMENT_PROVIDER} == UserBookingConst::PAYMENT_PROVIDER['AT_HOTEL']))
            && $now <= $expireTimeProcessingBooking
            && in_array($userBooking->{UserBooking::COL_BOOKING_STATUS}, [
                UserBookingConst::BOOKING_STATUS['AWAITING_CHECKIN'],
                UserBookingConst::BOOKING_STATUS['COMPLETED'],
                UserBookingConst::BOOKING_STATUS['CANCELLED'],
                UserBookingConst::BOOKING_STATUS['NO_SHOW'],
                UserBookingConst::BOOKING_STATUS['RECEIVED'],
            ])
            && !$isExistsRefunded
        ) {
            $userBooking->{UserBooking::VAR_G2J_HANDLE_BOOKING} = true;
        }

        $userBooking->{UserBooking::VAR_IS_REFUNDED_POINT} = $isExistsRefunded;
        $userBooking->{UserBooking::VAR_ALLOW_REFUND_POINT} = true;
        if (!$userBooking->{UserBooking::VAR_IS_REFUNDED_POINT}) {
            $createTime = $userBooking->{UserBooking::COL_CREATE_TIME};
            // If booking use point in old flow, will not be show refund point button
            if (Carbon::parse($createTime)->timestamp <= Carbon::parse(config('go2joy.remake_reward_point_released_time'))->timestamp) {
                $userBooking->{UserBooking::VAR_ALLOW_REFUND_POINT} = false;
            }
        }
        $userBooking->{UserBooking::VAR_REFUND_POINT_TIME} = null;
        $userBooking->{UserBooking::VAR_STAFF_REFUND_POINT_NAME} = null;
        $userBooking->{UserBooking::VAR_REFUNDED_POINT} = 0;
        if ($isExistsRefunded) {
            $mileagePointTransactionHistory = $this->mileagePointTransactionHistoryRepository->findRefundedPointStatusViaUserBookingSn($userBooking->{UserBooking::COL_SN});
            if (!empty($mileagePointTransactionHistory)) {
                $userBooking->{UserBooking::VAR_REFUNDED_POINT} = $mileagePointTransactionHistory->{MileagePointTransactionHistory::COL_ACTUAL_POINT};
            }

            $bookingActionHistory = $this->bookingActionHistoryRepository->findRefundPointAction($userBooking->{UserBooking::COL_SN});
            if (!empty($bookingActionHistory)) {
                $createTime = $bookingActionHistory->{BookingActionHistory::COL_CREATE_TIME};
                $actionUserSn = $bookingActionHistory->{BookingActionHistory::COL_ACTION_USER_SN};
                if ($actionUserSn == StaffConst::SYSTEM) {
                    $userId = app()->getLocale() == LocaleConst::ENGLISH ? 'System' : 'Hệ thống';
                } else {
                    $staff = $this->staffRepository->find($actionUserSn, [Staff::COL_USER_ID]);
                    $userId = $staff->{Staff::COL_USER_ID};
                }
                $userBooking->{UserBooking::VAR_REFUND_POINT_TIME} = Carbon::parse($createTime)->toDateTimeString();
                $userBooking->{UserBooking::VAR_STAFF_REFUND_POINT_NAME} = $userId;
            }
        }

        $userBooking->{UserBooking::VAR_REFUND_POINT_BOOKING} = false;
        if ($userBooking->{UserBooking::COL_MILEAGE_POINT} > 0) {
            $userBooking->{UserBooking::VAR_REFUND_POINT_BOOKING} = true;
        }
        if ($this->mileagePointTransactionHistoryRepository->isOldActivePoint($userBooking->{UserBooking::COL_SN})) {
            $userBooking->{UserBooking::VAR_REFUND_POINT_BOOKING} = false;
        }
        $bookingDirectDiscountHistory = BookingDirectDiscountHistory::where(BookingDirectDiscountHistory::COL_USER_BOOKING_SN, $userBooking->{UserBooking::COL_SN})->get([
            BookingDirectDiscountHistory::COL_DIRECT_DISCOUNT_PROGRAM_SN,
            BookingDirectDiscountHistory::COL_DIRECT_DISCOUNT_PROGRAM_NAME,
        ]);
        $userBooking->{UserBooking::VAR_DIRECT_DISCOUNT_LIST} = $bookingDirectDiscountHistory ?? [];

        return GetBookingDetailOutputDTO::assemble($userBooking, $hotelProductList);
    }

    private function isRequiredApproval(int $userBookingSn): bool
    {
        $requiredApproval = false;
        $numOfRecord = $this->bookingActionHistoryRepository->count([
            [BookingActionHistory::COL_USER_BOOKING_SN, '=', $userBookingSn],
            [BookingActionHistory::COL_WORKING_STATUS, '=', BookingActionHistoryConst::WORKING_STATUS['SOLVED']],
            [BookingActionHistory::COL_ACTION_TYPE, '!=', BookingActionHistoryConst::ACTION_TYPE['TRANSFER']],
        ]);
        if ($numOfRecord > 0) {
            $requiredApproval = true;
        }
        return $requiredApproval;
    }
}
