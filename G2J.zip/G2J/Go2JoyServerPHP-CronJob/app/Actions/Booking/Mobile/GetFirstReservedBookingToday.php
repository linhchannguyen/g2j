<?php

namespace App\Actions\Booking\Mobile;

use App\DTOs\Booking\Mobile\GetFirstReservedBookingTodayInputDTO;
use App\DTOs\Booking\Mobile\GetFirstReservedBookingTodayOutputDTO;
use App\Repositories\Interfaces\UserBookingRepositoryInterface;

class GetFirstReservedBookingToday
{
    public $userBookingRepository;

    public function __construct()
    {
        $this->userBookingRepository = app(UserBookingRepositoryInterface::class);
    }

    public function handle(GetFirstReservedBookingTodayInputDTO $getFirstReservedBookingTodayInputDTO)
    {
        $userBooking = $this->userBookingRepository->findFirstReservedBookingToday($getFirstReservedBookingTodayInputDTO->getAppUserSn());
        if (empty($userBooking)) {
            return new GetFirstReservedBookingTodayOutputDTO();
        }

        return GetFirstReservedBookingTodayOutputDTO::assemble($userBooking);
    }
}