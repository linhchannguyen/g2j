<?php

namespace App\Actions\Booking\Mobile;

use App\DTOs\Booking\Mobile\GetFirstNoShowBookingNoActionInputDTO;
use App\DTOs\Booking\Mobile\GetFirstNoShowBookingNoActionOutputDTO;
use App\Models\HotelImage;
use App\Models\UserBooking;
use App\Repositories\Interfaces\HotelImageRepositoryInterface;
use App\Repositories\Interfaces\UserBookingRepositoryInterface;

class GetFirstNoShowBookingNoAction
{
    public $userBookingRepository;

    public $hotelImageRepository;

    public function __construct()
    {
        $this->userBookingRepository = app(UserBookingRepositoryInterface::class);
        $this->hotelImageRepository = app(HotelImageRepositoryInterface::class);
    }

    public function handle(GetFirstNoShowBookingNoActionInputDTO $getFirstNoShowBookingNoActionInputDTO)
    {
        $userBooking = $this->userBookingRepository->findFirstNoShowBookingNoAction($getFirstNoShowBookingNoActionInputDTO->getAppUserSn());
        if (empty($userBooking)) {
            return new GetFirstNoShowBookingNoActionOutputDTO();
        }
        $hotelImage = $this->hotelImageRepository->findFirstDisplayRoomTypeImage($userBooking->{UserBooking::COL_ROOM_TYPE_SN});
        $userBooking->{UserBooking::VAR_ROOM_TYPE_IMAGE_PATH} = $hotelImage->{HotelImage::COL_IMAGE_PATH} ?? null;

        return GetFirstNoShowBookingNoActionOutputDTO::assemble($userBooking);
    }
}