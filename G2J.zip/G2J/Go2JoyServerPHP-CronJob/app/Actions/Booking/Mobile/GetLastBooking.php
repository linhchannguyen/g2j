<?php

namespace App\Actions\Booking\Mobile;

use App\Constants\UserBooking as UserBookingConst;
use App\DTOs\Booking\Mobile\GetLastBookingInputDTO;
use App\DTOs\Booking\Mobile\GetLastBookingOutputDTO;
use App\Models\HotelImage;
use App\Models\UserBooking;
use App\Models\UserReview;
use App\Repositories\Interfaces\HotelImageRepositoryInterface;
use App\Repositories\Interfaces\UserBookingRepositoryInterface;
use Illuminate\Support\Carbon;

class GetLastBooking
{
    public $userBookingRepository;

    public $hotelImageRepository;

    public function __construct()
    {
        $this->userBookingRepository = app(UserBookingRepositoryInterface::class);
        $this->hotelImageRepository = app(HotelImageRepositoryInterface::class);
    }

    public function handle(GetLastBookingInputDTO $getLastBookingInputDTO)
    {
        if(empty($getLastBookingInputDTO->getAppUserSn())){
            return new GetLastBookingOutputDTO();
        }

        $userBooking = $this->userBookingRepository->findLastBooking($getLastBookingInputDTO->getAppUserSn(), $getLastBookingInputDTO->getBookingStatus());
        if (empty($userBooking)) {
            return new GetLastBookingOutputDTO();
        }
        $hotelImage = $this->hotelImageRepository->findFirstDisplayRoomTypeImage($userBooking->{UserBooking::COL_ROOM_TYPE_SN});
        $userBooking->{UserBooking::VAR_ROOM_TYPE_IMAGE_PATH} = $hotelImage->{HotelImage::COL_IMAGE_PATH} ?? null;
        if (UserBookingConst::BOOKING_STATUS['CHECK-IN'] == $getLastBookingInputDTO->getBookingStatus()) {
            if (UserReview::where(UserReview::COL_USER_BOOKING_SN, $userBooking->{UserBooking::COL_SN})->exists()) {
                $this->userBookingRepository->updateDisplayedPopup($userBooking->{UserBooking::COL_SN});

                return new GetLastBookingOutputDTO();
            }

            return GetLastBookingOutputDTO::assemble($userBooking);
        } else {
            if (UserBookingConst::BOOKING_TYPE['HOURLY'] == $userBooking->{UserBooking::COL_TYPE}) {
                $dateTime = Carbon::parse($userBooking->{UserBooking::COL_CHECK_IN_DATE_PLAN} . " " . $userBooking->{UserBooking::COL_START_TIME});
            } else {
                $dateTime = Carbon::parse($userBooking->{UserBooking::COL_CHECK_IN_DATE_PLAN});
            }
            if ($dateTime->isBefore(Carbon::now())) {
                return GetLastBookingOutputDTO::assemble($userBooking);
            }
        }

        return new GetLastBookingOutputDTO();
    }
}