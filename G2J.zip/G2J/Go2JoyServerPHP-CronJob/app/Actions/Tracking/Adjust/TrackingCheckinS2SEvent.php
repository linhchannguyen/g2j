<?php

namespace App\Actions\Tracking\Adjust;

use App\Constants\Globals\Adjust as AdjustConst;
use App\Constants\Globals\Slack as SlackConst;
use App\Constants\MobileDevice as MobileDeviceConst;
use App\DTOs\Tracking\Adjust\TrackingCheckinS2SEventInputDTO;
use App\DTOs\Tracking\Adjust\TrackingCheckinS2SEventOutputDTO;
use App\Helpers\GenerateHelper;
use App\Helpers\LoggingHelper;
use App\Models\MobileDevice;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

class TrackingCheckinS2SEvent
{
    const ADJUST_TABLE_NAME = 'RAW_DATA_V2';
    const ADJUST_TABLE_RAW_DATA_YEAR = 'RAW_DATA_';

    public function handle(TrackingCheckinS2SEventInputDTO $trackingCheckinS2SEventInputDTO): TrackingCheckinS2SEventOutputDTO
    {
        $mobileDeviceSn = $trackingCheckinS2SEventInputDTO->getMobileDeviceSn();
        $userBookingSn = $trackingCheckinS2SEventInputDTO->getUserBookingSn();
        // Log slack mobile device not found
        if (empty($mobileDeviceSn)) {
            $logMessage = GenerateHelper::logMessage('error', self::class, 'Tracking Checkin S2S Event: Mobile device not found!');
            LoggingHelper::toSlack(SlackConst::CHANNEL['BACKEND_MONITOR'], $logMessage);
            return new TrackingCheckinS2SEventOutputDTO();
        }
        // End log slack mobile device not found

        // Adjust db info
        $eventTokenBookingSuccess = config('adjust.adjust_event_token_booking_success');
        $rawDataYearTable = self::ADJUST_TABLE_RAW_DATA_YEAR . date('Y');
        $rawDataTable = self::ADJUST_TABLE_NAME;
        $rawData = [];
        if (Schema::connection('adjust')->hasTable($rawDataYearTable)) {
            $rawData = DB::connection('adjust')->table($rawDataYearTable)
                ->whereRaw("json_extract(DATA, '$.bookingSn') = '$userBookingSn'")
                ->whereRaw("json_extract(DATA, '$.event') = '$eventTokenBookingSuccess'")
                ->selectRaw("
                    json_extract(DATA, '$.adid') AS adid,
                    json_extract(DATA, '$.idfa') AS idfa,
                    json_extract(DATA, '$.gps_adid') AS gps_adid,
                    json_extract(DATA, '$.idfv') AS idfv,
                    json_extract(DATA, '$.android_id') AS android_id,
                    json_extract(DATA, '$.os_name') AS os_name,
                    json_extract(DATA, '$.mobileDeviceSn') AS mobileDeviceSn
                ")
                ->first();
        }
        
        if (empty($rawData)) {
            $rawData = DB::connection('adjust')->table($rawDataTable)
                ->whereRaw("json_extract(DATA, '$.bookingSn') = '$userBookingSn'")
                ->whereRaw("json_extract(DATA, '$.event') = '$eventTokenBookingSuccess'")
                ->selectRaw("
                    json_extract(DATA, '$.adid') AS adid,
                    json_extract(DATA, '$.idfa') AS idfa,
                    json_extract(DATA, '$.gps_adid') AS gps_adid,
                    json_extract(DATA, '$.idfv') AS idfv,
                    json_extract(DATA, '$.android_id') AS android_id,
                    json_extract(DATA, '$.os_name') AS os_name,
                    json_extract(DATA, '$.mobileDeviceSn') AS mobileDeviceSn
                ")
                ->first();
        }

        if (!empty($rawData)) {
            $adid = $rawData->adid ?? null;
            $idfa = $rawData->idfa ?? null;
            $gps_adid = $rawData->gps_adid ?? null;
            $idfv = $rawData->idfv ?? null;
            $android_id = $rawData->android_id ?? null;
            $osName = $rawData->os_name ?? null;
            $mobileDeviceSn = $rawData->mobileDeviceSn ?? null;
            $data['adid'] = str_replace('"', '', $adid); // Adjust device ID
            $data['idfa'] = str_replace('"', '', $idfa); // Raw IDFA (only iOS) [preferred identifiers]
            $data['gps_adid'] = str_replace('"', '', $gps_adid); // Raw Google advertising ID (Android) [preferred identifiers]
            $data['idfv'] = str_replace('"', '', $idfv); // Raw IDFV (iOS) [backup identifiers]
            $data['android_id'] = str_replace('"', '', $android_id); // Android ID (Android) [backup identifiers]
            $data['osName'] = str_replace('"', '', $osName);
            $data['mobileDeviceSn'] = str_replace('"', '', $mobileDeviceSn);

            // Share custom data
            $callBackParameter = $this->_shareCustomData($data, $userBookingSn);

            $data['callBackParameter'] = urlencode(json_encode($callBackParameter));

            if (!in_array(strtolower($data['osName']), [strtolower(MobileDeviceConst::OS_STR[1]), strtolower(MobileDeviceConst::OS_STR[2])])) {
                LoggingHelper::logAdjust(AdjustConst::EVENT_CHECKIN_SUCCESSFULLY, 'Tracking Checkin S2S Event: OS not supported', $data);
                return new TrackingCheckinS2SEventOutputDTO();
            }

            $updateDeviceFlag = $this->_checkUpdateMobileDevice($data);
            if ($updateDeviceFlag) {
                LoggingHelper::logAdjust(AdjustConst::EVENT_CHECKIN_SUCCESSFULLY, AdjustConst::DEVICE_IDENTIFIER_UPDATE_FLAG, $data);
            }

            return TrackingCheckinS2SEventOutputDTO::assemble($data);
        }
        $dataInfo = [
            'mobileDeviceSn' => $mobileDeviceSn,
            'userBookingSn' => $userBookingSn,
        ];
        LoggingHelper::logAdjust(
            AdjustConst::EVENT_CHECKIN_SUCCESSFULLY,
            'Tracking Checkin S2S Event: Request doesn\'t contain device identifiers',
            $dataInfo
        );

        return new TrackingCheckinS2SEventOutputDTO();
    }

    private function _shareCustomData(array $data, int $userBookingSn): array
    {
        $callBackParameter['bookingSn'] = "" . $userBookingSn;
        $callBackParameter['mobileDeviceSn'] = "" . $data['mobileDeviceSn'];
        $callBackParameter['os_name'] = $data['osName'];
        if (!empty($data['idfa'])) {
            $callBackParameter['idfa'] = $data['idfa'];
        }
        if (!empty($data['gps_adid'])) {
            $callBackParameter['gps_adid'] = $data['gps_adid'];
        }
        if (!empty($data['idfv'])) {
            $callBackParameter['idfv'] = $data['idfv'];
        }
        if (!empty($data['android_id'])) {
            $callBackParameter['android_id'] = $data['android_id'];
        }
        return $callBackParameter;
    }

    private function _checkUpdateMobileDevice(array &$data): bool
    {
        if (!empty($data['mobileDeviceSn'])) {
            $mobileDeviceG2J = MobileDevice::where(MobileDevice::COL_SN, $data['mobileDeviceSn'])
                ->first([
                    MobileDevice::COL_MKT_CODE,
                    MobileDevice::COL_MKT_CODE2,
                    MobileDevice::COL_OS,
                ]);
            $osG2J = $mobileDeviceG2J->{MobileDevice::COL_OS} ?? '';
            $os = '';
            switch ($osG2J) {
                case MobileDeviceConst::OS['IOS']: {
                        $os = strtolower(MobileDeviceConst::OS_STR[$osG2J]);
                    }
                    break;
                case MobileDeviceConst::OS['ANDROID']: {
                        $os = strtolower(MobileDeviceConst::OS_STR[$osG2J]);
                    }
                    break;
                default:
                    break;
            }
            $mktCode = $mobileDeviceG2J->{MobileDevice::COL_MKT_CODE} ?? '';
            $mktCode2 = $mobileDeviceG2J->{MobileDevice::COL_MKT_CODE2} ?? '';
            $data['mktCode'] = $mktCode;
            $data['mktCode2'] = $mktCode2;
            $data['os'] = $os;
            if (
                empty($os) || empty($data['osName'])
                || $os != strtolower($data['osName'])
                || $mktCode2 != $data['adid']
            ) {
                return true;
            }
            // If adjust's preferred identifiers does not match device
            if ((!empty($data['idfa']) && $mktCode != $data['idfa']) || (!empty($data['gps_adid']) && $mktCode != $data['gps_adid'])) {
                return true;
            }
            // If adjust's backup identifiers does not match device
            if ((!empty($data['idfv']) && $mktCode != $data['idfv']) || (!empty($data['android_id']) && $mktCode != $data['android_id'])) {
                return true;
            }
        }
        return false;
    }
}
