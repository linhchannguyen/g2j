<?php

namespace App\Actions\Tracking\Amplitude;

use App\Constants\Globals\Message;
use App\Constants\Globals\Slack;
use App\Constants\MobileDevice as MobileDeviceConst;
use App\Constants\Hotel as HotelConst;
use App\Constants\Setting as SettingConst;
use App\Constants\UserBooking as UserBookingConst;
use App\DTOs\Tracking\Amplitude\TrackingUpdateBookingStatusEventOutputDTO;
use App\Helpers\ConvertHelper;
use App\Helpers\GenerateHelper;
use App\Helpers\LoggingHelper;
use App\Models\AmplitudeChangeUserBookingStatus;
use App\Models\AmplitudeUserBooking;
use App\Models\AppUserSetting;
use App\Models\Country;
use App\Models\Hotel;
use App\Models\MobileDevice;
use App\Models\Setting;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;
use stdClass;

class TrackingUpdateBookingStatusEvent
{
    const EVENT_TYPE = "Update Booking Status";

    public function handle(stdClass $amplitudeChangeUserBookingStatus): TrackingUpdateBookingStatusEventOutputDTO
    {
        $userBookingSn = $amplitudeChangeUserBookingStatus->{AmplitudeChangeUserBookingStatus::COL_USER_BOOKING_SN};
        // Log slack mobile device not found
        if (empty($amplitudeChangeUserBookingStatus->{AmplitudeChangeUserBookingStatus::COL_MOBILE_DEVICE_SN})) {
            $logMessage = GenerateHelper::logMessage('error', self::class, 'Tracking Event Update Booking Status: Mobile device not found!');
            LoggingHelper::toSlack(Slack::CHANNEL['BACKEND_MONITOR'], $logMessage);
            return new TrackingUpdateBookingStatusEventOutputDTO();
        }
        // End log slack mobile device not found
        $hotel = DB::connection('replica')->table(Hotel::TABLE_NAME)->where(Hotel::COL_SN, $amplitudeChangeUserBookingStatus->{AmplitudeChangeUserBookingStatus::COL_HOTEL_SN})->first();
        $origin = $hotel->{Hotel::COL_ORIGIN} ?? null;

        $duration = $this->_getDuration(
            $amplitudeChangeUserBookingStatus->{AmplitudeChangeUserBookingStatus::COL_HOTEL_SN},
            $amplitudeChangeUserBookingStatus->{AmplitudeChangeUserBookingStatus::COL_TYPE},
            $amplitudeChangeUserBookingStatus->{AmplitudeChangeUserBookingStatus::COL_CHECK_IN_DATE_PLAN},
            $amplitudeChangeUserBookingStatus->{AmplitudeChangeUserBookingStatus::COL_START_TIME},
            $amplitudeChangeUserBookingStatus->{AmplitudeChangeUserBookingStatus::COL_END_TIME},
            $amplitudeChangeUserBookingStatus->{AmplitudeChangeUserBookingStatus::COL_END_DATE},
            $origin
        );
        $amplitudeChangeUserBookingStatus->{AmplitudeChangeUserBookingStatus::COL_START_TIME} = $duration['startTime'];
        $amplitudeChangeUserBookingStatus->{AmplitudeChangeUserBookingStatus::COL_END_TIME} = $duration['endTime'];
        $amplitudeChangeUserBookingStatus->{AmplitudeChangeUserBookingStatus::COL_CHECK_IN_DATE_PLAN} = $duration['checkInDatePlan'];
        $amplitudeChangeUserBookingStatus->{AmplitudeChangeUserBookingStatus::COL_END_DATE} = $duration['endDate'];

        $amplitudeChangeUserBookingStatus->{AmplitudeChangeUserBookingStatus::AS_INVENTORY} = "Go2Joy";
        if (HotelConst::ORIGIN['AGODA'] == $origin) {
            $amplitudeChangeUserBookingStatus->{AmplitudeChangeUserBookingStatus::AS_INVENTORY} = "Agoda";
        }
        $amplitudeChangeUserBookingStatus->{AmplitudeChangeUserBookingStatus::AS_BOOKING_TYPE} = "Daily";
        if ($amplitudeChangeUserBookingStatus->{AmplitudeChangeUserBookingStatus::COL_TYPE} == UserBookingConst::BOOKING_TYPE['HOURLY']) {
            $amplitudeChangeUserBookingStatus->{AmplitudeChangeUserBookingStatus::AS_BOOKING_TYPE} = "Hourly";
        } else if ($amplitudeChangeUserBookingStatus->{AmplitudeChangeUserBookingStatus::COL_TYPE} == UserBookingConst::BOOKING_TYPE['OVERNIGHT']) {
            $amplitudeChangeUserBookingStatus->{AmplitudeChangeUserBookingStatus::AS_BOOKING_TYPE} = "Overnight";
        }
        $amplitudeChangeUserBookingStatus->{AmplitudeChangeUserBookingStatus::AS_PRODUCT} = "G2J_app";
        if (UserBookingConst::SOURCE['MOMO'] == $amplitudeChangeUserBookingStatus->{AmplitudeChangeUserBookingStatus::COL_SOURCE}) {
            $amplitudeChangeUserBookingStatus->{AmplitudeChangeUserBookingStatus::AS_PRODUCT} = "Momo_app";
        }
        // Generate booking no when create new booking
        $bookingNo = $amplitudeChangeUserBookingStatus->{AmplitudeChangeUserBookingStatus::COL_BOOKING_NO};
        if (empty($bookingNo)) {
            $bookingNo = GenerateHelper::bookingNo($amplitudeChangeUserBookingStatus->{AmplitudeChangeUserBookingStatus::COL_USER_BOOKING_SN});
            $amplitudeChangeUserBookingStatus->{AmplitudeChangeUserBookingStatus::COL_BOOKING_NO} = $bookingNo;
        }

        $amplitudeSource = DB::connection('replica')->table(AmplitudeUserBooking::TABLE_NAME)->where(AmplitudeUserBooking::COL_USER_BOOKING_SN, $userBookingSn)->first([AmplitudeUserBooking::COL_EVENT]);

        $userBookingOption = DB::connection('replica')->table('USER_BOOKING as userBooking')
            ->leftJoin('MOBILE_DEVICE as mobileDevice', function ($leftJoin) {
                $leftJoin->on('mobileDevice.SN', '=', 'userBooking.MOBILE_DEVICE_SN');
            })->leftJoin('COUNTRY as country', function ($leftJoin) {
                $leftJoin->on('country.SN', '=', 'mobileDevice.COUNTRY_SN');
            })->leftJoin('USER_SETTING as userSetting', function ($leftJoin) {
                $leftJoin->on('userSetting.APP_USER_SN', '=', 'userBooking.APP_USER_SN');
                $leftJoin->on('userSetting.MOBILE_DEVICE_SN', '=', 'mobileDevice.SN');
            })
            ->where('userBooking.SN', $userBookingSn)
            ->first([
                'mobileDevice.OS',
                'mobileDevice.OS_VERSION',
                'mobileDevice.PHONE_MODEL',
                'mobileDevice.DEVICE_CODE',
                'country.NAME',
                'userSetting.LANGUAGE',
            ]);
        $country = $userBookingOption->{Country::COL_NAME} ?? '';
        $language = MobileDeviceConst::LANGUAGE_STR[$userBookingOption->{AppUserSetting::COL_LANGUAGE}] ?? '';
        $platform = MobileDeviceConst::OS_STR[$userBookingOption->{MobileDevice::COL_OS}] ?? '';
        $osVersion = '';
        if (!empty($userBookingOption->{MobileDevice::COL_OS_VERSION})) {
            $osVersion = " " . $userBookingOption->{MobileDevice::COL_OS_VERSION};
        }
        $device_type = $userBookingOption->{MobileDevice::COL_PHONE_MODEL} ?? '';
        $options["event_type"] = self::EVENT_TYPE;
        $options["time"] = round(strtotime($amplitudeChangeUserBookingStatus->{AmplitudeChangeUserBookingStatus::COL_CREATE_TIME}) * 1000);
        $options["language"] = $language;
        $options["country"] = $country;
        $options["os_name"] = strtolower($platform) . $osVersion;
        $options["platform"] = $platform;
        $options["device_type"] = $device_type;
        $userId = $amplitudeChangeUserBookingStatus->{AmplitudeChangeUserBookingStatus::COL_APP_USER_SN} ?? "";
        if ($userId) {
            $options['user_id'] = $userId;
        } else {
            $deviceCode = $userBookingOption->{MobileDevice::COL_DEVICE_CODE} ?? null;
            $options['device_id'] = $deviceCode;
        }
        return TrackingUpdateBookingStatusEventOutputDTO::assemble($amplitudeChangeUserBookingStatus, $amplitudeSource, $options);
    }

    private function _getDuration($hotelSn, $type, $checkInDatePlan, $startTime, $endTime, $endDate, $origin): ?array
    {
        $setting = $this->getHotelSetting(SettingConst::COMMON_TYPE['BOOKING'], SettingConst::CLASS_NO['03'], $hotelSn);
        $startDaily = ConvertHelper::getTimeZero($setting->{Setting::COL_NUMDATA4});
        $endDaily = ConvertHelper::getTimeZero($setting->{Setting::COL_NUMDATA1});
        $startOvernight = ConvertHelper::getTimeZero($setting->{Setting::COL_NUMDATA2});
        $endOvernight = ConvertHelper::getTimeZero($setting->{Setting::COL_NUMDATA3});
        switch ($type) {
            case UserBookingConst::BOOKING_TYPE['HOURLY']:
                $checkIn = "$checkInDatePlan $startTime";
                $checkOut = "$checkInDatePlan $endTime";

                $duration = (Carbon::parse($checkOut)->timestamp - Carbon::parse($checkIn)->timestamp) / 3600; // N hours

                return [
                    'startTime' => $startTime,
                    'endTime' => $endTime,
                    'checkInDatePlan' => $checkInDatePlan,
                    'endDate' => $checkInDatePlan,
                    'durationStr' => ConvertHelper::getMessage(Message::MSG_MOBILE_USER_BOOKING, 'durationInHours', ['duration' => $duration]),
                ];
            case UserBookingConst::BOOKING_TYPE['OVERNIGHT']:
                $nextDay = Carbon::parse($checkInDatePlan)->addDay()->toDateString();

                $duration = 1; // 1 night

                return [
                    'startTime' => $startOvernight,
                    'endTime' => $endOvernight,
                    'checkInDatePlan' => $checkInDatePlan,
                    'endDate' => $nextDay,
                    'durationStr' => ConvertHelper::getMessage(Message::MSG_MOBILE_USER_BOOKING, 'durationInNights'),
                ];
            case UserBookingConst::BOOKING_TYPE['DAILY']:
                if ($origin == HotelConst::ORIGIN['AGODA']) {
                    $setting = $this->getHotelSetting(SettingConst::COMMON_TYPE['INTEGRATION'], SettingConst::CLASS_NO['01'], $hotelSn);
                    $startDaily = $setting->{Setting::COL_CHARDATA1} ?? '14:00';
                    $endDaily = $setting->{Setting::COL_CHARDATA4} ?? '12:00';
                }

                $duration = (Carbon::parse($endDate)->timestamp - Carbon::parse($checkInDatePlan)->timestamp) / 3600 / 24; // N days

                return [
                    'startTime' => $startDaily,
                    'endTime' => $endDaily,
                    'checkInDatePlan' => $checkInDatePlan,
                    'endDate' => $endDate,
                    'durationStr' => ConvertHelper::getMessage(Message::MSG_MOBILE_USER_BOOKING, 'durationInDays', ['duration' => $duration]),
                ];
        }

        return null;
    }


    private function getHotelSetting($commonNo, $classNo, $hotelSn = HotelConst::GO2JOY)
    {
        $setting = DB::connection('replica')->table('SETTING')->where([
            ['HOTEL_SN', '=', $hotelSn],
            ['COMMON_NO', '=', $commonNo],
            ['CLASS_NO', '=', $classNo],
        ])->first();
        if (empty($setting)) {
            $setting = DB::connection('replica')->table('SETTING')->where([
                ['HOTEL_SN', '=', HotelConst::GO2JOY],
                ['COMMON_NO', '=', $commonNo],
                ['CLASS_NO', '=', $classNo],
            ])->first();
        }

        return $setting;
    }
}
