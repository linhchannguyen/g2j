<?php

namespace App\Actions\Tracking\Amplitude;

use App\Constants\Globals\Message;
use App\Constants\Globals\Slack;
use App\Constants\MobileDevice as MobileDeviceConst;
use App\Constants\Hotel as HotelConst;
use App\Constants\Setting as SettingConst;
use App\Constants\UserBooking as UserBookingConst;
use App\DTOs\Tracking\Amplitude\TrackingCheckinEventInputDTO;
use App\DTOs\Tracking\Amplitude\TrackingCheckinEventOutputDTO;
use App\Helpers\CommonHelper;
use App\Helpers\ConvertHelper;
use App\Helpers\GenerateHelper;
use App\Helpers\LoggingHelper;
use App\Models\AmplitudeUserBooking;
use App\Models\AppUserSetting;
use App\Models\Country;
use App\Models\Hotel;
use App\Models\MobileDevice;
use App\Models\Province;
use App\Models\Setting;
use App\Models\UserBooking;
use App\Repositories\Interfaces\CouponRepositoryInterface;
use App\Repositories\Interfaces\UserBookingRepositoryInterface;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;

class TrackingCheckinEvent
{
    const EVENT_TYPE = "Checkin";

    /** @var UserBookingRepositoryInterface */
    protected $userBookingRepository;
    /** @var CouponRepositoryInterface */
    protected $couponRepository;

    public function __construct(
        UserBookingRepositoryInterface $userBookingRepository,
        CouponRepositoryInterface      $couponRepository
    ) {
        $this->userBookingRepository = $userBookingRepository;
        $this->couponRepository = $couponRepository;
    }

    public function handle(TrackingCheckinEventInputDTO $trackingCheckinEventInputDTO): TrackingCheckinEventOutputDTO
    {
        $userBookingSn = $trackingCheckinEventInputDTO->getUserBookingSn();
        $userBooking = $this->userBookingRepository->findUserBookingDetail($userBookingSn);
        // Log slack mobile device not found
        if (empty($userBooking->{UserBooking::COL_MOBILE_DEVICE_SN})) {
            $logMessage = GenerateHelper::logMessage('error', self::class, 'Tracking Event Checkin: Mobile device not found!');
            LoggingHelper::toSlack(Slack::CHANNEL['BACKEND_MONITOR'], $logMessage);
            return new TrackingCheckinEventOutputDTO();
        }
        // End log slack mobile device not found

        $duration = $this->_getDuration(
            $userBooking->{UserBooking::COL_HOTEL_SN},
            $userBooking->{UserBooking::COL_TYPE},
            $userBooking->{UserBooking::COL_CHECK_IN_DATE_PLAN},
            $userBooking->{UserBooking::COL_START_TIME},
            $userBooking->{UserBooking::COL_END_TIME},
            $userBooking->{UserBooking::COL_END_DATE},
            $userBooking->{Hotel::COL_ORIGIN}
        );
        $userBooking->{UserBooking::COL_START_TIME} = $duration['startTime'];
        $userBooking->{UserBooking::COL_END_TIME} = $duration['endTime'];
        $userBooking->{UserBooking::COL_CHECK_IN_DATE_PLAN} = $duration['checkInDatePlan'];
        $userBooking->{UserBooking::COL_END_DATE} = $duration['endDate'];

        $coupon = null;
        $couponIssuedSn = $userBooking->{UserBooking::COL_COUPON_ISSUED_SN} ?? null;
        if (!empty($couponIssuedSn)) {
            $coupon = $this->couponRepository->findByCouponIssuedSn($couponIssuedSn);
        }

        $amplitudeSource = AmplitudeUserBooking::where(AmplitudeUserBooking::COL_USER_BOOKING_SN, $userBookingSn)->first([AmplitudeUserBooking::COL_EVENT]);

        $province = DB::table('MOBILE_DEVICE as mobileDevice')->join('PROVINCE as province', function ($join) {
            $join->on('province.SN', '=', 'mobileDevice.PROVINCE_SN');
        })->where('mobileDevice.SN', $userBooking->{UserBooking::COL_MOBILE_DEVICE_SN})
            ->first([
                Province::COL_NAME
            ]);

        $userBookingOption = DB::table('USER_BOOKING as userBooking')
            ->leftJoin('MOBILE_DEVICE as mobileDevice', function ($leftJoin) {
                $leftJoin->on('mobileDevice.SN', '=', 'userBooking.MOBILE_DEVICE_SN');
            })->leftJoin('COUNTRY as country', function ($leftJoin) {
                $leftJoin->on('country.SN', '=', 'mobileDevice.COUNTRY_SN');
            })->leftJoin('USER_SETTING as userSetting', function ($leftJoin) {
                $leftJoin->on('userSetting.APP_USER_SN', '=', 'userBooking.APP_USER_SN');
                $leftJoin->on('userSetting.MOBILE_DEVICE_SN', '=', 'mobileDevice.SN');
            })
            ->where('userBooking.SN', $userBookingSn)
            ->first([
                'mobileDevice.OS',
                'mobileDevice.OS_VERSION',
                'mobileDevice.PHONE_MODEL',
                'mobileDevice.DEVICE_CODE',
                'country.NAME',
                'userSetting.LANGUAGE',
            ]);
        $country = $userBookingOption->{Country::COL_NAME} ?? '';
        $language = MobileDeviceConst::LANGUAGE_STR[$userBookingOption->{AppUserSetting::COL_LANGUAGE}] ?? '';
        $platform = MobileDeviceConst::OS_STR[$userBookingOption->{MobileDevice::COL_OS}] ?? '';
        $osVersion = '';
        if (!empty($userBookingOption->{MobileDevice::COL_OS_VERSION})) {
            $osVersion = " " . $userBookingOption->{MobileDevice::COL_OS_VERSION};
        }
        $device_type = $userBookingOption->{MobileDevice::COL_PHONE_MODEL} ?? '';
        $options["event_type"] = self::EVENT_TYPE;
        $options["language"] = $language;
        $options["country"] = $country;
        $options["os_name"] = strtolower($platform) . $osVersion;
        $options["platform"] = $platform;
        $options["device_type"] = $device_type;
        $userId = $userBooking->{UserBooking::COL_APP_USER_SN} ?? "";
        if ($userId) {
            $options['user_id'] = $userId;
        } else {
            $deviceCode = $userBookingOption->{MobileDevice::COL_DEVICE_CODE} ?? null;
            $options['device_id'] = $deviceCode;
        }
        return TrackingCheckinEventOutputDTO::assemble($userBooking, $coupon, $amplitudeSource, $province, $options);
    }

    private function _getDuration($hotelSn, $type, $checkInDatePlan, $startTime, $endTime, $endDate, $origin): ?array
    {
        $setting = CommonHelper::getHotelSetting(SettingConst::COMMON_TYPE['BOOKING'], SettingConst::CLASS_NO['03'], $hotelSn);
        $startDaily = ConvertHelper::getTimeZero($setting->{Setting::COL_NUMDATA4});
        $endDaily = ConvertHelper::getTimeZero($setting->{Setting::COL_NUMDATA1});
        $startOvernight = ConvertHelper::getTimeZero($setting->{Setting::COL_NUMDATA2});
        $endOvernight = ConvertHelper::getTimeZero($setting->{Setting::COL_NUMDATA3});
        switch ($type) {
            case UserBookingConst::BOOKING_TYPE['HOURLY']:
                $checkIn = "$checkInDatePlan $startTime";
                $checkOut = "$checkInDatePlan $endTime";

                $duration = (Carbon::parse($checkOut)->timestamp - Carbon::parse($checkIn)->timestamp) / 3600; // N hours

                return [
                    'startTime' => $startTime,
                    'endTime' => $endTime,
                    'checkInDatePlan' => $checkInDatePlan,
                    'endDate' => $checkInDatePlan,
                    'durationStr' => ConvertHelper::getMessage(Message::MSG_MOBILE_USER_BOOKING, 'durationInHours', ['duration' => $duration]),
                ];
            case UserBookingConst::BOOKING_TYPE['OVERNIGHT']:
                $nextDay = Carbon::parse($checkInDatePlan)->addDay()->toDateString();

                $duration = 1; // 1 night

                return [
                    'startTime' => $startOvernight,
                    'endTime' => $endOvernight,
                    'checkInDatePlan' => $checkInDatePlan,
                    'endDate' => $nextDay,
                    'durationStr' => ConvertHelper::getMessage(Message::MSG_MOBILE_USER_BOOKING, 'durationInNights'),
                ];
            case UserBookingConst::BOOKING_TYPE['DAILY']:
                if ($origin == HotelConst::ORIGIN['AGODA']) {
                    $setting = CommonHelper::getHotelSetting(SettingConst::COMMON_TYPE['INTEGRATION'], SettingConst::CLASS_NO['01'], $hotelSn);
                    $startDaily = $setting->{Setting::COL_CHARDATA1} ?? '14:00';
                    $endDaily = $setting->{Setting::COL_CHARDATA4} ?? '12:00';
                }

                $duration = (Carbon::parse($endDate)->timestamp - Carbon::parse($checkInDatePlan)->timestamp) / 3600 / 24; // N days

                return [
                    'startTime' => $startDaily,
                    'endTime' => $endDaily,
                    'checkInDatePlan' => $checkInDatePlan,
                    'endDate' => $endDate,
                    'durationStr' => ConvertHelper::getMessage(Message::MSG_MOBILE_USER_BOOKING, 'durationInDays', ['duration' => $duration]),
                ];
        }

        return null;
    }
}
