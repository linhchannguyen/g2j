<?php

namespace App\Actions\Common;

use App\Constants\Activity as ActivityConst;
use App\Constants\Globals\Locale as LocaleConst;
use App\Constants\Staff as StaffConst;
use App\DTOs\Activity\GetScreenDataActivityOutputDTO;
use App\Helpers\CommonHelper;
use App\Models\ActivityFilter;
use App\Repositories\Interfaces\ActivityFilterRepositoryInterface;
use Illuminate\Support\Collection;

class SendExportFileMail
{
    protected $activityFilterRepository;

    public function __construct(
        ActivityFilterRepositoryInterface $activityFilterRepository
    )
    {
        $this->activityFilterRepository = $activityFilterRepository;
    }

    public function handle(): GetScreenDataActivityOutputDTO
    {

    }
}
