<?php

namespace App\Actions\Activity;

use App\Constants\Activity as ActivityConst;
use App\Constants\Globals\Locale as LocaleConst;
use App\Constants\Staff as StaffConst;
use App\DTOs\Activity\GetScreenDataActivityOutputDTO;
use App\Helpers\CommonHelper;
use App\Models\ActivityFilter;
use App\Repositories\Interfaces\ActivityFilterRepositoryInterface;
use Illuminate\Support\Collection;

class GetScreenDataActivity
{
    const FILE_LANGUAGE_NAME = 'activity';

    protected $activityFilterRepository;

    public function __construct(
        ActivityFilterRepositoryInterface $activityFilterRepository
    )
    {
        $this->activityFilterRepository = $activityFilterRepository;
    }

    public function handle(): GetScreenDataActivityOutputDTO
    {
        $activityFilter = $this->activityFilterRepository->findActivityFilter();
        $departmentRequestVi = $this->_toTransDepartmentRequest($activityFilter, StaffConst::DEPARTMENT_REQUEST, LocaleConst::VIETNAMESE['VI']);
        $departmentRequestEn = $this->_toTransDepartmentRequest($activityFilter, StaffConst::DEPARTMENT_REQUEST, LocaleConst::ENGLISH);
        $statusVi = $this->_toTransStatus(ActivityConst::STATUS, LocaleConst::VIETNAMESE['VI']);
        $statusEn = $this->_toTransStatus(ActivityConst::STATUS, LocaleConst::ENGLISH);
        return GetScreenDataActivityOutputDTO::assemble($departmentRequestVi, $departmentRequestEn, $statusVi, $statusEn);
    }

    private function _toTransDepartmentRequest(Collection $activityFilter, array $departmentRequest, string $locale): array
    {
        $_departmentRequest = [];
        foreach ($activityFilter as $value) {
            $_departmentRequest[] = [
                'value' => $departmentRequest[$value->{ActivityFilter::COL_DEPARTMENT_REQUEST}],
                'key' => CommonHelper::getMessage(self::FILE_LANGUAGE_NAME, $departmentRequest[$value->{ActivityFilter::COL_DEPARTMENT_REQUEST}], [], $locale)
            ];
        }
        return $_departmentRequest;
    }

    private function _toTransStatus(array $status, string $locale): array
    {
        $_status = [];
        foreach ($status as $key => $value) {
            if ($value != 0) {
                $_status[] = [
                    'value' => $value,
                    'key' => CommonHelper::getMessage(self::FILE_LANGUAGE_NAME, strtolower($key), [], $locale)
                ];
            }
        }
        return $_status;
    }
}
