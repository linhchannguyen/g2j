<?php

namespace App\Actions\Home;

use App\Actions\Article\Mobile\GetArticleList;
use App\Actions\Banner\Mobile\GetBannerList;
use App\Actions\Booking\Mobile\GetFirstNoShowBookingNoAction;
use App\Actions\Booking\Mobile\GetFirstReservedBookingToday;
use App\Actions\Floating\Mobile\GetFloating;
use App\Actions\HotelCollection\Mobile\GetHotelCollectionList;
use App\Actions\HotelCollection\Mobile\GetIconCollectionList;
use App\Constants\Globals\FcmNotification;
use App\Constants\HomeCategory as HomeCategoryConst;
use App\Constants\MobileDevice as MobileDeviceConst;
use App\DTOs\Article\Mobile\GetArticleListInputDTO;
use App\DTOs\Banner\Mobile\GetBannerListInputDTO;
use App\DTOs\Banner\Mobile\GetBannerListOutputDTO;
use App\DTOs\Booking\Mobile\GetFirstNoShowBookingNoActionInputDTO;
use App\DTOs\Booking\Mobile\GetFirstNoShowBookingNoActionOutputDTO;
use App\DTOs\Booking\Mobile\GetFirstReservedBookingTodayInputDTO;
use App\DTOs\Booking\Mobile\GetFirstReservedBookingTodayOutputDTO;
use App\DTOs\Floating\Mobile\GetFloatingInputDTO;
use App\DTOs\Home\GetHomeInputDTO;
use App\DTOs\Home\GetHomeOutputDTO;
use App\DTOs\HotelCollection\Mobile\GetHotelCollectionListInputDTO;
use App\DTOs\HotelCollection\Mobile\GetIconCollectionListInputDTO;
use App\Models\AppUserSetting;
use App\Models\HomeCategory;
use App\Models\MobileDevice;
use App\Models\Province;
use App\Repositories\Interfaces\AppUserSettingRepositoryInterface;
use App\Repositories\Interfaces\HomeCategoryRepositoryInterface;
use App\Repositories\Interfaces\ProvinceRepositoryInterface;
use stdClass;

class GetHome
{
    protected $appUserSettingRepository;

    protected $provinceRepository;

    protected $homeCategoryRepository;

    public function __construct()
    {
        $this->provinceRepository = app(ProvinceRepositoryInterface::class);
        $this->appUserSettingRepository = app(AppUserSettingRepositoryInterface::class);
        $this->homeCategoryRepository = app(HomeCategoryRepositoryInterface::class);
    }

    public function handle(GetHomeInputDTO $getHomeInputDTO)
    {
        $registered = false;
        $bannerList = new GetBannerListOutputDTO();
        $iconCollectionList = null;
        $displayCollectionList = null;
        $article = null;
        $bookingToday = new GetFirstReservedBookingTodayOutputDTO();
        $bookingNoShow = new GetFirstNoShowBookingNoActionOutputDTO();
        if (!empty($getHomeInputDTO->getMobileDevice())) { // check whether this device already registered by some one or not
            $registered = $getHomeInputDTO->getMobileDevice()->{MobileDevice::COL_APP_USER_SN} != null || $getHomeInputDTO->getMobileDevice()->{MobileDevice::COL_FIRST_APP_USER_SN} != null || $getHomeInputDTO->getMobileDevice()->{MobileDevice::COL_LAST_APP_USER_SN} != null;
        }
        // find province
        $prefixOs = MobileDeviceConst::PREFIX_ANDROID;
        if ($getHomeInputDTO->getMobileDevice()->{MobileDevice::COL_OS} == MobileDeviceConst::OS['IOS']) {
            $prefixOs = MobileDeviceConst::PREFIX_IOS;
        }

        $topic = getTopic(null); // find ALL topic
        $province = $this->provinceRepository->find($getHomeInputDTO->getProvinceSn());

        if (!empty($province)) {
            $topic = [$prefixOs . $topic, $prefixOs . getTopic($province->{Province::COL_CODE})]; // topic to send notification to Mobile
        } else {
            $topic = [$prefixOs . $topic]; // topic to send notification to Mobile
        }
        $appUserSetting = $this->appUserSettingRepository->findUserSetting($getHomeInputDTO->getAppUserSn(), $getHomeInputDTO->getMobileDevice()->{MobileDevice::COL_SN});
        if ((empty($appUserSetting) || !empty($appUserSetting->{AppUserSetting::COL_NOTI_FLASH_SALE})) && !empty($province)) {
            $topic[] = $prefixOs . FcmNotification::PREFIX_FS . getTopic($province->{Province::COL_CODE});
        }
        $currentTime = round(microtime(true) * 1000); // get current time for upate User Action

        if (!empty($getHomeInputDTO->getAppUserSn())) {
            $getFirstReservedBookingToday = new GetFirstReservedBookingToday();
            $getFirstReservedBookingTodayInputDTO = new GetFirstReservedBookingTodayInputDTO();
            $getFirstReservedBookingTodayInputDTO->setAppUserSn($getHomeInputDTO->getAppUserSn());
            $bookingToday = $getFirstReservedBookingToday->handle($getFirstReservedBookingTodayInputDTO);

            $getFirstNoShowBookingNoAction = new GetFirstNoShowBookingNoAction();
            $getFirstNoShowBookingNoActionInputDTO = new GetFirstNoShowBookingNoActionInputDTO();
            $getFirstNoShowBookingNoActionInputDTO->setAppUserSn($getHomeInputDTO->getAppUserSn());
            $bookingNoShow = $getFirstNoShowBookingNoAction->handle($getFirstNoShowBookingNoActionInputDTO);
        }

        if (!empty($getHomeInputDTO->getAppUserSn()) || !empty($getHomeInputDTO->getMobileDevice())) {
            $getBannerList = new GetBannerList();
            $getBannerListInputDTO = new GetBannerListInputDTO();
            $getBannerListInputDTO->setProvinceSn($getHomeInputDTO->getProvinceSn());
            $bannerList = $getBannerList->handle($getBannerListInputDTO);
        }
        $getFloating = new GetFloating();
        $getFloatingInputDTO = new GetFloatingInputDTO();
        $floating = $getFloating->handle($getFloatingInputDTO);

        $homeCategoryList = $this->homeCategoryRepository->findHomeCategoryDisplayList();
        foreach ($homeCategoryList as $homeCategory) {
            if (HomeCategoryConst::TYPE['HOTEL_COLLECTION'] == $homeCategory->{HomeCategory::COL_TYPE}) {
                $getHotelCollectionList = new GetHotelCollectionList();
                $getHotelCollectionListInputDTO = new GetHotelCollectionListInputDTO();
                $getHotelCollectionListInputDTO->setAppUserSn($getHomeInputDTO->getAppUserSn());
                $getHotelCollectionListInputDTO->setMobileDeviceSn($getHomeInputDTO->getMobileDevice()->{MobileDevice::COL_SN});
                $getHotelCollectionListInputDTO->setProvinceSn($getHomeInputDTO->getProvinceSn());
                $getHotelCollectionListOutputDTO = $getHotelCollectionList->handle($getHotelCollectionListInputDTO);
                $displayCollectionList = $getHotelCollectionListOutputDTO->toTransport();

                $getIconCollectionList = new GetIconCollectionList();
                $getIconCollectionListInputDTO = new GetIconCollectionListInputDTO();
                $getIconCollectionListInputDTO->setProvinceSn($getHomeInputDTO->getProvinceSn());
                $getIconCollectionListOutputDTO = $getIconCollectionList->handle($getIconCollectionListInputDTO);
                $iconCollectionList = $getIconCollectionListOutputDTO->toTransport();
            } elseif (HomeCategoryConst::TYPE['ARTICLE'] == $homeCategory->{HomeCategory::COL_TYPE}) {
                $getArticleList = new GetArticleList();
                $getArticleListInputDTO = new GetArticleListInputDTO();
                $getArticleListOutputDTO = $getArticleList->handle($getArticleListInputDTO);
                $articleList = $getArticleListOutputDTO->toTransport();
                $article = new stdClass();
                $article->title = $homeCategory->{HomeCategory::COL_TITLE1};
                $article->articleList = !empty($articleList) ? $articleList : [];
            }
        }

        return GetHomeOutputDTO::assemble($topic, $currentTime, $bookingToday, $bookingNoShow, $bannerList, $iconCollectionList, $displayCollectionList, $article, $floating);
    }
}