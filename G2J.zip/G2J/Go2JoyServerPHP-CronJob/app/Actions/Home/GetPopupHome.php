<?php

namespace App\Actions\Home;

use App\Actions\Booking\Mobile\GetLastBooking;
use App\Actions\Coupon\Mobile\GetPopupCouponList;
use App\Actions\Popup\Mobile\GetPopup;
use App\Constants\UserBooking as UserBookingConst;
use App\DTOs\Booking\Mobile\GetLastBookingInputDTO;
use App\DTOs\Coupon\Mobile\GetPopupCouponListInputDTO;
use App\DTOs\Home\GetPopupHomeInputDTO;
use App\DTOs\Home\GetPopupHomeOutputDTO;
use App\DTOs\Popup\Mobile\GetPopupInputDTO;
use App\Models\MobileDevice;

class GetPopupHome
{
    public function handle(GetPopupHomeInputDTO $getPopupHomeInputDTO)
    {
        if (empty($getPopupHomeInputDTO->getAppUserSn()) && empty($getPopupHomeInputDTO->getMobileDevice())) {
            return new GetPopupHomeOutputDTO();
        }

        $getPopup = new GetPopup();
        $getPopupInputDTO = new GetPopupInputDTO();
        $getPopupInputDTO->setProvinceSn($getPopupHomeInputDTO->getProvinceSn());
        $getPopupInputDTO->setMobileDeviceSn($getPopupHomeInputDTO->getMobileDevice()->{MobileDevice::COL_SN});
        $getPopupOutputDTO = $getPopup->handle($getPopupInputDTO);

        $getLastBooking = new GetLastBooking();
        $getLastBookingInputDTO = new GetLastBookingInputDTO();
        $getLastBookingInputDTO->setAppUserSn($getPopupHomeInputDTO->getAppUserSn());
        $getLastBookingInputDTO->setBookingStatus(UserBookingConst::BOOKING_STATUS['CHECK-IN']);
        $getLastBookingOutputDTO = $getLastBooking->handle($getLastBookingInputDTO);

        $getPopupCouponList = new GetPopupCouponList();
        $getPopupCouponListInputDTO = new GetPopupCouponListInputDTO();
        $getPopupCouponListInputDTO->setAppUserSn($getPopupHomeInputDTO->getAppUserSn());
        $couponList = $getPopupCouponList->handle($getPopupCouponListInputDTO);

        return GetPopupHomeOutputDTO::assemble($getPopupHomeInputDTO->getReadAgreePolicy(),$getLastBookingOutputDTO, $getPopupOutputDTO, $couponList);
    }
}