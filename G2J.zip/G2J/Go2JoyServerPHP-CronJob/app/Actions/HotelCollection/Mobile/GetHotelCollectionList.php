<?php

namespace App\Actions\HotelCollection\Mobile;

use App\Actions\Hotel\GetDisplayRuleInternal;
use App\Constants\Globals\Common as CommonConst;
use App\Constants\HotelCollection as HotelCollectionConst;
use App\Constants\HotelOnTop as HotelOnTopConst;
use App\Constants\PromotionGroup as PromotionGroupConst;
use App\Constants\UserBooking as UserBookingConst;
use App\DTOs\Hotel\GetDisplayRuleInternalInputDTO;
use App\DTOs\HotelCollection\Mobile\GetHotelCollectionListInputDTO;
use App\DTOs\HotelCollection\Mobile\GetHotelCollectionListOutputDTO;
use App\Helpers\ConvertHelper;
use App\Http\Resources\MobileV2\PromotionResource;
use App\Http\Resources\MobileV4\HotelResource;
use App\Models\Hotel;
use App\Models\HotelCollection;
use App\Models\PromotionGroup;
use App\Repositories\Interfaces\HotelCollectionRepositoryInterface;
use App\Repositories\Interfaces\HotelRepositoryInterface;
use App\Repositories\Interfaces\PromotionGroupRepositoryInterface;
use Illuminate\Pagination\LengthAwarePaginator;
use Illuminate\Support\Carbon;
use stdClass;

class GetHotelCollectionList
{
    public $hotelCollectionRepository;

    public $hotelRepository;

    public $promotionGroupRepository;

    public function __construct()
    {
        $this->hotelCollectionRepository = app(HotelCollectionRepositoryInterface::class);
        $this->hotelRepository = app(HotelRepositoryInterface::class);
        $this->promotionGroupRepository = app(PromotionGroupRepositoryInterface::class);
    }

    public function handle(GetHotelCollectionListInputDTO $getHotelCollectionListInputDTO)
    {
        $hotelCollectionList = $this->hotelCollectionRepository->findAllHotelCollectionDisplayHome($getHotelCollectionListInputDTO->getProvinceSn());
        foreach ($hotelCollectionList as $hotelCollection) {
            $homeHotelList = [];
            if ($hotelCollection->{HotelCollection::COL_FLASH_SALE}) {
                $homeHotelList = $this->_findHotelFlashSaleList($hotelCollection->{HotelCollection::COL_SN}, $getHotelCollectionListInputDTO->getProvinceSn(), CommonConst::LIMIT_50);
            } elseif ($hotelCollection->{HotelCollection::COL_HOTEL_SEARCHED}) {
                $homeHotelList = $this->_findLimitSearchedHotelList($hotelCollection->{HotelCollection::COL_SN}, $getHotelCollectionListInputDTO->getProvinceSn(), $getHotelCollectionListInputDTO->getAppUserSn(), $getHotelCollectionListInputDTO->getMobileDeviceSn(), CommonConst::LIMIT_ALL);
            } elseif ($hotelCollection->{HotelCollection::COL_HOTEL_FAVORITE}) {
                $homeHotelList = $this->_findLimitFavoriteHotelList($hotelCollection->{HotelCollection::COL_SN}, $getHotelCollectionListInputDTO->getProvinceSn(), $getHotelCollectionListInputDTO->getAppUserSn(), CommonConst::LIMIT_ALL);
            } elseif ($hotelCollection->{HotelCollection::COL_HOTEL_BOOKED}) {
                $homeHotelList = $this->_findLimitHotelBookedList($hotelCollection->{HotelCollection::COL_SN}, $getHotelCollectionListInputDTO->getProvinceSn(), $getHotelCollectionListInputDTO->getAppUserSn(), CommonConst::LIMIT_ALL);
            } elseif ($hotelCollection->{HotelCollection::COL_HOTEL_SUGGESTION}) {
                $homeHotelList = $this->_findLimitHotelSuggestionList($hotelCollection->{HotelCollection::COL_SN}, $getHotelCollectionListInputDTO->getProvinceSn(), CommonConst::LIMIT_ALL);
            } elseif ($hotelCollection->{HotelCollection::COL_PROMOTION_SUGGESTION}) {
                $promotionList = $this->_findLimitPromotionByGroupForApp($getHotelCollectionListInputDTO->getAppUserSn(), $hotelCollection->{HotelCollection::COL_TARGET_SN}, CommonConst::LIMIT_ALL);
                $hotelCollection->{HotelCollection::VAR_PROMOTION_FORM_LIST} = $promotionList;
            } else {
                $homeHotelList = $this->_findLimitHotelListInCollection($hotelCollection, $getHotelCollectionListInputDTO->getProvinceSn(), CommonConst::LIMIT_ALL);
            }
            if ($hotelCollection->{HotelCollection::COL_DISPLAY_TYPE} != HotelCollectionConst::DISPLAY_TYPE['RECT_2_1']) {
                $homeHotelList = array_slice($homeHotelList, 0, 25); // get first 25 items for all collection
            } else {
                $homeHotelList = array_slice($homeHotelList, 0, 3); // get first 3 items for collection rect
            }
            $hotelCollection->{HotelCollection::VAR_HOTEL_FORM_LIST} = $homeHotelList;
        }

        return GetHotelCollectionListOutputDTO::assemble($hotelCollectionList);
    }

    private function _findHotelFlashSaleList($hotelCollectionSn, $provinceSn, $limit)
    {
        $hotelList = $this->hotelRepository->findLimitHotelFlashSaleList($provinceSn, $limit);
        $hotelOnTopList = $this->hotelRepository->findHotelOnTopAtHome(null, $hotelCollectionSn, $provinceSn, HotelOnTopConst::TYPE['COLLECTION'], $limit);
        $hotelOnTopList = $hotelOnTopList->filter(function($hotel) {
            return !empty($hotel->{Hotel::ALIAS_FS_SN});
        })->all();

        $homeHotelList = $this->_arrangeHotelOnTop($hotelList, $hotelOnTopList);

        return $this->_getDisplayRuleInternal($homeHotelList, true);
    }

    private function _arrangeHotelOnTop($hotelList, $hotelOnTopList)
    {
        if (is_array($hotelList)) {
            $hotelList = Collect($hotelList);
        } elseif ($hotelList instanceof LengthAwarePaginator) {
            $hotelList = $hotelList->collect();
        }

        if (is_array($hotelOnTopList)) {
            $hotelOnTopList = Collect($hotelOnTopList);
        } elseif ($hotelOnTopList instanceof LengthAwarePaginator) {
            $hotelOnTopList = $hotelOnTopList->collect();
        }
        $topHotelSnList = $hotelOnTopList->pluck(Hotel::COL_SN)->all();
        $hotelList = $hotelList->filter(function($hotel) use ($topHotelSnList) {
            return !in_array($hotel->{Hotel::COL_SN}, $topHotelSnList);
        });
        $homeHotelList = [];
        if ($hotelOnTopList->isNotEmpty()) {
            array_push($homeHotelList, ...$hotelOnTopList->toArray());
        }
        if ($hotelList->isNotEmpty()) {
            array_push($homeHotelList, ...$hotelList->toArray());
        }

        return $homeHotelList;
    }

    private function _getDisplayRuleInternal($homeHotelList, $flashSale = false)
    {
        $_homeHotelList = [];
        if (empty($homeHotelList)) {
            return $_homeHotelList;
        }
        $getDisplayRuleInternal = new GetDisplayRuleInternal();
        $getDisplayRuleInternalInputDTO = new GetDisplayRuleInternalInputDTO();
        $getDisplayRuleInternalInputDTO->setCheckin(Carbon::now()->toDateString());
        $getDisplayRuleInternalInputDTO->setCheckout(Carbon::now()->toDateString());
        $getDisplayRuleInternalInputDTO->setFlashSale($flashSale);
        $getDisplayRuleInternalInputDTO->setHotelSnList(array_column($homeHotelList, 'SN'));
        $getDisplayRuleInternalOutputDTO = $getDisplayRuleInternal->handle($getDisplayRuleInternalInputDTO);

        foreach ($homeHotelList as $hotel) {
            $_homeHotelList[$hotel->{Hotel::COL_SN}] = HotelResource::toHotelDisplayForm((object)$hotel, UserBookingConst::BOOKING_TYPE['ALL'], $flashSale);
        }

        if (!empty($getDisplayRuleInternalOutputDTO)) {
            foreach ($getDisplayRuleInternalOutputDTO as $key => $hotel) {
                $_homeHotelList[$key]->displayRule = $hotel;
            }
        }

        return array_values($_homeHotelList);
    }

    private function _findLimitSearchedHotelList($hotelCollectionSn, $provinceSn, $appUserSn, $mobileDeviceSn, $limit)
    {
        if (empty($appUserSn) && empty($mobileDeviceSn)) {
            return null;
        }
        $hotelList = $this->hotelRepository->findLimitSearchedHotelList($appUserSn, $mobileDeviceSn, $limit);
        $hotelOnTopList = $this->hotelRepository->findHotelOnTopAtHome(null, $hotelCollectionSn, $provinceSn, HotelOnTopConst::TYPE['COLLECTION'], $limit);
        $homeHotelList = $this->_arrangeHotelOnTop($hotelList, $hotelOnTopList);

        return $this->_getDisplayRuleInternal($homeHotelList);

    }

    private function _findLimitFavoriteHotelList($hotelCollectionSn, $provinceSn, $appUserSn, $limit)
    {
        $hotelList = $this->hotelRepository->findLimitHotelFavoriteList($appUserSn, false, $limit);
        $hotelOnTopList = $this->hotelRepository->findHotelOnTopAtHome(null, $hotelCollectionSn, $provinceSn, HotelOnTopConst::TYPE['COLLECTION'], $limit);
        $homeHotelList = $this->_arrangeHotelOnTop($hotelList, $hotelOnTopList);

        return $this->_getDisplayRuleInternal($homeHotelList);
    }

    private function _findLimitHotelBookedList($hotelCollectionSn, $provinceSn, $appUserSn, $limit)
    {
        $hotelList = $this->hotelRepository->findLimitHotelBookedList($appUserSn, $limit);
        $hotelOnTopList = $this->hotelRepository->findHotelOnTopAtHome(null, $hotelCollectionSn, $provinceSn, HotelOnTopConst::TYPE['COLLECTION'], $limit);
        $homeHotelList = $this->_arrangeHotelOnTop($hotelList, $hotelOnTopList);

        return $this->_getDisplayRuleInternal($homeHotelList);
    }

    private function _findLimitHotelSuggestionList($hotelCollectionSn, $provinceSn, $limit)
    {
        $hotelList = $this->hotelRepository->findLimitHotelSuggestionList($hotelCollectionSn, $provinceSn, $limit);
        $hotelList = $hotelList->shuffle();
        $hotelOnTopList = $this->hotelRepository->findHotelOnTopAtHome(null, $hotelCollectionSn, $provinceSn, HotelOnTopConst::TYPE['COLLECTION'], $limit);
        $homeHotelList = $this->_arrangeHotelOnTop($hotelList, $hotelOnTopList);

        return $this->_getDisplayRuleInternal($homeHotelList);
    }

    private function _findLimitPromotionByGroupForApp($appUserSn, $targetSn, $limit)
    {
        $promotionList = [];
        $promotionGroup = PromotionGroup::where(PromotionGroup::COL_SN, $targetSn)->first([PromotionGroup::COL_STATUS, PromotionGroup::COL_PROMOTION_SN_LIST]);
        if ($promotionGroup->{PromotionGroup::COL_STATUS} == PromotionGroupConst::STATUS['ACTIVE']) {
            $promotionList = $this->promotionGroupRepository->findLimitPromotionListByGroupForApp(ConvertHelper::toArray($promotionGroup->{PromotionGroup::COL_PROMOTION_SN_LIST}),
                $limit);
            $promotionList = PromotionResource::toFormList($promotionList, $appUserSn);
        }

        return PromotionResource::toPromotionFormList($promotionList);
    }

    private function _findLimitHotelListInCollection($hotelCollection, $provinceSn, $limit)
    {
        $collectionSearch = $this->_generateCollectionSearch($hotelCollection, $provinceSn);
        $collectionSearch->provinceSn = $provinceSn;
        $hotelList = $this->hotelRepository->findLimitHotelListInCollection($collectionSearch, $limit);
        $hotelOnTopList = $this->hotelRepository->findHotelOnTopAtHome(null, $hotelCollection->{HotelCollection::COL_SN}, $provinceSn, HotelOnTopConst::TYPE['COLLECTION'], $limit);
        $homeHotelList = $this->_arrangeHotelOnTop($hotelList, $hotelOnTopList);

        return $this->_getDisplayRuleInternal($homeHotelList);

    }

    private function _generateCollectionSearch($hotelCollection, $provinceSn)
    {
        $collectionSearch = new stdClass();
        $collectionSearch->sn = $hotelCollection->{HotelCollection::COL_SN};
        $collectionSearch->promotion = boolval($hotelCollection->{HotelCollection::COL_PROMOTION});
        $collectionSearch->directDiscount = boolval($hotelCollection->{HotelCollection::COL_DIRECT_DISCOUNT});
        $collectionSearch->amenityPackHotel = boolval($hotelCollection->{HotelCollection::COL_AMENITY_PACK_HOTEL});
        $collectionSearch->loveHotel = boolval($hotelCollection->{HotelCollection::COL_LOVE_HOTEL});
        $collectionSearch->travelHotel = boolval($hotelCollection->{HotelCollection::COL_TRAVEL_HOTEL});
        $collectionSearch->hotHotel = boolval($hotelCollection->{HotelCollection::COL_HOT_HOTEL});
        $collectionSearch->newHotel = boolval($hotelCollection->{HotelCollection::COL_NEW_HOTEL});
        $collectionSearch->image360 = boolval($hotelCollection->{HotelCollection::COL_IMAGE360});
        $collectionSearch->hotelReview = boolval($hotelCollection->{HotelCollection::COL_HOTEL_REVIEW});
        $collectionSearch->stamp = boolval($hotelCollection->{HotelCollection::COL_STAMP});
        $collectionSearch->g2jCertified = boolval($hotelCollection->{HotelCollection::COL_G2J_CERTIFIED});
        $collectionSearch->isTet = boolval($hotelCollection->{HotelCollection::COL_TET});
        $collectionSearch->isGo2Choice = boolval($hotelCollection->{HotelCollection::COL_G2J_CERTIFIED});
        $collectionSearch->specialOffer = boolval($hotelCollection->{HotelCollection::COL_DIRECT_DISCOUNT});
        $collectionSearch->quarantine = boolval($hotelCollection->{HotelCollection::COL_QUARANTINE});
        $collectionSearch->hasFilter = 0;
        $collectionSearch->provinceSn = $provinceSn;
        $collectionSearch->hotelFormList = [];

        if ($collectionSearch->promotion || $collectionSearch->directDiscount || $collectionSearch->amenityPackHotel || $collectionSearch->hotHotel || $collectionSearch->newHotel || $collectionSearch->image360 || $collectionSearch->hotelReview || $collectionSearch->stamp || $collectionSearch->g2jCertified || $collectionSearch->isTet || $collectionSearch->specialOffer) {
            $collectionSearch->hasFilter = 1;
        }

        return $collectionSearch;
    }
}