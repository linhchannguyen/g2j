<?php

namespace App\Actions\HotelCollection\Mobile;

use App\Constants\HotelCollection as HotelCollectionConst;
use App\DTOs\HotelCollection\Mobile\GetIconCollectionListInputDTO;
use App\DTOs\HotelCollection\Mobile\GetIconCollectionListOutputDTO;
use App\Repositories\Interfaces\HotelCollectionRepositoryInterface;

class GetIconCollectionList
{
    public $hotelCollectionRepository;

    public function __construct()
    {
        $this->hotelCollectionRepository = app(HotelCollectionRepositoryInterface::class);
    }

    public function handle(GetIconCollectionListInputDTO $getIconCollectionListInputDTO)
    {
        $iconCollectionList = $this->hotelCollectionRepository->findAll(true, HotelCollectionConst::DISPLAY_TYPE['ICON'], $getIconCollectionListInputDTO->getProvinceSn());

        return GetIconCollectionListOutputDTO::assemble($iconCollectionList);
    }
}