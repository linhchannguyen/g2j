<?php

namespace App\Actions\Popup\Mobile;

use App\Constants\Popup as PopupConst;
use App\Constants\Setting as SettingConst;
use App\DTOs\Popup\Mobile\GetPopupInputDTO;
use App\DTOs\Popup\Mobile\GetPopupOutputDTO;
use App\Helpers\CommonHelper;
use App\Models\DeviceShowPopupToday;
use App\Models\Popup;
use App\Models\Setting;
use App\Repositories\Interfaces\DeviceShowPopupTodayRepositoryInterface;
use App\Repositories\Interfaces\PopupRepositoryInterface;
use Illuminate\Support\Carbon;

class GetPopup
{
    protected $popupRepository;

    protected $deviceShowPopupTodayRepository;

    public function __construct()
    {
        $this->popupRepository = app(PopupRepositoryInterface::class);
        $this->deviceShowPopupTodayRepository = app(DeviceShowPopupTodayRepositoryInterface::class);
    }

    public function handle(GetPopupInputDTO $getPopupInputDTO): GetPopupOutputDTO
    {
        $setting = CommonHelper::getHotelSetting(SettingConst::COMMON_TYPE['BANNER_POPUP'], '01');
        $displayType = !empty($setting->{Setting::COL_NUMDATA2}) ? $setting->{Setting::COL_NUMDATA1} : PopupConst::TYPE_OF_DISPLAY['CUSTOM'];
        $popupMaxViewDay = $setting->{Setting::COL_NUMDATA3};
        $popupBothNumOfCustom = $setting->{Setting::COL_NUMDATA4};
        $existToday = 0;
        $popup = null;
        $showPopupToday = $this->deviceShowPopupTodayRepository->numOfShowPopupToday($getPopupInputDTO->getMobileDeviceSn());
        if ($showPopupToday > $popupMaxViewDay) {
            return new GetPopupOutputDTO();
        }
        $popupList = $this->popupRepository->findAllPopupActive($getPopupInputDTO->getProvinceSn())->toArray();
        if (empty($popupList)) {
            return new GetPopupOutputDTO();
        }

        switch ($displayType) {
            case PopupConst::TYPE_OF_DISPLAY['RANDOM']:
                shuffle($popupList);
                break;
            case PopupConst::TYPE_OF_DISPLAY['BOTH']:
                $popupCustomList = array_values(array_chunk($popupList, $popupBothNumOfCustom)[0]);
                $popupList = array_values(array_udiff($popupList, $popupCustomList,
                    function($popup_1, $popup_2) {
                        return $popup_1->sn - $popup_2->sn;
                    }));
                shuffle($popupList);
                array_splice($popupList, 0, 0, $popupCustomList);
                break;
            default:
                break;
        }
        $popupShowTodayList = $this->deviceShowPopupTodayRepository->findListPopupShowTodayByDevice($getPopupInputDTO->getMobileDeviceSn());
        if ($popupShowTodayList->count() < count($popupList)) {
            do {
                if ($existToday > 0) {
                    $popupList = Collect($popupList)->filter(function($item) use ($popup) {
                        return $item->{Popup::COL_SN} != $popup->{Popup::COL_SN};
                    })->toArray();
                    $popup = null;
                }
                if (count($popupList) > 0) {
                    $popup = array_values($popupList)[0];
                    $existToday = $this->deviceShowPopupTodayRepository->existDeviceShowPopupToday($getPopupInputDTO->getMobileDeviceSn(), $popup->{Popup::COL_SN});
                }
            } while ($existToday > 0 && count($popupList) > 0);
        } else {
            $countShow = $popupShowTodayList->map(function($m) {
                return $m->{DeviceShowPopupToday::ALIAS_COUNT_SHOW};
            });
            $sum = $countShow->sum();
            $max = $countShow->max();
            if ($sum < $popupMaxViewDay) {
                if (($sum % $max) > 0 || intdiv($sum, $max) != $popupShowTodayList->count()) {
                    $tempList = $popupShowTodayList->filter(function($f) use ($max) {
                        return $f->{DeviceShowPopupToday::ALIAS_COUNT_SHOW} == $max;
                    });
                    foreach ($tempList as $temp) {
                        $popupList = Collect($popupList)->filter(function($item) use ($temp) {
                            return $item->{Popup::COL_SN} != $temp->{DeviceShowPopupToday::COL_POPUP_SN};
                        })->toArray();
                    }
                }
                if (count($popupList) > 0) {
                    $popup = array_values($popupList)[0];
                }
            }
        }
        if (!empty($popup)) {
            $deviceShowPopupToday = new DeviceShowPopupToday();
            $deviceShowPopupToday->{DeviceShowPopupToday::COL_POPUP_SN} = $popup->{Popup::COL_SN};
            $deviceShowPopupToday->{DeviceShowPopupToday::COL_DEVICE_SN} = $getPopupInputDTO->getMobileDeviceSn();
            $deviceShowPopupToday->{DeviceShowPopupToday::COL_CLICK} = 0;
            $deviceShowPopupToday->{DeviceShowPopupToday::COL_SHOW_DATE} = Carbon::now()->format('Y-m-d');
            $this->deviceShowPopupTodayRepository->create($deviceShowPopupToday->toArray());

            $this->popupRepository->update([Popup::COL_TOTAL_VIEWS => (((int)$popup->{Popup::COL_TOTAL_VIEWS}) + 1)], $popup->{Popup::COL_SN});
        }else{
            return new GetPopupOutputDTO();
        }

        return GetPopupOutputDTO::assemble($popup);
    }
}