<?php

namespace App\Actions\Promotion\DirectDiscount;

use App\Constants\Globals\QueueName as QueueNameConst;
use App\Constants\Hotel as HotelConst;
use App\Constants\RoomPriceAdjustment as RoomPriceAdjustmentConst;
use App\Constants\RoomType as RoomTypeConst;
use App\DTOs\Common\RoomTypeHistory\StoreDTO as RoomTypeHistoryStoreDTO;
use App\DTOs\Promotion\DirectDiscount\DeleteRoomPriceAdjustmentInputDTO;
use App\DTOs\Promotion\DirectDiscount\DeleteRoomPriceAdjustmentOutputDTO;
use App\Helpers\ConvertHelper;
use App\Helpers\LoggingHelper;
use App\Jobs\ElasticSearch\SyncRoomPriceAdjustmentJob;
use App\Models\Hotel;
use App\Models\RoomPriceAdjustment;
use App\Models\RoomPriceAdjustmentHistory;
use App\Models\RoomType;
use App\Repositories\Interfaces\HotelRepositoryInterface;
use App\Repositories\Interfaces\RoomPriceAdjustmentHistoryRepositoryInterface;
use App\Repositories\Interfaces\RoomPriceAdjustmentRepositoryInterface;
use App\Repositories\Interfaces\RoomTypeHistoryRepositoryInterface;
use App\Repositories\Interfaces\RoomTypeRepositoryInterface;
use App\Services\Mobile\HotelDisplayRuleService;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\DB;

class DeleteRoomPriceAdjustment
{
    public $roomTypeRepository;

    public $roomTypeHistoryRepository;

    public $roomPriceAdjustmentRepository;

    public $hotelRepository;

    public $roomPriceAdjustmentHistoryRepository;

    //Tạm giữ sau này sẽ đưa ra action riêng
    public $hotelDisplayRuleService;

    public function __construct()
    {
        $this->roomTypeRepository = app(RoomTypeRepositoryInterface::class);
        $this->hotelRepository = app(HotelRepositoryInterface::class);
        $this->roomTypeHistoryRepository = app(RoomTypeHistoryRepositoryInterface::class);
        $this->roomPriceAdjustmentRepository = app(RoomPriceAdjustmentRepositoryInterface::class);
        $this->roomPriceAdjustmentHistoryRepository = app(RoomPriceAdjustmentHistoryRepositoryInterface::class);
        $this->hotelDisplayRuleService = app(HotelDisplayRuleService::class);
    }

    public function handle(DeleteRoomPriceAdjustmentInputDTO $deleteRoomPriceAdjustmentInputDTO): DeleteRoomPriceAdjustmentOutputDTO
    {
        $now = Carbon::now();
        $roomPriceAdjustment = $this->roomPriceAdjustmentRepository->findRoomPriceAdjustmentByDirectDiscount($deleteRoomPriceAdjustmentInputDTO->getDirectDiscountProgramSn(), $deleteRoomPriceAdjustmentInputDTO->getRoomTypeSn());
        $roomType = RoomType::where(RoomType::COL_SN, $deleteRoomPriceAdjustmentInputDTO->getRoomTypeSn())->first();
        $roomTypeOrigin = clone $roomType;
        if (empty($roomPriceAdjustment)) {
            return DeleteRoomPriceAdjustmentOutputDTO::assemble(false);
        }
        $exists = DB::table(RoomPriceAdjustment::TABLE_NAME)
            ->where(RoomPriceAdjustment::COL_ROOM_TYPE_SN, '=', $roomPriceAdjustment->{RoomPriceAdjustment::COL_ROOM_TYPE_SN})
            ->where(RoomPriceAdjustment::COL_SN, '!=', $roomPriceAdjustment->{RoomPriceAdjustment::COL_SN})
            ->where(RoomPriceAdjustment::COL_TYPE, '=', RoomPriceAdjustmentConst::TYPE['EXTRA_FEE'])
            ->exists();
        if (!$exists) {
            $roomType->{RoomType::COL_DISCOUNT} = 0;
            $roomType->{RoomType::COL_START_DATE} = null;
            $roomType->{RoomType::COL_END_DATE} = null;
            $roomType->{RoomType::COL_WILL_PRICES} = null;
            $roomType->{RoomType::COL_DAY_DISCOUNT} = null;
        } else {
            if ($this->isDiscountToday($roomPriceAdjustment, Carbon::now())) {
                $roomType->{RoomType::COL_DISCOUNT} = 0;
                $roomType->{RoomType::COL_START_DATE} = null;
                $roomType->{RoomType::COL_END_DATE} = null;
                $roomType->{RoomType::COL_WILL_PRICES} = null;
                $roomType->{RoomType::COL_DAY_DISCOUNT} = null;
            }
        }

        $roomTypeSn = $roomPriceAdjustment->{RoomPriceAdjustment::COL_ROOM_TYPE_SN};
        $roomPriceAdjustmentList = $this->getRoomPriceAdjustmentApplyToday($roomTypeSn, $now, $roomPriceAdjustment->{RoomPriceAdjustment::COL_SN});
        $this->setupRoomPriceToday($roomPriceAdjustmentList, $roomType);
        $this->updatePriceRoomType($roomType, $roomTypeOrigin, $roomTypeSn);
        $roomPriceAdjustmentHistory = RoomPriceAdjustmentHistory::where(RoomPriceAdjustmentHistory::COL_ROOM_PRICE_ADJUSTMENT_SN, $roomPriceAdjustment->{RoomPriceAdjustment::COL_SN})->first();
        if (!empty($roomPriceAdjustmentHistory)) {
            $roomPriceAdjustmentHistory->{RoomPriceAdjustmentHistory::COL_STATUS} = RoomPriceAdjustmentConst::STATUS['DELETE'];
            $roomPriceAdjustmentHistory->{RoomPriceAdjustmentHistory::COL_DELETE_TIME} = Carbon::now();
            $roomPriceAdjustmentHistory->{RoomPriceAdjustmentHistory::COL_STAFF_DELETE_SN} = $deleteRoomPriceAdjustmentInputDTO->getDeleteStaffSn();
            $this->roomPriceAdjustmentHistoryRepository->update($roomPriceAdjustmentHistory->toArray(), $roomPriceAdjustmentHistory->{RoomPriceAdjustmentHistory::COL_SN});
        }

        $this->roomPriceAdjustmentRepository->delete($roomPriceAdjustment->{RoomPriceAdjustment::COL_SN});
        $syncRoomPriceAdjustmentJob = new SyncRoomPriceAdjustmentJob(json_encode([
            'sn'          => $roomType->{RoomType::COL_SN},
            'hotelSn'     => $roomType->{RoomType::COL_HOTEL_SN},
            'typeApply'   => $roomPriceAdjustment->{RoomPriceAdjustment::COL_TYPE_APPLY},
            'startDate'   => $roomPriceAdjustment->{RoomPriceAdjustment::COL_START_DATE},
            'endDate'     => $roomPriceAdjustment->{RoomPriceAdjustment::COL_END_DATE},
            'specialDate' => $roomPriceAdjustment->{RoomPriceAdjustment::COL_SPECIAL_DATE},
            'maxHour'     => $roomType->{RoomType::COL_MAX_NUM_HOUR},
        ]));
        dispatch($syncRoomPriceAdjustmentJob)->onQueue(QueueNameConst::ROOM_PRICING_SYNCING);

        return DeleteRoomPriceAdjustmentOutputDTO::assemble(true);
    }

    public function isDiscountToday($roomPriceAdjustment, Carbon $date)
    {
        if ($roomPriceAdjustment->{RoomPriceAdjustment::COL_STATUS} == RoomPriceAdjustmentConst::STATUS['ACTIVE']) {
            if (!empty($roomPriceAdjustment) && !empty($date)) {
                $date = $date->startOfDay();
                $startDate = Carbon::parse($roomPriceAdjustment->{RoomPriceAdjustment::COL_START_DATE});
                $endDate = Carbon::parse($roomPriceAdjustment->{RoomPriceAdjustment::COL_END_DATE});
                if ($roomPriceAdjustment->{RoomPriceAdjustment::COL_TYPE_APPLY} == RoomPriceAdjustmentConst::TYPE_APPLY['SPECIAL_DAYS']) {
                    // check special days
                    $specialDate = ConvertHelper::toArray($roomPriceAdjustment->{RoomPriceAdjustment::COL_SPECIAL_DATE});
                    if (in_array($date->format('Y-m-d'), $specialDate)) {
                        return 1;
                    }
                } elseif ($roomPriceAdjustment->{RoomPriceAdjustment::COL_TYPE_APPLY} == RoomPriceAdjustmentConst::TYPE_APPLY['DAY_OF_WEEK']) {
                    // check day of week
                    $checkStartEndDiscount = !empty($roomPriceAdjustment->{RoomPriceAdjustment::COL_START_DATE}) && !empty($roomPriceAdjustment->{RoomPriceAdjustment::COL_END_DATE});
                    if (!$checkStartEndDiscount || ($date->lessThan($startDate) || $date->greaterThan($endDate))) {
                        return 0;
                    } else {
                        switch ($date->dayOfWeek) {
                            case Carbon::SUNDAY:
                                if ($roomPriceAdjustment->{RoomPriceAdjustment::COL_SUNDAY}) {
                                    return 1;
                                }
                                break;
                            case Carbon::MONDAY:
                                if ($roomPriceAdjustment->{RoomPriceAdjustment::COL_MONDAY}) {
                                    return 1;
                                }
                                break;
                            case Carbon::TUESDAY:
                                if ($roomPriceAdjustment->{RoomPriceAdjustment::COL_TUESDAY}) {
                                    return 1;
                                }
                                break;
                            case Carbon::WEDNESDAY:
                                if ($roomPriceAdjustment->{RoomPriceAdjustment::COL_WEDNESDAY}) {
                                    return 1;
                                }
                                break;
                            case Carbon::THURSDAY:
                                if ($roomPriceAdjustment->{RoomPriceAdjustment::COL_THURSDAY}) {
                                    return 1;
                                }
                                break;
                            case Carbon::FRIDAY:
                                if ($roomPriceAdjustment->{RoomPriceAdjustment::COL_FRIDAY}) {
                                    return 1;
                                }
                                break;
                            case Carbon::SATURDAY:
                                if ($roomPriceAdjustment->{RoomPriceAdjustment::COL_SATURDAY}) {
                                    return 1;
                                }
                                break;
                        }

                        return 0;
                    }
                }
                //
                if (!$date->isBefore($startDate)) {
                    return 0;
                }
            }
        }

        return 0;
    }

    public function getRoomPriceAdjustmentApplyToday($roomTypeSn, $toDate, $excludeAdjustSn = null)
    {
        $adjustmentDDList = $this->roomPriceAdjustmentRepository->findPriceAdjustmentApplyToday($roomTypeSn, RoomPriceAdjustmentConst::TYPE['DIRECT_DISCOUNT'], $toDate, $excludeAdjustSn);
        $adjustmentEFList = $this->roomPriceAdjustmentRepository->findPriceAdjustmentApplyToday($roomTypeSn, RoomPriceAdjustmentConst::TYPE['EXTRA_FEE'], $toDate, $excludeAdjustSn);

        return $this->sortPriorityRoomPriceAdjustment($adjustmentDDList, $adjustmentEFList);
    }

    public function sortPriorityRoomPriceAdjustment($adjustmentDD, $adjustmentEF)
    {
        if (empty($adjustmentDD) && empty($adjustmentEF)) {
            return [];
        } elseif (empty($adjustmentDD) && !empty($adjustmentEF)) {
            return [$adjustmentEF];
        } elseif (!empty($adjustmentDD) && empty($adjustmentEF)) {
            return [$adjustmentDD];
        } else {
            return [$adjustmentDD, $adjustmentEF];

        }
    }

    public function setupRoomPriceToday($roomPriceAdjustmentList, &$roomType)
    {
        $roomType->{RoomType::COL_EXTRA_FEE} = 0;
        $roomType->{RoomType::COL_DISCOUNT} = 0;
        $roomType->{RoomType::COL_PRICE_FIRST_HOURS} = $roomType->{RoomType::COL_FIRST_HOURS_ORIGIN};
        $roomType->{RoomType::COL_PRICE_ADDITIONAL_HOURS} = $roomType->{RoomType::COL_ADDITIONAL_ORIGIN};
        $roomType->{RoomType::COL_PRICE_OVERNIGHT} = $roomType->{RoomType::COL_OVERNIGHT_ORIGIN};
        $roomType->{RoomType::COL_PRICE_ONE_DAY} = $roomType->{RoomType::COL_ONE_DAY_ORIGIN};
        foreach ($roomPriceAdjustmentList as $roomPriceAdjustment) {
            if (RoomPriceAdjustmentConst::TYPE['DIRECT_DISCOUNT'] == $roomPriceAdjustment->{RoomPriceAdjustment::COL_TYPE}) {
                $roomType->{RoomType::COL_DISCOUNT} = 1;
                if ($roomPriceAdjustment->{RoomPriceAdjustment::COL_TYPE_APPLY} == RoomPriceAdjustmentConst::TYPE_APPLY['DAY_OF_WEEK']) {
                    $roomType->{RoomType::COL_START_DATE} = $roomPriceAdjustment->{RoomPriceAdjustment::COL_START_DATE};
                    $roomType->{RoomType::COL_END_DATE} = $roomPriceAdjustment->{RoomPriceAdjustment::COL_END_DATE};
                } else {
                    $roomType->{RoomType::COL_START_DATE} = null;
                    $roomType->{RoomType::COL_END_DATE} = null;
                }
                $isApplyTime = $this->isApplyTimeRoomPriceAdjustment($roomPriceAdjustment);
                if ($isApplyTime) {
                    $roomType->{RoomType::COL_PRICE_FIRST_HOURS} = ($roomType->{RoomType::COL_PRICE_FIRST_HOURS} + $roomPriceAdjustment->{RoomPriceAdjustment::COL_PRICE_FIRST_HOURS}) - $roomType->{RoomType::COL_FIRST_HOURS_ORIGIN};
                    $roomType->{RoomType::COL_PRICE_ADDITIONAL_HOURS} = ($roomType->{RoomType::COL_PRICE_ADDITIONAL_HOURS} + $roomPriceAdjustment->{RoomPriceAdjustment::COL_PRICE_ADDITIONAL_HOURS}) - $roomType->{RoomType::COL_ADDITIONAL_ORIGIN};
                }
                $roomType->{RoomType::COL_PRICE_OVERNIGHT} = ($roomType->{RoomType::COL_PRICE_OVERNIGHT} + $roomPriceAdjustment->{RoomPriceAdjustment::COL_PRICE_OVERNIGHT}) - $roomType->{RoomType::COL_OVERNIGHT_ORIGIN};
                $roomType->{RoomType::COL_PRICE_ONE_DAY} = ($roomType->{RoomType::COL_PRICE_ONE_DAY} + $roomPriceAdjustment->{RoomPriceAdjustment::COL_PRICE_ONE_DAY}) - $roomType->{RoomType::COL_ONE_DAY_ORIGIN};
            } elseif (RoomPriceAdjustmentConst::TYPE['EXTRA_FEE'] == $roomPriceAdjustment->{RoomPriceAdjustment::COL_TYPE}) {
                $roomType->{RoomType::COL_EXTRA_FEE} = 1;
                if ($roomPriceAdjustment->{RoomPriceAdjustment::COL_TYPE_APPLY} == RoomPriceAdjustmentConst::TYPE_APPLY['DAY_OF_WEEK']) {
                    $roomType->{RoomType::COL_START_DATE_EXTRA_FEE} = $roomPriceAdjustment->{RoomPriceAdjustment::COL_START_DATE};
                    $roomType->{RoomType::COL_END_DATE_EXTRA_FEE} = $roomPriceAdjustment->{RoomPriceAdjustment::COL_END_DATE};
                } else {
                    $roomType->{RoomType::COL_START_DATE_EXTRA_FEE} = null;
                    $roomType->{RoomType::COL_END_DATE_EXTRA_FEE} = null;
                }

                $roomType->{RoomType::COL_PRICE_FIRST_HOURS} = ($roomType->{RoomType::COL_PRICE_FIRST_HOURS} + $roomPriceAdjustment->{RoomPriceAdjustment::COL_PRICE_FIRST_HOURS}) - $roomType->{RoomType::COL_FIRST_HOURS_ORIGIN};
                $roomType->{RoomType::COL_PRICE_ADDITIONAL_HOURS} = ($roomType->{RoomType::COL_PRICE_ADDITIONAL_HOURS} + $roomPriceAdjustment->{RoomPriceAdjustment::COL_PRICE_ADDITIONAL_HOURS}) - $roomType->{RoomType::COL_ADDITIONAL_ORIGIN};
                $roomType->{RoomType::COL_PRICE_OVERNIGHT} = ($roomType->{RoomType::COL_PRICE_OVERNIGHT} + $roomPriceAdjustment->{RoomPriceAdjustment::COL_PRICE_OVERNIGHT}) - $roomType->{RoomType::COL_OVERNIGHT_ORIGIN};
                $roomType->{RoomType::COL_PRICE_ONE_DAY} = ($roomType->{RoomType::COL_PRICE_ONE_DAY} + $roomPriceAdjustment->{RoomPriceAdjustment::COL_PRICE_ONE_DAY}) - $roomType->{RoomType::COL_ONE_DAY_ORIGIN};
            }
        }
    }

    public function isApplyTimeRoomPriceAdjustment($roomPriceAdjustment)
    {
        if ((empty($roomPriceAdjustment->{RoomPriceAdjustment::COL_START_TIME}) && empty($roomPriceAdjustment->{RoomPriceAdjustment::COL_START_TIME})) ||
            (RoomPriceAdjustmentConst::DEFAULT_START_TIME == $roomPriceAdjustment->{RoomPriceAdjustment::COL_START_TIME}
                && RoomPriceAdjustmentConst::DEFAULT_END_TIME == $roomPriceAdjustment->{RoomPriceAdjustment::COL_END_TIME})) {
            return true;
        }

        $now = Carbon::now();
        $startTime = Carbon::parse($roomPriceAdjustment->{RoomPriceAdjustment::COL_START_TIME});
        $endTime = Carbon::parse($roomPriceAdjustment->{RoomPriceAdjustment::COL_END_TIME});
        if ($now->between($startTime, $endTime)) {
            return true;
        }

        return false;
    }

    /**
     * @param $roomType
     * @param $originRoomType
     * @param $roomTypeSn
     */
    private function updatePriceRoomType($roomType, $originRoomType, $roomTypeSn)
    {
        DB::table(RoomType::TABLE_NAME)->where(RoomType::COL_SN, $roomTypeSn)
            ->update([
                RoomType::COL_DISCOUNT               => $roomType->{RoomType::COL_DISCOUNT},
                RoomType::COL_APPLY_DISCOUNT         => $roomType->{RoomType::COL_APPLY_DISCOUNT},
                RoomType::COL_EXTRA_FEE              => $roomType->{RoomType::COL_EXTRA_FEE},
                RoomType::COL_APPLY_EXTRA_FEE        => $roomType->{RoomType::COL_APPLY_EXTRA_FEE},
                RoomType::COL_START_DATE             => $roomType->{RoomType::COL_START_DATE},
                RoomType::COL_END_DATE               => $roomType->{RoomType::COL_END_DATE},
                RoomType::COL_START_DATE_EXTRA_FEE   => $roomType->{RoomType::COL_START_DATE_EXTRA_FEE},
                RoomType::COL_END_DATE_EXTRA_FEE     => $roomType->{RoomType::COL_END_DATE_EXTRA_FEE},
                RoomType::COL_PRICE_FIRST_HOURS      => $roomType->{RoomType::COL_PRICE_FIRST_HOURS},
                RoomType::COL_PRICE_ADDITIONAL_HOURS => $roomType->{RoomType::COL_PRICE_ADDITIONAL_HOURS},
                RoomType::COL_PRICE_OVERNIGHT        => $roomType->{RoomType::COL_PRICE_OVERNIGHT},
                RoomType::COL_PRICE_ONE_DAY          => $roomType->{RoomType::COL_PRICE_ONE_DAY},
            ]);

        $this->_updateGiftBonusHourForHotel($roomType->{RoomType::COL_HOTEL_SN});
        $this->_updateLowestPriceForHotel($roomType->{RoomType::COL_HOTEL_SN});
        $result = $this->_isChangePrices($roomType, $originRoomType);
        if ($result) {
            $this->insertRoomTypeHistory($roomType->{RoomType::COL_SN});
        }

        LoggingHelper::logFunction('DEBUG_JOB_DELETE:', json_encode($roomType));
        $this->hotelDisplayRuleService->refreshHotelDisplayRuleJob($roomType->{RoomType::COL_HOTEL_SN});
    }

    /**
     * @param string|int $hotelSn
     *
     * @return int
     */
    public function _updateGiftBonusHourForHotel($hotelSn)
    {
        $hasGift = $this->roomTypeRepository->existHasGiftForHotel($hotelSn);
        $hasBonusHour = $this->roomTypeRepository->existHasBonusHourForHotel($hotelSn);
        $extraFee = $this->roomTypeRepository->existExtraFeeForHotel($hotelSn);
        return DB::table(Hotel::TABLE_NAME)
            ->where(Hotel::COL_SN, $hotelSn)
            ->whereIn(Hotel::COL_HOTEL_STATUS, [
                HotelConst::STATUS['CONTRACTED'],
                HotelConst::STATUS['TRIAL'],
                HotelConst::STATUS['TERMINATED'],
                HotelConst::STATUS['SUSPENDED'],
            ])
            ->update([
                Hotel::COL_HAS_GIFT       => $hasGift,
                Hotel::COL_HAS_BONUS_HOUR => $hasBonusHour,
                Hotel::COL_EXTRA_FEE      => $extraFee,
            ]);
    }

    /**
     * @param string|int $hotelSn
     *
     * @return int
     */
    private function _updateLowestPriceForHotel($hotelSn)
    {
        // Number of rooms is running flash sale
        $hotel = DB::table(Hotel::TABLE_NAME)->where(Hotel::COL_SN, $hotelSn)->exists();
        if ($hotel) {
            $roomTypes = DB::table(RoomType::TABLE_NAME)
                ->where(RoomType::COL_STATUS, '!=', RoomTypeConst::STATUS['DELETED'])
                ->where(RoomType::COL_HOTEL_SN, $hotelSn)
                ->where(RoomType::COL_MODE, RoomTypeConst::MODE['NORMAL'])
                ->orderBy(RoomType::COL_IDX, 'ASC')
                ->get();
            $hasDiscount = $roomTypes->contains(function($value) {
                return $value->{RoomType::COL_DISCOUNT};
            });
            $data[Hotel::COL_DISCOUNT] = $hasDiscount;
            $hasExtraFee = $roomTypes->contains(function($value) {
                return $value->{RoomType::COL_EXTRA_FEE};
            });
            $data[Hotel::COL_EXTRA_FEE] = $hasExtraFee;
            #region Min price first hours
            $roomTypeHasPriceFirstHours = $roomTypes->filter(function($value) {
                return $value->{RoomType::COL_FIRST_HOURS_ORIGIN} != 0;
            });
            $roomTypeHasMinPriceFirstHours = $roomTypeHasPriceFirstHours->where(RoomType::COL_PRICE_FIRST_HOURS, $roomTypeHasPriceFirstHours->min(RoomType::COL_PRICE_FIRST_HOURS))->first();
            if (!empty($roomTypeHasMinPriceFirstHours)) {
                $data[Hotel::COL_FIRST_HOURS] = $roomTypeHasMinPriceFirstHours->{RoomType::COL_FIRST_HOURS};
                $data[Hotel::COL_LOWEST_PRICE] = $roomTypeHasMinPriceFirstHours->{RoomType::COL_PRICE_FIRST_HOURS};
                $data[Hotel::COL_FIRST_HOURS_ORIGIN] = $roomTypeHasMinPriceFirstHours->{RoomType::COL_FIRST_HOURS_ORIGIN};
            } else {
                $data[Hotel::COL_FIRST_HOURS] = 0;
                $data[Hotel::COL_LOWEST_PRICE] = 0;
                $data[Hotel::COL_FIRST_HOURS_ORIGIN] = 0;
            }
            #endregion
            #region Min first hours
            $roomTypeHasMinFirstHours = $roomTypeHasPriceFirstHours->where(RoomType::COL_FIRST_HOURS, $roomTypeHasPriceFirstHours->min(RoomType::COL_FIRST_HOURS))->first();
            if (!empty($roomTypeHasMinFirstHours)) {
                $data[Hotel::COL_FIRST_HOURS] = $roomTypeHasMinFirstHours->{RoomType::COL_FIRST_HOURS};
            } else {
                $data[Hotel::COL_FIRST_HOURS] = 1;
            }
            #endregion

            #region Min overnight
            $roomTypeHasPriceOvernight = $roomTypes->filter(function($value) {
                return $value->{RoomType::COL_OVERNIGHT_ORIGIN} != 0;
            });
            $roomTypeHasMinPriceOvernight = $roomTypeHasPriceOvernight->where(RoomType::COL_PRICE_OVERNIGHT, $roomTypeHasPriceOvernight->min(RoomType::COL_PRICE_OVERNIGHT))->first();
            if (!empty($roomTypeHasMinPriceOvernight)) {
                $data[Hotel::COL_LOWEST_PRICE_OVERNIGHT] = $roomTypeHasMinPriceOvernight->{RoomType::COL_PRICE_OVERNIGHT};
                $data[Hotel::COL_OVERNIGHT_ORIGIN] = $roomTypeHasMinPriceOvernight->{RoomType::COL_OVERNIGHT_ORIGIN};
            } else {
                $data[Hotel::COL_LOWEST_PRICE_OVERNIGHT] = 0;
                $data[Hotel::COL_OVERNIGHT_ORIGIN] = 0;
            }
            #endregion

            #region Min daily
            $roomTypeHasPriceOneDay = $roomTypes->filter(function($value) {
                return $value->{RoomType::COL_ONE_DAY_ORIGIN} != 0;
            });
            $roomTypeHasMinPriceOneDay = $roomTypeHasPriceOneDay->where(RoomType::COL_PRICE_ONE_DAY, $roomTypeHasPriceOneDay->min(RoomType::COL_PRICE_ONE_DAY))->first();
            if (!empty($roomTypeHasMinPriceOneDay)) {
                $data[Hotel::COL_LOWEST_ONE_DAY] = $roomTypeHasMinPriceOneDay->{RoomType::COL_PRICE_ONE_DAY};
                $data[Hotel::COL_ONE_DAY_ORIGIN] = $roomTypeHasMinPriceOneDay->{RoomType::COL_ONE_DAY_ORIGIN};
            } else {
                $data[Hotel::COL_LOWEST_ONE_DAY] = 0;
                $data[Hotel::COL_ONE_DAY_ORIGIN] = 0;
            }
            #endregion
            #region Min discount date
            $roomTypeHasEndDate = $roomTypes->filter(function($value) {
                return $value->{RoomType::COL_END_DATE} != 0;
            });
            $roomTypeHasMinEndDate = $roomTypeHasEndDate->where(RoomType::COL_END_DATE, $roomTypeHasEndDate->min(RoomType::COL_END_DATE))->first();
            if (!empty($roomTypeHasMinEndDate)) {
                $data[Hotel::COL_MIN_DISCOUNT_DATE] = $roomTypeHasMinEndDate->{RoomType::COL_END_DATE};
            } else {
                $data[Hotel::COL_MIN_DISCOUNT_DATE] = null;
            }
            #endregion
            // Update price for hotel
            return $this->hotelRepository->update($data, $hotelSn);
        }

        return 0;
    }

    private function _isChangePrices($roomType, $originRoomType)
    {
        if ($roomType->{RoomType::COL_ADDITIONAL_HOURS} != $originRoomType->{RoomType::COL_ADDITIONAL_HOURS}) {
            return true;
        } elseif ($roomType->{RoomType::COL_ADDITIONAL_ORIGIN} != $originRoomType->{RoomType::COL_ADDITIONAL_ORIGIN}) {
            return true;
        } elseif ($roomType->{RoomType::COL_FIRST_HOURS} != $originRoomType->{RoomType::COL_FIRST_HOURS}) {
            return true;
        } elseif ($roomType->{RoomType::COL_FIRST_HOURS_ORIGIN} != $originRoomType->{RoomType::COL_FIRST_HOURS_ORIGIN}) {
            return true;
        } elseif ($roomType->{RoomType::COL_ONE_DAY_ORIGIN} != $originRoomType->{RoomType::COL_ONE_DAY_ORIGIN}) {
            return true;
        } elseif ($roomType->{RoomType::COL_OVERNIGHT_ORIGIN} != $originRoomType->{RoomType::COL_OVERNIGHT_ORIGIN}) {
            return true;
        } elseif ($roomType->{RoomType::COL_PRICE_ADDITIONAL_HOURS} != $originRoomType->{RoomType::COL_PRICE_ADDITIONAL_HOURS}) {
            return true;
        } elseif ($roomType->{RoomType::COL_PRICE_FIRST_HOURS} != $originRoomType->{RoomType::COL_PRICE_FIRST_HOURS}) {
            return true;
        } elseif ($roomType->{RoomType::COL_PRICE_ONE_DAY} != $originRoomType->{RoomType::COL_PRICE_ONE_DAY}) {
            return true;
        } elseif ($roomType->{RoomType::COL_PRICE_OVERNIGHT} != $originRoomType->{RoomType::COL_PRICE_OVERNIGHT}) {
            return true;
        } elseif ($roomType->{RoomType::COL_HAS_GIFT} != $originRoomType->{RoomType::COL_HAS_GIFT}) {
            return true;
        } elseif ($roomType->{RoomType::COL_BONUS_HOUR} != $originRoomType->{RoomType::COL_BONUS_HOUR}) {
            return true;
        }

        return false;
    }

    public function insertRoomTypeHistory($roomTypeSn)
    {
        $roomType = $this->roomTypeRepository->findRoomType($roomTypeSn);
        $roomHistory = RoomTypeHistoryStoreDTO::toRoomTypeHistory($roomType);
        $this->roomTypeHistoryRepository->create($roomHistory->toArray());
    }
}