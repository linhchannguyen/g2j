<?php

namespace App\Actions\Promotion\DirectDiscount;

use App\Constants\DirectDiscountProgramActionHistory as DirectDiscountProgramActionHistoryConst;
use App\Constants\DirectDiscountProgramRoomType as DirectDiscountProgramRoomTypeConst;
use App\DTOs\Promotion\DirectDiscount\ChangeOriginPriceRoomTypeInputDTO;
use App\Models\DirectDiscountProgram;
use App\Models\DirectDiscountProgramRoomType;
use App\Models\DirectDiscountProgramRoomTypeHistory;
use App\Repositories\Interfaces\DirectDiscountProgramActionHistoryRepositoryInterface;
use App\Repositories\Interfaces\DirectDiscountProgramRepositoryInterface;
use App\Repositories\Interfaces\DirectDiscountProgramRoomTypeHistoryRepositoryInterface;
use App\Repositories\Interfaces\DirectDiscountProgramRoomTypeRepositoryInterface;
use App\Repositories\Interfaces\RoomPriceAdjustmentRepositoryInterface;
use Exception;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\DB;

class ChangeOriginPriceRoomType
{
    public $directDiscountProgramRepository;

    public $directDiscountProgramRoomTypeRepository;

    public $directDiscountProgramRoomTypeHistoryRepository;

    public $directDiscountProgramActionHistoryRepository;

    public $roomPriceAdjustmentRepository;

    public function __construct()
    {
        $this->directDiscountProgramRepository = app(DirectDiscountProgramRepositoryInterface::class);
        $this->directDiscountProgramRoomTypeRepository = app(DirectDiscountProgramRoomTypeRepositoryInterface::class);
        $this->directDiscountProgramRoomTypeHistoryRepository = app(DirectDiscountProgramRoomTypeHistoryRepositoryInterface::class);
        $this->directDiscountProgramActionHistoryRepository = app(DirectDiscountProgramActionHistoryRepositoryInterface::class);
        $this->roomPriceAdjustmentRepository = app(RoomPriceAdjustmentRepositoryInterface::class);
    }

    public function handle(ChangeOriginPriceRoomTypeInputDTO $changeOriginPriceRoomTypeInputDTO)
    {
        $directDiscountProgramRoomTypeList = $this->directDiscountProgramRoomTypeRepository->findRoomTypeRunning($changeOriginPriceRoomTypeInputDTO->getHotelSn(), $changeOriginPriceRoomTypeInputDTO->getRoomTypeSn());
        DB::connection('mysql')->beginTransaction();
        try {
            foreach ($directDiscountProgramRoomTypeList as $directDiscountProgramRoomType) {
                $this->_updateOriginPriceRoomType($changeOriginPriceRoomTypeInputDTO, $directDiscountProgramRoomType->{DirectDiscountProgramRoomType::VAR_DIRECT_DISCOUNT_PROGRAM_ROOM_TYPE_SN});
                if (DirectDiscountProgramRoomTypeConst::STATUS['AVAILABLE'] == $directDiscountProgramRoomType->{DirectDiscountProgramRoomType::VAR_DIRECT_DISCOUNT_PROGRAM_ROOM_TYPE_STATUS}) {
                    $actionSn = $this->directDiscountProgramActionHistoryRepository->createRoomStopParticipatedHistory($directDiscountProgramRoomType->{DirectDiscountProgram::COL_SN}, $changeOriginPriceRoomTypeInputDTO->getUpdateStaffSn(), DirectDiscountProgramActionHistoryConst::ACTION_USER_TYPE['GO2JOY_STAFF'], Carbon::now(), json_encode($directDiscountProgramRoomType));
                    $this->_createDirectDiscountProgramRoomTypeHistory($actionSn, $directDiscountProgramRoomType);
                }

            }
            DB::connection('mysql')->commit();
        } catch (Exception $e) {
            DB::connection('mysql')->rollBack();
            throw $e;
        }

    }

    private function _updateOriginPriceRoomType(ChangeOriginPriceRoomTypeInputDTO $changeOriginPriceRoomTypeInputDTO, $directDiscountProgramRoomTypeSn)
    {
        $this->directDiscountProgramRoomTypeRepository->update([
            DirectDiscountProgramRoomType::COL_PRICE_FIRST_HOURS_DISCOUNT_PERCENT      => 0,
            DirectDiscountProgramRoomType::COL_PRICE_FIRST_HOURS_AFTER_DISCOUNT        => $changeOriginPriceRoomTypeInputDTO->getFirstHourOrigin(),
            DirectDiscountProgramRoomType::COL_FIRST_HOURS_ORIGIN                      => $changeOriginPriceRoomTypeInputDTO->getFirstHourOrigin(),
            DirectDiscountProgramRoomType::COL_PRICE_ADDITIONAL_HOURS_DISCOUNT_PERCENT => 0,
            DirectDiscountProgramRoomType::COL_PRICE_ADDITIONAL_HOURS_AFTER_DISCOUNT   => $changeOriginPriceRoomTypeInputDTO->getAdditionalOrigin(),
            DirectDiscountProgramRoomType::COL_ADDITIONAL_ORIGIN                       => $changeOriginPriceRoomTypeInputDTO->getAdditionalOrigin(),
            DirectDiscountProgramRoomType::COL_PRICE_OVERNIGHT_DISCOUNT_PERCENT        => 0,
            DirectDiscountProgramRoomType::COL_PRICE_OVERNIGHT_AFTER_DISCOUNT          => $changeOriginPriceRoomTypeInputDTO->getOvernightOrigin(),
            DirectDiscountProgramRoomType::COL_OVERNIGHT_ORIGIN                        => $changeOriginPriceRoomTypeInputDTO->getOvernightOrigin(),
            DirectDiscountProgramRoomType::COL_PRICE_ONE_DAY_DISCOUNT_PERCENT          => 0,
            DirectDiscountProgramRoomType::COL_PRICE_ONE_DAY_AFTER_DISCOUNT            => $changeOriginPriceRoomTypeInputDTO->getOneDayOrigin(),
            DirectDiscountProgramRoomType::COL_ONE_DAY_ORIGIN                          => $changeOriginPriceRoomTypeInputDTO->getOneDayOrigin(),
            DirectDiscountProgramRoomType::COL_STATUS                                  => DirectDiscountProgramRoomTypeConst::STATUS['PENDING'],
        ], $directDiscountProgramRoomTypeSn);
    }

    private function _createDirectDiscountProgramRoomTypeHistory($actionSn, $directDiscountProgramRoomType)
    {
        $directDiscountRoomTypeHistoryList = [];
        $directDiscountProgramRoomTypeList = $this->directDiscountProgramRoomTypeRepository->findAllDirectDiscountProgramRoomTypeRunning($directDiscountProgramRoomType->{DirectDiscountProgram::COL_SN});
        foreach ($directDiscountProgramRoomTypeList as $directDiscountProgramRoomType) {
            $directDiscountRoomTypeHistoryList [] = [
                DirectDiscountProgramRoomTypeHistory::COL_DIRECT_DISCOUNT_PROGRAM_SN                => $directDiscountProgramRoomType->{DirectDiscountProgramRoomTypeHistory::COL_DIRECT_DISCOUNT_PROGRAM_SN},
                DirectDiscountProgramRoomTypeHistory::COL_DIRECT_DISCOUNT_PROGRAM_ACTION_HISTORY_SN => $actionSn,
                DirectDiscountProgramRoomTypeHistory::COL_STATUS                                    => $directDiscountProgramRoomType->{DirectDiscountProgramRoomTypeHistory::COL_STATUS},
                DirectDiscountProgramRoomTypeHistory::COL_HOTEL_SN                                  => $directDiscountProgramRoomType->{DirectDiscountProgramRoomTypeHistory::COL_HOTEL_SN},
                DirectDiscountProgramRoomTypeHistory::COL_HOTEL_NAME                                => $directDiscountProgramRoomType->{DirectDiscountProgramRoomTypeHistory::COL_HOTEL_NAME},
                DirectDiscountProgramRoomTypeHistory::COL_HOTEL_CODE                                => $directDiscountProgramRoomType->{DirectDiscountProgramRoomTypeHistory::COL_HOTEL_CODE},
                DirectDiscountProgramRoomTypeHistory::COL_ROOM_TYPE_SN                              => $directDiscountProgramRoomType->{DirectDiscountProgramRoomTypeHistory::COL_ROOM_TYPE_SN},
                DirectDiscountProgramRoomTypeHistory::COL_ROOM_TYPE_NAME                            => $directDiscountProgramRoomType->{DirectDiscountProgramRoomTypeHistory::COL_ROOM_TYPE_NAME},
                DirectDiscountProgramRoomTypeHistory::COL_PRICE_FIRST_HOURS_DISCOUNT_PERCENT        => $directDiscountProgramRoomType->{DirectDiscountProgramRoomTypeHistory::COL_PRICE_FIRST_HOURS_DISCOUNT_PERCENT},
                DirectDiscountProgramRoomTypeHistory::COL_PRICE_FIRST_HOURS_AFTER_DISCOUNT          => $directDiscountProgramRoomType->{DirectDiscountProgramRoomTypeHistory::COL_PRICE_FIRST_HOURS_AFTER_DISCOUNT},
                DirectDiscountProgramRoomTypeHistory::COL_PRICE_ADDITIONAL_HOURS_DISCOUNT_PERCENT   => $directDiscountProgramRoomType->{DirectDiscountProgramRoomTypeHistory::COL_PRICE_ADDITIONAL_HOURS_DISCOUNT_PERCENT},
                DirectDiscountProgramRoomTypeHistory::COL_PRICE_ADDITIONAL_HOURS_AFTER_DISCOUNT     => $directDiscountProgramRoomType->{DirectDiscountProgramRoomTypeHistory::COL_PRICE_ADDITIONAL_HOURS_AFTER_DISCOUNT},
                DirectDiscountProgramRoomTypeHistory::COL_PRICE_OVERNIGHT_DISCOUNT_PERCENT          => $directDiscountProgramRoomType->{DirectDiscountProgramRoomTypeHistory::COL_PRICE_OVERNIGHT_DISCOUNT_PERCENT},
                DirectDiscountProgramRoomTypeHistory::COL_PRICE_OVERNIGHT_AFTER_DISCOUNT            => $directDiscountProgramRoomType->{DirectDiscountProgramRoomTypeHistory::COL_PRICE_OVERNIGHT_AFTER_DISCOUNT},
                DirectDiscountProgramRoomTypeHistory::COL_PRICE_ONE_DAY_DISCOUNT_PERCENT            => $directDiscountProgramRoomType->{DirectDiscountProgramRoomTypeHistory::COL_PRICE_ONE_DAY_DISCOUNT_PERCENT},
                DirectDiscountProgramRoomTypeHistory::COL_PRICE_ONE_DAY_AFTER_DISCOUNT              => $directDiscountProgramRoomType->{DirectDiscountProgramRoomTypeHistory::COL_PRICE_ONE_DAY_AFTER_DISCOUNT},
                DirectDiscountProgramRoomTypeHistory::COL_FIRST_HOURS_ORIGIN                        => $directDiscountProgramRoomType->{DirectDiscountProgramRoomTypeHistory::COL_FIRST_HOURS_ORIGIN},
                DirectDiscountProgramRoomTypeHistory::COL_ADDITIONAL_ORIGIN                         => $directDiscountProgramRoomType->{DirectDiscountProgramRoomTypeHistory::COL_ADDITIONAL_ORIGIN},
                DirectDiscountProgramRoomTypeHistory::COL_OVERNIGHT_ORIGIN                          => $directDiscountProgramRoomType->{DirectDiscountProgramRoomTypeHistory::COL_OVERNIGHT_ORIGIN},
                DirectDiscountProgramRoomTypeHistory::COL_ONE_DAY_ORIGIN                            => $directDiscountProgramRoomType->{DirectDiscountProgramRoomTypeHistory::COL_ONE_DAY_ORIGIN},
            ];
        }
        $this->directDiscountProgramRoomTypeHistoryRepository->batchInsert($directDiscountRoomTypeHistoryList);
    }
}