<?php

namespace App\Actions\Promotion\DirectDiscount\SA;

use App\Constants\DirectDiscountProgram as DirectDiscountProgramConst;
use App\Constants\DirectDiscountProgramRoomType as DirectDiscountProgramRoomTypeAlias;
use App\Constants\Globals\Code as CodeConst;
use App\Constants\Globals\FunctionName;
use App\DTOs\Promotion\DirectDiscount\SA\AddDirectDiscountHotelInputDTO;
use App\DTOs\Promotion\DirectDiscount\SA\AddDirectDiscountHotelOutputDTO;
use App\Exceptions\ServiceException;
use App\Helpers\CommonHelper;
use App\Helpers\ConvertHelper;
use App\Helpers\GenerateHelper;
use App\Libraries\Maatwebsite\Excel\Imports\ApplyingHotelImport;
use App\Models\DirectDiscountProgram;
use App\Repositories\Interfaces\DirectDiscountProgramRepositoryInterface;
use App\Repositories\Interfaces\DirectDiscountProgramRoomTypeRepositoryInterface;
use App\Repositories\Interfaces\HotelRepositoryInterface;
use Illuminate\Support\Carbon;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Cache;
use Maatwebsite\Excel\Facades\Excel;

class AddDirectDiscountHotel
{
    const FILE_LANGUAGE_NAME = 'promotion';

    public $hotelRepository;

    public $directDiscountProgramRepository;

    public $directDiscountProgramRoomTypeRepository;

    public function __construct()
    {
        $this->hotelRepository = app(HotelRepositoryInterface::class);
        $this->directDiscountProgramRepository = app(DirectDiscountProgramRepositoryInterface::class);
        $this->directDiscountProgramRoomTypeRepository = app(DirectDiscountProgramRoomTypeRepositoryInterface::class);
    }

    public function handle(AddDirectDiscountHotelInputDTO $addDirectDiscountHotelInputDTO)
    {
        $this->_checkBeforeAddDirectDiscountHotel($addDirectDiscountHotelInputDTO);
        $hotelList = [];
        switch ($addDirectDiscountHotelInputDTO->getType()) {
            case DirectDiscountProgramConst::IMPORT_TYPE['FILE']:
            {
                $columnCode = 1;
                $collection = (Excel::toCollection(new ApplyingHotelImport(), $addDirectDiscountHotelInputDTO->getFile()))->first();
                $plucked = $collection->filter(function($row) use ($columnCode) {
                    $code = $row[$columnCode];

                    return !empty($code);
                })->pluck($columnCode);
                $codeList = $plucked->all();
                if ($this->hotelRepository->checkExistsHotelNotContractedByCode($codeList)) {
                    throw new ServiceException(CommonHelper::getMessage(self::FILE_LANGUAGE_NAME, CodeConst::API_PRN_001), CodeConst::API_PRN_001);
                }
                $hotelList = $this->hotelRepository->getHotelListByCode($codeList);

                break;
            }
            case DirectDiscountProgramConst::IMPORT_TYPE['MANUAL']:
            {
                $hotelList = $this->hotelRepository->getHotelListBySn($addDirectDiscountHotelInputDTO->getHotelSnList());
                break;
            }
        }

        $_hotelList = $this->_generateDataRoomTypeList($addDirectDiscountHotelInputDTO, $hotelList);

        $key = GenerateHelper::cacheName(FunctionName::APPLYING_DIRECT_DISCOUNT, $addDirectDiscountHotelInputDTO->getStaffSn());
        if (Cache::store('redis')->has($key)) {
            $obj = json_decode(Cache::store('redis')->get($key), true);
            $data = !empty($obj['data']) ? $obj['data'] : [];
            $createdAt = $obj['createdAt'];
            $updatedAt = Carbon::now()->timestamp;
            $expiredAt = $obj['expiredAt'];

            $dataAdd = array_diff_key($_hotelList, $data);
            $added = $dataAdd + $data;

            // Update cache in Redis
            $remainingTTL = $expiredAt - Carbon::now()->timestamp;
            $obj = json_encode([
                'data'      => $added,
                'createdAt' => $createdAt,
                'updatedAt' => $updatedAt,
                'expiredAt' => $expiredAt,
            ]);
            Cache::store('redis')->put($key, $obj, $remainingTTL);

            return AddDirectDiscountHotelOutputDTO::assemble(CommonHelper::paginate($added, $addDirectDiscountHotelInputDTO->getLimit()));
        }
        $createdAt = Carbon::now()->timestamp;
        $updatedAt = Carbon::now()->timestamp;
        $ttl = Carbon::now()->addMinutes(60);
        $expiredAt = $ttl->timestamp;
        $obj = json_encode([
            'data'      => $_hotelList,
            'createdAt' => $createdAt,
            'updatedAt' => $updatedAt,
            'expiredAt' => $expiredAt,
        ]);
        Cache::store('redis')->put($key, $obj, $ttl);

        return AddDirectDiscountHotelOutputDTO::assemble(CommonHelper::paginate($_hotelList, 10));
    }

    private function _checkBeforeAddDirectDiscountHotel(AddDirectDiscountHotelInputDTO $addDirectDiscountHotelInputDTO)
    {
        if (!empty($addDirectDiscountHotelInputDTO->getDirectDiscountSn())) {
            if ($this->directDiscountProgramRepository->checkDirectDiscountProgramCreatedByHotel($addDirectDiscountHotelInputDTO->getDirectDiscountSn())) {
                throw new ServiceException(CommonHelper::getMessage(self::FILE_LANGUAGE_NAME, CodeConst::API_PRN_018), CodeConst::API_PRN_018);
            }
        }
        if ($addDirectDiscountHotelInputDTO->getType() == DirectDiscountProgramConst::IMPORT_TYPE['FILE'] && empty($addDirectDiscountHotelInputDTO->getFile())) {
            throw new ServiceException(CommonHelper::getMessage(self::FILE_LANGUAGE_NAME, CodeConst::API_PRN_011), CodeConst::API_PRN_011);
        }
        if ($addDirectDiscountHotelInputDTO->getType() == DirectDiscountProgramConst::IMPORT_TYPE['MANUAL'] && empty($addDirectDiscountHotelInputDTO->getHotelSnList())) {
            throw new ServiceException(CommonHelper::getMessage(self::FILE_LANGUAGE_NAME, CodeConst::API_PRN_012), CodeConst::API_PRN_012);
        }
        if ($addDirectDiscountHotelInputDTO->getTypeApply() == DirectDiscountProgramConst::TYPE_APPLY['DAY_OF_WEEK']) {
            if (empty($addDirectDiscountHotelInputDTO->getStartDate())) {
                throw new ServiceException(CommonHelper::getMessage(self::FILE_LANGUAGE_NAME, CodeConst::API_PRN_003), CodeConst::API_PRN_003);
            }
            if (empty($addDirectDiscountHotelInputDTO->getEndDate())) {
                throw new ServiceException(CommonHelper::getMessage(self::FILE_LANGUAGE_NAME, CodeConst::API_PRN_004), CodeConst::API_PRN_004);
            }
            if (Carbon::now()->addYear()->lt(Carbon::parse($addDirectDiscountHotelInputDTO->getEndDate()))) {
                throw new ServiceException(CommonHelper::getMessage(self::FILE_LANGUAGE_NAME, CodeConst::API_PRN_007), CodeConst::API_PRN_007);
            }
            if (empty($addDirectDiscountHotelInputDTO->getMonday())
                && empty($addDirectDiscountHotelInputDTO->getTuesday())
                && empty($addDirectDiscountHotelInputDTO->getWednesday())
                && empty($addDirectDiscountHotelInputDTO->getThursday())
                && empty($addDirectDiscountHotelInputDTO->getFriday())
                && empty($addDirectDiscountHotelInputDTO->getSaturday())
                && empty($addDirectDiscountHotelInputDTO->getSunday())) {
                throw new ServiceException(CommonHelper::getMessage(self::FILE_LANGUAGE_NAME, CodeConst::API_PRN_013), CodeConst::API_PRN_013);
            }
        } else {
            if (empty($addDirectDiscountHotelInputDTO->getSpecialDate())) {
                throw new ServiceException(CommonHelper::getMessage(self::FILE_LANGUAGE_NAME, CodeConst::API_PRN_009), CodeConst::API_PRN_009);
            }
            if (count($addDirectDiscountHotelInputDTO->getSpecialDate()) > DirectDiscountProgramConst::LIMIT_SPECIAL_DATE) {
                throw new ServiceException(CommonHelper::getMessage(self::FILE_LANGUAGE_NAME, CodeConst::API_PRN_010), CodeConst::API_PRN_010);
            }
        }
        if (!empty($addDirectDiscountHotelInputDTO->getStartTime()) &&
            !empty($addDirectDiscountHotelInputDTO->getEndTime()) &&
            Carbon::parse($addDirectDiscountHotelInputDTO->getEndTime())->lte(Carbon::parse($addDirectDiscountHotelInputDTO->getStartTime()))) {
            throw new ServiceException(CommonHelper::getMessage(self::FILE_LANGUAGE_NAME, CodeConst::API_PRN_008), CodeConst::API_PRN_008);
        }
    }

    private function _generateDataRoomTypeList(AddDirectDiscountHotelInputDTO $addDirectDiscountHotelInputDTO, collection $hotelList)
    {
        $_hotelList = [];
        $directDiscountSnList = [];
        if ($addDirectDiscountHotelInputDTO->getTypeApply() == DirectDiscountProgramConst::TYPE_APPLY['DAY_OF_WEEK']) {
            $directDiscountList = $this->directDiscountProgramRepository->getExistRangeDayDirectDiscountHotel($addDirectDiscountHotelInputDTO->getDirectDiscountSn(), $addDirectDiscountHotelInputDTO->getTypeApply(),
                $addDirectDiscountHotelInputDTO->getStartDate(), $addDirectDiscountHotelInputDTO->getEndDate(), $addDirectDiscountHotelInputDTO->getMonday(),
                $addDirectDiscountHotelInputDTO->getTuesday(), $addDirectDiscountHotelInputDTO->getWednesday(), $addDirectDiscountHotelInputDTO->getThursday(),
                $addDirectDiscountHotelInputDTO->getFriday(), $addDirectDiscountHotelInputDTO->getSaturday(), $addDirectDiscountHotelInputDTO->getSunday());
            $directDiscountSnList = $directDiscountList->pluck(DirectDiscountProgram::COL_SN)->toArray();
        } else {
            $specialDateArray = $addDirectDiscountHotelInputDTO->getSpecialDate();
            $directDiscountList = $this->directDiscountProgramRepository->getExistSpecialDayDirectDiscountHotel($addDirectDiscountHotelInputDTO->getDirectDiscountSn(), $addDirectDiscountHotelInputDTO->getTypeApply());
            foreach ($directDiscountList as $directDiscount) {
                $array = ConvertHelper::toArray($directDiscount->{DirectDiscountProgram::COL_SPECIAL_DATE});
                if (count(array_intersect($specialDateArray, $array)) !== 0) {
                    $directDiscountSnList[] = [
                        $directDiscount->{DirectDiscountProgram::COL_SN},
                    ];
                }
            }
        }

        $roomTypeListRunningDirectDiscount = $this->directDiscountProgramRoomTypeRepository->findDirectDiscountProgramRoomTypeRunning($directDiscountSnList)->pluck('ROOM_TYPE_SN')->toArray();

        foreach ($hotelList as $hotel) {
            $status = DirectDiscountProgramRoomTypeAlias::STATUS['AVAILABLE'];
            if (in_array($hotel->{DirectDiscountProgram::AS_ROOM_TYPE_SN}, $roomTypeListRunningDirectDiscount)) {
                $status = DirectDiscountProgramRoomTypeAlias::STATUS['UNAVAILABLE'];
            }
            if (isset($_hotelList[$hotel->{DirectDiscountProgram::AS_HOTEL_SN}])) {
                $_hotelList[$hotel->{DirectDiscountProgram::AS_HOTEL_SN}] = [
                    'hotelSn'      => $hotel->{DirectDiscountProgram::AS_HOTEL_SN},
                    'hotelName'    => $hotel->{DirectDiscountProgram::AS_HOTEL_NAME},
                    'hotelCode'    => $hotel->{DirectDiscountProgram::AS_HOTEL_CODE},
                    'roomTypeList' => array_merge($_hotelList[$hotel->{DirectDiscountProgram::AS_HOTEL_SN}]['roomTypeList'],
                        array(
                            [
                                'roomTypeSn'                        => $hotel->{DirectDiscountProgram::AS_ROOM_TYPE_SN},
                                'roomTypeName'                      => $hotel->{DirectDiscountProgram::AS_ROOM_TYPE_NAME},
                                'firstHourOrigin'                   => $hotel->{DirectDiscountProgram::AS_FIRST_HOURS_ORIGIN},
                                'additionOrigin'                    => $hotel->{DirectDiscountProgram::AS_ADDITIONAL_ORIGIN},
                                'overnightOrigin'                   => $hotel->{DirectDiscountProgram::AS_OVERNIGHT_ORIGIN},
                                'oneDayOrigin'                      => $hotel->{DirectDiscountProgram::AS_ONE_DAY_ORIGIN},
                                'priceFirstHoursDiscountPercent'    => 0,
                                'priceFirstHoursAfterDiscount'      => $hotel->{DirectDiscountProgram::AS_FIRST_HOURS_ORIGIN},
                                'priceAdditionHoursDiscountPercent' => 0,
                                'priceAdditionHoursAfterDiscount'   => $hotel->{DirectDiscountProgram::AS_ADDITIONAL_ORIGIN},
                                'priceOvernightDiscountPercent'     => 0,
                                'priceOvernightAfterDiscount'       => $hotel->{DirectDiscountProgram::AS_OVERNIGHT_ORIGIN},
                                'priceOneDayDiscountPercent'        => 0,
                                'priceOneDayAfterDiscount'          => $hotel->{DirectDiscountProgram::AS_ONE_DAY_ORIGIN},
                                'status'                            => $status,
                            ],
                        )

                    ),
                ];
            } else {
                $_hotelList[$hotel->{DirectDiscountProgram::AS_HOTEL_SN}] = [

                    'hotelSn'      => $hotel->{DirectDiscountProgram::AS_HOTEL_SN},
                    'hotelName'    => $hotel->{DirectDiscountProgram::AS_HOTEL_NAME},
                    'hotelCode'    => $hotel->{DirectDiscountProgram::AS_HOTEL_CODE},
                    'roomTypeList' => array(
                        [
                            'roomTypeSn'                        => $hotel->{DirectDiscountProgram::AS_ROOM_TYPE_SN},
                            'roomTypeName'                      => $hotel->{DirectDiscountProgram::AS_ROOM_TYPE_NAME},
                            'firstHourOrigin'                   => $hotel->{DirectDiscountProgram::AS_FIRST_HOURS_ORIGIN},
                            'additionOrigin'                    => $hotel->{DirectDiscountProgram::AS_ADDITIONAL_ORIGIN},
                            'overnightOrigin'                   => $hotel->{DirectDiscountProgram::AS_OVERNIGHT_ORIGIN},
                            'oneDayOrigin'                      => $hotel->{DirectDiscountProgram::AS_ONE_DAY_ORIGIN},
                            'priceFirstHoursDiscountPercent'    => 0,
                            'priceFirstHoursAfterDiscount'      => $hotel->{DirectDiscountProgram::AS_FIRST_HOURS_ORIGIN},
                            'priceAdditionHoursDiscountPercent' => 0,
                            'priceAdditionHoursAfterDiscount'   => $hotel->{DirectDiscountProgram::AS_ADDITIONAL_ORIGIN},
                            'priceOvernightDiscountPercent'     => 0,
                            'priceOvernightAfterDiscount'       => $hotel->{DirectDiscountProgram::AS_OVERNIGHT_ORIGIN},
                            'priceOneDayDiscountPercent'        => 0,
                            'priceOneDayAfterDiscount'          => $hotel->{DirectDiscountProgram::AS_ONE_DAY_ORIGIN},
                            'status'                            => $status,
                        ],
                    ),
                ];
            }

        }

        return $_hotelList;
    }
}