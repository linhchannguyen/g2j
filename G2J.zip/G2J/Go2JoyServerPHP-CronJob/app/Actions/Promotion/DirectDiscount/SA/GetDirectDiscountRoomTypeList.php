<?php

namespace App\Actions\Promotion\DirectDiscount\SA;

use App\Constants\DirectDiscountProgram as DirectDiscountProgramConst;
use App\Constants\DirectDiscountProgramRoomType as DirectDiscountProgramRoomTypeConst;
use App\DTOs\Promotion\DirectDiscount\SA\GetDirectDiscountRoomTypeListInputDTO;
use App\DTOs\Promotion\DirectDiscount\SA\GetDirectDiscountRoomTypeListOutputDTO;
use App\Helpers\CommonHelper;
use App\Helpers\ConvertHelper;
use App\Models\DirectDiscountProgram;
use App\Repositories\Interfaces\DirectDiscountProgramRepositoryInterface;
use App\Repositories\Interfaces\DirectDiscountProgramRoomTypeRepositoryInterface;

class GetDirectDiscountRoomTypeList
{
    public $directDiscountProgramRepository;

    public $directDiscountProgramRoomTypeRepository;

    public function __construct()
    {
        $this->directDiscountProgramRepository = app(DirectDiscountProgramRepositoryInterface::class);
        $this->directDiscountProgramRoomTypeRepository = app(DirectDiscountProgramRoomTypeRepositoryInterface::class);
    }

    public function handle(GetDirectDiscountRoomTypeListInputDTO $getDirectDiscountRoomTypeListInputDTO): GetDirectDiscountRoomTypeListOutputDTO
    {
        $hotelList = $this->directDiscountProgramRoomTypeRepository->findDirectDiscountProgramRoomTypeActive($getDirectDiscountRoomTypeListInputDTO->getDirectDiscountProgramSn(), $getDirectDiscountRoomTypeListInputDTO->getKeyword());
        $hotelList = $this->_generateDataRoomTypeList($hotelList);
        $directDiscountProgram = $this->directDiscountProgramRepository->findDirectDiscountDetail($getDirectDiscountRoomTypeListInputDTO->getDirectDiscountProgramSn());
        $this->_checkRoomAvailable($directDiscountProgram, $hotelList);

        return GetDirectDiscountRoomTypeListOutputDTO::assemble(CommonHelper::paginate($hotelList, $getDirectDiscountRoomTypeListInputDTO->getLimit()));
    }

    private function _generateDataRoomTypeList($hotelList)
    {
        $_hotelList = [];
        foreach ($hotelList as $hotel) {
            if (isset($_hotelList[$hotel->{DirectDiscountProgram::AS_HOTEL_SN}])) {
                $_hotelList[$hotel->{DirectDiscountProgram::AS_HOTEL_SN}] = [
                    'hotelSn'      => $hotel->{DirectDiscountProgram::AS_HOTEL_SN},
                    'hotelName'    => $hotel->{DirectDiscountProgram::AS_HOTEL_NAME},
                    'hotelCode'    => $hotel->{DirectDiscountProgram::AS_HOTEL_CODE},
                    'roomTypeList' => array_merge($_hotelList[$hotel->{DirectDiscountProgram::AS_HOTEL_SN}]['roomTypeList'],
                        array(
                            [
                                'roomTypeSn'                        => $hotel->{DirectDiscountProgram::AS_ROOM_TYPE_SN},
                                'roomTypeName'                      => $hotel->{DirectDiscountProgram::AS_ROOM_TYPE_NAME},
                                'firstHourOrigin'                   => $hotel->{DirectDiscountProgram::AS_FIRST_HOURS_ORIGIN},
                                'additionOrigin'                    => $hotel->{DirectDiscountProgram::AS_ADDITIONAL_ORIGIN},
                                'overnightOrigin'                   => $hotel->{DirectDiscountProgram::AS_OVERNIGHT_ORIGIN},
                                'oneDayOrigin'                      => $hotel->{DirectDiscountProgram::AS_ONE_DAY_ORIGIN},
                                'priceFirstHoursDiscountPercent'    => $hotel->{DirectDiscountProgram::AS_COL_PRICE_FIRST_HOURS_DISCOUNT_PERCENT},
                                'priceFirstHoursAfterDiscount'      => $hotel->{DirectDiscountProgram::AS_COL_PRICE_FIRST_HOURS_AFTER_DISCOUNT},
                                'priceAdditionHoursDiscountPercent' => $hotel->{DirectDiscountProgram::AS_COL_PRICE_ADDITIONAL_HOURS_DISCOUNT_PERCENT},
                                'priceAdditionHoursAfterDiscount'   => $hotel->{DirectDiscountProgram::AS_COL_PRICE_ADDITIONAL_HOURS_AFTER_DISCOUNT},
                                'priceOvernightDiscountPercent'     => $hotel->{DirectDiscountProgram::AS_COL_PRICE_OVERNIGHT_DISCOUNT_PERCENT},
                                'priceOvernightAfterDiscount'       => $hotel->{DirectDiscountProgram::AS_COL_PRICE_OVERNIGHT_AFTER_DISCOUNT},
                                'priceOneDayDiscountPercent'        => $hotel->{DirectDiscountProgram::AS_COL_PRICE_ONE_DAY_DISCOUNT_PERCENT},
                                'priceOneDayAfterDiscount'          => $hotel->{DirectDiscountProgram::AS_COL_PRICE_ONE_DAY_AFTER_DISCOUNT},
                                'status'                            => $hotel->{DirectDiscountProgram::AS_STATUS},
                            ],
                        )

                    ),
                ];
            } else {
                $_hotelList[$hotel->{DirectDiscountProgram::AS_HOTEL_SN}] = [

                    'hotelSn'      => $hotel->{DirectDiscountProgram::AS_HOTEL_SN},
                    'hotelName'    => $hotel->{DirectDiscountProgram::AS_HOTEL_NAME},
                    'hotelCode'    => $hotel->{DirectDiscountProgram::AS_HOTEL_CODE},
                    'roomTypeList' => array(
                        [
                            'roomTypeSn'                        => $hotel->{DirectDiscountProgram::AS_ROOM_TYPE_SN},
                            'roomTypeName'                      => $hotel->{DirectDiscountProgram::AS_ROOM_TYPE_NAME},
                            'firstHourOrigin'                   => $hotel->{DirectDiscountProgram::AS_FIRST_HOURS_ORIGIN},
                            'additionOrigin'                    => $hotel->{DirectDiscountProgram::AS_ADDITIONAL_ORIGIN},
                            'overnightOrigin'                   => $hotel->{DirectDiscountProgram::AS_OVERNIGHT_ORIGIN},
                            'oneDayOrigin'                      => $hotel->{DirectDiscountProgram::AS_ONE_DAY_ORIGIN},
                            'priceFirstHoursDiscountPercent'    => $hotel->{DirectDiscountProgram::AS_COL_PRICE_FIRST_HOURS_DISCOUNT_PERCENT},
                            'priceFirstHoursAfterDiscount'      => $hotel->{DirectDiscountProgram::AS_COL_PRICE_FIRST_HOURS_AFTER_DISCOUNT},
                            'priceAdditionHoursDiscountPercent' => $hotel->{DirectDiscountProgram::AS_COL_PRICE_ADDITIONAL_HOURS_DISCOUNT_PERCENT},
                            'priceAdditionHoursAfterDiscount'   => $hotel->{DirectDiscountProgram::AS_COL_PRICE_ADDITIONAL_HOURS_AFTER_DISCOUNT},
                            'priceOvernightDiscountPercent'     => $hotel->{DirectDiscountProgram::AS_COL_PRICE_OVERNIGHT_DISCOUNT_PERCENT},
                            'priceOvernightAfterDiscount'       => $hotel->{DirectDiscountProgram::AS_COL_PRICE_OVERNIGHT_AFTER_DISCOUNT},
                            'priceOneDayDiscountPercent'        => $hotel->{DirectDiscountProgram::AS_COL_PRICE_ONE_DAY_DISCOUNT_PERCENT},
                            'priceOneDayAfterDiscount'          => $hotel->{DirectDiscountProgram::AS_COL_PRICE_ONE_DAY_AFTER_DISCOUNT},
                            'status'                            => $hotel->{DirectDiscountProgram::AS_STATUS},
                        ],
                    ),
                ];
            }

        }

        return $_hotelList;
    }

    private function _checkRoomAvailable($directDiscountProgram, &$hotelList)
    {
        $directDiscountSnList = [];
        if ($directDiscountProgram->{DirectDiscountProgram::COL_TYPE_APPLY} == DirectDiscountProgramConst::TYPE_APPLY['DAY_OF_WEEK']) {
            $directDiscountList = $this->directDiscountProgramRepository->getExistRangeDayDirectDiscountHotel($directDiscountProgram->{DirectDiscountProgram::COL_SN}, $directDiscountProgram->{DirectDiscountProgram::COL_TYPE_APPLY},
                $directDiscountProgram->{DirectDiscountProgram::COL_START_DATE}, $directDiscountProgram->{DirectDiscountProgram::COL_END_DATE}, $directDiscountProgram->{DirectDiscountProgram::COL_MONDAY},
                $directDiscountProgram->{DirectDiscountProgram::COL_TUESDAY}, $directDiscountProgram->{DirectDiscountProgram::COL_WEDNESDAY}, $directDiscountProgram->{DirectDiscountProgram::COL_THURSDAY},
                $directDiscountProgram->{DirectDiscountProgram::COL_FRIDAY}, $directDiscountProgram->{DirectDiscountProgram::COL_SATURDAY}, $directDiscountProgram->{DirectDiscountProgram::COL_SUNDAY});
            $directDiscountSnList = $directDiscountList->pluck(DirectDiscountProgram::COL_SN)->toArray();
        } else {
            $specialDateArray = ConvertHelper::toArray($directDiscountProgram->{DirectDiscountProgram::COL_SPECIAL_DATE});
            $directDiscountList = $this->directDiscountProgramRepository->getExistSpecialDayDirectDiscountHotel($directDiscountProgram->{DirectDiscountProgram::COL_SN}, $directDiscountProgram->{DirectDiscountProgram::COL_TYPE_APPLY});
            foreach ($directDiscountList as $directDiscount) {
                $array = ConvertHelper::toArray($directDiscount->{DirectDiscountProgram::COL_SPECIAL_DATE});
                if (count(array_intersect($specialDateArray, $array)) !== 0) {
                    $directDiscountSnList[] = [
                        $directDiscount->{DirectDiscountProgram::COL_SN},
                    ];
                }
            }
        }
        $roomTypeListRunningDirectDiscount = $this->directDiscountProgramRoomTypeRepository->findDirectDiscountProgramRoomTypeRunning($directDiscountSnList)->pluck('ROOM_TYPE_SN')->toArray();
        foreach ($hotelList as &$hotel) {
            foreach ($hotel['roomTypeList'] as &$roomType) {
                if (in_array($roomType['roomTypeSn'], $roomTypeListRunningDirectDiscount)) {
                    $roomType['status'] = DirectDiscountProgramRoomTypeConst::STATUS['UNAVAILABLE'];
                } else {
                    $roomType['status'] = DirectDiscountProgramRoomTypeConst::STATUS['AVAILABLE'];
                }
            }
        }
    }
}