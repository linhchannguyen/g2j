<?php

namespace App\Actions\Promotion\DirectDiscount\SA;

use App\DTOs\Promotion\DirectDiscount\SA\GetDirectDiscountListInputDTO;
use App\DTOs\Promotion\DirectDiscount\SA\GetDirectDiscountListOutputDTO;
use App\Repositories\Interfaces\DirectDiscountProgramRepositoryInterface;

class GetDirectDiscountList
{
    public $directDiscountProgramRepository;

    public function __construct()
    {
        $this->directDiscountProgramRepository = app(DirectDiscountProgramRepositoryInterface::class);

    }

    public function handle(GetDirectDiscountListInputDTO $getDirectDiscountListInputDTO): GetDirectDiscountListOutputDTO
    {
        $directDiscountList = $this->directDiscountProgramRepository->findDirectDiscountList($getDirectDiscountListInputDTO->getKeyword(), $getDirectDiscountListInputDTO->getStatus(), $getDirectDiscountListInputDTO->limit);

        if ($directDiscountList->isEmpty()) {
            return new GetDirectDiscountListOutputDTO();
        }

        return GetDirectDiscountListOutputDTO::assemble($directDiscountList);
    }
}