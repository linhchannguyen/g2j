<?php

namespace App\Actions\Promotion\DirectDiscount\SA;

use App\Actions\Promotion\DirectDiscount\CreateRoomPriceAdjustment;
use App\Actions\Promotion\DirectDiscount\DeleteRoomPriceAdjustment;
use App\Actions\Promotion\DirectDiscount\UpdateRoomPriceAdjustment;
use App\Constants\DirectDiscountProgram as DirectDiscountProgramConst;
use App\Constants\DirectDiscountProgramActionHistory as DirectDiscountProgramActionHistoryConst;
use App\Constants\DirectDiscountProgramRoomType as DirectDiscountProgramRoomTypeConst;
use App\Constants\Globals\Code as CodeConst;
use App\Constants\Globals\FunctionName;
use App\Constants\RoomPriceAdjustment as RoomPriceAdjustmentConst;
use App\DTOs\Promotion\DirectDiscount\CreateRoomPriceAdjustmentInputDTO;
use App\DTOs\Promotion\DirectDiscount\DeleteRoomPriceAdjustmentInputDTO;
use App\DTOs\Promotion\DirectDiscount\SA\CreateDirectDiscountOutputDTO;
use App\DTOs\Promotion\DirectDiscount\SA\UpdateDirectDiscountInputDTO;
use App\DTOs\Promotion\DirectDiscount\UpdateRoomPriceAdjustmentInputDTO;
use App\Exceptions\ServiceException;
use App\Helpers\CommonHelper;
use App\Helpers\GenerateHelper;
use App\Models\DirectDiscountProgram;
use App\Models\DirectDiscountProgramHotel;
use App\Models\DirectDiscountProgramRoomType;
use App\Models\DirectDiscountProgramRoomTypeHistory;
use App\Models\RoomPriceAdjustment;
use App\Repositories\Interfaces\DirectDiscountProgramActionHistoryRepositoryInterface;
use App\Repositories\Interfaces\DirectDiscountProgramHotelRepositoryInterface;
use App\Repositories\Interfaces\DirectDiscountProgramRepositoryInterface;
use App\Repositories\Interfaces\DirectDiscountProgramRoomTypeHistoryRepositoryInterface;
use App\Repositories\Interfaces\DirectDiscountProgramRoomTypeRepositoryInterface;
use App\Repositories\Interfaces\RoomPriceAdjustmentRepositoryInterface;
use Exception;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;

class UpdateDirectDiscount
{
    const FILE_LANGUAGE_NAME = 'promotion';

    public $directDiscountProgramRepository;

    public $directDiscountProgramHotelRepository;

    public $directDiscountProgramRoomTypeRepository;

    public $directDiscountProgramRoomTypeHistoryRepository;

    public $directDiscountProgramActionHistoryRepository;

    public $roomPriceAdjustmentRepository;

    public function __construct()
    {
        $this->directDiscountProgramRepository = app(DirectDiscountProgramRepositoryInterface::class);
        $this->directDiscountProgramHotelRepository = app(DirectDiscountProgramHotelRepositoryInterface::class);
        $this->directDiscountProgramRoomTypeRepository = app(DirectDiscountProgramRoomTypeRepositoryInterface::class);
        $this->directDiscountProgramRoomTypeHistoryRepository = app(DirectDiscountProgramRoomTypeHistoryRepositoryInterface::class);
        $this->directDiscountProgramActionHistoryRepository = app(DirectDiscountProgramActionHistoryRepositoryInterface::class);
        $this->roomPriceAdjustmentRepository = app(RoomPriceAdjustmentRepositoryInterface::class);
    }

    public function handle(UpdateDirectDiscountInputDTO $updateDirectDiscountInputDTO)
    {
        try {
            $hotelList = [];
            $key = GenerateHelper::cacheName(FunctionName::APPLYING_DIRECT_DISCOUNT, $updateDirectDiscountInputDTO->getUpdateBy());
            if (Cache::store('redis')->has($key)) {
                $obj = json_decode(Cache::store('redis')->get($key), true);
                $hotelList = !empty($obj['data']) ? $obj['data'] : [];
                foreach ($hotelList as $index => $hotel) {
                    $check = true;
                    foreach ($hotel['roomTypeList'] as $roomType) {
                        if ($roomType['status'] == DirectDiscountProgramRoomTypeConst::STATUS['AVAILABLE']
                            && ($roomType['priceFirstHoursAfterDiscount'] != $roomType['firstHourOrigin']
                                || $roomType['priceAdditionHoursAfterDiscount'] != $roomType['additionOrigin']
                                || $roomType['priceOvernightAfterDiscount'] != $roomType['overnightOrigin']
                                || $roomType['priceOneDayAfterDiscount'] != $roomType['oneDayOrigin'])) {
                            $check = false;
                            break;
                        }
                    }
                    if ($check) {
                        unset($hotelList[$index]);
                    }
                }
            }
            if(count($hotelList) > DirectDiscountProgramConst::LIMIT_HOTEL){
                throw new ServiceException(CommonHelper::getMessage(self::FILE_LANGUAGE_NAME, CodeConst::API_PRN_017), CodeConst::API_PRN_017);
            }

            $directDiscountProgramHotelList = $this->directDiscountProgramHotelRepository->findDirectDiscountProgramHotel($updateDirectDiscountInputDTO->getDirectDiscountSn());
            $hotelDeleteList = $this->_checkHotelList($directDiscountProgramHotelList, $hotelList);

            DB::connection('mysql')->beginTransaction();
            $this->directDiscountProgramRepository->update([
                DirectDiscountProgram::COL_UPDATED_NAME       => $updateDirectDiscountInputDTO->getUpdatedName(),
                DirectDiscountProgram::COL_UPDATED_BY         => $updateDirectDiscountInputDTO->getUpdateBy(),
                DirectDiscountProgram::COL_TOTAL_HOTEL_JOINED => count($hotelList),
            ], $updateDirectDiscountInputDTO->getDirectDiscountSn());
            $directDiscountProgram = $this->directDiscountProgramRepository->findDirectDiscountDetail($updateDirectDiscountInputDTO->getDirectDiscountSn());
            $actionSn = $this->directDiscountProgramActionHistoryRepository->createUpdateHistory($updateDirectDiscountInputDTO->getDirectDiscountSn(), $updateDirectDiscountInputDTO->getUpdateBy(), DirectDiscountProgramActionHistoryConst::ACTION_USER_TYPE['GO2JOY_STAFF'], Carbon::now(), json_encode($directDiscountProgram));
            $directDiscountRoomTypeList = $this->_updateDirectDiscountHotel($actionSn, $directDiscountProgram, $hotelList);
            $this->_deleteDirectDiscountHotel($directDiscountProgram->{DirectDiscountProgram::COL_SN}, $hotelDeleteList);
            $this->_updateRoomPriceAdjustment($directDiscountProgram, $directDiscountRoomTypeList);
            DB::connection('mysql')->commit();
            Cache::store('redis')->delete($key);
        } catch (Exception $e) {
            DB::connection('mysql')->rollBack();
            throw $e;
        }

        return CreateDirectDiscountOutputDTO::assemble($directDiscountProgram);
    }

    private function _checkHotelList($directDiscountProgramHotelList, $hotelList)
    {
        $directDiscountProgramHasHotelList = $directDiscountProgramHotelList->pluck(DirectDiscountProgramHotel::COL_HOTEL_SN)->toArray();
        $updateHotelList = array_keys($hotelList);

        return array_diff($directDiscountProgramHasHotelList, $updateHotelList);

    }

    private function _updateDirectDiscountHotel($actionSn, $directDiscountProgram, $hotelList)
    {
        $directDiscountRoomTypeHistoryList = [];

        foreach ($hotelList as $hotel) {
            DirectDiscountProgramHotel::updateOrcreate(
                [
                    DirectDiscountProgramHotel::COL_DIRECT_DISCOUNT_PROGRAM_SN => $directDiscountProgram->{DirectDiscountProgram::COL_SN},
                    DirectDiscountProgramHotel::COL_HOTEL_SN                   => $hotel['hotelSn'],
                ],
                [
                    DirectDiscountProgramHotel::COL_DIRECT_DISCOUNT_PROGRAM_NAME => $directDiscountProgram->{DirectDiscountProgram::COL_NAME},
                    DirectDiscountProgramHotel::COL_TYPE_APPLY                   => $directDiscountProgram->{DirectDiscountProgram::COL_TYPE_APPLY},
                    DirectDiscountProgramHotel::COL_STATUS                       => DirectDiscountProgramConst::STATUS['RUNNING'],
                    DirectDiscountProgramHotel::COL_START_DATE                   => $directDiscountProgram->{DirectDiscountProgram::COL_START_DATE},
                    DirectDiscountProgramHotel::COL_END_DATE                     => $directDiscountProgram->{DirectDiscountProgram::COL_END_DATE},
                    DirectDiscountProgramHotel::COL_SPECIAL_DATE                 => $directDiscountProgram->{DirectDiscountProgram::COL_SPECIAL_DATE},
                    DirectDiscountProgramHotel::COL_START_TIME                   => $directDiscountProgram->{DirectDiscountProgram::COL_START_TIME},
                    DirectDiscountProgramHotel::COL_END_TIME                     => $directDiscountProgram->{DirectDiscountProgram::COL_END_TIME},
                    DirectDiscountProgramHotel::COL_MONDAY                       => $directDiscountProgram->{DirectDiscountProgram::COL_MONDAY},
                    DirectDiscountProgramHotel::COL_TUESDAY                      => $directDiscountProgram->{DirectDiscountProgram::COL_TUESDAY},
                    DirectDiscountProgramHotel::COL_WEDNESDAY                    => $directDiscountProgram->{DirectDiscountProgram::COL_WEDNESDAY},
                    DirectDiscountProgramHotel::COL_THURSDAY                     => $directDiscountProgram->{DirectDiscountProgram::COL_THURSDAY},
                    DirectDiscountProgramHotel::COL_FRIDAY                       => $directDiscountProgram->{DirectDiscountProgram::COL_FRIDAY},
                    DirectDiscountProgramHotel::COL_SATURDAY                     => $directDiscountProgram->{DirectDiscountProgram::COL_SATURDAY},
                    DirectDiscountProgramHotel::COL_SUNDAY                       => $directDiscountProgram->{DirectDiscountProgram::COL_SUNDAY},
                    DirectDiscountProgramHotel::COL_CREATED_NAME                 => DirectDiscountProgramConst::CREATE_NAME['GO2JOY'],
                ]
            );
            foreach ($hotel['roomTypeList'] as $roomType) {
                DirectDiscountProgramRoomType::updateOrcreate([
                    DirectDiscountProgramRoomType::COL_DIRECT_DISCOUNT_PROGRAM_SN => $directDiscountProgram->{DirectDiscountProgram::COL_SN},
                    DirectDiscountProgramRoomType::COL_ROOM_TYPE_SN               => $roomType['roomTypeSn'],
                ], [
                    DirectDiscountProgramRoomType::COL_DIRECT_DISCOUNT_PROGRAM_SN              => $directDiscountProgram->{DirectDiscountProgram::COL_SN},
                    DirectDiscountProgramRoomType::COL_STATUS                                  => $this->_statusOfRoomType($roomType),
                    DirectDiscountProgramRoomType::COL_HOTEL_SN                                => $hotel['hotelSn'],
                    DirectDiscountProgramRoomType::COL_HOTEL_NAME                              => $hotel['hotelName'],
                    DirectDiscountProgramRoomType::COL_HOTEL_CODE                              => $hotel['hotelCode'],
                    DirectDiscountProgramRoomType::COL_ROOM_TYPE_SN                            => $roomType['roomTypeSn'],
                    DirectDiscountProgramRoomType::COL_ROOM_TYPE_NAME                          => $roomType['roomTypeName'],
                    DirectDiscountProgramRoomType::COL_PRICE_FIRST_HOURS_DISCOUNT_PERCENT      => $roomType['priceFirstHoursDiscountPercent'],
                    DirectDiscountProgramRoomType::COL_PRICE_FIRST_HOURS_AFTER_DISCOUNT        => $roomType['priceFirstHoursAfterDiscount'],
                    DirectDiscountProgramRoomType::COL_PRICE_ADDITIONAL_HOURS_DISCOUNT_PERCENT => $roomType['priceAdditionHoursDiscountPercent'],
                    DirectDiscountProgramRoomType::COL_PRICE_ADDITIONAL_HOURS_AFTER_DISCOUNT   => $roomType['priceAdditionHoursAfterDiscount'],
                    DirectDiscountProgramRoomType::COL_PRICE_OVERNIGHT_DISCOUNT_PERCENT        => $roomType['priceOvernightDiscountPercent'],
                    DirectDiscountProgramRoomType::COL_PRICE_OVERNIGHT_AFTER_DISCOUNT          => $roomType['priceOvernightAfterDiscount'],
                    DirectDiscountProgramRoomType::COL_PRICE_ONE_DAY_DISCOUNT_PERCENT          => $roomType['priceOneDayDiscountPercent'],
                    DirectDiscountProgramRoomType::COL_PRICE_ONE_DAY_AFTER_DISCOUNT            => $roomType['priceOneDayAfterDiscount'],
                    DirectDiscountProgramRoomType::COL_FIRST_HOURS_ORIGIN                      => $roomType['firstHourOrigin'],
                    DirectDiscountProgramRoomType::COL_ADDITIONAL_ORIGIN                       => $roomType['additionOrigin'],
                    DirectDiscountProgramRoomType::COL_OVERNIGHT_ORIGIN                        => $roomType['overnightOrigin'],
                    DirectDiscountProgramRoomType::COL_ONE_DAY_ORIGIN                          => $roomType['oneDayOrigin'],
                    DirectDiscountProgramRoomType::COL_DELETED_AT                              => null,
                ]);

                $directDiscountRoomTypeHistoryList [] = [
                    DirectDiscountProgramRoomTypeHistory::COL_DIRECT_DISCOUNT_PROGRAM_SN                => $directDiscountProgram->{DirectDiscountProgram::COL_SN},
                    DirectDiscountProgramRoomTypeHistory::COL_DIRECT_DISCOUNT_PROGRAM_ACTION_HISTORY_SN => $actionSn,
                    DirectDiscountProgramRoomTypeHistory::COL_STATUS                                    => $this->_statusOfRoomType($roomType),
                    DirectDiscountProgramRoomTypeHistory::COL_HOTEL_SN                                  => $hotel['hotelSn'],
                    DirectDiscountProgramRoomTypeHistory::COL_HOTEL_NAME                                => $hotel['hotelName'],
                    DirectDiscountProgramRoomTypeHistory::COL_HOTEL_CODE                                => $hotel['hotelCode'],
                    DirectDiscountProgramRoomTypeHistory::COL_ROOM_TYPE_SN                              => $roomType['roomTypeSn'],
                    DirectDiscountProgramRoomTypeHistory::COL_ROOM_TYPE_NAME                            => $roomType['roomTypeName'],
                    DirectDiscountProgramRoomTypeHistory::COL_PRICE_FIRST_HOURS_DISCOUNT_PERCENT        => $roomType['priceFirstHoursDiscountPercent'],
                    DirectDiscountProgramRoomTypeHistory::COL_PRICE_FIRST_HOURS_AFTER_DISCOUNT          => $roomType['priceFirstHoursAfterDiscount'],
                    DirectDiscountProgramRoomTypeHistory::COL_PRICE_ADDITIONAL_HOURS_DISCOUNT_PERCENT   => $roomType['priceAdditionHoursDiscountPercent'],
                    DirectDiscountProgramRoomTypeHistory::COL_PRICE_ADDITIONAL_HOURS_AFTER_DISCOUNT     => $roomType['priceAdditionHoursAfterDiscount'],
                    DirectDiscountProgramRoomTypeHistory::COL_PRICE_OVERNIGHT_DISCOUNT_PERCENT          => $roomType['priceOvernightDiscountPercent'],
                    DirectDiscountProgramRoomTypeHistory::COL_PRICE_OVERNIGHT_AFTER_DISCOUNT            => $roomType['priceOvernightAfterDiscount'],
                    DirectDiscountProgramRoomTypeHistory::COL_PRICE_ONE_DAY_DISCOUNT_PERCENT            => $roomType['priceOneDayDiscountPercent'],
                    DirectDiscountProgramRoomTypeHistory::COL_PRICE_ONE_DAY_AFTER_DISCOUNT              => $roomType['priceOneDayAfterDiscount'],
                    DirectDiscountProgramRoomTypeHistory::COL_FIRST_HOURS_ORIGIN                        => $roomType['firstHourOrigin'],
                    DirectDiscountProgramRoomTypeHistory::COL_ADDITIONAL_ORIGIN                         => $roomType['additionOrigin'],
                    DirectDiscountProgramRoomTypeHistory::COL_OVERNIGHT_ORIGIN                          => $roomType['overnightOrigin'],
                    DirectDiscountProgramRoomTypeHistory::COL_ONE_DAY_ORIGIN                            => $roomType['oneDayOrigin'],
                ];
            }
        }
        $this->directDiscountProgramRoomTypeHistoryRepository->batchInsert($directDiscountRoomTypeHistoryList);

        return $directDiscountRoomTypeHistoryList;
    }

    private function _statusOfRoomType($roomType)
    {
        if ($roomType['status'] == DirectDiscountProgramRoomTypeConst::STATUS['AVAILABLE']
            && $roomType['priceFirstHoursAfterDiscount'] == $roomType['firstHourOrigin']
            && $roomType['priceAdditionHoursAfterDiscount'] == $roomType['additionOrigin']
            && $roomType['priceOvernightAfterDiscount'] == $roomType['overnightOrigin']
            && $roomType['priceOneDayAfterDiscount'] == $roomType['oneDayOrigin']) {
            return DirectDiscountProgramRoomTypeConst::STATUS['PENDING'];
        }

        return $roomType['status'];
    }

    private function _deleteDirectDiscountHotel($directDiscountProgramSn, $hotelDeleteList)
    {
        $this->directDiscountProgramHotelRepository->deleteDirectDiscountHotel($directDiscountProgramSn, $hotelDeleteList);
        $this->directDiscountProgramRoomTypeRepository->deleteDirectDiscountRoomType($directDiscountProgramSn, $hotelDeleteList);
    }

    private function _updateRoomPriceAdjustment($directDiscountProgram, array $directDiscountRoomTypeList)
    {
        $deleteRoomPriceAdjustment = new DeleteRoomPriceAdjustment();
        $updateRoomPriceAdjustment = new UpdateRoomPriceAdjustment();
        $exceptionRoomTypeSnList = array_column($directDiscountRoomTypeList,DirectDiscountProgramRoomType::COL_ROOM_TYPE_SN);
        $roomPriceAdjustmentList = $this->roomPriceAdjustmentRepository->findRoomPriceAdjustmentListByCondition($directDiscountProgram->{DirectDiscountProgram::COL_SN}, $exceptionRoomTypeSnList);
        foreach ($roomPriceAdjustmentList as $roomPriceAdjustment) {
            $deleteRoomPriceAdjustmentInputDTO = new DeleteRoomPriceAdjustmentInputDTO();
            $deleteRoomPriceAdjustmentInputDTO->setDirectDiscountProgramSn($directDiscountProgram->{DirectDiscountProgram::COL_SN});
            $deleteRoomPriceAdjustmentInputDTO->setRoomTypeSn($roomPriceAdjustment->{RoomPriceAdjustment::COL_ROOM_TYPE_SN});
            $deleteRoomPriceAdjustmentInputDTO->setDeleteStaffSn($directDiscountProgram->{DirectDiscountProgram::COL_UPDATED_BY});
            $deleteRoomPriceAdjustment->handle($deleteRoomPriceAdjustmentInputDTO);
        }

        foreach ($directDiscountRoomTypeList as $directDiscountRoomType) {
            if ($directDiscountRoomType[DirectDiscountProgramRoomType::COL_STATUS] != DirectDiscountProgramRoomTypeConst::STATUS['AVAILABLE']) {
                $deleteRoomPriceAdjustmentInputDTO = new DeleteRoomPriceAdjustmentInputDTO();
                $deleteRoomPriceAdjustmentInputDTO->setDirectDiscountProgramSn($directDiscountProgram->{DirectDiscountProgram::COL_SN});
                $deleteRoomPriceAdjustmentInputDTO->setRoomTypeSn($directDiscountRoomType[DirectDiscountProgramRoomType::COL_ROOM_TYPE_SN]);
                $deleteRoomPriceAdjustmentInputDTO->setDeleteStaffSn($directDiscountProgram->{DirectDiscountProgram::COL_UPDATED_BY});
                $deleteRoomPriceAdjustment->handle($deleteRoomPriceAdjustmentInputDTO);
                continue;
            }

            $updateRoomPriceAdjustmentInputDTO = new UpdateRoomPriceAdjustmentInputDTO();
            $updateRoomPriceAdjustmentInputDTO->setDirectDiscountProgramSn($directDiscountProgram->{DirectDiscountProgram::COL_SN});
            $updateRoomPriceAdjustmentInputDTO->setRoomTypeSn($directDiscountRoomType[DirectDiscountProgramRoomType::COL_ROOM_TYPE_SN]);
            $updateRoomPriceAdjustmentInputDTO->setType(RoomPriceAdjustmentConst::TYPE['DIRECT_DISCOUNT']);
            $updateRoomPriceAdjustmentInputDTO->setTypeApply($directDiscountProgram->{DirectDiscountProgram::COL_TYPE_APPLY});
            $updateRoomPriceAdjustmentInputDTO->setPriceFirstHours($directDiscountRoomType[DirectDiscountProgramRoomType::COL_PRICE_FIRST_HOURS_AFTER_DISCOUNT]);
            $updateRoomPriceAdjustmentInputDTO->setPriceAdditionalHours($directDiscountRoomType[DirectDiscountProgramRoomType::COL_PRICE_ADDITIONAL_HOURS_AFTER_DISCOUNT]);
            $updateRoomPriceAdjustmentInputDTO->setPriceOvernight($directDiscountRoomType[DirectDiscountProgramRoomType::COL_PRICE_OVERNIGHT_AFTER_DISCOUNT]);
            $updateRoomPriceAdjustmentInputDTO->setPriceOneDay($directDiscountRoomType[DirectDiscountProgramRoomType::COL_PRICE_ONE_DAY_AFTER_DISCOUNT]);
            $updateRoomPriceAdjustmentInputDTO->setStartDate($directDiscountProgram->{DirectDiscountProgram::COL_START_DATE});
            $updateRoomPriceAdjustmentInputDTO->setEndDate($directDiscountProgram->{DirectDiscountProgram::COL_END_DATE});
            $updateRoomPriceAdjustmentInputDTO->setStartTime($directDiscountProgram->{DirectDiscountProgram::COL_START_TIME});
            $updateRoomPriceAdjustmentInputDTO->setEndTime($directDiscountProgram->{DirectDiscountProgram::COL_END_TIME});
            $updateRoomPriceAdjustmentInputDTO->setMonday($directDiscountProgram->{DirectDiscountProgram::COL_MONDAY});
            $updateRoomPriceAdjustmentInputDTO->setTuesday($directDiscountProgram->{DirectDiscountProgram::COL_TUESDAY});
            $updateRoomPriceAdjustmentInputDTO->setWednesday($directDiscountProgram->{DirectDiscountProgram::COL_WEDNESDAY});
            $updateRoomPriceAdjustmentInputDTO->setThursday($directDiscountProgram->{DirectDiscountProgram::COL_THURSDAY});
            $updateRoomPriceAdjustmentInputDTO->setFriday($directDiscountProgram->{DirectDiscountProgram::COL_FRIDAY});
            $updateRoomPriceAdjustmentInputDTO->setSaturday($directDiscountProgram->{DirectDiscountProgram::COL_SATURDAY});
            $updateRoomPriceAdjustmentInputDTO->setSunday($directDiscountProgram->{DirectDiscountProgram::COL_SUNDAY});
            $updateRoomPriceAdjustmentInputDTO->setSpecialDate($directDiscountProgram->{DirectDiscountProgram::COL_SPECIAL_DATE});
            $updateRoomPriceAdjustmentInputDTO->setUpdateStaffSn($directDiscountProgram->{DirectDiscountProgram::COL_UPDATED_BY});
            $updateRoomPriceAdjustment->handle($updateRoomPriceAdjustmentInputDTO);
        }
    }
    
}