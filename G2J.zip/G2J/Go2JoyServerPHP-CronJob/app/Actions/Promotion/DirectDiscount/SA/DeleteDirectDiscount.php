<?php

namespace App\Actions\Promotion\DirectDiscount\SA;

use App\Actions\Promotion\DirectDiscount\DeleteRoomPriceAdjustment;
use App\Constants\DirectDiscountProgram as DirectDiscountProgramConst;
use App\Constants\DirectDiscountProgramActionHistory as DirectDiscountProgramActionHistoryConst;
use App\DTOs\Promotion\DirectDiscount\DeleteRoomPriceAdjustmentInputDTO;
use App\DTOs\Promotion\DirectDiscount\SA\DeleteDirectDiscountHotelOutputDTO;
use App\DTOs\Promotion\DirectDiscount\SA\DeleteDirectDiscountInputDTO;
use App\Models\DirectDiscountProgram;
use App\Models\DirectDiscountProgramHotel;
use App\Models\DirectDiscountProgramRoomType;
use App\Models\DirectDiscountProgramRoomTypeHistory;
use App\Models\RoomPriceAdjustment;
use App\Repositories\Interfaces\DirectDiscountProgramActionHistoryRepositoryInterface;
use App\Repositories\Interfaces\DirectDiscountProgramHotelRepositoryInterface;
use App\Repositories\Interfaces\DirectDiscountProgramRepositoryInterface;
use App\Repositories\Interfaces\DirectDiscountProgramRoomTypeHistoryRepositoryInterface;
use App\Repositories\Interfaces\DirectDiscountProgramRoomTypeRepositoryInterface;
use App\Repositories\Interfaces\RoomPriceAdjustmentRepositoryInterface;
use Exception;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\DB;
use Throwable;

class DeleteDirectDiscount
{
    const FILE_LANGUAGE_NAME = 'promotion';

    public $hotelRepository;

    public $directDiscountProgramRepository;

    public $directDiscountProgramHotelRepository;

    public $directDiscountProgramRoomTypeRepository;

    public $directDiscountProgramRoomTypeHistoryRepository;

    public $directDiscountProgramActionHistoryRepository;

    public $roomPriceAdjustmentRepository;

    public function __construct()
    {
        $this->directDiscountProgramRepository = app(DirectDiscountProgramRepositoryInterface::class);
        $this->directDiscountProgramHotelRepository = app(DirectDiscountProgramHotelRepositoryInterface::class);
        $this->directDiscountProgramRoomTypeRepository = app(DirectDiscountProgramRoomTypeRepositoryInterface::class);
        $this->directDiscountProgramRoomTypeHistoryRepository = app(DirectDiscountProgramRoomTypeHistoryRepositoryInterface::class);
        $this->directDiscountProgramActionHistoryRepository = app(DirectDiscountProgramActionHistoryRepositoryInterface::class);
        $this->roomPriceAdjustmentRepository = app(RoomPriceAdjustmentRepositoryInterface::class);
    }

    /**
     * @throws Throwable
     */
    public function handle(DeleteDirectDiscountInputDTO $deleteDirectDiscountInputDTO): DeleteDirectDiscountHotelOutputDTO
    {
        $directDiscountProgram = $this->directDiscountProgramRepository->findDirectDiscountDetail($deleteDirectDiscountInputDTO->getDirectDiscountSn());
        if (!empty($directDiscountProgram)) {
            $tries = 5;
            DB::connection('mysql')->transaction(function () use($deleteDirectDiscountInputDTO, $directDiscountProgram) {
                $this->directDiscountProgramRepository->update([
                    DirectDiscountProgram::COL_STATUS       => DirectDiscountProgramConst::STATUS['STOPPED'],
                    DirectDiscountProgram::COL_UPDATED_NAME => $deleteDirectDiscountInputDTO->getUpdatedName(),
                    DirectDiscountProgram::COL_UPDATED_BY   => $deleteDirectDiscountInputDTO->getUpdateBy(),
                ], $deleteDirectDiscountInputDTO->getDirectDiscountSn());
                $actionSn = $this->directDiscountProgramActionHistoryRepository->createStoppedHistory($deleteDirectDiscountInputDTO->getDirectDiscountSn(), $deleteDirectDiscountInputDTO->getUpdateBy(), DirectDiscountProgramActionHistoryConst::ACTION_USER_TYPE['GO2JOY_STAFF'], Carbon::now(), json_encode($directDiscountProgram));
                $directDiscountRoomTypeList = $this->directDiscountProgramRoomTypeRepository->findDirectDiscountProgramRoomTypeActive($deleteDirectDiscountInputDTO->getDirectDiscountSn());
                $this->directDiscountProgramHotelRepository->updateWhere([
                    DirectDiscountProgram::COL_STATUS => DirectDiscountProgramConst::STATUS['STOPPED'],
                ], [DirectDiscountProgramHotel::COL_DIRECT_DISCOUNT_PROGRAM_SN => $deleteDirectDiscountInputDTO->getDirectDiscountSn()]);
                $this->_createDirectDiscountRoomTypeHistory($actionSn, $directDiscountRoomTypeList);
                $this->_deleteRoomPriceAdjustment($deleteDirectDiscountInputDTO);
            }, $tries);
        }

        return DeleteDirectDiscountHotelOutputDTO::assemble(true);
    }

    private function _createDirectDiscountRoomTypeHistory($actionSn, $directDiscountRoomTypeList)
    {
        $directDiscountRoomTypeHistory = [];
        foreach ($directDiscountRoomTypeList as $directDiscountRoomType) {
            $directDiscountRoomTypeHistory [] = [
                DirectDiscountProgramRoomTypeHistory::COL_DIRECT_DISCOUNT_PROGRAM_SN                => $directDiscountRoomType->{DirectDiscountProgramRoomType::COL_DIRECT_DISCOUNT_PROGRAM_SN},
                DirectDiscountProgramRoomTypeHistory::COL_DIRECT_DISCOUNT_PROGRAM_ACTION_HISTORY_SN => $actionSn,
                DirectDiscountProgramRoomTypeHistory::COL_STATUS                                    => $directDiscountRoomType->{DirectDiscountProgramRoomType::COL_STATUS},
                DirectDiscountProgramRoomTypeHistory::COL_HOTEL_SN                                  => $directDiscountRoomType->{DirectDiscountProgramRoomType::COL_HOTEL_SN},
                DirectDiscountProgramRoomTypeHistory::COL_HOTEL_NAME                                => $directDiscountRoomType->{DirectDiscountProgramRoomType::COL_HOTEL_NAME},
                DirectDiscountProgramRoomTypeHistory::COL_HOTEL_CODE                                => $directDiscountRoomType->{DirectDiscountProgramRoomType::COL_HOTEL_CODE},
                DirectDiscountProgramRoomTypeHistory::COL_ROOM_TYPE_SN                              => $directDiscountRoomType->{DirectDiscountProgramRoomType::COL_ROOM_TYPE_SN},
                DirectDiscountProgramRoomTypeHistory::COL_ROOM_TYPE_NAME                            => $directDiscountRoomType->{DirectDiscountProgramRoomType::COL_ROOM_TYPE_NAME},
                DirectDiscountProgramRoomTypeHistory::COL_PRICE_FIRST_HOURS_DISCOUNT_PERCENT        => $directDiscountRoomType->{DirectDiscountProgramRoomType::COL_PRICE_FIRST_HOURS_DISCOUNT_PERCENT},
                DirectDiscountProgramRoomTypeHistory::COL_PRICE_FIRST_HOURS_AFTER_DISCOUNT          => $directDiscountRoomType->{DirectDiscountProgramRoomType::COL_PRICE_FIRST_HOURS_AFTER_DISCOUNT},
                DirectDiscountProgramRoomTypeHistory::COL_PRICE_ADDITIONAL_HOURS_DISCOUNT_PERCENT   => $directDiscountRoomType->{DirectDiscountProgramRoomType::COL_PRICE_ADDITIONAL_HOURS_DISCOUNT_PERCENT},
                DirectDiscountProgramRoomTypeHistory::COL_PRICE_ADDITIONAL_HOURS_AFTER_DISCOUNT     => $directDiscountRoomType->{DirectDiscountProgramRoomType::COL_PRICE_ADDITIONAL_HOURS_AFTER_DISCOUNT},
                DirectDiscountProgramRoomTypeHistory::COL_PRICE_OVERNIGHT_DISCOUNT_PERCENT          => $directDiscountRoomType->{DirectDiscountProgramRoomType::COL_PRICE_OVERNIGHT_DISCOUNT_PERCENT},
                DirectDiscountProgramRoomTypeHistory::COL_PRICE_OVERNIGHT_AFTER_DISCOUNT            => $directDiscountRoomType->{DirectDiscountProgramRoomType::COL_PRICE_OVERNIGHT_AFTER_DISCOUNT},
                DirectDiscountProgramRoomTypeHistory::COL_PRICE_ONE_DAY_DISCOUNT_PERCENT            => $directDiscountRoomType->{DirectDiscountProgramRoomType::COL_PRICE_ONE_DAY_DISCOUNT_PERCENT},
                DirectDiscountProgramRoomTypeHistory::COL_PRICE_ONE_DAY_AFTER_DISCOUNT              => $directDiscountRoomType->{DirectDiscountProgramRoomType::COL_PRICE_ONE_DAY_AFTER_DISCOUNT},
                DirectDiscountProgramRoomTypeHistory::COL_FIRST_HOURS_ORIGIN                        => $directDiscountRoomType->{DirectDiscountProgramRoomType::COL_FIRST_HOURS_ORIGIN},
                DirectDiscountProgramRoomTypeHistory::COL_ADDITIONAL_ORIGIN                         => $directDiscountRoomType->{DirectDiscountProgramRoomType::COL_ADDITIONAL_ORIGIN},
                DirectDiscountProgramRoomTypeHistory::COL_OVERNIGHT_ORIGIN                          => $directDiscountRoomType->{DirectDiscountProgramRoomType::COL_OVERNIGHT_ORIGIN},
                DirectDiscountProgramRoomTypeHistory::COL_ONE_DAY_ORIGIN                            => $directDiscountRoomType->{DirectDiscountProgramRoomType::COL_ONE_DAY_ORIGIN},
            ];
        }
        $this->directDiscountProgramRoomTypeHistoryRepository->batchInsert($directDiscountRoomTypeHistory);
    }

    private function _deleteRoomPriceAdjustment(DeleteDirectDiscountInputDTO $deleteDirectDiscountInputDTO)
    {
        $deleteRoomPriceAdjustment = new DeleteRoomPriceAdjustment();
        $roomPriceAdjustmentList = $this->roomPriceAdjustmentRepository->findRoomPriceAdjustmentListByCondition($deleteDirectDiscountInputDTO->getDirectDiscountSn());
        foreach ($roomPriceAdjustmentList as $roomPriceAdjustment) {
            $deleteRoomPriceAdjustmentInputDTO = new DeleteRoomPriceAdjustmentInputDTO();
            $deleteRoomPriceAdjustmentInputDTO->setDirectDiscountProgramSn($deleteDirectDiscountInputDTO->getDirectDiscountSn());
            $deleteRoomPriceAdjustmentInputDTO->setRoomTypeSn($roomPriceAdjustment->{RoomPriceAdjustment::COL_ROOM_TYPE_SN});
            $deleteRoomPriceAdjustmentInputDTO->setDeleteStaffSn($deleteDirectDiscountInputDTO->getUpdateBy());
            $deleteRoomPriceAdjustment->handle($deleteRoomPriceAdjustmentInputDTO);
        }
    }
}