<?php

namespace App\Actions\Promotion\DirectDiscount\SA;

use App\Constants\DirectDiscountProgram as DirectDiscountProgramConst;
use App\Constants\Globals\FunctionName;
use App\DTOs\Promotion\DirectDiscount\SA\EditDirectDiscountHotelInputDTO;
use App\DTOs\Promotion\DirectDiscount\SA\EditDirectDiscountHotelOutputDTO;
use App\Helpers\CommonHelper;
use App\Helpers\GenerateHelper;
use App\Models\DirectDiscountProgram;
use App\Repositories\Interfaces\DirectDiscountProgramRepositoryInterface;
use App\Repositories\Interfaces\DirectDiscountProgramRoomTypeRepositoryInterface;
use App\Repositories\Interfaces\HotelRepositoryInterface;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Cache;

class EditDirectDiscountHotel
{
    const FILE_LANGUAGE_NAME = 'promotion';

    public $hotelRepository;

    public $directDiscountProgramRepository;

    public $directDiscountProgramRoomTypeRepository;

    public function __construct()
    {
        $this->hotelRepository = app(HotelRepositoryInterface::class);
        $this->directDiscountProgramRepository = app(DirectDiscountProgramRepositoryInterface::class);
        $this->directDiscountProgramRoomTypeRepository = app(DirectDiscountProgramRoomTypeRepositoryInterface::class);
    }

    public function handle(EditDirectDiscountHotelInputDTO $editDirectDiscountHotelInputDTO): EditDirectDiscountHotelOutputDTO
    {
        $hotelList = [];
        $key = GenerateHelper::cacheName(FunctionName::APPLYING_DIRECT_DISCOUNT, $editDirectDiscountHotelInputDTO->getStaffSn());
        if (Cache::store('redis')->has($key)) {
            $obj = json_decode(Cache::store('redis')->get($key), true);
            $hotelList = !empty($obj['data']) ? $obj['data'] : [];
        } else {
            if (!empty($editDirectDiscountHotelInputDTO->getDirectDiscountSn())) {
                $hotelList = $this->directDiscountProgramRoomTypeRepository->findDirectDiscountProgramRoomTypeActive($editDirectDiscountHotelInputDTO->getDirectDiscountSn());
            }
            $hotelList = $this->_generateDataRoomTypeList($hotelList);
        }
        if(!empty($hotelList)){
            $this->_editRoomTypePrice($editDirectDiscountHotelInputDTO, $hotelList);
        }
        $createdAt = Carbon::now()->timestamp;
        $updatedAt = Carbon::now()->timestamp;
        $ttl = Carbon::now()->addMinutes(60);
        $expiredAt = $ttl->timestamp;
        $obj = json_encode([
            'data'      => $hotelList,
            'createdAt' => $createdAt,
            'updatedAt' => $updatedAt,
            'expiredAt' => $expiredAt,
        ]);
        Cache::store('redis')->put($key, $obj, $ttl);

        return EditDirectDiscountHotelOutputDTO::assemble(CommonHelper::paginate($hotelList, $editDirectDiscountHotelInputDTO->getLimit()));
    }

    private function _generateDataRoomTypeList($hotelList)
    {
        $_hotelList = [];
        foreach ($hotelList as $hotel) {
            if (isset($_hotelList[$hotel->{DirectDiscountProgram::AS_HOTEL_SN}])) {
                $_hotelList[$hotel->{DirectDiscountProgram::AS_HOTEL_SN}] = [
                    'hotelSn'      => $hotel->{DirectDiscountProgram::AS_HOTEL_SN},
                    'hotelName'    => $hotel->{DirectDiscountProgram::AS_HOTEL_NAME},
                    'hotelCode'    => $hotel->{DirectDiscountProgram::AS_HOTEL_CODE},
                    'roomTypeList' => array_merge($_hotelList[$hotel->{DirectDiscountProgram::AS_HOTEL_SN}]['roomTypeList'],
                        array(
                            [
                                'roomTypeSn'                        => $hotel->{DirectDiscountProgram::AS_ROOM_TYPE_SN},
                                'roomTypeName'                      => $hotel->{DirectDiscountProgram::AS_ROOM_TYPE_NAME},
                                'firstHourOrigin'                   => $hotel->{DirectDiscountProgram::AS_FIRST_HOURS_ORIGIN},
                                'additionOrigin'                    => $hotel->{DirectDiscountProgram::AS_ADDITIONAL_ORIGIN},
                                'overnightOrigin'                   => $hotel->{DirectDiscountProgram::AS_OVERNIGHT_ORIGIN},
                                'oneDayOrigin'                      => $hotel->{DirectDiscountProgram::AS_ONE_DAY_ORIGIN},
                                'priceFirstHoursDiscountPercent'    => $hotel->{DirectDiscountProgram::AS_COL_PRICE_FIRST_HOURS_DISCOUNT_PERCENT},
                                'priceFirstHoursAfterDiscount'      => $hotel->{DirectDiscountProgram::AS_COL_PRICE_FIRST_HOURS_AFTER_DISCOUNT},
                                'priceAdditionHoursDiscountPercent' => $hotel->{DirectDiscountProgram::AS_COL_PRICE_ADDITIONAL_HOURS_DISCOUNT_PERCENT},
                                'priceAdditionHoursAfterDiscount'   => $hotel->{DirectDiscountProgram::AS_COL_PRICE_ADDITIONAL_HOURS_AFTER_DISCOUNT},
                                'priceOvernightDiscountPercent'     => $hotel->{DirectDiscountProgram::AS_COL_PRICE_OVERNIGHT_DISCOUNT_PERCENT},
                                'priceOvernightAfterDiscount'       => $hotel->{DirectDiscountProgram::AS_COL_PRICE_OVERNIGHT_AFTER_DISCOUNT},
                                'priceOneDayDiscountPercent'        => $hotel->{DirectDiscountProgram::AS_COL_PRICE_ONE_DAY_DISCOUNT_PERCENT},
                                'priceOneDayAfterDiscount'          => $hotel->{DirectDiscountProgram::AS_COL_PRICE_ONE_DAY_AFTER_DISCOUNT},
                                'status'                            => $hotel->{DirectDiscountProgram::AS_STATUS},
                            ],
                        )

                    ),
                ];
            } else {
                $_hotelList[$hotel->{DirectDiscountProgram::AS_HOTEL_SN}] = [

                    'hotelSn'      => $hotel->{DirectDiscountProgram::AS_HOTEL_SN},
                    'hotelName'    => $hotel->{DirectDiscountProgram::AS_HOTEL_NAME},
                    'hotelCode'    => $hotel->{DirectDiscountProgram::AS_HOTEL_CODE},
                    'roomTypeList' => array(
                        [
                            'roomTypeSn'                        => $hotel->{DirectDiscountProgram::AS_ROOM_TYPE_SN},
                            'roomTypeName'                      => $hotel->{DirectDiscountProgram::AS_ROOM_TYPE_NAME},
                            'firstHourOrigin'                   => $hotel->{DirectDiscountProgram::AS_FIRST_HOURS_ORIGIN},
                            'additionOrigin'                    => $hotel->{DirectDiscountProgram::AS_ADDITIONAL_ORIGIN},
                            'overnightOrigin'                   => $hotel->{DirectDiscountProgram::AS_OVERNIGHT_ORIGIN},
                            'oneDayOrigin'                      => $hotel->{DirectDiscountProgram::AS_ONE_DAY_ORIGIN},
                            'priceFirstHoursDiscountPercent'    => $hotel->{DirectDiscountProgram::AS_COL_PRICE_FIRST_HOURS_DISCOUNT_PERCENT},
                            'priceFirstHoursAfterDiscount'      => $hotel->{DirectDiscountProgram::AS_COL_PRICE_FIRST_HOURS_AFTER_DISCOUNT},
                            'priceAdditionHoursDiscountPercent' => $hotel->{DirectDiscountProgram::AS_COL_PRICE_ADDITIONAL_HOURS_DISCOUNT_PERCENT},
                            'priceAdditionHoursAfterDiscount'   => $hotel->{DirectDiscountProgram::AS_COL_PRICE_ADDITIONAL_HOURS_AFTER_DISCOUNT},
                            'priceOvernightDiscountPercent'     => $hotel->{DirectDiscountProgram::AS_COL_PRICE_OVERNIGHT_DISCOUNT_PERCENT},
                            'priceOvernightAfterDiscount'       => $hotel->{DirectDiscountProgram::AS_COL_PRICE_OVERNIGHT_AFTER_DISCOUNT},
                            'priceOneDayDiscountPercent'        => $hotel->{DirectDiscountProgram::AS_COL_PRICE_ONE_DAY_DISCOUNT_PERCENT},
                            'priceOneDayAfterDiscount'          => $hotel->{DirectDiscountProgram::AS_COL_PRICE_ONE_DAY_AFTER_DISCOUNT},
                            'status'                            => $hotel->{DirectDiscountProgram::AS_STATUS},
                        ],
                    ),
                ];
            }

        }

        return $_hotelList;
    }

    private function _editRoomTypePrice(EditDirectDiscountHotelInputDTO $editDirectDiscountHotelInputDTO, &$hotelList)
    {
        if ($editDirectDiscountHotelInputDTO->getTypeSetup() == DirectDiscountProgramConst::TYPE_SETUP['ALL']) {
            foreach ($hotelList as &$hotel) {
                foreach ($hotel['roomTypeList'] as &$roomType) {
                    if (in_array($roomType['roomTypeSn'], $editDirectDiscountHotelInputDTO->getExceptionRoomTypeSnList())) {
                        continue;
                    }
                    if (!empty($editDirectDiscountHotelInputDTO->getOnlyRoomTypeSnList()) && !in_array($roomType['roomTypeSn'], $editDirectDiscountHotelInputDTO->getOnlyRoomTypeSnList())) {
                        continue;
                    }
                    $roomType['priceFirstHoursDiscountPercent'] = !empty($roomType['firstHourOrigin']) ? $editDirectDiscountHotelInputDTO->getPriceFirstHoursDiscountPercentTotal() : 0;
                    $roomType['priceFirstHoursAfterDiscount'] = $this->_calculationPrice($editDirectDiscountHotelInputDTO->getPriceFirstHoursDiscountPercentTotal(), $roomType['firstHourOrigin']);
                    $roomType['priceAdditionHoursDiscountPercent'] = !empty($roomType['additionOrigin']) ? $editDirectDiscountHotelInputDTO->getPriceAdditionHoursDiscountPercentTotal() : 0;
                    $roomType['priceAdditionHoursAfterDiscount'] = $this->_calculationPrice($editDirectDiscountHotelInputDTO->getPriceAdditionHoursDiscountPercentTotal(), $roomType['additionOrigin']);
                    $roomType['priceOvernightDiscountPercent'] = !empty($roomType['overnightOrigin']) ? $editDirectDiscountHotelInputDTO->getPriceOvernightDiscountPercentTotal() : 0;
                    $roomType['priceOvernightAfterDiscount'] = $this->_calculationPrice($editDirectDiscountHotelInputDTO->getPriceOvernightDiscountPercentTotal(), $roomType['overnightOrigin']);
                    $roomType['priceOneDayDiscountPercent'] = !empty($roomType['oneDayOrigin']) ? $editDirectDiscountHotelInputDTO->getPriceOneDayDiscountPercentTotal() : 0;
                    $roomType['priceOneDayAfterDiscount'] = $this->_calculationPrice($editDirectDiscountHotelInputDTO->getPriceOneDayDiscountPercentTotal(), $roomType['oneDayOrigin']);
                }
            }
        } else {
            $hotel = &$hotelList[$editDirectDiscountHotelInputDTO->getHotelSn()];
            foreach ($hotel['roomTypeList'] as &$roomType) {
                if ($roomType['roomTypeSn'] == $editDirectDiscountHotelInputDTO->getRoomTypeSn()) {
                    $roomType['priceFirstHoursDiscountPercent'] = $editDirectDiscountHotelInputDTO->getPriceFirstHoursDiscountPercent();
                    $roomType['priceFirstHoursAfterDiscount'] = $editDirectDiscountHotelInputDTO->getPriceFirstHoursAfterDiscount();
                    $roomType['priceAdditionHoursDiscountPercent'] = $editDirectDiscountHotelInputDTO->getPriceAdditionHoursDiscountPercent();
                    $roomType['priceAdditionHoursAfterDiscount'] = $editDirectDiscountHotelInputDTO->getPriceAdditionHoursAfterDiscount();
                    $roomType['priceOvernightDiscountPercent'] = $editDirectDiscountHotelInputDTO->getPriceOvernightDiscountPercent();
                    $roomType['priceOvernightAfterDiscount'] = $editDirectDiscountHotelInputDTO->getPriceOvernightAfterDiscount();
                    $roomType['priceOneDayDiscountPercent'] = $editDirectDiscountHotelInputDTO->getPriceOneDayDiscountPercent();
                    $roomType['priceOneDayAfterDiscount'] = $editDirectDiscountHotelInputDTO->getPriceOneDayAfterDiscount();
                }
            }
        }

        return $hotelList;
    }

    private function _calculationPrice($percent, $priceDiscount)
    {
        if ($percent > 0 && $percent < 100) {
            $priceDiscount -= intval(($priceDiscount / 100) * $percent);
        }

        return $priceDiscount;
    }
}