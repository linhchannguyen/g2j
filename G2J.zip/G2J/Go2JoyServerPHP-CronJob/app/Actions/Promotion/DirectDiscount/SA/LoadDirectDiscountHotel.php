<?php

namespace App\Actions\Promotion\DirectDiscount\SA;

use App\Constants\DirectDiscountProgram as DirectDiscountProgramConst;
use App\Constants\DirectDiscountProgramRoomType as DirectDiscountProgramRoomTypeConst;
use App\Constants\Globals\FunctionName;
use App\Constants\Globals\Pagination as PaginationConst;
use App\DTOs\Promotion\DirectDiscount\SA\LoadDirectDiscountHotelInputDTO;
use App\DTOs\Promotion\DirectDiscount\SA\LoadDirectDiscountHotelOutputDTO;
use App\Helpers\CommonHelper;
use App\Helpers\ConvertHelper;
use App\Helpers\GenerateHelper;
use App\Models\DirectDiscountProgram;
use App\Repositories\Interfaces\DirectDiscountProgramRepositoryInterface;
use App\Repositories\Interfaces\DirectDiscountProgramRoomTypeRepositoryInterface;
use App\Repositories\Interfaces\HotelRepositoryInterface;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Cache;

class LoadDirectDiscountHotel
{
    const FILE_LANGUAGE_NAME = 'promotion';

    public $hotelRepository;

    public $directDiscountProgramRepository;

    public $directDiscountProgramRoomTypeRepository;

    public function __construct()
    {
        $this->hotelRepository = app(HotelRepositoryInterface::class);
        $this->directDiscountProgramRepository = app(DirectDiscountProgramRepositoryInterface::class);
        $this->directDiscountProgramRoomTypeRepository = app(DirectDiscountProgramRoomTypeRepositoryInterface::class);
    }

    public function handle(LoadDirectDiscountHotelInputDTO $loadDirectDiscountHotelInputDTO): LoadDirectDiscountHotelOutputDTO
    {
        $hotelList = [];
        $key = GenerateHelper::cacheName(FunctionName::APPLYING_DIRECT_DISCOUNT, $loadDirectDiscountHotelInputDTO->getStaffSn());
        if (Cache::store('redis')->has($key)) {
            $obj = json_decode(Cache::store('redis')->get($key), true);
            $hotelList = !empty($obj['data']) ? $obj['data'] : [];
        } else {
            if (!empty($loadDirectDiscountHotelInputDTO->getDirectDiscountSn())) {
                $hotelList = $this->directDiscountProgramRoomTypeRepository->findDirectDiscountProgramRoomTypeActive($loadDirectDiscountHotelInputDTO->getDirectDiscountSn());
            }
            $hotelList = $this->_generateDataRoomTypeList($hotelList);
        }
        if ($loadDirectDiscountHotelInputDTO->getCheck() && !empty($hotelList)) {
            $this->_checkRoomAvailable($loadDirectDiscountHotelInputDTO, $hotelList);
        }

        $createdAt = Carbon::now()->timestamp;
        $updatedAt = Carbon::now()->timestamp;
        $ttl = Carbon::now()->addMinutes(60);
        $expiredAt = $ttl->timestamp;
        $obj = json_encode([
            'data'      => $hotelList,
            'createdAt' => $createdAt,
            'updatedAt' => $updatedAt,
            'expiredAt' => $expiredAt,
        ]);
        Cache::store('redis')->put($key, $obj, $ttl);

        if (!empty($loadDirectDiscountHotelInputDTO->getKeyword())) {
            $keywordSearch = ConvertHelper::removeAccentVietnameseHasSpace($loadDirectDiscountHotelInputDTO->getKeyword());
            foreach ($hotelList as $index => $hotel) {
                if (!preg_match("/{$keywordSearch}/i", ConvertHelper::removeAccentVietnameseHasSpace($hotel['hotelName']))
                    && !preg_match("/{$keywordSearch}/i", ConvertHelper::removeAccentVietnameseHasSpace($hotel['hotelCode']))) {
                    unset($hotelList[$index]);
                }
            }
        }
        if(PaginationConst::LIMIT['NO_LIMIT'] == $loadDirectDiscountHotelInputDTO->getLimit()){
            return LoadDirectDiscountHotelOutputDTO::assemble(array_values($hotelList));
        }
        return LoadDirectDiscountHotelOutputDTO::assemble(CommonHelper::paginate($hotelList, $loadDirectDiscountHotelInputDTO->getLimit()));
    }

    private function _generateDataRoomTypeList($hotelList)
    {
        $_hotelList = [];
        foreach ($hotelList as $hotel) {
            if (isset($_hotelList[$hotel->{DirectDiscountProgram::AS_HOTEL_SN}])) {
                $_hotelList[$hotel->{DirectDiscountProgram::AS_HOTEL_SN}] = [
                    'hotelSn'      => $hotel->{DirectDiscountProgram::AS_HOTEL_SN},
                    'hotelName'    => $hotel->{DirectDiscountProgram::AS_HOTEL_NAME},
                    'hotelCode'    => $hotel->{DirectDiscountProgram::AS_HOTEL_CODE},
                    'roomTypeList' => array_merge($_hotelList[$hotel->{DirectDiscountProgram::AS_HOTEL_SN}]['roomTypeList'],
                        array(
                            [
                                'roomTypeSn'                        => $hotel->{DirectDiscountProgram::AS_ROOM_TYPE_SN},
                                'roomTypeName'                      => $hotel->{DirectDiscountProgram::AS_ROOM_TYPE_NAME},
                                'firstHourOrigin'                   => $hotel->{DirectDiscountProgram::AS_FIRST_HOURS_ORIGIN},
                                'additionOrigin'                    => $hotel->{DirectDiscountProgram::AS_ADDITIONAL_ORIGIN},
                                'overnightOrigin'                   => $hotel->{DirectDiscountProgram::AS_OVERNIGHT_ORIGIN},
                                'oneDayOrigin'                      => $hotel->{DirectDiscountProgram::AS_ONE_DAY_ORIGIN},
                                'priceFirstHoursDiscountPercent'    => $hotel->{DirectDiscountProgram::AS_COL_PRICE_FIRST_HOURS_DISCOUNT_PERCENT},
                                'priceFirstHoursAfterDiscount'      => $hotel->{DirectDiscountProgram::AS_COL_PRICE_FIRST_HOURS_AFTER_DISCOUNT},
                                'priceAdditionHoursDiscountPercent' => $hotel->{DirectDiscountProgram::AS_COL_PRICE_ADDITIONAL_HOURS_DISCOUNT_PERCENT},
                                'priceAdditionHoursAfterDiscount'   => $hotel->{DirectDiscountProgram::AS_COL_PRICE_ADDITIONAL_HOURS_AFTER_DISCOUNT},
                                'priceOvernightDiscountPercent'     => $hotel->{DirectDiscountProgram::AS_COL_PRICE_OVERNIGHT_DISCOUNT_PERCENT},
                                'priceOvernightAfterDiscount'       => $hotel->{DirectDiscountProgram::AS_COL_PRICE_OVERNIGHT_AFTER_DISCOUNT},
                                'priceOneDayDiscountPercent'        => $hotel->{DirectDiscountProgram::AS_COL_PRICE_ONE_DAY_DISCOUNT_PERCENT},
                                'priceOneDayAfterDiscount'          => $hotel->{DirectDiscountProgram::AS_COL_PRICE_ONE_DAY_AFTER_DISCOUNT},
                                'status'                            => $hotel->{DirectDiscountProgram::AS_STATUS},
                            ],
                        )

                    ),
                ];
            } else {
                $_hotelList[$hotel->{DirectDiscountProgram::AS_HOTEL_SN}] = [

                    'hotelSn'      => $hotel->{DirectDiscountProgram::AS_HOTEL_SN},
                    'hotelName'    => $hotel->{DirectDiscountProgram::AS_HOTEL_NAME},
                    'hotelCode'    => $hotel->{DirectDiscountProgram::AS_HOTEL_CODE},
                    'roomTypeList' => array(
                        [
                            'roomTypeSn'                        => $hotel->{DirectDiscountProgram::AS_ROOM_TYPE_SN},
                            'roomTypeName'                      => $hotel->{DirectDiscountProgram::AS_ROOM_TYPE_NAME},
                            'firstHourOrigin'                   => $hotel->{DirectDiscountProgram::AS_FIRST_HOURS_ORIGIN},
                            'additionOrigin'                    => $hotel->{DirectDiscountProgram::AS_ADDITIONAL_ORIGIN},
                            'overnightOrigin'                   => $hotel->{DirectDiscountProgram::AS_OVERNIGHT_ORIGIN},
                            'oneDayOrigin'                      => $hotel->{DirectDiscountProgram::AS_ONE_DAY_ORIGIN},
                            'priceFirstHoursDiscountPercent'    => $hotel->{DirectDiscountProgram::AS_COL_PRICE_FIRST_HOURS_DISCOUNT_PERCENT},
                            'priceFirstHoursAfterDiscount'      => $hotel->{DirectDiscountProgram::AS_COL_PRICE_FIRST_HOURS_AFTER_DISCOUNT},
                            'priceAdditionHoursDiscountPercent' => $hotel->{DirectDiscountProgram::AS_COL_PRICE_ADDITIONAL_HOURS_DISCOUNT_PERCENT},
                            'priceAdditionHoursAfterDiscount'   => $hotel->{DirectDiscountProgram::AS_COL_PRICE_ADDITIONAL_HOURS_AFTER_DISCOUNT},
                            'priceOvernightDiscountPercent'     => $hotel->{DirectDiscountProgram::AS_COL_PRICE_OVERNIGHT_DISCOUNT_PERCENT},
                            'priceOvernightAfterDiscount'       => $hotel->{DirectDiscountProgram::AS_COL_PRICE_OVERNIGHT_AFTER_DISCOUNT},
                            'priceOneDayDiscountPercent'        => $hotel->{DirectDiscountProgram::AS_COL_PRICE_ONE_DAY_DISCOUNT_PERCENT},
                            'priceOneDayAfterDiscount'          => $hotel->{DirectDiscountProgram::AS_COL_PRICE_ONE_DAY_AFTER_DISCOUNT},
                            'status'                            => $hotel->{DirectDiscountProgram::AS_STATUS},
                        ],
                    ),
                ];
            }

        }

        return $_hotelList;
    }

    private function _checkRoomAvailable(LoadDirectDiscountHotelInputDTO $loadDirectDiscountHotelInputDTO, &$hotelList)
    {
        $directDiscountSnList = [];
        if ($loadDirectDiscountHotelInputDTO->getTypeApply() == DirectDiscountProgramConst::TYPE_APPLY['DAY_OF_WEEK']) {
            $directDiscountList = $this->directDiscountProgramRepository->getExistRangeDayDirectDiscountHotel($loadDirectDiscountHotelInputDTO->getDirectDiscountSn(), $loadDirectDiscountHotelInputDTO->getTypeApply(),
                $loadDirectDiscountHotelInputDTO->getStartDate(), $loadDirectDiscountHotelInputDTO->getEndDate(), $loadDirectDiscountHotelInputDTO->getMonday(),
                $loadDirectDiscountHotelInputDTO->getTuesday(), $loadDirectDiscountHotelInputDTO->getWednesday(), $loadDirectDiscountHotelInputDTO->getThursday(),
                $loadDirectDiscountHotelInputDTO->getFriday(), $loadDirectDiscountHotelInputDTO->getSaturday(), $loadDirectDiscountHotelInputDTO->getSunday());
            $directDiscountSnList = $directDiscountList->pluck(DirectDiscountProgram::COL_SN)->toArray();
        } else {
            $specialDateArray = $loadDirectDiscountHotelInputDTO->getSpecialDate();
            $directDiscountList = $this->directDiscountProgramRepository->getExistSpecialDayDirectDiscountHotel($loadDirectDiscountHotelInputDTO->getDirectDiscountSn(), $loadDirectDiscountHotelInputDTO->getTypeApply());
            foreach ($directDiscountList as $directDiscount) {
                $array = ConvertHelper::toArray($directDiscount->{DirectDiscountProgram::COL_SPECIAL_DATE});
                if (count(array_intersect($specialDateArray, $array)) !== 0) {
                    $directDiscountSnList[] = [
                        $directDiscount->{DirectDiscountProgram::COL_SN},
                    ];
                }
            }
        }
        $roomTypeListRunningDirectDiscount = $this->directDiscountProgramRoomTypeRepository->findDirectDiscountProgramRoomTypeRunning($directDiscountSnList)->pluck('ROOM_TYPE_SN')->toArray();
        foreach ($hotelList as &$hotel) {
            foreach ($hotel['roomTypeList'] as &$roomType) {
                if (in_array($roomType['roomTypeSn'], $roomTypeListRunningDirectDiscount)) {
                    $roomType['status'] = DirectDiscountProgramRoomTypeConst::STATUS['UNAVAILABLE'];
                } else {
                    $roomType['status'] = DirectDiscountProgramRoomTypeConst::STATUS['AVAILABLE'];
                }
            }
        }
    }
}