<?php

namespace App\Actions\Promotion\DirectDiscount\SA;

use App\Constants\Globals\Code as CodeConst;
use App\Constants\Globals\FunctionName;
use App\DTOs\Promotion\DirectDiscount\SA\DeleteDirectDiscountHotelInputDTO;
use App\DTOs\Promotion\DirectDiscount\SA\DeleteDirectDiscountHotelOutputDTO;
use App\Exceptions\ServiceException;
use App\Helpers\CommonHelper;
use App\Helpers\GenerateHelper;
use App\Models\DirectDiscountProgram;
use App\Repositories\Interfaces\DirectDiscountProgramRepositoryInterface;
use App\Repositories\Interfaces\DirectDiscountProgramRoomTypeRepositoryInterface;
use App\Repositories\Interfaces\HotelRepositoryInterface;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Cache;

class DeleteDirectDiscountHotel
{
    const FILE_LANGUAGE_NAME = 'promotion';

    public $hotelRepository;

    public $directDiscountProgramRepository;

    public $directDiscountProgramRoomTypeRepository;

    public function __construct()
    {
        $this->hotelRepository = app(HotelRepositoryInterface::class);
        $this->directDiscountProgramRepository = app(DirectDiscountProgramRepositoryInterface::class);
        $this->directDiscountProgramRoomTypeRepository = app(DirectDiscountProgramRoomTypeRepositoryInterface::class);
    }

    public function handle(DeleteDirectDiscountHotelInputDTO $deleteDirectDiscountHotelInputDTO): DeleteDirectDiscountHotelOutputDTO
    {
        if (!empty($deleteDirectDiscountHotelInputDTO->getDirectDiscountSn())) {
            if($this->directDiscountProgramRepository->checkDirectDiscountProgramCreatedByHotel($deleteDirectDiscountHotelInputDTO->getDirectDiscountSn())){
                throw new ServiceException(CommonHelper::getMessage(self::FILE_LANGUAGE_NAME, CodeConst::API_PRN_019), CodeConst::API_PRN_019);
            }
        }

        $hotelList = [];
        $key = GenerateHelper::cacheName(FunctionName::APPLYING_DIRECT_DISCOUNT, $deleteDirectDiscountHotelInputDTO->getStaffSn());
        if (Cache::store('redis')->has($key)) {
            $obj = json_decode(Cache::store('redis')->get($key), true);
            $hotelList = $obj['data'];
        } else {
            if (!empty($deleteDirectDiscountHotelInputDTO->getDirectDiscountSn())) {
                $hotelList = $this->directDiscountProgramRoomTypeRepository->findDirectDiscountProgramRoomTypeActive($deleteDirectDiscountHotelInputDTO->getDirectDiscountSn());
            }
            $hotelList = $this->_generateDataRoomTypeList($hotelList);
        }
        unset($hotelList[$deleteDirectDiscountHotelInputDTO->getHotelSn()]);
        $createdAt = Carbon::now()->timestamp;
        $updatedAt = Carbon::now()->timestamp;
        $ttl = Carbon::now()->addMinutes(60);
        $expiredAt = $ttl->timestamp;
        $obj = json_encode([
            'data'      => $hotelList,
            'createdAt' => $createdAt,
            'updatedAt' => $updatedAt,
            'expiredAt' => $expiredAt,
        ]);
        Cache::store('redis')->put($key, $obj, $ttl);

        return DeleteDirectDiscountHotelOutputDTO::assemble(true);
    }

    private function _generateDataRoomTypeList($hotelList)
    {
        $_hotelList = [];
        foreach ($hotelList as $hotel) {
            if (isset($_hotelList[$hotel->{DirectDiscountProgram::AS_HOTEL_SN}])) {
                $_hotelList[$hotel->{DirectDiscountProgram::AS_HOTEL_SN}] = [
                    'hotelSn'      => $hotel->{DirectDiscountProgram::AS_HOTEL_SN},
                    'hotelName'    => $hotel->{DirectDiscountProgram::AS_HOTEL_NAME},
                    'hotelCode'    => $hotel->{DirectDiscountProgram::AS_HOTEL_NAME},
                    'roomTypeList' => array_merge($_hotelList[$hotel->{DirectDiscountProgram::AS_HOTEL_SN}]['roomTypeList'],
                        array(
                            [
                                'roomTypeSn'                        => $hotel->{DirectDiscountProgram::AS_ROOM_TYPE_SN},
                                'roomTypeName'                      => $hotel->{DirectDiscountProgram::AS_ROOM_TYPE_NAME},
                                'firstHourOrigin'                   => $hotel->{DirectDiscountProgram::AS_FIRST_HOURS_ORIGIN},
                                'additionOrigin'                    => $hotel->{DirectDiscountProgram::AS_ADDITIONAL_ORIGIN},
                                'overnightOrigin'                   => $hotel->{DirectDiscountProgram::AS_OVERNIGHT_ORIGIN},
                                'oneDayOrigin'                      => $hotel->{DirectDiscountProgram::AS_ONE_DAY_ORIGIN},
                                'priceFirstHoursDiscountPercent'    => $hotel->{DirectDiscountProgram::AS_COL_PRICE_FIRST_HOURS_DISCOUNT_PERCENT},
                                'priceFirstHoursAfterDiscount'      => $hotel->{DirectDiscountProgram::AS_COL_PRICE_FIRST_HOURS_AFTER_DISCOUNT},
                                'priceAdditionHoursDiscountPercent' => $hotel->{DirectDiscountProgram::AS_COL_PRICE_ADDITIONAL_HOURS_DISCOUNT_PERCENT},
                                'priceAdditionHoursAfterDiscount'   => $hotel->{DirectDiscountProgram::AS_COL_PRICE_ADDITIONAL_HOURS_AFTER_DISCOUNT},
                                'priceOvernightDiscountPercent'     => $hotel->{DirectDiscountProgram::AS_COL_PRICE_OVERNIGHT_DISCOUNT_PERCENT},
                                'priceOvernightAfterDiscount'       => $hotel->{DirectDiscountProgram::AS_COL_PRICE_OVERNIGHT_AFTER_DISCOUNT},
                                'priceOneDayDiscountPercent'        => $hotel->{DirectDiscountProgram::AS_COL_PRICE_ONE_DAY_DISCOUNT_PERCENT},
                                'priceOneDayAfterDiscount'          => $hotel->{DirectDiscountProgram::AS_COL_PRICE_ONE_DAY_AFTER_DISCOUNT},
                                'status'                            => $hotel->{DirectDiscountProgram::AS_STATUS},
                            ],
                        )

                    ),
                ];
            } else {
                $_hotelList[$hotel->{DirectDiscountProgram::AS_HOTEL_SN}] = [

                    'hotelSn'      => $hotel->{DirectDiscountProgram::AS_HOTEL_SN},
                    'hotelName'    => $hotel->{DirectDiscountProgram::AS_HOTEL_NAME},
                    'hotelCode'    => $hotel->{DirectDiscountProgram::AS_HOTEL_NAME},
                    'roomTypeList' => array(
                        [
                            'roomTypeSn'                        => $hotel->{DirectDiscountProgram::AS_ROOM_TYPE_SN},
                            'roomTypeName'                      => $hotel->{DirectDiscountProgram::AS_ROOM_TYPE_NAME},
                            'firstHourOrigin'                   => $hotel->{DirectDiscountProgram::AS_FIRST_HOURS_ORIGIN},
                            'additionOrigin'                    => $hotel->{DirectDiscountProgram::AS_ADDITIONAL_ORIGIN},
                            'overnightOrigin'                   => $hotel->{DirectDiscountProgram::AS_OVERNIGHT_ORIGIN},
                            'oneDayOrigin'                      => $hotel->{DirectDiscountProgram::AS_ONE_DAY_ORIGIN},
                            'priceFirstHoursDiscountPercent'    => $hotel->{DirectDiscountProgram::AS_COL_PRICE_FIRST_HOURS_DISCOUNT_PERCENT},
                            'priceFirstHoursAfterDiscount'      => $hotel->{DirectDiscountProgram::AS_COL_PRICE_FIRST_HOURS_AFTER_DISCOUNT},
                            'priceAdditionHoursDiscountPercent' => $hotel->{DirectDiscountProgram::AS_COL_PRICE_ADDITIONAL_HOURS_DISCOUNT_PERCENT},
                            'priceAdditionHoursAfterDiscount'   => $hotel->{DirectDiscountProgram::AS_COL_PRICE_ADDITIONAL_HOURS_AFTER_DISCOUNT},
                            'priceOvernightDiscountPercent'     => $hotel->{DirectDiscountProgram::AS_COL_PRICE_OVERNIGHT_DISCOUNT_PERCENT},
                            'priceOvernightAfterDiscount'       => $hotel->{DirectDiscountProgram::AS_COL_PRICE_OVERNIGHT_AFTER_DISCOUNT},
                            'priceOneDayDiscountPercent'        => $hotel->{DirectDiscountProgram::AS_COL_PRICE_ONE_DAY_DISCOUNT_PERCENT},
                            'priceOneDayAfterDiscount'          => $hotel->{DirectDiscountProgram::AS_COL_PRICE_ONE_DAY_AFTER_DISCOUNT},
                            'status'                            => $hotel->{DirectDiscountProgram::AS_STATUS},
                        ],
                    ),
                ];
            }

        }

        return $_hotelList;
    }
}