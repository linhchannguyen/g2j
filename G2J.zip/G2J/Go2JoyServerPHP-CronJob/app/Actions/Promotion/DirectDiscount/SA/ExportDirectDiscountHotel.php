<?php

namespace App\Actions\Promotion\DirectDiscount\SA;

use App\Constants\Globals\QueueName;
use App\DTOs\Promotion\DirectDiscount\SA\ExportDirectDiscountHotelInputDTO;
use App\DTOs\Promotion\DirectDiscount\SA\ExportDirectDiscountHotelOutputDTO;
use App\Jobs\Exports\Promotion\DirectDiscount\ExportDirectDiscountHotelJob;
use App\Repositories\Interfaces\DirectDiscountProgramRepositoryInterface;

class ExportDirectDiscountHotel
{
    public $directDiscountProgramRepository;

    public function __construct()
    {
        $this->directDiscountProgramRepository = app(DirectDiscountProgramRepositoryInterface::class);
    }

    public function handle(ExportDirectDiscountHotelInputDTO $exportDirectDiscountHotelInputDTO)
    {
        $job = new ExportDirectDiscountHotelJob($exportDirectDiscountHotelInputDTO->getStaffSn(), $exportDirectDiscountHotelInputDTO->getDirectDiscountSn(), $exportDirectDiscountHotelInputDTO->getActionHistorySn());
        dispatch($job->onQueue(QueueName::EXPORTS));

        return ExportDirectDiscountHotelOutputDTO::assemble(true);
    }
}