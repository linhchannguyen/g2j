<?php

namespace App\Actions\Promotion\DirectDiscount\SA;

use App\DTOs\Promotion\DirectDiscount\SA\GetDirectDiscountActionHistoryInputDTO;
use App\DTOs\Promotion\DirectDiscount\SA\GetDirectDiscountActionHistoryOutputDTO;
use App\Repositories\Interfaces\DirectDiscountProgramActionHistoryRepositoryInterface;
use App\Repositories\Interfaces\DirectDiscountProgramRoomTypeHistoryRepositoryInterface;

class GetDirectDiscountActionHistory
{
    public $directDiscountProgramActionHistoryRepository;

    public function __construct()
    {
        $this->directDiscountProgramActionHistoryRepository = app(DirectDiscountProgramActionHistoryRepositoryInterface::class);
    }

    public function handle(GetDirectDiscountActionHistoryInputDTO $getDirectDiscountActionHistoryInputDTO): GetDirectDiscountActionHistoryOutputDTO
    {
        $directDiscountActionHistoryList = $this->directDiscountProgramActionHistoryRepository->findDirectDiscountActionHistoryList($getDirectDiscountActionHistoryInputDTO->getDirectDiscountSn());
        return GetDirectDiscountActionHistoryOutputDTO::assemble($directDiscountActionHistoryList);
    }
}