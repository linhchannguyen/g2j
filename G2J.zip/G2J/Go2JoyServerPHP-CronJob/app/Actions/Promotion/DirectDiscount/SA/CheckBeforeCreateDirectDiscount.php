<?php

namespace App\Actions\Promotion\DirectDiscount\SA;

use App\Constants\DirectDiscountProgramRoomType as DirectDiscountProgramRoomTypeConst;
use App\Constants\Globals\FunctionName;
use App\Constants\RoomPriceAdjustment as RoomPriceAdjustmentConst;
use App\DTOs\Promotion\DirectDiscount\SA\CheckBeforeCreateDirectDiscountInputDTO;
use App\DTOs\Promotion\DirectDiscount\SA\CheckBeforeCreateDirectDiscountOutputDTO;
use App\Helpers\GenerateHelper;
use App\Models\RoomType;
use App\Repositories\Interfaces\RoomTypeRepositoryInterface;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Cache;

class CheckBeforeCreateDirectDiscount
{
    public $directDiscountProgramRepository;

    public $roomTypeRepository;

    public function __construct()
    {
        $this->roomTypeRepository = app(RoomTypeRepositoryInterface::class);
    }

    public function handle(CheckBeforeCreateDirectDiscountInputDTO $checkBeforeCreateDirectDiscountInputDTO): CheckBeforeCreateDirectDiscountOutputDTO
    {
        $numOfHotel = 0;
        $hotelHasFlashSaleList = [];
        $hotelHasPrice = [];
        $key = GenerateHelper::cacheName(FunctionName::APPLYING_DIRECT_DISCOUNT, $checkBeforeCreateDirectDiscountInputDTO->getStaffSn());
        if (Cache::store('redis')->has($key)) {
            $obj = json_decode(Cache::store('redis')->get($key), true);
            $hotelList = !empty($obj['data']) ? $obj['data'] : [];
            foreach ($hotelList as $hotel) {
                $check = true;
                foreach ($hotel['roomTypeList'] as $roomType) {
                    if ($roomType['status'] == DirectDiscountProgramRoomTypeConst::STATUS['AVAILABLE']
                        && ($roomType['priceFirstHoursAfterDiscount'] != $roomType['firstHourOrigin']
                            || $roomType['priceAdditionHoursAfterDiscount'] != $roomType['additionOrigin']
                            || $roomType['priceOvernightAfterDiscount'] != $roomType['overnightOrigin']
                            || $roomType['priceOneDayAfterDiscount'] != $roomType['oneDayOrigin'])) {
                        $hotelHasPrice[] = $hotel['hotelSn'];
                        $check = false;
                        break;
                    }
                }
                if ($check) {
                    $numOfHotel++;
                }
            }
            $overlap = $this->_checkDirectDiscountSetupOverlapFlashSale($checkBeforeCreateDirectDiscountInputDTO);
            if (!empty($hotelHasPrice) && $overlap) {
                $roomTypeFlashSaleList = $this->roomTypeRepository->findRoomTypeHasFlashSaleByHotelSnList(array_unique($hotelHasPrice));
                $hotelHasFlashSaleList = $this->_checkDirectDiscountGreaterThanFlashSale($hotelList, $roomTypeFlashSaleList);
            }
        }

        return CheckBeforeCreateDirectDiscountOutputDTO::assemble($numOfHotel, $hotelHasFlashSaleList);
    }

    private function _checkDirectDiscountSetupOverlapFlashSale(CheckBeforeCreateDirectDiscountInputDTO $checkBeforeCreateDirectDiscountInputDTO)
    {
        $dayOfWeek = Carbon::now()->dayOfWeek;
        if (RoomPriceAdjustmentConst::TYPE_APPLY['DAY_OF_WEEK'] == $checkBeforeCreateDirectDiscountInputDTO->getTypeApply()) {
            $between = Carbon::now()->between(Carbon::parse($checkBeforeCreateDirectDiscountInputDTO->getStartDate())->startOfDay(), Carbon::parse($checkBeforeCreateDirectDiscountInputDTO->getEndDate())->endOfDay());
            if ($between) {
                if (Carbon::SUNDAY == $dayOfWeek && $checkBeforeCreateDirectDiscountInputDTO->getSunday() == 1) {
                    return true;
                } elseif (Carbon::MONDAY == $dayOfWeek && $checkBeforeCreateDirectDiscountInputDTO->getMonday() == 1) {
                    return true;
                } elseif (Carbon::TUESDAY == $dayOfWeek && $checkBeforeCreateDirectDiscountInputDTO->getTuesday() == 1) {
                    return true;
                } elseif (Carbon::WEDNESDAY == $dayOfWeek && $checkBeforeCreateDirectDiscountInputDTO->getWednesday() == 1) {
                    return true;
                } elseif (Carbon::THURSDAY == $dayOfWeek && $checkBeforeCreateDirectDiscountInputDTO->getThursday() == 1) {
                    return true;
                } elseif (Carbon::FRIDAY == $dayOfWeek && $checkBeforeCreateDirectDiscountInputDTO->getFriday() == 1) {
                    return true;
                } elseif (Carbon::SATURDAY == $dayOfWeek && $checkBeforeCreateDirectDiscountInputDTO->getSaturday() == 1) {
                    return true;
                }
            }
        } else {
            $specialDateList = $checkBeforeCreateDirectDiscountInputDTO->getSpecialDate();
            if (in_array(Carbon::now()->toDateString(), $specialDateList)) {
                return true;
            }
        }

        return false;
    }

    private function _checkDirectDiscountGreaterThanFlashSale($hotelList, $roomTypeFlashSaleList)
    {
        $_hotelList = [];
        foreach ($roomTypeFlashSaleList as $roomTypeFlashSale) {
            $hotel = $hotelList[$roomTypeFlashSale->{RoomType::COL_HOTEL_SN}];
            foreach ($hotel['roomTypeList'] as $roomType) {
                if ($roomType['status'] == DirectDiscountProgramRoomTypeConst::STATUS['AVAILABLE'] &&
                    $roomType['roomTypeSn'] == $roomTypeFlashSale->{RoomType::COL_SN} &&
                    $roomTypeFlashSale->{RoomType::COL_PRICE_FLASH_SALE} >= $roomType['priceOvernightAfterDiscount']) {
                    if(!isset($_hotelList[$hotel['hotelSn']])){
                        $_hotelList[] = [
                            'hotelSn'      => $hotel['hotelSn'],
                            'hotelCode'    => $hotel['hotelCode'],
                            'hotelName'    => $hotel['hotelName'],
                        ];
                    }
                }
            }
        }

        return $_hotelList;
    }
}