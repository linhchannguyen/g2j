<?php

namespace App\Actions\Promotion\DirectDiscount\SA;

use App\DTOs\Promotion\DirectDiscount\SA\GetDirectDiscountDetailInputDTO;
use App\DTOs\Promotion\DirectDiscount\SA\GetDirectDiscountDetailOutputDTO;
use App\DTOs\Promotion\DirectDiscount\SA\GetDirectDiscountListInputDTO;
use App\DTOs\Promotion\DirectDiscount\SA\GetDirectDiscountListOutputDTO;
use App\Repositories\Interfaces\DirectDiscountProgramRepositoryInterface;

class GetDirectDiscountDetail
{
    public $directDiscountProgramRepository;

    public function __construct()
    {
        $this->directDiscountProgramRepository = app(DirectDiscountProgramRepositoryInterface::class);
    }

    public function handle(GetDirectDiscountDetailInputDTO $getDirectDiscountDetailInputDTO): GetDirectDiscountDetailOutputDTO
    {
        $directDiscount = $this->directDiscountProgramRepository->findDirectDiscountDetail($getDirectDiscountDetailInputDTO->getDirectDiscountProgramSn());

        return GetDirectDiscountDetailOutputDTO::assemble($directDiscount);
    }
}