<?php

namespace App\Actions\Promotion\DirectDiscount\SA;

use App\Constants\Globals\FunctionName;
use App\DTOs\Promotion\DirectDiscount\SA\RefreshDirectDiscountHotelInputDTO;
use App\DTOs\Promotion\DirectDiscount\SA\RefreshDirectDiscountHotelOutputDTO;
use App\Helpers\GenerateHelper;
use App\Repositories\Interfaces\DirectDiscountProgramRepositoryInterface;
use Illuminate\Support\Facades\Cache;

class RefreshDirectDiscountHotel
{
    public $directDiscountProgramRepository;

    public function __construct()
    {
        $this->directDiscountProgramRepository = app(DirectDiscountProgramRepositoryInterface::class);
    }

    public function handle(RefreshDirectDiscountHotelInputDTO $refreshDirectDiscountHotelInputDTO)
    {
        $key = GenerateHelper::cacheName(FunctionName::APPLYING_DIRECT_DISCOUNT, $refreshDirectDiscountHotelInputDTO->getStaffSn());
        Cache::store('redis')->delete($key);

        return RefreshDirectDiscountHotelOutputDTO::assemble(true);
    }
}