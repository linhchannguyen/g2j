<?php

namespace App\Actions\Promotion\DirectDiscount\SA;

use App\Actions\Promotion\DirectDiscount\CreateRoomPriceAdjustment;
use App\Constants\DirectDiscountProgram as DirectDiscountProgramConst;
use App\Constants\DirectDiscountProgramActionHistory as DirectDiscountProgramActionHistoryConst;
use App\Constants\DirectDiscountProgramRoomType as DirectDiscountProgramRoomTypeConst;
use App\Constants\Globals\Code as CodeConst;
use App\Constants\Globals\FunctionName;
use App\Constants\RoomPriceAdjustment;
use App\DTOs\Promotion\DirectDiscount\CreateRoomPriceAdjustmentInputDTO;
use App\DTOs\Promotion\DirectDiscount\SA\CreateDirectDiscountInputDTO;
use App\DTOs\Promotion\DirectDiscount\SA\CreateDirectDiscountOutputDTO;
use App\Exceptions\ServiceException;
use App\Helpers\CommonHelper;
use App\Helpers\ConvertHelper;
use App\Helpers\GenerateHelper;
use App\Models\DirectDiscountProgram;
use App\Models\DirectDiscountProgramHotel;
use App\Models\DirectDiscountProgramRoomType;
use App\Models\DirectDiscountProgramRoomTypeHistory;
use App\Repositories\Interfaces\DirectDiscountProgramActionHistoryRepositoryInterface;
use App\Repositories\Interfaces\DirectDiscountProgramHotelRepositoryInterface;
use App\Repositories\Interfaces\DirectDiscountProgramRepositoryInterface;
use App\Repositories\Interfaces\DirectDiscountProgramRoomTypeHistoryRepositoryInterface;
use App\Repositories\Interfaces\DirectDiscountProgramRoomTypeRepositoryInterface;
use Exception;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;

class CreateDirectDiscount
{
    const FILE_LANGUAGE_NAME = 'promotion';

    public $directDiscountProgramRepository;

    public $directDiscountProgramHotelRepository;

    public $directDiscountProgramRoomTypeRepository;

    public $directDiscountProgramRoomTypeHistoryRepository;

    public $directDiscountProgramActionHistoryRepository;

    public function __construct()
    {
        $this->directDiscountProgramRepository = app(DirectDiscountProgramRepositoryInterface::class);
        $this->directDiscountProgramHotelRepository = app(DirectDiscountProgramHotelRepositoryInterface::class);
        $this->directDiscountProgramRoomTypeRepository = app(DirectDiscountProgramRoomTypeRepositoryInterface::class);
        $this->directDiscountProgramRoomTypeHistoryRepository = app(DirectDiscountProgramRoomTypeHistoryRepositoryInterface::class);
        $this->directDiscountProgramActionHistoryRepository = app(DirectDiscountProgramActionHistoryRepositoryInterface::class);
    }

    public function handle(CreateDirectDiscountInputDTO $createDirectDiscountInputDTO): CreateDirectDiscountOutputDTO
    {
        $this->_checkBeforeCreateDirectDiscount($createDirectDiscountInputDTO);
        try {
            $hotelList = [];
            $key = GenerateHelper::cacheName(FunctionName::APPLYING_DIRECT_DISCOUNT, $createDirectDiscountInputDTO->getCreateBy());
            if (Cache::store('redis')->has($key)) {
                $obj = json_decode(Cache::store('redis')->get($key), true);
                $hotelList = !empty($obj['data']) ? $obj['data'] : [];
                foreach ($hotelList as $index => $hotel) {
                    $check = true;
                    foreach ($hotel['roomTypeList'] as $roomType) {
                        if ($roomType['status'] == DirectDiscountProgramRoomTypeConst::STATUS['AVAILABLE']
                            && ($roomType['priceFirstHoursAfterDiscount'] != $roomType['firstHourOrigin']
                                || $roomType['priceAdditionHoursAfterDiscount'] != $roomType['additionOrigin']
                                || $roomType['priceOvernightAfterDiscount'] != $roomType['overnightOrigin']
                                || $roomType['priceOneDayAfterDiscount'] != $roomType['oneDayOrigin'])) {
                            $check = false;
                            break;
                        }
                    }
                    if ($check) {
                        unset($hotelList[$index]);
                    }
                }
            }

            if (count($hotelList) > DirectDiscountProgramConst::LIMIT_HOTEL) {
                throw new ServiceException(CommonHelper::getMessage(self::FILE_LANGUAGE_NAME, CodeConst::API_PRN_017), CodeConst::API_PRN_017);
            }

            DB::connection('mysql')->beginTransaction();
            $createDirectDiscount = DirectDiscountProgram::create([
                DirectDiscountProgram::COL_NAME               => $createDirectDiscountInputDTO->getName(),
                DirectDiscountProgram::COL_ACTION_USER_TYPE   => $createDirectDiscountInputDTO->getActionUserType(),
                DirectDiscountProgram::COL_TYPE_APPLY         => $createDirectDiscountInputDTO->getTypeApply(),
                DirectDiscountProgram::COL_STATUS             => DirectDiscountProgramConst::STATUS['RUNNING'],
                DirectDiscountProgram::COL_START_DATE         => $createDirectDiscountInputDTO->getStartDate(),
                DirectDiscountProgram::COL_END_DATE           => $createDirectDiscountInputDTO->getEndDate(),
                DirectDiscountProgram::COL_SPECIAL_DATE       => !empty($createDirectDiscountInputDTO->getSpecialDate()) ? ConvertHelper::toJson($createDirectDiscountInputDTO->getSpecialDate()) : null,
                DirectDiscountProgram::COL_START_TIME         => $createDirectDiscountInputDTO->getStartTime(),
                DirectDiscountProgram::COL_END_TIME           => $createDirectDiscountInputDTO->getEndTime(),
                DirectDiscountProgram::COL_MONDAY             => $createDirectDiscountInputDTO->getMonday(),
                DirectDiscountProgram::COL_TUESDAY            => $createDirectDiscountInputDTO->getTuesday(),
                DirectDiscountProgram::COL_WEDNESDAY          => $createDirectDiscountInputDTO->getWednesday(),
                DirectDiscountProgram::COL_THURSDAY           => $createDirectDiscountInputDTO->getThursday(),
                DirectDiscountProgram::COL_FRIDAY             => $createDirectDiscountInputDTO->getFriday(),
                DirectDiscountProgram::COL_SATURDAY           => $createDirectDiscountInputDTO->getSaturday(),
                DirectDiscountProgram::COL_SUNDAY             => $createDirectDiscountInputDTO->getSunday(),
                DirectDiscountProgram::COL_CREATED_NAME       => $createDirectDiscountInputDTO->getCreatedName(),
                DirectDiscountProgram::COL_CREATED_BY         => $createDirectDiscountInputDTO->getCreateBy(),
                DirectDiscountProgram::COL_TOTAL_HOTEL_JOINED => count($hotelList),
            ]);
            $actionSn = $this->directDiscountProgramActionHistoryRepository->createCreatedHistory($createDirectDiscount->{DirectDiscountProgram::COL_SN}, $createDirectDiscount->{DirectDiscountProgram::COL_CREATED_BY}, DirectDiscountProgramActionHistoryConst::ACTION_USER_TYPE['GO2JOY_STAFF'], Carbon::now(), json_encode($createDirectDiscount));
            list($directDiscountRoomType) = $this->_createDirectDiscountHotel($actionSn, $createDirectDiscount, $hotelList);
            $this->_createRoomPriceAdjustment($createDirectDiscount, $directDiscountRoomType);
            DB::connection('mysql')->commit();
        } catch (Exception $e) {
            DB::connection('mysql')->rollBack();
            throw $e;
        }
        Cache::store('redis')->delete($key);

        return CreateDirectDiscountOutputDTO::assemble($createDirectDiscount);
    }

    private function _checkBeforeCreateDirectDiscount(CreateDirectDiscountInputDTO $createDirectDiscountInputDTO)
    {
        if ($createDirectDiscountInputDTO->getTypeApply() == DirectDiscountProgramConst::TYPE_APPLY['DAY_OF_WEEK']) {
            if (empty($createDirectDiscountInputDTO->getStartDate())) {
                throw new ServiceException(CommonHelper::getMessage(self::FILE_LANGUAGE_NAME, CodeConst::API_PRN_003), CodeConst::API_PRN_003);
            }
            if (empty($createDirectDiscountInputDTO->getEndDate())) {
                throw new ServiceException(CommonHelper::getMessage(self::FILE_LANGUAGE_NAME, CodeConst::API_PRN_004), CodeConst::API_PRN_004);
            }
            if (Carbon::parse($createDirectDiscountInputDTO->getStartDate())->addYear()->lt(Carbon::parse($createDirectDiscountInputDTO->getEndDate()))) {
                throw new ServiceException(CommonHelper::getMessage(self::FILE_LANGUAGE_NAME, CodeConst::API_PRN_007), CodeConst::API_PRN_007);
            }
            if (empty($createDirectDiscountInputDTO->getMonday())
                && empty($createDirectDiscountInputDTO->getTuesday())
                && empty($createDirectDiscountInputDTO->getWednesday())
                && empty($createDirectDiscountInputDTO->getThursday())
                && empty($createDirectDiscountInputDTO->getFriday())
                && empty($createDirectDiscountInputDTO->getSaturday())
                && empty($createDirectDiscountInputDTO->getSunday())) {
                throw new ServiceException(CommonHelper::getMessage(self::FILE_LANGUAGE_NAME, CodeConst::API_PRN_013), CodeConst::API_PRN_013);
            }
        } else {
            if (empty($createDirectDiscountInputDTO->getSpecialDate())) {
                throw new ServiceException(CommonHelper::getMessage(self::FILE_LANGUAGE_NAME, CodeConst::API_PRN_009), CodeConst::API_PRN_009);
            }
            if (count($createDirectDiscountInputDTO->getSpecialDate()) > DirectDiscountProgramConst::LIMIT_SPECIAL_DATE) {
                throw new ServiceException(CommonHelper::getMessage(self::FILE_LANGUAGE_NAME, CodeConst::API_PRN_010), CodeConst::API_PRN_010);
            }
        }
        if (!empty($createDirectDiscountInputDTO->getStartTime()) &&
            !empty($createDirectDiscountInputDTO->getEndTime()) &&
            Carbon::parse($createDirectDiscountInputDTO->getEndTime())->lte(Carbon::parse($createDirectDiscountInputDTO->getStartTime()))) {
            throw new ServiceException(CommonHelper::getMessage(self::FILE_LANGUAGE_NAME, CodeConst::API_PRN_008), CodeConst::API_PRN_008);
        }
    }

    private function _createDirectDiscountHotel($actionSn, $createDirectDiscount, $hotelList)
    {
        $directDiscountHotel = [];
        $directDiscountRoomType = [];
        $directDiscountRoomTypeHistory = [];
        foreach ($hotelList as $index => $hotel) {
            $directDiscountHotel[] = [
                DirectDiscountProgramHotel::COL_DIRECT_DISCOUNT_PROGRAM_NAME => $createDirectDiscount->{DirectDiscountProgram::COL_NAME},
                DirectDiscountProgramHotel::COL_DIRECT_DISCOUNT_PROGRAM_SN   => $createDirectDiscount->{DirectDiscountProgram::COL_SN},
                DirectDiscountProgramHotel::COL_TYPE_APPLY                   => $createDirectDiscount->{DirectDiscountProgram::COL_TYPE_APPLY},
                DirectDiscountProgramHotel::COL_STATUS                       => DirectDiscountProgramConst::STATUS['RUNNING'],
                DirectDiscountProgramHotel::COL_HOTEL_SN                     => $hotel['hotelSn'],
                DirectDiscountProgramHotel::COL_START_DATE                   => $createDirectDiscount->{DirectDiscountProgram::COL_START_DATE},
                DirectDiscountProgramHotel::COL_END_DATE                     => $createDirectDiscount->{DirectDiscountProgram::COL_END_DATE},
                DirectDiscountProgramHotel::COL_SPECIAL_DATE                 => $createDirectDiscount->{DirectDiscountProgram::COL_SPECIAL_DATE},
                DirectDiscountProgramHotel::COL_START_TIME                   => $createDirectDiscount->{DirectDiscountProgram::COL_START_TIME},
                DirectDiscountProgramHotel::COL_END_TIME                     => $createDirectDiscount->{DirectDiscountProgram::COL_END_TIME},
                DirectDiscountProgramHotel::COL_MONDAY                       => $createDirectDiscount->{DirectDiscountProgram::COL_MONDAY},
                DirectDiscountProgramHotel::COL_TUESDAY                      => $createDirectDiscount->{DirectDiscountProgram::COL_TUESDAY},
                DirectDiscountProgramHotel::COL_WEDNESDAY                    => $createDirectDiscount->{DirectDiscountProgram::COL_WEDNESDAY},
                DirectDiscountProgramHotel::COL_THURSDAY                     => $createDirectDiscount->{DirectDiscountProgram::COL_THURSDAY},
                DirectDiscountProgramHotel::COL_FRIDAY                       => $createDirectDiscount->{DirectDiscountProgram::COL_FRIDAY},
                DirectDiscountProgramHotel::COL_SATURDAY                     => $createDirectDiscount->{DirectDiscountProgram::COL_SATURDAY},
                DirectDiscountProgramHotel::COL_SUNDAY                       => $createDirectDiscount->{DirectDiscountProgram::COL_SUNDAY},
                DirectDiscountProgramHotel::COL_CREATED_NAME                 => DirectDiscountProgramConst::CREATE_NAME['GO2JOY'],
            ];
            foreach ($hotel['roomTypeList'] as $roomType) {
                $directDiscountRoomType [] = [
                    DirectDiscountProgramRoomType::COL_DIRECT_DISCOUNT_PROGRAM_SN              => $createDirectDiscount->{DirectDiscountProgram::COL_SN},
                    DirectDiscountProgramRoomType::COL_STATUS                                  => $this->_statusOfRoomType($roomType),
                    DirectDiscountProgramRoomType::COL_HOTEL_SN                                => $hotel['hotelSn'],
                    DirectDiscountProgramRoomType::COL_HOTEL_NAME                              => $hotel['hotelName'],
                    DirectDiscountProgramRoomType::COL_HOTEL_CODE                              => $hotel['hotelCode'],
                    DirectDiscountProgramRoomType::COL_ROOM_TYPE_SN                            => $roomType['roomTypeSn'],
                    DirectDiscountProgramRoomType::COL_ROOM_TYPE_NAME                          => $roomType['roomTypeName'],
                    DirectDiscountProgramRoomType::COL_PRICE_FIRST_HOURS_DISCOUNT_PERCENT      => $roomType['priceFirstHoursDiscountPercent'],
                    DirectDiscountProgramRoomType::COL_PRICE_FIRST_HOURS_AFTER_DISCOUNT        => $roomType['priceFirstHoursAfterDiscount'],
                    DirectDiscountProgramRoomType::COL_PRICE_ADDITIONAL_HOURS_DISCOUNT_PERCENT => $roomType['priceAdditionHoursDiscountPercent'],
                    DirectDiscountProgramRoomType::COL_PRICE_ADDITIONAL_HOURS_AFTER_DISCOUNT   => $roomType['priceAdditionHoursAfterDiscount'],
                    DirectDiscountProgramRoomType::COL_PRICE_OVERNIGHT_DISCOUNT_PERCENT        => $roomType['priceOvernightDiscountPercent'],
                    DirectDiscountProgramRoomType::COL_PRICE_OVERNIGHT_AFTER_DISCOUNT          => $roomType['priceOvernightAfterDiscount'],
                    DirectDiscountProgramRoomType::COL_PRICE_ONE_DAY_DISCOUNT_PERCENT          => $roomType['priceOneDayDiscountPercent'],
                    DirectDiscountProgramRoomType::COL_PRICE_ONE_DAY_AFTER_DISCOUNT            => $roomType['priceOneDayAfterDiscount'],
                    DirectDiscountProgramRoomType::COL_FIRST_HOURS_ORIGIN                      => $roomType['firstHourOrigin'],
                    DirectDiscountProgramRoomType::COL_ADDITIONAL_ORIGIN                       => $roomType['additionOrigin'],
                    DirectDiscountProgramRoomType::COL_OVERNIGHT_ORIGIN                        => $roomType['overnightOrigin'],
                    DirectDiscountProgramRoomType::COL_ONE_DAY_ORIGIN                          => $roomType['oneDayOrigin'],
                ];

                $directDiscountRoomTypeHistory [] = [
                    DirectDiscountProgramRoomTypeHistory::COL_DIRECT_DISCOUNT_PROGRAM_SN                => $createDirectDiscount->{DirectDiscountProgram::COL_SN},
                    DirectDiscountProgramRoomTypeHistory::COL_DIRECT_DISCOUNT_PROGRAM_ACTION_HISTORY_SN => $actionSn,
                    DirectDiscountProgramRoomTypeHistory::COL_STATUS                                    => $this->_statusOfRoomType($roomType),
                    DirectDiscountProgramRoomTypeHistory::COL_HOTEL_SN                                  => $hotel['hotelSn'],
                    DirectDiscountProgramRoomTypeHistory::COL_HOTEL_NAME                                => $hotel['hotelName'],
                    DirectDiscountProgramRoomTypeHistory::COL_HOTEL_CODE                                => $hotel['hotelCode'],
                    DirectDiscountProgramRoomTypeHistory::COL_ROOM_TYPE_SN                              => $roomType['roomTypeSn'],
                    DirectDiscountProgramRoomTypeHistory::COL_ROOM_TYPE_NAME                            => $roomType['roomTypeName'],
                    DirectDiscountProgramRoomTypeHistory::COL_PRICE_FIRST_HOURS_DISCOUNT_PERCENT        => $roomType['priceFirstHoursDiscountPercent'],
                    DirectDiscountProgramRoomTypeHistory::COL_PRICE_FIRST_HOURS_AFTER_DISCOUNT          => $roomType['priceFirstHoursAfterDiscount'],
                    DirectDiscountProgramRoomTypeHistory::COL_PRICE_ADDITIONAL_HOURS_DISCOUNT_PERCENT   => $roomType['priceAdditionHoursDiscountPercent'],
                    DirectDiscountProgramRoomTypeHistory::COL_PRICE_ADDITIONAL_HOURS_AFTER_DISCOUNT     => $roomType['priceAdditionHoursAfterDiscount'],
                    DirectDiscountProgramRoomTypeHistory::COL_PRICE_OVERNIGHT_DISCOUNT_PERCENT          => $roomType['priceOvernightDiscountPercent'],
                    DirectDiscountProgramRoomTypeHistory::COL_PRICE_OVERNIGHT_AFTER_DISCOUNT            => $roomType['priceOvernightAfterDiscount'],
                    DirectDiscountProgramRoomTypeHistory::COL_PRICE_ONE_DAY_DISCOUNT_PERCENT            => $roomType['priceOneDayDiscountPercent'],
                    DirectDiscountProgramRoomTypeHistory::COL_PRICE_ONE_DAY_AFTER_DISCOUNT              => $roomType['priceOneDayAfterDiscount'],
                    DirectDiscountProgramRoomTypeHistory::COL_FIRST_HOURS_ORIGIN                        => $roomType['firstHourOrigin'],
                    DirectDiscountProgramRoomTypeHistory::COL_ADDITIONAL_ORIGIN                         => $roomType['additionOrigin'],
                    DirectDiscountProgramRoomTypeHistory::COL_OVERNIGHT_ORIGIN                          => $roomType['overnightOrigin'],
                    DirectDiscountProgramRoomTypeHistory::COL_ONE_DAY_ORIGIN                            => $roomType['oneDayOrigin'],
                ];
            }
        }
        $this->directDiscountProgramHotelRepository->batchInsert($directDiscountHotel);
        $this->directDiscountProgramRoomTypeRepository->batchInsert($directDiscountRoomType);
        $this->directDiscountProgramRoomTypeHistoryRepository->batchInsert($directDiscountRoomTypeHistory);

        return [$directDiscountRoomType];
    }

    private function _statusOfRoomType($roomType)
    {
        if ($roomType['status'] == DirectDiscountProgramRoomTypeConst::STATUS['AVAILABLE']
            && $roomType['priceFirstHoursAfterDiscount'] == $roomType['firstHourOrigin']
            && $roomType['priceAdditionHoursAfterDiscount'] == $roomType['additionOrigin']
            && $roomType['priceOvernightAfterDiscount'] == $roomType['overnightOrigin']
            && $roomType['priceOneDayAfterDiscount'] == $roomType['oneDayOrigin']) {
            return DirectDiscountProgramRoomTypeConst::STATUS['PENDING'];
        }

        return $roomType['status'];
    }

    private function _createRoomPriceAdjustment($createDirectDiscount, $directDiscountRoomTypeList)
    {
        /** @var CreateRoomPriceAdjustment $createRoomPriceAdjustment */
        $createRoomPriceAdjustment = app(CreateRoomPriceAdjustment::class);
        foreach ($directDiscountRoomTypeList as $directDiscountRoomType) {
            if ($directDiscountRoomType[DirectDiscountProgramRoomType::COL_STATUS] != DirectDiscountProgramRoomTypeConst::STATUS['AVAILABLE']) {
                continue;
            }
            $createRoomPriceAdjustmentInputDTO = new CreateRoomPriceAdjustmentInputDTO();
            $createRoomPriceAdjustmentInputDTO->setDirectDiscountProgramSn($createDirectDiscount->{DirectDiscountProgram::COL_SN});
            $createRoomPriceAdjustmentInputDTO->setRoomTypeSn($directDiscountRoomType[DirectDiscountProgramRoomType::COL_ROOM_TYPE_SN]);
            $createRoomPriceAdjustmentInputDTO->setType(RoomPriceAdjustment::TYPE['DIRECT_DISCOUNT']);
            $createRoomPriceAdjustmentInputDTO->setTypeApply($createDirectDiscount->{DirectDiscountProgram::COL_TYPE_APPLY});
            $createRoomPriceAdjustmentInputDTO->setPriceFirstHours($directDiscountRoomType[DirectDiscountProgramRoomType::COL_PRICE_FIRST_HOURS_AFTER_DISCOUNT]);
            $createRoomPriceAdjustmentInputDTO->setPriceAdditionalHours($directDiscountRoomType[DirectDiscountProgramRoomType::COL_PRICE_ADDITIONAL_HOURS_AFTER_DISCOUNT]);
            $createRoomPriceAdjustmentInputDTO->setPriceOvernight($directDiscountRoomType[DirectDiscountProgramRoomType::COL_PRICE_OVERNIGHT_AFTER_DISCOUNT]);
            $createRoomPriceAdjustmentInputDTO->setPriceOneDay($directDiscountRoomType[DirectDiscountProgramRoomType::COL_PRICE_ONE_DAY_AFTER_DISCOUNT]);
            $createRoomPriceAdjustmentInputDTO->setStartDate($createDirectDiscount->{DirectDiscountProgram::COL_START_DATE});
            $createRoomPriceAdjustmentInputDTO->setEndDate($createDirectDiscount->{DirectDiscountProgram::COL_END_DATE});
            $createRoomPriceAdjustmentInputDTO->setStartTime($createDirectDiscount->{DirectDiscountProgram::COL_START_TIME});
            $createRoomPriceAdjustmentInputDTO->setEndTime($createDirectDiscount->{DirectDiscountProgram::COL_END_TIME});
            $createRoomPriceAdjustmentInputDTO->setMonday($createDirectDiscount->{DirectDiscountProgram::COL_MONDAY});
            $createRoomPriceAdjustmentInputDTO->setTuesday($createDirectDiscount->{DirectDiscountProgram::COL_TUESDAY});
            $createRoomPriceAdjustmentInputDTO->setWednesday($createDirectDiscount->{DirectDiscountProgram::COL_WEDNESDAY});
            $createRoomPriceAdjustmentInputDTO->setThursday($createDirectDiscount->{DirectDiscountProgram::COL_THURSDAY});
            $createRoomPriceAdjustmentInputDTO->setFriday($createDirectDiscount->{DirectDiscountProgram::COL_FRIDAY});
            $createRoomPriceAdjustmentInputDTO->setSaturday($createDirectDiscount->{DirectDiscountProgram::COL_SATURDAY});
            $createRoomPriceAdjustmentInputDTO->setSunday($createDirectDiscount->{DirectDiscountProgram::COL_SUNDAY});
            $createRoomPriceAdjustmentInputDTO->setSpecialDate($createDirectDiscount->{DirectDiscountProgram::COL_SPECIAL_DATE});
            $createRoomPriceAdjustmentInputDTO->setCreateStaffSn($createDirectDiscount->{DirectDiscountProgram::COL_CREATED_BY});
            $createRoomPriceAdjustment->handle($createRoomPriceAdjustmentInputDTO);
        }
    }
}