<?php

namespace App\Actions\Promotion\DirectDiscount;

use App\Constants\Globals\QueueName as QueueNameConst;
use App\Constants\Hotel as HotelConst;
use App\Constants\RoomPriceAdjustment as RoomPriceAdjustmentConst;
use App\Constants\RoomType as RoomTypeConst;
use App\DTOs\Common\RoomTypeHistory\StoreDTO as RoomTypeHistoryStoreDTO;
use App\DTOs\Promotion\DirectDiscount\CreateRoomPriceAdjustmentInputDTO;
use App\DTOs\Promotion\DirectDiscount\CreateRoomPriceAdjustmentOutputDTO;
use App\DTOs\Promotion\DirectDiscount\UpdateRoomPriceAdjustmentInputDTO;
use App\DTOs\Promotion\DirectDiscount\UpdateRoomPriceAdjustmentOutputDTO;
use App\Helpers\ConvertHelper;
use App\Helpers\LoggingHelper;
use App\Jobs\ElasticSearch\SyncRoomPriceAdjustmentJob;
use App\Models\Hotel;
use App\Models\RoomPriceAdjustment;
use App\Models\RoomPriceAdjustmentHistory;
use App\Models\RoomType;
use App\Repositories\Interfaces\HotelRepositoryInterface;
use App\Repositories\Interfaces\RoomPriceAdjustmentHistoryRepositoryInterface;
use App\Repositories\Interfaces\RoomPriceAdjustmentRepositoryInterface;
use App\Repositories\Interfaces\RoomTypeHistoryRepositoryInterface;
use App\Repositories\Interfaces\RoomTypeRepositoryInterface;
use App\Services\Mobile\HotelDisplayRuleService;
use Carbon\CarbonPeriod;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\DB;
use stdClass;

class UpdateRoomPriceAdjustment
{
    public $roomTypeRepository;

    public $roomTypeHistoryRepository;

    public $roomPriceAdjustmentRepository;

    public $roomPriceAdjustmentHistoryRepository;

    public $hotelRepository;

    //Tạm giữ sau này sẽ đưa ra action riêng
    public $hotelDisplayRuleService;

    public function __construct()
    {
        $this->roomTypeRepository = app(RoomTypeRepositoryInterface::class);
        $this->hotelRepository = app(HotelRepositoryInterface::class);
        $this->roomTypeHistoryRepository = app(RoomTypeHistoryRepositoryInterface::class);
        $this->roomPriceAdjustmentRepository = app(RoomPriceAdjustmentRepositoryInterface::class);
        $this->roomPriceAdjustmentHistoryRepository = app(RoomPriceAdjustmentHistoryRepositoryInterface::class);
        $this->hotelDisplayRuleService = app(HotelDisplayRuleService::class);
    }

    public function handle(UpdateRoomPriceAdjustmentInputDTO $updateRoomPriceAdjustmentInputDTO)
    {
        $roomPriceAdjustment = $this->roomPriceAdjustmentRepository->findExistRoomPriceAdjustment($updateRoomPriceAdjustmentInputDTO->getDirectDiscountProgramSn(), $updateRoomPriceAdjustmentInputDTO->getRoomTypeSn(), RoomPriceAdjustmentConst::TYPE['DIRECT_DISCOUNT']);
        if (!empty($roomPriceAdjustment)) {
            if (!$this->_checkChangePriceRoom($updateRoomPriceAdjustmentInputDTO, $roomPriceAdjustment)) {
                return CreateRoomPriceAdjustmentOutputDTO::assemble(true);
            } else {
                $this->roomPriceAdjustmentHistoryRepository->updateWhere([
                    RoomPriceAdjustmentHistory::COL_STATUS          => RoomPriceAdjustmentConst::STATUS['DELETE'],
                    RoomPriceAdjustmentHistory::COL_DELETE_TIME     => Carbon::now(),
                    RoomPriceAdjustmentHistory::COL_STAFF_DELETE_SN => $updateRoomPriceAdjustmentInputDTO->getUpdateStaffSn(),
                ], [RoomPriceAdjustmentHistory::COL_ROOM_PRICE_ADJUSTMENT_SN => $roomPriceAdjustment->{RoomPriceAdjustment::COL_SN}]);
                $this->roomPriceAdjustmentRepository->delete($roomPriceAdjustment->{RoomPriceAdjustment::COL_SN});
            }

        }
        $displayCalendar = $this->_setDisplayCalendar(
            $updateRoomPriceAdjustmentInputDTO->getTypeApply(),
            $updateRoomPriceAdjustmentInputDTO->getStartDate(),
            $updateRoomPriceAdjustmentInputDTO->getEndDate(),
            $updateRoomPriceAdjustmentInputDTO->getSpecialDate(),
            $updateRoomPriceAdjustmentInputDTO->getMonday(),
            $updateRoomPriceAdjustmentInputDTO->getTuesday(),
            $updateRoomPriceAdjustmentInputDTO->getWednesday(),
            $updateRoomPriceAdjustmentInputDTO->getThursday(),
            $updateRoomPriceAdjustmentInputDTO->getFriday(),
            $updateRoomPriceAdjustmentInputDTO->getSaturday(),
            $updateRoomPriceAdjustmentInputDTO->getSunday()
        );
        if (empty($displayCalendar)) {
            return CreateRoomPriceAdjustmentOutputDTO::assemble(false);
        }
        $roomType = $this->roomTypeRepository->findRoomType($updateRoomPriceAdjustmentInputDTO->getRoomTypeSn());
        $roomTypeOrigin = clone $roomType;
        if ($updateRoomPriceAdjustmentInputDTO->getPriceOvernight() != $roomType->{RoomType::COL_OVERNIGHT_ORIGIN} || $updateRoomPriceAdjustmentInputDTO->getPriceOneDay() != $roomType->{RoomType::COL_ONE_DAY_ORIGIN} || $updateRoomPriceAdjustmentInputDTO->getPriceFirstHours() != $roomType->{RoomType::COL_FIRST_HOURS_ORIGIN} || $updateRoomPriceAdjustmentInputDTO->getPriceAdditionalHours() != $roomType->{RoomType::COL_ADDITIONAL_ORIGIN}) {
            if ($updateRoomPriceAdjustmentInputDTO->getPriceOvernight() > 0 || $updateRoomPriceAdjustmentInputDTO->getPriceOneDay() > 0 || $updateRoomPriceAdjustmentInputDTO->getPriceFirstHours() > 0 || $updateRoomPriceAdjustmentInputDTO->getPriceAdditionalHours() > 0) {
                $roomType->{RoomType::COL_APPLY_DISCOUNT} = 1;
                $roomPriceAdjustment = RoomPriceAdjustment::create([
                    RoomPriceAdjustment::COL_DIRECT_DISCOUNT_PROGRAM_SN => $updateRoomPriceAdjustmentInputDTO->getDirectDiscountProgramSn(),
                    RoomPriceAdjustment::COL_ROOM_TYPE_SN               => $roomType->{RoomType::COL_SN},
                    RoomPriceAdjustment::COL_ROOM_TYPE_NAME             => $roomType->{RoomType::COL_NAME},
                    RoomPriceAdjustment::COL_ROOM_TYPE_SHORT_NAME       => $roomType->{RoomType::COL_SHORT_NAME},
                    RoomPriceAdjustment::COL_NUM_OF_ROOM                => $roomType->{RoomType::COL_NUM_OF_ROOM},
                    RoomPriceAdjustment::COL_START_DATE                 => $updateRoomPriceAdjustmentInputDTO->getStartDate(),
                    RoomPriceAdjustment::COL_END_DATE                   => $updateRoomPriceAdjustmentInputDTO->getEndDate(),
                    RoomPriceAdjustment::COL_START_TIME                 => $updateRoomPriceAdjustmentInputDTO->getStartTime(),
                    RoomPriceAdjustment::COL_END_TIME                   => $updateRoomPriceAdjustmentInputDTO->getEndTime(),
                    RoomPriceAdjustment::COL_MONDAY                     => $updateRoomPriceAdjustmentInputDTO->getMonday(),
                    RoomPriceAdjustment::COL_TUESDAY                    => $updateRoomPriceAdjustmentInputDTO->getTuesday(),
                    RoomPriceAdjustment::COL_WEDNESDAY                  => $updateRoomPriceAdjustmentInputDTO->getWednesday(),
                    RoomPriceAdjustment::COL_THURSDAY                   => $updateRoomPriceAdjustmentInputDTO->getThursday(),
                    RoomPriceAdjustment::COL_FRIDAY                     => $updateRoomPriceAdjustmentInputDTO->getFriday(),
                    RoomPriceAdjustment::COL_SATURDAY                   => $updateRoomPriceAdjustmentInputDTO->getSaturday(),
                    RoomPriceAdjustment::COL_SUNDAY                     => $updateRoomPriceAdjustmentInputDTO->getSunday(),
                    RoomPriceAdjustment::COL_SPECIAL_DATE               => $updateRoomPriceAdjustmentInputDTO->getSpecialDate(),
                    RoomPriceAdjustment::COL_FIRST_HOURS                => $roomType->{RoomType::COL_FIRST_HOURS},
                    RoomPriceAdjustment::COL_ADDITIONAL_HOURS           => $roomType->{RoomType::COL_ADDITIONAL_HOURS},
                    RoomPriceAdjustment::COL_PRICE_FIRST_HOURS          => $updateRoomPriceAdjustmentInputDTO->getPriceFirstHours(),
                    RoomPriceAdjustment::COL_PRICE_ADDITIONAL_HOURS     => $updateRoomPriceAdjustmentInputDTO->getPriceAdditionalHours(),
                    RoomPriceAdjustment::COL_PRICE_OVERNIGHT            => $updateRoomPriceAdjustmentInputDTO->getPriceOvernight(),
                    RoomPriceAdjustment::COL_PRICE_ONE_DAY              => $updateRoomPriceAdjustmentInputDTO->getPriceOneDay(),
                    RoomPriceAdjustment::COL_FIRST_HOURS_ORIGIN         => $roomType->{RoomType::COL_FIRST_HOURS_ORIGIN},
                    RoomPriceAdjustment::COL_ADDITIONAL_ORIGIN          => $roomType->{RoomType::COL_ADDITIONAL_ORIGIN},
                    RoomPriceAdjustment::COL_OVERNIGHT_ORIGIN           => $roomType->{RoomType::COL_OVERNIGHT_ORIGIN},
                    RoomPriceAdjustment::COL_ONE_DAY_ORIGIN             => $roomType->{RoomType::COL_ONE_DAY_ORIGIN},
                    RoomPriceAdjustment::COL_TYPE                       => $updateRoomPriceAdjustmentInputDTO->getType(),
                    RoomPriceAdjustment::COL_TYPE_APPLY                 => $updateRoomPriceAdjustmentInputDTO->getTypeApply(),
                    RoomPriceAdjustment::COL_STATUS                     => RoomPriceAdjustmentConst::STATUS['ACTIVE'],
                    RoomPriceAdjustment::COL_DISPLAY_CALENDAR           => ConvertHelper::toJson($displayCalendar),
                    RoomPriceAdjustment::COL_STAFF_CREATE_SN            => $updateRoomPriceAdjustmentInputDTO->getUpdateStaffSn(),
                ]);
                RoomPriceAdjustmentHistory::create([
                    RoomPriceAdjustmentHistory::COL_DIRECT_DISCOUNT_PROGRAM_SN => $updateRoomPriceAdjustmentInputDTO->getDirectDiscountProgramSn(),
                    RoomPriceAdjustmentHistory::COL_ROOM_PRICE_ADJUSTMENT_SN   => $roomPriceAdjustment->{RoomPriceAdjustment::COL_SN},
                    RoomPriceAdjustmentHistory::COL_ROOM_TYPE_SN               => $roomType->{RoomType::COL_SN},
                    RoomPriceAdjustmentHistory::COL_ROOM_TYPE_NAME             => $roomType->{RoomType::COL_NAME},
                    RoomPriceAdjustmentHistory::COL_ROOM_TYPE_SHORT_NAME       => $roomType->{RoomType::COL_SHORT_NAME},
                    RoomPriceAdjustmentHistory::COL_NUM_OF_ROOM                => $roomType->{RoomType::COL_NUM_OF_ROOM},
                    RoomPriceAdjustmentHistory::COL_START_DATE                 => $updateRoomPriceAdjustmentInputDTO->getStartDate(),
                    RoomPriceAdjustmentHistory::COL_END_DATE                   => $updateRoomPriceAdjustmentInputDTO->getEndDate(),
                    RoomPriceAdjustmentHistory::COL_START_TIME                 => $updateRoomPriceAdjustmentInputDTO->getStartTime(),
                    RoomPriceAdjustmentHistory::COL_END_TIME                   => $updateRoomPriceAdjustmentInputDTO->getEndTime(),
                    RoomPriceAdjustmentHistory::COL_MONDAY                     => $updateRoomPriceAdjustmentInputDTO->getMonday(),
                    RoomPriceAdjustmentHistory::COL_TUESDAY                    => $updateRoomPriceAdjustmentInputDTO->getTuesday(),
                    RoomPriceAdjustmentHistory::COL_WEDNESDAY                  => $updateRoomPriceAdjustmentInputDTO->getWednesday(),
                    RoomPriceAdjustmentHistory::COL_THURSDAY                   => $updateRoomPriceAdjustmentInputDTO->getThursday(),
                    RoomPriceAdjustmentHistory::COL_FRIDAY                     => $updateRoomPriceAdjustmentInputDTO->getFriday(),
                    RoomPriceAdjustmentHistory::COL_SATURDAY                   => $updateRoomPriceAdjustmentInputDTO->getSaturday(),
                    RoomPriceAdjustmentHistory::COL_SUNDAY                     => $updateRoomPriceAdjustmentInputDTO->getSunday(),
                    RoomPriceAdjustmentHistory::COL_SPECIAL_DATE               => $updateRoomPriceAdjustmentInputDTO->getSpecialDate(),
                    RoomPriceAdjustmentHistory::COL_FIRST_HOURS                => $roomType->{RoomType::COL_FIRST_HOURS},
                    RoomPriceAdjustmentHistory::COL_ADDITIONAL_HOURS           => $roomType->{RoomType::COL_ADDITIONAL_HOURS},
                    RoomPriceAdjustmentHistory::COL_PRICE_FIRST_HOURS          => $updateRoomPriceAdjustmentInputDTO->getPriceFirstHours(),
                    RoomPriceAdjustmentHistory::COL_PRICE_ADDITIONAL_HOURS     => $updateRoomPriceAdjustmentInputDTO->getPriceAdditionalHours(),
                    RoomPriceAdjustmentHistory::COL_PRICE_OVERNIGHT            => $updateRoomPriceAdjustmentInputDTO->getPriceOvernight(),
                    RoomPriceAdjustmentHistory::COL_PRICE_ONE_DAY              => $updateRoomPriceAdjustmentInputDTO->getPriceOneDay(),
                    RoomPriceAdjustmentHistory::COL_FIRST_HOURS_ORIGIN         => $roomType->{RoomType::COL_FIRST_HOURS_ORIGIN},
                    RoomPriceAdjustmentHistory::COL_ADDITIONAL_ORIGIN          => $roomType->{RoomType::COL_ADDITIONAL_ORIGIN},
                    RoomPriceAdjustmentHistory::COL_OVERNIGHT_ORIGIN           => $roomType->{RoomType::COL_OVERNIGHT_ORIGIN},
                    RoomPriceAdjustmentHistory::COL_ONE_DAY_ORIGIN             => $roomType->{RoomType::COL_ONE_DAY_ORIGIN},
                    RoomPriceAdjustmentHistory::COL_TYPE                       => $updateRoomPriceAdjustmentInputDTO->getType(),
                    RoomPriceAdjustmentHistory::COL_TYPE_APPLY                 => $updateRoomPriceAdjustmentInputDTO->getTypeApply(),
                    RoomPriceAdjustmentHistory::COL_STATUS                     => RoomPriceAdjustmentConst::STATUS['ACTIVE'],
                    RoomPriceAdjustmentHistory::COL_DISPLAY_CALENDAR           => ConvertHelper::toJson($displayCalendar),
                    RoomPriceAdjustmentHistory::COL_STAFF_CREATE_SN            => $updateRoomPriceAdjustmentInputDTO->getUpdateStaffSn(),
                    RoomPriceAdjustmentHistory::COL_ACTIVE_TIME                => Carbon::now(),
                ]);
            }
            $roomPriceAdjustmentList = $this->getRoomPriceAdjustmentApplyToday($roomType->{RoomType::COL_SN}, Carbon::now());
            $this->setupRoomPriceToday($roomPriceAdjustmentList, $roomType);

            $this->updatePriceRoomType($roomType, $roomTypeOrigin, $roomType->{RoomType::COL_SN});

            $syncRoomPriceAdjustmentJob = new SyncRoomPriceAdjustmentJob(json_encode([
                'sn'          => $roomType->{RoomType::COL_SN},
                'hotelSn'     => $roomType->{RoomType::COL_HOTEL_SN},
                'typeApply'   => $updateRoomPriceAdjustmentInputDTO->getTypeApply(),
                'startDate'   => $updateRoomPriceAdjustmentInputDTO->getStartDate(),
                'endDate'     => $updateRoomPriceAdjustmentInputDTO->getEndDate(),
                'specialDate' => $updateRoomPriceAdjustmentInputDTO->getSpecialDate(),
                'maxHour'     => $roomType->{RoomType::COL_MAX_NUM_HOUR},
            ]));
            dispatch($syncRoomPriceAdjustmentJob)->onQueue(QueueNameConst::ROOM_PRICING_SYNCING);
        }

        return CreateRoomPriceAdjustmentOutputDTO::assemble(true);
    }

    private function _setDisplayCalendar($typeApply, $startDate, $endDate, $specialDate, $monday, $tuesday, $wednesday, $thursday, $friday, $saturday, $sunday)
    {
        $displayCalendar = Collect([]);
        if ($typeApply == RoomPriceAdjustmentConst::TYPE_APPLY['DAY_OF_WEEK']) {
            do {
                $form = new stdClass();
                $form->startDate = null;
                $form->endDate = null;
                //
                $dateBetween = CarbonPeriod::between($startDate, $endDate);
                foreach ($dateBetween as $date) {
                    $continue = 0;
                    switch ($date->dayOfWeek) {
                        case Carbon::SUNDAY:
                            if ($sunday) {
                                $continue = 1;
                            }
                            break;
                        case Carbon::MONDAY:
                            if ($monday) {
                                $continue = 1;
                            }
                            break;
                        case Carbon::TUESDAY:
                            if ($tuesday) {
                                $continue = 1;
                            }
                            break;
                        case Carbon::WEDNESDAY:
                            if ($wednesday) {
                                $continue = 1;
                            }
                            break;
                        case Carbon::THURSDAY:
                            if ($thursday) {
                                $continue = 1;
                            }
                            break;
                        case Carbon::FRIDAY:
                            if ($friday) {
                                $continue = 1;
                            }
                            break;
                        case Carbon::SATURDAY:
                            if ($saturday) {
                                $continue = 1;
                            }
                            break;
                    }
                    if ($continue) {
                        if (empty($form->startDate)) {
                            $form->startDate = $date->format('Y-m-d');
                        }
                        $form->endDate = $date->format('Y-m-d');
                        $startDate = $form->endDate;
                        continue;
                    } else {
                        $startDate = $date->addDay()->format('Y-m-d');
                        break;
                    }
                }
                //
                if (!empty($form->startDate) && !empty($form->endDate)) {
                    $displayCalendar->add($form);
                    if ($form->endDate == $endDate) {
                        break;
                    }
                }
            } while (Carbon::parse($startDate)->lessThanOrEqualTo(Carbon::parse($endDate)));
        } else {
            $specialDate = ConvertHelper::toArray($specialDate);
            foreach ($specialDate as $date) {
                $form = new stdClass();
                $form->startDate = Carbon::parse($date)->format('Y-m-d');
                $form->endDate = Carbon::parse($date)->format('Y-m-d');
                $displayCalendar->add($form);
            }
        }

        return $displayCalendar;
    }

    public function getRoomPriceAdjustmentApplyToday($roomTypeSn, $toDate, $excludeAdjustSn = null)
    {
        $adjustmentDDList = $this->roomPriceAdjustmentRepository->findPriceAdjustmentApplyToday($roomTypeSn,
            RoomPriceAdjustmentConst::TYPE['DIRECT_DISCOUNT'], $toDate, $excludeAdjustSn);
        $adjustmentEFList = $this->roomPriceAdjustmentRepository->findPriceAdjustmentApplyToday($roomTypeSn,
            RoomPriceAdjustmentConst::TYPE['EXTRA_FEE'], $toDate, $excludeAdjustSn);

        return $this->sortPriorityRoomPriceAdjustment($adjustmentDDList, $adjustmentEFList);
    }

    public function sortPriorityRoomPriceAdjustment($adjustmentDD, $adjustmentEF)
    {
        if (empty($adjustmentDD) && empty($adjustmentEF)) {
            return [];
        } elseif (empty($adjustmentDD) && !empty($adjustmentEF)) {
            return [$adjustmentEF];
        } elseif (!empty($adjustmentDD) && empty($adjustmentEF)) {
            return [$adjustmentDD];
        } else {
            return [$adjustmentDD, $adjustmentEF];

        }
    }

    public function setupRoomPriceToday($roomPriceAdjustmentList, &$roomType)
    {
        $roomType->{RoomType::COL_EXTRA_FEE} = 0;
        $roomType->{RoomType::COL_DISCOUNT} = 0;
        $roomType->{RoomType::COL_PRICE_FIRST_HOURS} = $roomType->{RoomType::COL_FIRST_HOURS_ORIGIN};
        $roomType->{RoomType::COL_PRICE_ADDITIONAL_HOURS} = $roomType->{RoomType::COL_ADDITIONAL_ORIGIN};
        $roomType->{RoomType::COL_PRICE_OVERNIGHT} = $roomType->{RoomType::COL_OVERNIGHT_ORIGIN};
        $roomType->{RoomType::COL_PRICE_ONE_DAY} = $roomType->{RoomType::COL_ONE_DAY_ORIGIN};
        foreach ($roomPriceAdjustmentList as $roomPriceAdjustment) {
            if (RoomPriceAdjustmentConst::TYPE['DIRECT_DISCOUNT'] == $roomPriceAdjustment->{RoomPriceAdjustment::COL_TYPE}) {
                $roomType->{RoomType::COL_DISCOUNT} = 1;
                if ($roomPriceAdjustment->{RoomPriceAdjustment::COL_TYPE_APPLY} == RoomPriceAdjustmentConst::TYPE_APPLY['DAY_OF_WEEK']) {
                    $roomType->{RoomType::COL_START_DATE} = $roomPriceAdjustment->{RoomPriceAdjustment::COL_START_DATE};
                    $roomType->{RoomType::COL_END_DATE} = $roomPriceAdjustment->{RoomPriceAdjustment::COL_END_DATE};
                } else {
                    $roomType->{RoomType::COL_START_DATE} = null;
                    $roomType->{RoomType::COL_END_DATE} = null;
                }
                $isApplyTime = $this->isApplyTimeRoomPriceAdjustment($roomPriceAdjustment);
                if ($isApplyTime) {
                    $roomType->{RoomType::COL_PRICE_FIRST_HOURS} = ($roomType->{RoomType::COL_PRICE_FIRST_HOURS} + $roomPriceAdjustment->{RoomPriceAdjustment::COL_PRICE_FIRST_HOURS}) - $roomType->{RoomType::COL_FIRST_HOURS_ORIGIN};
                    $roomType->{RoomType::COL_PRICE_ADDITIONAL_HOURS} = ($roomType->{RoomType::COL_PRICE_ADDITIONAL_HOURS} + $roomPriceAdjustment->{RoomPriceAdjustment::COL_PRICE_ADDITIONAL_HOURS}) - $roomType->{RoomType::COL_ADDITIONAL_ORIGIN};
                }
                $roomType->{RoomType::COL_PRICE_OVERNIGHT} = ($roomType->{RoomType::COL_PRICE_OVERNIGHT} + $roomPriceAdjustment->{RoomPriceAdjustment::COL_PRICE_OVERNIGHT}) - $roomType->{RoomType::COL_OVERNIGHT_ORIGIN};
                $roomType->{RoomType::COL_PRICE_ONE_DAY} = ($roomType->{RoomType::COL_PRICE_ONE_DAY} + $roomPriceAdjustment->{RoomPriceAdjustment::COL_PRICE_ONE_DAY}) - $roomType->{RoomType::COL_ONE_DAY_ORIGIN};
            } elseif (RoomPriceAdjustmentConst::TYPE['EXTRA_FEE'] == $roomPriceAdjustment->{RoomPriceAdjustment::COL_TYPE}) {
                $roomType->{RoomType::COL_EXTRA_FEE} = 1;
                if ($roomPriceAdjustment->{RoomPriceAdjustment::COL_TYPE_APPLY} == RoomPriceAdjustmentConst::TYPE_APPLY['DAY_OF_WEEK']) {
                    $roomType->{RoomType::COL_START_DATE_EXTRA_FEE} = $roomPriceAdjustment->{RoomPriceAdjustment::COL_START_DATE};
                    $roomType->{RoomType::COL_END_DATE_EXTRA_FEE} = $roomPriceAdjustment->{RoomPriceAdjustment::COL_END_DATE};
                } else {
                    $roomType->{RoomType::COL_START_DATE_EXTRA_FEE} = null;
                    $roomType->{RoomType::COL_END_DATE_EXTRA_FEE} = null;
                }

                $roomType->{RoomType::COL_PRICE_FIRST_HOURS} = ($roomType->{RoomType::COL_PRICE_FIRST_HOURS} + $roomPriceAdjustment->{RoomPriceAdjustment::COL_PRICE_FIRST_HOURS}) - $roomType->{RoomType::COL_FIRST_HOURS_ORIGIN};
                $roomType->{RoomType::COL_PRICE_ADDITIONAL_HOURS} = ($roomType->{RoomType::COL_PRICE_ADDITIONAL_HOURS} + $roomPriceAdjustment->{RoomPriceAdjustment::COL_PRICE_ADDITIONAL_HOURS}) - $roomType->{RoomType::COL_ADDITIONAL_ORIGIN};
                $roomType->{RoomType::COL_PRICE_OVERNIGHT} = ($roomType->{RoomType::COL_PRICE_OVERNIGHT} + $roomPriceAdjustment->{RoomPriceAdjustment::COL_PRICE_OVERNIGHT}) - $roomType->{RoomType::COL_OVERNIGHT_ORIGIN};
                $roomType->{RoomType::COL_PRICE_ONE_DAY} = ($roomType->{RoomType::COL_PRICE_ONE_DAY} + $roomPriceAdjustment->{RoomPriceAdjustment::COL_PRICE_ONE_DAY}) - $roomType->{RoomType::COL_ONE_DAY_ORIGIN};
            }
        }
    }

    public function isApplyTimeRoomPriceAdjustment($roomPriceAdjustment)
    {
        if ((empty($roomPriceAdjustment->{RoomPriceAdjustment::COL_START_TIME}) && empty($roomPriceAdjustment->{RoomPriceAdjustment::COL_START_TIME})) ||
            (RoomPriceAdjustmentConst::DEFAULT_START_TIME == $roomPriceAdjustment->{RoomPriceAdjustment::COL_START_TIME}
                && RoomPriceAdjustmentConst::DEFAULT_END_TIME == $roomPriceAdjustment->{RoomPriceAdjustment::COL_END_TIME})) {
            return true;
        }

        $now = Carbon::now();
        $startTime = Carbon::parse($roomPriceAdjustment->{RoomPriceAdjustment::COL_START_TIME});
        $endTime = Carbon::parse($roomPriceAdjustment->{RoomPriceAdjustment::COL_END_TIME});
        if ($now->between($startTime, $endTime)) {
            return true;
        }

        return false;
    }

    private function updatePriceRoomType($roomType, $originRoomType, $roomTypeSn)
    {
        if ($this->roomTypeRepository->update([
            RoomType::COL_DISCOUNT               => $roomType->{RoomType::COL_DISCOUNT},
            RoomType::COL_APPLY_DISCOUNT         => $roomType->{RoomType::COL_APPLY_DISCOUNT},
            RoomType::COL_EXTRA_FEE              => $roomType->{RoomType::COL_EXTRA_FEE},
            RoomType::COL_APPLY_EXTRA_FEE        => $roomType->{RoomType::COL_APPLY_EXTRA_FEE},
            RoomType::COL_START_DATE             => $roomType->{RoomType::COL_START_DATE},
            RoomType::COL_END_DATE               => $roomType->{RoomType::COL_END_DATE},
            RoomType::COL_START_DATE_EXTRA_FEE   => $roomType->{RoomType::COL_START_DATE_EXTRA_FEE},
            RoomType::COL_END_DATE_EXTRA_FEE     => $roomType->{RoomType::COL_END_DATE_EXTRA_FEE},
            RoomType::COL_PRICE_FIRST_HOURS      => $roomType->{RoomType::COL_PRICE_FIRST_HOURS},
            RoomType::COL_PRICE_ADDITIONAL_HOURS => $roomType->{RoomType::COL_PRICE_ADDITIONAL_HOURS},
            RoomType::COL_PRICE_OVERNIGHT        => $roomType->{RoomType::COL_PRICE_OVERNIGHT},
            RoomType::COL_PRICE_ONE_DAY          => $roomType->{RoomType::COL_PRICE_ONE_DAY},

        ], $roomTypeSn)) {
            $this->_updateGiftBonusHourForHotel($roomType->{RoomType::COL_HOTEL_SN});
            $this->_updateLowestPriceForHotel($roomType->{RoomType::COL_HOTEL_SN});
            $result = $this->_isChangePrices($roomType, $originRoomType);
            if ($result) {
                $this->insertRoomTypeHistory($roomType->{RoomType::COL_SN});
            }
            // update hotel display rule
            LoggingHelper::logFunction('DEBUG_JOB_UPDATE:', json_encode($roomType));
            $this->hotelDisplayRuleService->refreshHotelDisplayRuleJob($roomType->{RoomType::COL_HOTEL_SN});
        }
    }

    public function _updateGiftBonusHourForHotel($hotelSn)
    {
        $hasGift = $this->roomTypeRepository->existHasGiftForHotel($hotelSn);
        $hasBonusHour = $this->roomTypeRepository->existHasBonusHourForHotel($hotelSn);
        $extraFee = $this->roomTypeRepository->existExtraFeeForHotel($hotelSn);
        return DB::table('HOTEL AS H')
            ->where('H.SN', $hotelSn)
            ->whereIn('H.HOTEL_STATUS', [
                HotelConst::STATUS['CONTRACTED'],
                HotelConst::STATUS['TRIAL'],
                HotelConst::STATUS['TERMINATED'],
                HotelConst::STATUS['SUSPENDED'],
            ])
            ->update([
                Hotel::COL_HAS_GIFT       => $hasGift,
                Hotel::COL_HAS_BONUS_HOUR => $hasBonusHour,
                Hotel::COL_EXTRA_FEE      => $extraFee,
            ]);
    }

    private function _updateLowestPriceForHotel($hotelSn)
    {        // Number of rooms is running flash sale
        $hotel = DB::table('HOTEL AS H')->where('H.SN', $hotelSn)->exists();
        if ($hotel) {
            $roomTypes = DB::table('ROOM_TYPE AS RT')
                ->where('RT.STATUS', '!=', RoomTypeConst::STATUS['DELETED'])
                ->where('RT.HOTEL_SN', $hotelSn)->where('RT.MODE', RoomTypeConst::MODE['NORMAL'])
                ->orderBy('RT.IDX', 'ASC')
                ->get();
            $hasDiscount = $roomTypes->contains(function($value) {
                return $value->{RoomType::COL_DISCOUNT};
            });
            $data[Hotel::COL_DISCOUNT] = $hasDiscount;
            $hasExtraFee = $roomTypes->contains(function($value) {
                return $value->{RoomType::COL_EXTRA_FEE};
            });
            $data[Hotel::COL_EXTRA_FEE] = $hasExtraFee;
            #region Min price first hours
            $roomTypeHasPriceFirstHours = $roomTypes->filter(function($value) {
                return $value->{RoomType::COL_FIRST_HOURS_ORIGIN} != 0;
            });
            $roomTypeHasMinPriceFirstHours = $roomTypeHasPriceFirstHours->where(RoomType::COL_PRICE_FIRST_HOURS, $roomTypeHasPriceFirstHours->min(RoomType::COL_PRICE_FIRST_HOURS))->first();
            if (!empty($roomTypeHasMinPriceFirstHours)) {
                $data[Hotel::COL_FIRST_HOURS] = $roomTypeHasMinPriceFirstHours->{RoomType::COL_FIRST_HOURS};
                $data[Hotel::COL_LOWEST_PRICE] = $roomTypeHasMinPriceFirstHours->{RoomType::COL_PRICE_FIRST_HOURS};
                $data[Hotel::COL_FIRST_HOURS_ORIGIN] = $roomTypeHasMinPriceFirstHours->{RoomType::COL_FIRST_HOURS_ORIGIN};
            } else {
                $data[Hotel::COL_FIRST_HOURS] = 0;
                $data[Hotel::COL_LOWEST_PRICE] = 0;
                $data[Hotel::COL_FIRST_HOURS_ORIGIN] = 0;
            }
            #endregion
            #region Min first hours
            $roomTypeHasMinFirstHours = $roomTypeHasPriceFirstHours->where(RoomType::COL_FIRST_HOURS, $roomTypeHasPriceFirstHours->min(RoomType::COL_FIRST_HOURS))->first();
            if (!empty($roomTypeHasMinFirstHours)) {
                $data[Hotel::COL_FIRST_HOURS] = $roomTypeHasMinFirstHours->{RoomType::COL_FIRST_HOURS};
            } else {
                $data[Hotel::COL_FIRST_HOURS] = 1;
            }
            #endregion

            #region Min overnight
            $roomTypeHasPriceOvernight = $roomTypes->filter(function($value) {
                return $value->{RoomType::COL_OVERNIGHT_ORIGIN} != 0;
            });
            $roomTypeHasMinPriceOvernight = $roomTypeHasPriceOvernight->where(RoomType::COL_PRICE_OVERNIGHT, $roomTypeHasPriceOvernight->min(RoomType::COL_PRICE_OVERNIGHT))->first();
            if (!empty($roomTypeHasMinPriceOvernight)) {
                $data[Hotel::COL_LOWEST_PRICE_OVERNIGHT] = $roomTypeHasMinPriceOvernight->{RoomType::COL_PRICE_OVERNIGHT};
                $data[Hotel::COL_OVERNIGHT_ORIGIN] = $roomTypeHasMinPriceOvernight->{RoomType::COL_OVERNIGHT_ORIGIN};
            } else {
                $data[Hotel::COL_LOWEST_PRICE_OVERNIGHT] = 0;
                $data[Hotel::COL_OVERNIGHT_ORIGIN] = 0;
            }
            #endregion

            #region Min daily
            $roomTypeHasPriceOneDay = $roomTypes->filter(function($value) {
                return $value->{RoomType::COL_ONE_DAY_ORIGIN} != 0;
            });
            $roomTypeHasMinPriceOneDay = $roomTypeHasPriceOneDay->where(RoomType::COL_PRICE_ONE_DAY, $roomTypeHasPriceOneDay->min(RoomType::COL_PRICE_ONE_DAY))->first();
            if (!empty($roomTypeHasMinPriceOneDay)) {
                $data[Hotel::COL_LOWEST_ONE_DAY] = $roomTypeHasMinPriceOneDay->{RoomType::COL_PRICE_ONE_DAY};
                $data[Hotel::COL_ONE_DAY_ORIGIN] = $roomTypeHasMinPriceOneDay->{RoomType::COL_ONE_DAY_ORIGIN};
            } else {
                $data[Hotel::COL_LOWEST_ONE_DAY] = 0;
                $data[Hotel::COL_ONE_DAY_ORIGIN] = 0;
            }
            #endregion
            #region Min discount date
            $roomTypeHasEndDate = $roomTypes->filter(function($value) {
                return $value->{RoomType::COL_END_DATE} != 0;
            });
            $roomTypeHasMinEndDate = $roomTypeHasEndDate->where(RoomType::COL_END_DATE, $roomTypeHasEndDate->min(RoomType::COL_END_DATE))->first();
            if (!empty($roomTypeHasMinEndDate)) {
                $data[Hotel::COL_MIN_DISCOUNT_DATE] = $roomTypeHasMinEndDate->{RoomType::COL_END_DATE};
            } else {
                $data[Hotel::COL_MIN_DISCOUNT_DATE] = null;
            }
            #endregion
            // Update price for hotel
            return $this->hotelRepository->update($data, $hotelSn);
        }

        return 0;
    }

    private function _isChangePrices($roomType, $originRoomType)
    {
        if ($roomType->{RoomType::COL_ADDITIONAL_HOURS} != $originRoomType->{RoomType::COL_ADDITIONAL_HOURS}) {
            return true;
        } elseif ($roomType->{RoomType::COL_ADDITIONAL_ORIGIN} != $originRoomType->{RoomType::COL_ADDITIONAL_ORIGIN}) {
            return true;
        } elseif ($roomType->{RoomType::COL_FIRST_HOURS} != $originRoomType->{RoomType::COL_FIRST_HOURS}) {
            return true;
        } elseif ($roomType->{RoomType::COL_FIRST_HOURS_ORIGIN} != $originRoomType->{RoomType::COL_FIRST_HOURS_ORIGIN}) {
            return true;
        } elseif ($roomType->{RoomType::COL_ONE_DAY_ORIGIN} != $originRoomType->{RoomType::COL_ONE_DAY_ORIGIN}) {
            return true;
        } elseif ($roomType->{RoomType::COL_OVERNIGHT_ORIGIN} != $originRoomType->{RoomType::COL_OVERNIGHT_ORIGIN}) {
            return true;
        } elseif ($roomType->{RoomType::COL_PRICE_ADDITIONAL_HOURS} != $originRoomType->{RoomType::COL_PRICE_ADDITIONAL_HOURS}) {
            return true;
        } elseif ($roomType->{RoomType::COL_PRICE_FIRST_HOURS} != $originRoomType->{RoomType::COL_PRICE_FIRST_HOURS}) {
            return true;
        } elseif ($roomType->{RoomType::COL_PRICE_ONE_DAY} != $originRoomType->{RoomType::COL_PRICE_ONE_DAY}) {
            return true;
        } elseif ($roomType->{RoomType::COL_PRICE_OVERNIGHT} != $originRoomType->{RoomType::COL_PRICE_OVERNIGHT}) {
            return true;
        } elseif ($roomType->{RoomType::COL_HAS_GIFT} != $originRoomType->{RoomType::COL_HAS_GIFT}) {
            return true;
        } elseif ($roomType->{RoomType::COL_BONUS_HOUR} != $originRoomType->{RoomType::COL_BONUS_HOUR}) {
            return true;
        }

        return false;
    }

    private function insertRoomTypeHistory($roomTypeSn)
    {
        $roomType = $this->roomTypeRepository->findRoomType($roomTypeSn);
        $roomHistory = RoomTypeHistoryStoreDTO::toRoomTypeHistory($roomType);
        $this->roomTypeHistoryRepository->create($roomHistory->toArray());

    }

    private function _checkChangePriceRoom(UpdateRoomPriceAdjustmentInputDTO $updateRoomPriceAdjustmentInputDTO, $roomPriceAdjustment)
    {
        if ($updateRoomPriceAdjustmentInputDTO->getPriceAdditionalHours() != $roomPriceAdjustment->{RoomType::COL_PRICE_ADDITIONAL_HOURS}) {
            return true;
        } elseif ($updateRoomPriceAdjustmentInputDTO->getPriceFirstHours() != $roomPriceAdjustment->{RoomType::COL_PRICE_FIRST_HOURS}) {
            return true;
        } elseif ($updateRoomPriceAdjustmentInputDTO->getPriceOneDay() != $roomPriceAdjustment->{RoomType::COL_PRICE_ONE_DAY}) {
            return true;
        } elseif ($updateRoomPriceAdjustmentInputDTO->getPriceOvernight() != $roomPriceAdjustment->{RoomType::COL_PRICE_OVERNIGHT}) {
            return true;
        }

        return false;
    }
}