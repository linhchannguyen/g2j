<?php

namespace App\Actions\Promotion\SA;

use App\DTOs\Web\SA\Promotion\ImportsCouponForHotelInputDTO;
use App\DTOs\Web\SA\Promotion\ImportsCouponForHotelOutputDTO;
use App\Helpers\ConvertHelper;
use App\Libraries\Maatwebsite\Excel\Imports\CouponForHotelImport;
use App\Models\CouponForHotel;
use App\Repositories\Interfaces\HotelRepositoryInterface;
use Maatwebsite\Excel\Facades\Excel;

class ImportsCouponForHotel
{
    protected $hotelRepository;

    public function __construct(
        HotelRepositoryInterface $hotelRepository
    )
    {
        $this->hotelRepository = $hotelRepository;
    }

    public function handle(ImportsCouponForHotelInputDTO $importCouponForHotelRequestInputDTO): ImportsCouponForHotelOutputDTO
    {
        $file = $importCouponForHotelRequestInputDTO->getFile();
        $hotelSnList = $importCouponForHotelRequestInputDTO->getHotelSnList();
        $hotels = Excel::toArray(new CouponForHotelImport(), $file)[0];
        $hotelCodeList = [];
        foreach ($hotels as $values) {
            $hotelCodeList[] = $values[1];
        }
        $couponForHotels = [];
        if (!empty($hotelCodeList)) {
            $couponForHotels = $this->hotelRepository->findHotelListAcceptCoupon([], $hotelCodeList);
        }

        $strHotelSnList = $hotelSnList ? trim($hotelSnList, ',') : '';
        if (!str_starts_with($strHotelSnList, '[')) {
            $strHotelSnList = '[' . $strHotelSnList . ']';
        }
        $hotelSnList = ConvertHelper::toArray($strHotelSnList);
        if (count($hotelSnList) > 0) {
            $hotelSnList = array_unique(array_merge($hotelSnList, $couponForHotels));
        } else {
            $hotelSnList = array_unique($couponForHotels);
        }
        $couponForHotels = $this->hotelRepository->findHotelListAcceptCoupon($hotelSnList, []);

        if ($couponForHotels->isEmpty()) {
            return new ImportsCouponForHotelOutputDTO();
        }

        foreach ($couponForHotels as $values) {
            $values->{CouponForHotel::VAR_ROOM_TYPE_LIST} = json_decode($values->{CouponForHotel::VAR_ROOM_TYPE_LIST}, true);
        }

        return ImportsCouponForHotelOutputDTO::assemble($couponForHotels);
    }
}
