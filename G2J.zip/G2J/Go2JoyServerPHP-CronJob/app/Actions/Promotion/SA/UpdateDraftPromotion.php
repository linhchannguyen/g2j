<?php

namespace App\Actions\Promotion\SA;

use App\DTOs\Web\SA\Promotion\InfoDraftPromotionOutputDTO;
use App\DTOs\Web\SA\Promotion\UpdateDraftPromotionInputDTO;
use App\Helpers\UploadHelper;
use App\Models\DraftPromotion;
use App\Models\PromotionGroup;
use App\Repositories\Interfaces\DraftPromotionRepositoryInterface;
use stdClass;

class UpdateDraftPromotion
{
    protected $draftPromotionRepository;

    public function __construct(
        DraftPromotionRepositoryInterface $draftPromotionRepository
    )
    {
        $this->draftPromotionRepository = $draftPromotionRepository;
    }

    public function handle(UpdateDraftPromotionInputDTO $updateDraftPromotionInputDTO): InfoDraftPromotionOutputDTO
    {
        $sn = $updateDraftPromotionInputDTO->getSn();
        $draftSession = $updateDraftPromotionInputDTO->getDraftSession();
        $images = $updateDraftPromotionInputDTO->getImages();
        $updateDraftPromotionInputDTO->setPromotionGroupSn($updateDraftPromotionInputDTO->getPromotionGroupSn());
        if (!empty($images)) {
            $preSignedUrl = new stdClass;
            $extension = pathinfo($images, PATHINFO_EXTENSION);
            $pathName = UploadHelper::getPathFromExtension($extension, UploadHelper::FOLDER['PROMOTION']);
            if (!empty($pathName)) {
                $preSignedUrl = UploadHelper::getPreSigned($pathName);
            }
            $draftSession['session1']['imagePath'] = $pathName;
            $draftSession['session1']['originalName'] = $images;
            $draftSession['session1']['preSignedUrl'] = $preSignedUrl;
        }
        $updateDraftPromotionInputDTO->setDraftSession(json_encode($draftSession));
        $promotionData = $updateDraftPromotionInputDTO->except(['images'])->toArray();
        $this->draftPromotionRepository->update($promotionData, $sn);
        $promotion = $this->draftPromotionRepository->find($sn);
        $promotion->{DraftPromotion::COL_DRAFT_SESSION} = json_decode($promotion->{DraftPromotion::COL_DRAFT_SESSION}, true);
        $promotionGroup = PromotionGroup::where(PromotionGroup::COL_SN, $promotion->{DraftPromotion::COL_PROMOTION_GROUP_SN})->first();
        $promotion->{DraftPromotion::VAR_PROMOTION_GROUP_NAME} = $promotionGroup->{PromotionGroup::COL_TITLE} ?? "";

        return InfoDraftPromotionOutputDTO::assemble($promotion);
    }
}
