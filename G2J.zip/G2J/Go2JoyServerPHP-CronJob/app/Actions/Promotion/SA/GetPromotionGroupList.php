<?php

namespace App\Actions\Promotion\SA;

use App\DTOs\Web\SA\PromotionGroup\GetPromotionGroupListInputDTO;
use App\DTOs\Web\SA\PromotionGroup\GetPromotionGroupListOutputDTO;
use App\Repositories\Interfaces\PromotionGroupRepositoryInterface;
use App\Helpers\ConvertHelper;
use App\Models\DraftPromotion;
use App\Models\Promotion;
use App\Models\PromotionGroup;
use App\Models\Province;

class GetPromotionGroupList
{
    /** @var PromotionGroupRepositoryInterface */
    protected $promotionGroupRepository;

    public function __construct(
        PromotionGroupRepositoryInterface $promotionGroupRepository
    )
    {
        $this->promotionGroupRepository = $promotionGroupRepository;
    }

    public function handle(GetPromotionGroupListInputDTO $getPromotionGroupListInputDTO): GetPromotionGroupListOutputDTO
    {
        $promotionGroupList = $this->promotionGroupRepository->getPromotionGroup(
            $getPromotionGroupListInputDTO->getLimit(),
            $getPromotionGroupListInputDTO->getKeyword()
        );

        if ($promotionGroupList->isEmpty()) {
            return new GetPromotionGroupListOutputDTO();
        }

        foreach ($promotionGroupList as $promotionGroup) {
            $strPromotionSnList = $promotionGroup->{PromotionGroup::COL_PROMOTION_SN_LIST} ? trim($promotionGroup->{PromotionGroup::COL_PROMOTION_SN_LIST}, ',') : '';
            $promotionSnList = [];
            $promotionGroup->{PromotionGroup::VAR_COUPON_STATUS_LIST} = [];
            if (!str_starts_with($strPromotionSnList, '[')) {
                $strPromotionSnList = '[' . $strPromotionSnList . ']';
            }
            $promotionSnList = ConvertHelper::toArray($strPromotionSnList);
            if (!empty($promotionSnList)) {
                $promotionGroup->{PromotionGroup::VAR_COUPON_STATUS_LIST} = Promotion::whereIn(Promotion::COL_SN, $promotionSnList)->pluck(Promotion::COL_STATUS)->toArray();
            }
            $promotionGroup->{PromotionGroup::COL_PROMOTION_SN_LIST} = $promotionSnList;
            $numOfPromotion = count((is_countable($promotionGroup->{PromotionGroup::COL_PROMOTION_SN_LIST}) ? $promotionGroup->{PromotionGroup::COL_PROMOTION_SN_LIST} : []));
            $numOfDraftPromotion = DraftPromotion::where(DraftPromotion::COL_PROMOTION_GROUP_SN, $promotionGroup->{PromotionGroup::COL_SN})->count();
            $promotionGroup->{PromotionGroup::VAR_TOTAL_COUPON_PROMOTION} = $numOfPromotion + $numOfDraftPromotion;
            #Convert to array
            $strProvinceSnList = $promotionGroup->{PromotionGroup::COL_LIST_PROVINCE_SN} ? trim($promotionGroup->{PromotionGroup::COL_LIST_PROVINCE_SN}, ',') : '';
            if (!str_starts_with($strProvinceSnList, '[')) {
                $strProvinceSnList = '[' . $strProvinceSnList . ']';
            }
            $promotionGroup->{PromotionGroup::COL_LIST_PROVINCE_SN} = ConvertHelper::toArray($strProvinceSnList);
            if ($promotionGroup->{PromotionGroup::COL_LIST_PROVINCE_SN}) {
                $promotionGroup->{PromotionGroup::VAR_PROVINCE_NAME_LIST} = Province::whereIn(Province::COL_SN, $promotionGroup->{PromotionGroup::COL_LIST_PROVINCE_SN})->pluck(Province::COL_NAME)->toArray();
            } else {
                $promotionGroup->{PromotionGroup::VAR_PROVINCE_NAME_LIST} = null;
            }
        }
        return GetPromotionGroupListOutputDTO::assemble($promotionGroupList);
    }
}
