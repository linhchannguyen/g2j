<?php

namespace App\Actions\Promotion\SA;

use App\Constants\CouponIssued as CouponIssuedConst;
use App\Constants\CouponForHotel as CouponForHotelConst;
use App\Constants\Globals\Code as CodeConst;
use App\Constants\Hotel as HotelConst;
use App\Constants\Promotion as PromotionConst;
use App\Constants\PromotionGroup as PromotionGroupConst;
use App\Constants\PromotionImage as PromotionImageConst;
use App\Constants\PromotionTimeFrame as PromotionTimeFrameConst;
use App\DTOs\Web\SA\Promotion\ApproveRequestPromotionInputDTO;
use App\DTOs\Web\SA\Promotion\CancelRequestPromotionDTO;
use App\Exceptions\ServiceException;
use App\Helpers\ConvertHelper;
use App\Models\Coupon;
use App\Models\CouponForHotel;
use App\Models\CouponForUserGroup;
use App\Models\CouponIssued;
use App\Models\Hotel;
use App\Models\HotelAcceptPromotion;
use App\Models\IssueCondition;
use App\Models\Promotion;
use App\Models\PromotionGroup;
use App\Models\PromotionImage;
use App\Models\PromotionTimeFrame;
use App\Models\UseCondition;
use App\Repositories\Interfaces\CouponForHotelRepositoryInterface;
use App\Repositories\Interfaces\CouponForUserGroupRepositoryInterface;
use App\Repositories\Interfaces\CouponIssuedRepositoryInterface;
use App\Repositories\Interfaces\CouponRepositoryInterface;
use App\Repositories\Interfaces\HotelAcceptPromotionRepositoryInterface;
use App\Repositories\Interfaces\IssueConditionRepositoryInterface;
use App\Repositories\Interfaces\PromotionGroupRepositoryInterface;
use App\Repositories\Interfaces\PromotionImageRepositoryInterface;
use App\Repositories\Interfaces\PromotionRepositoryInterface;
use App\Repositories\Interfaces\UseConditionRepositoryInterface;
use Carbon\Carbon;

class ApproveRequestPromotion
{
    const FILE_LANGUAGE_NAME = 'sa/promotion';

    protected $promotionRepository;

    protected $promotionGroupRepository;

    protected $promotionImageRepository;

    protected $useConditionRepository;

    protected $couponForUserGroupRepository;

    protected $issueConditionRepository;

    protected $couponRepository;

    protected $couponForHotelRepository;

    protected $hotelAcceptPromotionRepository;

    protected $couponIssuedRepository;

    public function __construct(
        PromotionGroupRepositoryInterface       $promotionGroupRepository,
        PromotionRepositoryInterface            $promotionRepository,
        PromotionImageRepositoryInterface       $promotionImageRepository,
        UseConditionRepositoryInterface         $useConditionRepository,
        CouponForUserGroupRepositoryInterface   $couponForUserGroupRepository,
        IssueConditionRepositoryInterface       $issueConditionRepository,
        CouponRepositoryInterface               $couponRepository,
        CouponForHotelRepositoryInterface       $couponForHotelRepository,
        HotelAcceptPromotionRepositoryInterface $hotelAcceptPromotionRepository,
        CouponIssuedRepositoryInterface         $couponIssuedRepository
    )
    {
        $this->promotionGroupRepository = $promotionGroupRepository;
        $this->promotionRepository = $promotionRepository;
        $this->promotionImageRepository = $promotionImageRepository;
        $this->useConditionRepository = $useConditionRepository;
        $this->couponForUserGroupRepository = $couponForUserGroupRepository;
        $this->issueConditionRepository = $issueConditionRepository;
        $this->couponRepository = $couponRepository;
        $this->couponForHotelRepository = $couponForHotelRepository;
        $this->hotelAcceptPromotionRepository = $hotelAcceptPromotionRepository;
        $this->couponIssuedRepository = $couponIssuedRepository;
    }

    public function handle(ApproveRequestPromotionInputDTO $approveRequestPromotionInputDTO): void
    {
        $clonePromotionSn = $approveRequestPromotionInputDTO->getClonePromotionSn();
        $sourcePromotionSn = $approveRequestPromotionInputDTO->getSourcePromotionSn();
        $clonePromotion = $this->promotionRepository->find($clonePromotionSn);

        $listPromotionGroupSn = $clonePromotion->{Promotion::COL_LIST_PROMOTION_GROUP_SN};
        $this->_updatePromotionIntoGroupPromotion($listPromotionGroupSn, $sourcePromotionSn);
        $promotionData = [
            Promotion::COL_STATUS => $clonePromotion->{Promotion::COL_STATUS},
            Promotion::COL_TITLE => $clonePromotion->{Promotion::COL_TITLE},
            Promotion::COL_TITLE_EN => $clonePromotion->{Promotion::COL_TITLE_EN},
            Promotion::COL_CONTENT => $clonePromotion->{Promotion::COL_CONTENT},
            Promotion::COL_CONTENT_EN => $clonePromotion->{Promotion::COL_CONTENT_EN},
            Promotion::COL_NUM_OF_COUPON => $clonePromotion->{Promotion::COL_NUM_OF_COUPON},
            Promotion::COL_APPLY_START => $clonePromotion->{Promotion::COL_APPLY_START},
            Promotion::COL_APPLY_END => $clonePromotion->{Promotion::COL_APPLY_END},
            Promotion::COL_GO2JOY_DISCOUNT => $clonePromotion->{Promotion::COL_GO2JOY_DISCOUNT},
            Promotion::COL_HOTEL_DISCOUNT => $clonePromotion->{Promotion::COL_HOTEL_DISCOUNT},
            Promotion::COL_UPDATE_STAFF_SN => $clonePromotion->{Promotion::COL_UPDATE_STAFF_SN},
        ];
        $this->promotionRepository->update($promotionData, $sourcePromotionSn);
        // End update promotion

        // Update promotion image
        $promotionImage = $this->promotionImageRepository->findWhere([
            PromotionImage::COL_PROMOTION_SN => $clonePromotionSn,
            PromotionImage::COL_TYPE_DISPLAY => PromotionImageConst::TYPE['DETAIL']
        ])->first();
        if (!empty($promotionImage)) {
            PromotionImage::updateOrCreate([
                PromotionImage::COL_PROMOTION_SN => $sourcePromotionSn,
                PromotionImage::COL_TYPE_DISPLAY => PromotionImageConst::TYPE['DETAIL']
            ], [
                PromotionImage::COL_IMAGE_PATH => $promotionImage->{PromotionImage::COL_IMAGE_PATH},
                PromotionImage::COL_ORIGINAL_NAME => $promotionImage->{PromotionImage::COL_ORIGINAL_NAME}
            ]);
        }
        // End update promotion image

        // Update promotion time frame
        $promotionTimeFrame = PromotionTimeFrame::where(PromotionTimeFrame::COL_PROMOTION_SN, $clonePromotionSn)->first();
        if (!empty($promotionTimeFrame)) {
            PromotionTimeFrame::updateOrCreate([
                PromotionTimeFrame::COL_PROMOTION_SN => $sourcePromotionSn
            ], [
                PromotionTimeFrame::COL_START_TIME => $promotionTimeFrame->{PromotionTimeFrame::COL_START_TIME},
                PromotionTimeFrame::COL_END_TIME => $promotionTimeFrame->{PromotionTimeFrame::COL_END_TIME},
                PromotionTimeFrame::COL_IS_APPLY => $promotionTimeFrame->{PromotionTimeFrame::COL_IS_APPLY},
            ]);
        } else {
            PromotionTimeFrame::where(PromotionTimeFrame::COL_PROMOTION_SN, $sourcePromotionSn)
                ->update([
                    PromotionTimeFrame::COL_IS_APPLY => PromotionTimeFrameConst::IS_APPLY['FALSE'],
                ]);
        }
        // End update promotion time frame

        // Update coupon
        $coupon = $this->couponRepository->findByField(Coupon::COL_PROMOTION_SN, $clonePromotionSn)->first();
        $oldCoupon = $this->couponRepository->findByField(Coupon::COL_PROMOTION_SN, $sourcePromotionSn)->first();
        if (empty($coupon) || empty($oldCoupon)) {
            throw new ServiceException(ConvertHelper::getMessage(self::FILE_LANGUAGE_NAME, CodeConst::API_PRN_022), CodeConst::API_PRN_022);
        }
        $cloneCouponSn = $coupon->{Coupon::COL_SN};
        $sourceCouponSn = $oldCoupon->{Coupon::COL_SN};
        $couponData = [
            Coupon::COL_TITLE => $coupon->{Coupon::COL_TITLE},
            Coupon::COL_CODE => mb_substr($coupon->{Coupon::COL_CODE}, 1),
            Coupon::COL_START_DATE => $coupon->{Coupon::COL_START_DATE},
            Coupon::COL_END_DATE => $coupon->{Coupon::COL_END_DATE},
            Coupon::COL_NUM_ACTIVE_DAY => $coupon->{Coupon::COL_NUM_ACTIVE_DAY},
            Coupon::COL_DISCOUNT => $coupon->{Coupon::COL_DISCOUNT},
            Coupon::COL_MAX_NUM => $coupon->{Coupon::COL_MAX_NUM},
            Coupon::COL_MAX_DISCOUNT => $coupon->{Coupon::COL_MAX_DISCOUNT},
            Coupon::COL_DIRECT_DISCOUNT => $coupon->{Coupon::COL_DIRECT_DISCOUNT},
            Coupon::COL_GIFT_NAME => $coupon->{Coupon::COL_GIFT_NAME},
            Coupon::COL_NUM_GIVE_HOURS => $coupon->{Coupon::COL_NUM_GIVE_HOURS}
        ];
        $this->couponRepository->update($couponData, $sourceCouponSn);
        // End update coupon

        // Update use condition
        $useCondition = $this->useConditionRepository->findByField(UseCondition::COL_COUPON_SN, $cloneCouponSn)->first();
        if (empty($useCondition)) {
            throw new ServiceException(ConvertHelper::getMessage(self::FILE_LANGUAGE_NAME, CodeConst::API_PRN_022), CodeConst::API_PRN_022);
        }
        $useConditionData = [
            UseCondition::COL_APPLY_TARGET => $useCondition->{UseCondition::COL_APPLY_TARGET},
            UseCondition::COL_HOURLY => $useCondition->{UseCondition::COL_HOURLY},
            UseCondition::COL_NUM_HOURS_CONDITION => $useCondition->{UseCondition::COL_NUM_HOURS_CONDITION},
            UseCondition::COL_NUM_HOURS => $useCondition->{UseCondition::COL_NUM_HOURS},
            UseCondition::COL_START_TIME => $useCondition->{UseCondition::COL_START_TIME},
            UseCondition::COL_END_TIME => $useCondition->{UseCondition::COL_END_TIME},
            UseCondition::COL_DAILY => $useCondition->{UseCondition::COL_DAILY},
            UseCondition::COL_NUM_DAYS_CONDITION => $useCondition->{UseCondition::COL_NUM_DAYS_CONDITION},
            UseCondition::COL_NUM_DAYS => $useCondition->{UseCondition::COL_NUM_DAYS},
            UseCondition::COL_OVERNIGHT => $useCondition->{UseCondition::COL_OVERNIGHT},
            UseCondition::COL_SUNDAY => $useCondition->{UseCondition::COL_SUNDAY},
            UseCondition::COL_MONDAY => $useCondition->{UseCondition::COL_MONDAY},
            UseCondition::COL_TUESDAY => $useCondition->{UseCondition::COL_TUESDAY},
            UseCondition::COL_WEDNESDAY => $useCondition->{UseCondition::COL_WEDNESDAY},
            UseCondition::COL_THURSDAY => $useCondition->{UseCondition::COL_THURSDAY},
            UseCondition::COL_FRIDAY => $useCondition->{UseCondition::COL_FRIDAY},
            UseCondition::COL_SATURDAY => $useCondition->{UseCondition::COL_SATURDAY},
            UseCondition::COL_PAYMENT_METHOD => $useCondition->{UseCondition::COL_PAYMENT_METHOD},
            UseCondition::COL_MIN_MONEY => $useCondition->{UseCondition::COL_MIN_MONEY},
            UseCondition::COL_NUM_COUPON_LIMIT => $useCondition->{UseCondition::COL_NUM_COUPON_LIMIT},
            UseCondition::COL_MAX_ONE_DAY => $useCondition->{UseCondition::COL_MAX_ONE_DAY},
            UseCondition::COL_MAX_ONE_HOTEL => $useCondition->{UseCondition::COL_MAX_ONE_HOTEL},
            UseCondition::COL_HOTEL_ACCEPT => $useCondition->{UseCondition::COL_HOTEL_ACCEPT}
        ];
        $this->useConditionRepository->updateWhere(
            $useConditionData,
            [UseCondition::COL_COUPON_SN => $sourceCouponSn]
        );
        // End update use condition

        $type = $clonePromotion->{Promotion::COL_TYPE};
        if ($type == PromotionConst::TYPE['APPLY']) { // Update coupon for user group
            $couponForUserGroup = $this->couponForUserGroupRepository->findByField(CouponForUserGroup::COL_COUPON_SN, $cloneCouponSn)->first();
            if (empty($couponForUserGroup)) {
                throw new ServiceException(ConvertHelper::getMessage(self::FILE_LANGUAGE_NAME, CodeConst::API_PRN_022), CodeConst::API_PRN_022);
            }
            $couponForUserGroupData = [
                CouponForUserGroup::COL_TYPE => $couponForUserGroup->{CouponForUserGroup::COL_TYPE},
                CouponForUserGroup::COL_TYPE_DETAIL => $couponForUserGroup->{CouponForUserGroup::COL_TYPE_DETAIL},
                CouponForUserGroup::COL_NUM_CHECK_IN => $couponForUserGroup->{CouponForUserGroup::COL_NUM_CHECK_IN},
                CouponForUserGroup::COL_START_DATE => $couponForUserGroup->{CouponForUserGroup::COL_START_DATE},
                CouponForUserGroup::COL_END_DATE => $couponForUserGroup->{CouponForUserGroup::COL_END_DATE},
                CouponForUserGroup::COL_UPDATE_STAFF_SN => $couponForUserGroup->{CouponForUserGroup::COL_UPDATE_STAFF_SN},
                CouponForUserGroup::COL_PROVINCE_SN_LIST => $couponForUserGroup->{CouponForUserGroup::COL_PROVINCE_SN_LIST}
            ];
            $this->couponForUserGroupRepository->updateWhere(
                $couponForUserGroupData,
                [CouponForUserGroup::COL_COUPON_SN => $sourceCouponSn]
            );
        } else if ($type == PromotionConst::TYPE['VOUCHER_CODE']) { // Update voucher condition
        } else {
            $issueCondition = $this->issueConditionRepository->findByField(IssueCondition::COL_COUPON_SN, $cloneCouponSn)->first();
            if (empty($issueCondition)) {
                throw new ServiceException(ConvertHelper::getMessage(self::FILE_LANGUAGE_NAME, CodeConst::API_PRN_022), CodeConst::API_PRN_022);
            }
            $issueConditionData = [
                IssueCondition::COL_APPLY_TARGET => $issueCondition->{IssueCondition::COL_APPLY_TARGET},
                IssueCondition::COL_HOURLY => $issueCondition->{IssueCondition::COL_HOURLY},
                IssueCondition::COL_HOURLY_START_TIME => $issueCondition->{IssueCondition::COL_HOURLY_START_TIME},
                IssueCondition::COL_HOURLY_END_TIME => $issueCondition->{IssueCondition::COL_HOURLY_END_TIME},
                IssueCondition::COL_OVERNIGHT => $issueCondition->{IssueCondition::COL_OVERNIGHT},
                IssueCondition::COL_DAILY => $issueCondition->{IssueCondition::COL_DAILY},
                IssueCondition::COL_PAY_IN_ADVANCE => $issueCondition->{IssueCondition::COL_PAY_IN_ADVANCE},
                IssueCondition::COL_SUNDAY => $issueCondition->{IssueCondition::COL_SUNDAY},
                IssueCondition::COL_MONDAY => $issueCondition->{IssueCondition::COL_MONDAY},
                IssueCondition::COL_TUESDAY => $issueCondition->{IssueCondition::COL_TUESDAY},
                IssueCondition::COL_WEDNESDAY => $issueCondition->{IssueCondition::COL_WEDNESDAY},
                IssueCondition::COL_THURSDAY => $issueCondition->{IssueCondition::COL_THURSDAY},
                IssueCondition::COL_FRIDAY => $issueCondition->{IssueCondition::COL_FRIDAY},
                IssueCondition::COL_SATURDAY => $issueCondition->{IssueCondition::COL_SATURDAY},
                IssueCondition::COL_START_TIME => $issueCondition->{IssueCondition::COL_START_TIME},
                IssueCondition::COL_END_TIME => $issueCondition->{IssueCondition::COL_END_TIME},
                IssueCondition::COL_COUPON => $issueCondition->{IssueCondition::COL_COUPON},
                IssueCondition::COL_APPLY_TO_USER => $issueCondition->{IssueCondition::COL_APPLY_TO_USER},
                IssueCondition::COL_NUM_CHECKIN => $issueCondition->{IssueCondition::COL_NUM_CHECKIN}
            ];
            $this->issueConditionRepository->updateWhere(
                $issueConditionData,
                [IssueCondition::COL_COUPON_SN => $sourceCouponSn]
            );
        }
        $couponForHotel = $this->couponForHotelRepository->findByField(
            CouponForHotel::COL_COUPON_SN,
            $cloneCouponSn,
            [
                CouponForHotel::COL_HOTEL_SN,
                CouponForHotel::COL_TYPE,
                CouponForHotel::COL_ROOM_TYPE_SN_LIST
            ]
        );
        $insertDataList = [];
        foreach ($couponForHotel as $values) {
            array_push($insertDataList, [
                CouponForHotel::COL_COUPON_SN => $sourceCouponSn,
                CouponForHotel::COL_HOTEL_SN => $values->{CouponForHotel::COL_HOTEL_SN},
                CouponForHotel::COL_TYPE => $values->{CouponForHotel::COL_TYPE},
                CouponForHotel::COL_ROOM_TYPE_SN_LIST => $values->{CouponForHotel::COL_ROOM_TYPE_SN_LIST}
            ]);
        }
        CouponForHotel::where(CouponForHotel::COL_COUPON_SN, $sourceCouponSn)->delete();
        if (!empty($insertDataList)) {
            $this->couponForHotelRepository->batchInsert($insertDataList);
        }
        $this->_updateHotelAcceptPromotion($sourcePromotionSn, $cloneCouponSn, $useCondition->{UseCondition::COL_APPLY_TARGET});
        $this->_updateCouponIssued($clonePromotion, $coupon, $sourceCouponSn);
        $cancelRequestPromotionDTO = CancelRequestPromotionDTO::fromParameter($clonePromotionSn);
        $cancelRequestPromotion = app(CancelRequestPromotion::class);
        $cancelRequestPromotion->handle($cancelRequestPromotionDTO);
    }

    private function _updatePromotionIntoGroupPromotion($listPromotionGroupSn, $oldPromotionSn): void
    {
        $oldPromotion = Promotion::where([Promotion::COL_SN => $oldPromotionSn])->get([Promotion::COL_LIST_PROMOTION_GROUP_SN])->first();

        $strPromotionGroupSnList = $oldPromotion->{Promotion::COL_LIST_PROMOTION_GROUP_SN} ? trim($oldPromotion->{Promotion::COL_LIST_PROMOTION_GROUP_SN}, ',') : '';
        if (!str_starts_with($strPromotionGroupSnList, '[')) {
            $strPromotionGroupSnList = '[' . $strPromotionGroupSnList . ']';
        }
        $promotionGroupList = ConvertHelper::toArray($strPromotionGroupSnList);
        if (empty($promotionGroupList)) {
            $promotionGroupList = [];
        }
        $promotionGroupList[] = $listPromotionGroupSn;
        $promotionGroupList = array_values(array_unique($promotionGroupList));
        if (!empty($promotionGroupList)) {
            $promotionGroups = PromotionGroup::whereIn(PromotionGroup::COL_SN, $promotionGroupList)->get([
                PromotionGroup::COL_SN,
                PromotionGroup::COL_PROMOTION_SN_LIST
            ]);
            foreach ($promotionGroups as $values) {
                $strPromotionSnList = $values->{PromotionGroup::COL_PROMOTION_SN_LIST} ? trim($values->{PromotionGroup::COL_PROMOTION_SN_LIST}, ',') : '';
                if (!str_starts_with($strPromotionSnList, '[')) {
                    $strPromotionSnList = '[' . $strPromotionSnList . ']';
                }
                $promotionList = ConvertHelper::toArray($strPromotionSnList);
                if (empty($promotionList)) {
                    $promotionList = [];
                }
                if ($values->{PromotionGroup::COL_SN} != $listPromotionGroupSn) {
                    $promotionList = array_values(array_diff($promotionList, [$oldPromotionSn]));
                } else {
                    $promotionList[] = $oldPromotionSn;
                    $promotionList = array_values(array_unique($promotionList));
                }
                if (!empty($promotionList)) {
                    $strPromotionList = ConvertHelper::toJson($promotionList);
                    $this->promotionGroupRepository->update([PromotionGroup::COL_PROMOTION_SN_LIST => $strPromotionList], $values->{PromotionGroup::COL_SN});
                    $countPromotionExpired = $this->promotionRepository->countPromotionExpired($promotionList);
                    if ($countPromotionExpired == 0) {
                        $this->promotionGroupRepository->disablePromotionGroup($values->{PromotionGroup::COL_SN});
                    }
                }
            }
        }
        Promotion::where([Promotion::COL_SN => $oldPromotionSn])->update([
            Promotion::COL_LIST_PROMOTION_GROUP_SN => $listPromotionGroupSn
        ]);
    }

    private function _updateCouponIssued($promotion, $coupon, $sourceCouponSn): void
    {
        $couponIssued = CouponIssued::where(CouponIssued::COL_COUPON_SN, $sourceCouponSn)
            ->whereNotIn(CouponIssued::COL_USED, [CouponIssuedConst::USED['USED']])
            ->first();
        if (!empty($couponIssued) && $promotion->{Promotion::COL_TYPE} == PromotionConst::TYPE['APPLY']) {
            $isUpadte = false;
            if ($coupon->{Coupon::COL_NUM_ACTIVE_DAY} > 0) {
                if (!empty($promotion->{Promotion::COL_APPLY_START})) {
                    $startDate = Carbon::parse($promotion->{Promotion::COL_APPLY_START})->startOfDay();
                    $endDate = Carbon::parse($promotion->{Promotion::COL_APPLY_START})->addDays($coupon->{Coupon::COL_NUM_ACTIVE_DAY})->endOfDay();
                    $now = Carbon::now()->endOfDay();
                    if ($endDate->timestamp < $now->timestamp) {
                        $couponIssuedUpdate[CouponIssued::COL_USED] = CouponIssuedConst::USED['EXPIRED'];
                    }
                    $couponIssuedUpdate[CouponIssued::COL_START_DATE] = $startDate;
                    $couponIssuedUpdate[CouponIssued::COL_END_DATE] = $endDate;
                    $isUpadte = true;
                }
            } else {
                if (!empty($coupon->{Coupon::COL_START_DATE}) && !empty($coupon->{Coupon::COL_END_DATE})) {
                    $now = Carbon::now()->endOfDay();
                    $startDate = Carbon::parse($coupon->{Coupon::COL_START_DATE})->startOfDay();
                    $endDate = Carbon::parse($coupon->{Coupon::COL_END_DATE})->endOfDay();
                    if ($endDate->timestamp < $now->timestamp) {
                        $couponIssuedUpdate[CouponIssued::COL_USED] = CouponIssuedConst::USED['EXPIRED'];
                    }
                    $couponIssuedUpdate[CouponIssued::COL_START_DATE] = $startDate;
                    $couponIssuedUpdate[CouponIssued::COL_END_DATE] = $endDate;
                    $isUpadte = true;
                }
            }
            if ($isUpadte) {
                CouponIssued::where(CouponIssued::COL_COUPON_SN, $sourceCouponSn)
                    ->whereNotIn(CouponIssued::COL_USED, [CouponIssuedConst::USED['USED']])
                    ->update($couponIssuedUpdate);
            }
        }
    }

    private function _updateHotelAcceptPromotion(int $sourcePromotionSn, int $cloneCouponSn, int $applyTarget): void
    {
        $hotelSn = CouponForHotel::where(CouponForHotel::COL_COUPON_SN, $cloneCouponSn)
            ->where(CouponForHotel::COL_TYPE, CouponForHotelConst::TYPE['USE'])
            ->pluck(CouponForHotel::COL_HOTEL_SN)
            ->toArray();
        $promotion = Promotion::where(Promotion::COL_SN, $sourcePromotionSn)->first([Promotion::COL_HOTEL_DISCOUNT]);
        $hotelDiscount = intval($promotion->{Promotion::COL_HOTEL_DISCOUNT} ?? 0);
        if (!empty($hotelSn)) {
            $hotelAcceptProList = [];
            if ($applyTarget == CouponForHotelConst::APPLY_TARGET['ALL_BUT_EXCLUDE']) {
                if ($hotelDiscount == 0) {
                    $hotelAcceptList = Hotel::where(Hotel::COL_HOTEL_STATUS, HotelConst::STATUS['CONTRACTED'])
                        ->where(Hotel::COL_ORIGIN, HotelConst::ORIGIN['GO2JOY'])
                        ->whereNotIn(Hotel::COL_SN, $hotelSn)
                        ->get([Hotel::COL_SN])
                        ->pluck(Hotel::COL_SN)
                        ->all();
                    HotelAcceptPromotion::where(HotelAcceptPromotion::COL_PROMOTION_SN, $sourcePromotionSn)->delete();
                    foreach ($hotelAcceptList as $value) {
                        $hotelAcceptPro = new HotelAcceptPromotion();
                        $hotelAcceptPro->{HotelAcceptPromotion::COL_PROMOTION_SN} = $sourcePromotionSn;
                        $hotelAcceptPro->{HotelAcceptPromotion::COL_HOTEL_SN} = $value;
                        $hotelAcceptProList[] = $hotelAcceptPro->toArray();
                    }
                    $this->hotelAcceptPromotionRepository->batchInsert($hotelAcceptProList);
                } else {
                    HotelAcceptPromotion::where(HotelAcceptPromotion::COL_PROMOTION_SN, $sourcePromotionSn)
                        ->whereIn(HotelAcceptPromotion::COL_HOTEL_SN, $hotelSn)
                        ->delete();
                }
            } elseif ($applyTarget == CouponForHotelConst::APPLY_TARGET['JUST_APPLY']) {
                if ($hotelDiscount == 0) {
                    HotelAcceptPromotion::where(HotelAcceptPromotion::COL_PROMOTION_SN, $sourcePromotionSn)->delete();
                    foreach ($hotelSn as $value) {
                        $hotelAcceptPro = new HotelAcceptPromotion();
                        $hotelAcceptPro->{HotelAcceptPromotion::COL_PROMOTION_SN} = $sourcePromotionSn;
                        $hotelAcceptPro->{HotelAcceptPromotion::COL_HOTEL_SN} = $value;
                        $hotelAcceptProList[] = $hotelAcceptPro->toArray();
                    }
                    $this->hotelAcceptPromotionRepository->batchInsert($hotelAcceptProList);
                } else {
                    HotelAcceptPromotion::where(HotelAcceptPromotion::COL_PROMOTION_SN, $sourcePromotionSn)
                        ->whereNotIn(HotelAcceptPromotion::COL_HOTEL_SN, $hotelSn)
                        ->delete();
                }
            }
        }
    }
}
