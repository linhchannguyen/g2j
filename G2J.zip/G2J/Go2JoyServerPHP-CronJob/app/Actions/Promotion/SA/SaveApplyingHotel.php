<?php

namespace App\Actions\Promotion\SA;

use App\Constants\Globals\Code as CodeConst;
use App\Constants\Globals\Pagination as PaginationConst;
use App\Constants\CouponForHotel as CouponForHotelConst;
use App\Constants\Hotel as HotelConst;
use App\Constants\UseCondition as UseConditionConst;
use App\DTOs\Web\SA\Promotion\SaveApplyingHotelDTO;
use App\Exceptions\ServiceException;
use App\Helpers\ConvertHelper;
use App\Models\Coupon;
use App\Models\CouponForHotel;
use App\Models\Hotel;
use App\Models\HotelAcceptPromotion;
use App\Models\Promotion;
use App\Models\UseCondition;
use App\Repositories\Interfaces\CouponForHotelRepositoryInterface;
use App\Repositories\Interfaces\HotelAcceptPromotionRepositoryInterface;
use App\Repositories\Interfaces\HotelRepositoryInterface;
use App\Repositories\Interfaces\UseConditionRepositoryInterface;

class SaveApplyingHotel
{
    const FILE_LANGUAGE_PROMOTION = 'sa/promotion';
    const FILE_LANGUAGE_HOTEL = 'sa/hotel';

    protected $useConditionRepository;

    protected $couponForHotelRepository;

    protected $hotelRepository;

    protected $hotelAcceptPromotionRepository;

    public function __construct(
        UseConditionRepositoryInterface         $useConditionRepository,
        CouponForHotelRepositoryInterface       $couponForHotelRepository,
        HotelRepositoryInterface                $hotelRepository,
        HotelAcceptPromotionRepositoryInterface $hotelAcceptPromotionRepository
    )
    {
        $this->useConditionRepository = $useConditionRepository;
        $this->couponForHotelRepository = $couponForHotelRepository;
        $this->hotelRepository = $hotelRepository;
        $this->hotelAcceptPromotionRepository = $hotelAcceptPromotionRepository;
    }

    public function handle(SaveApplyingHotelDTO $saveApplyingHotelDTO): void
    {
        $applyTarget = $saveApplyingHotelDTO->getApplyTarget();
        $type = $saveApplyingHotelDTO->getType();
        $couponSn = $saveApplyingHotelDTO->getCouponSn();
        $hotelSnList = $saveApplyingHotelDTO->getHotelSnList();
        $roomTypeList = $saveApplyingHotelDTO->getRoomTypeList();
        $this->couponForHotelRepository->deleteAllCouponForHotel($couponSn, $type);
        if ($applyTarget != UseConditionConst::APPLY_TARGET['ALL']) {
            $insertDataList = [];
            if ($applyTarget == UseConditionConst::APPLY_TARGET['ALL_BUT_EXCLUDE']) {
                foreach ($hotelSnList as $sn) {
                    $cfh = new CouponForHotel();
                    $cfh->{CouponForHotel::COL_TYPE} = $type;
                    $cfh->{CouponForHotel::COL_COUPON_SN} = $couponSn;
                    $cfh->{CouponForHotel::COL_HOTEL_SN} = $sn;
                    array_push($insertDataList, $cfh->toArray());
                }
            } else {
                foreach ($hotelSnList as $sn) {
                    $cfh = new CouponForHotel();
                    $cfh->{CouponForHotel::COL_TYPE} = $type;
                    $cfh->{CouponForHotel::COL_COUPON_SN} = $couponSn;
                    $cfh->{CouponForHotel::COL_HOTEL_SN} = $sn;
                    if (isset($roomTypeList[$sn])) {
                        $strRoomTypeSnList = $roomTypeList[$sn] ? trim($roomTypeList[$sn], ',') : '';
                        if (!str_starts_with($strRoomTypeSnList, '[')) {
                            $strRoomTypeSnList = '[' . $strRoomTypeSnList . ']';
                        }
                        $roomTypeSnList = ConvertHelper::toArray($strRoomTypeSnList);
                        $cfh->{CouponForHotel::COL_ROOM_TYPE_SN_LIST} = ConvertHelper::toJson($roomTypeSnList);
                    } else {
                        throw new ServiceException(ConvertHelper::getMessage(self::FILE_LANGUAGE_PROMOTION, CodeConst::API_PRN_022), CodeConst::API_PRN_022);
                    }
                    array_push($insertDataList, $cfh->toArray());
                }
            }
            if (!empty($insertDataList)) {
                $this->couponForHotelRepository->batchInsert($insertDataList);
            } else {
                throw new ServiceException(ConvertHelper::getMessage(self::FILE_LANGUAGE_HOTEL, CodeConst::API_HTL_001), CodeConst::API_HTL_001);
            }
        } else {
            $hotelSnList = $this->hotelRepository->findShortHotelList(null, null, null, null, PaginationConst::LIMIT['NO_LIMIT'])->pluck(Hotel::COL_SN)->all();
        }
        if (intval($type) == CouponForHotelConst::TYPE['USE']) {
            $hotelAcceptList = ConvertHelper::toArray($hotelSnList);
            if (CouponForHotelConst::APPLY_TARGET['ALL'] == $applyTarget) {
                $hotelAcceptList = Hotel::where(Hotel::COL_HOTEL_STATUS, HotelConst::STATUS['CONTRACTED'])
                    ->where(Hotel::COL_ORIGIN, HotelConst::ORIGIN['GO2JOY'])
                    ->get([Hotel::COL_SN])
                    ->pluck(Hotel::COL_SN)
                    ->all();
            } else if (CouponForHotelConst::APPLY_TARGET['ALL_BUT_EXCLUDE'] == $applyTarget) {
                $hotelAcceptList = Hotel::where(Hotel::COL_HOTEL_STATUS, HotelConst::STATUS['CONTRACTED'])
                    ->where(Hotel::COL_ORIGIN, HotelConst::ORIGIN['GO2JOY'])
                    ->whereNotIn(Hotel::COL_SN, $hotelSnList)
                    ->get([Hotel::COL_SN])
                    ->pluck(Hotel::COL_SN)
                    ->all();
            }
            $useCondition = $this->useConditionRepository->findByField(UseCondition::COL_COUPON_SN, $couponSn)->first();
            $useCondition->{UseCondition::COL_APPLY_TARGET} = $applyTarget;
            $useCondition->{UseCondition::COL_HOTEL_ACCEPT} = ConvertHelper::toJson($hotelAcceptList);
            $this->useConditionRepository->update($useCondition->toArray(), $useCondition->{UseCondition::COL_SN});
            $this->_updateHotelAcceptPromotion($applyTarget, $hotelSnList, $couponSn, $hotelAcceptList);
        }
    }

    private function _updateHotelAcceptPromotion(int $applyTarget, $hotelSnList, int $couponSn, $hotelAcceptList): void
    {
        $coupon = Coupon::where(Coupon::COL_SN, $couponSn)->first([Coupon::COL_PROMOTION_SN]);
        if (!empty($coupon)) {
            $promotion = Promotion::where(Promotion::COL_SN, $coupon->{Coupon::COL_PROMOTION_SN})->first();
            if (!empty($promotion) && $promotion->{Promotion::COL_HOTEL_DISCOUNT} == 0) {
                $promotionSn = $promotion->{Promotion::COL_SN};
                $hotelAcceptProList = [];
                if ($applyTarget == CouponForHotelConst::APPLY_TARGET['ALL']) {
                    $hotelAcceptProList = [];
                } elseif ($applyTarget == CouponForHotelConst::APPLY_TARGET['ALL_BUT_EXCLUDE']) {
                    // Get the list of existing hotel accept promotions for the given hotels and promotion
                    $existingHotels = HotelAcceptPromotion::where(HotelAcceptPromotion::COL_PROMOTION_SN, $promotionSn)
                        ->whereIn(HotelAcceptPromotion::COL_HOTEL_SN, $hotelAcceptList)
                        ->pluck(HotelAcceptPromotion::COL_HOTEL_SN)
                        ->toArray();

                    // Find the list of hotels that don't already have a promotion
                    $newHotels = array_diff($hotelAcceptList, $existingHotels);

                    // Update new HotelAcceptPromotion models for the new hotels
                    foreach ($newHotels as $hotelSn) {
                        $hotelAcceptPro = new HotelAcceptPromotion();
                        $hotelAcceptPro->{HotelAcceptPromotion::COL_PROMOTION_SN} = $promotionSn;
                        $hotelAcceptPro->{HotelAcceptPromotion::COL_HOTEL_SN} = $hotelSn;
                        $hotelAcceptProList[] = $hotelAcceptPro->toArray();
                    }
                    HotelAcceptPromotion::where(HotelAcceptPromotion::COL_PROMOTION_SN, $promotionSn)
                        ->whereIn(HotelAcceptPromotion::COL_HOTEL_SN, $hotelSnList)
                        ->delete();
                } else {
                    // Get the list of existing hotel accept promotions for the given hotels and promotion
                    $existingHotels = HotelAcceptPromotion::where(HotelAcceptPromotion::COL_PROMOTION_SN, $promotionSn)
                        ->whereIn(HotelAcceptPromotion::COL_HOTEL_SN, $hotelAcceptList)
                        ->pluck(HotelAcceptPromotion::COL_HOTEL_SN)
                        ->toArray();

                    // Find the list of hotels that don't already have a promotion
                    $newHotels = array_diff($hotelAcceptList, $existingHotels);

                    // Update new HotelAcceptPromotion models for the new hotels
                    foreach ($newHotels as $hotelSn) {
                        $hotelAcceptPro = new HotelAcceptPromotion();
                        $hotelAcceptPro->{HotelAcceptPromotion::COL_PROMOTION_SN} = $promotionSn;
                        $hotelAcceptPro->{HotelAcceptPromotion::COL_HOTEL_SN} = $hotelSn;
                        $hotelAcceptProList[] = $hotelAcceptPro->toArray();
                    }
                    HotelAcceptPromotion::where(HotelAcceptPromotion::COL_PROMOTION_SN, $promotionSn)
                        ->whereNotIn(HotelAcceptPromotion::COL_HOTEL_SN, $hotelSnList)
                        ->delete();
                }
                if (count($hotelAcceptProList) > 0) {
                    $this->hotelAcceptPromotionRepository->batchInsert($hotelAcceptProList);
                }
            }
        }
    }
}
