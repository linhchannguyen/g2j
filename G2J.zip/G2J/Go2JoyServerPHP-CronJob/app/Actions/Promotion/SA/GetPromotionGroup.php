<?php

namespace App\Actions\Promotion\SA;

use App\DTOs\Web\SA\PromotionGroup\GetPromotionGroupInputDTO;
use App\DTOs\Web\SA\PromotionGroup\GetPromotionGroupOutputDTO;
use App\Helpers\ConvertHelper;
use App\Models\PromotionGroup;
use App\Models\Province;
use App\Repositories\Interfaces\PromotionGroupRepositoryInterface;

class GetPromotionGroup
{
    protected $promotionGroupRepository;

    protected $draftPromotionGroupRepository;

    public function __construct(
        PromotionGroupRepositoryInterface $promotionGroupRepository
    )
    {
        $this->promotionGroupRepository = $promotionGroupRepository;
    }

    public function handle(GetPromotionGroupInputDTO $getPromotionListInputDTO): GetPromotionGroupOutputDTO
    {
        $promotionGroup = $this->promotionGroupRepository->find($getPromotionListInputDTO->getPromotionGroupSn());

        $strPromotionList = $promotionGroup->{PromotionGroup::COL_PROMOTION_SN_LIST} ? trim($promotionGroup->{PromotionGroup::COL_PROMOTION_SN_LIST}, ',') : '';
        if (!str_starts_with($strPromotionList, '[')) {
            $strPromotionList = '[' . $strPromotionList . ']';
        }
        $promotionSnList = ConvertHelper::toArray($strPromotionList);
        $numOfPromotion = count((is_countable($promotionSnList) ? $promotionSnList : []));
        $promotionGroup->{PromotionGroup::VAR_TOTAL_COUPON_PROMOTION} = $numOfPromotion;

        #Convert to array
        $strListProvinceSn = $promotionGroup->{PromotionGroup::COL_LIST_PROVINCE_SN} ? trim($promotionGroup->{PromotionGroup::COL_LIST_PROVINCE_SN}, ',') : '';
        if (!str_starts_with($strListProvinceSn, '[')) {
            $strListProvinceSn = '[' . $strListProvinceSn . ']';
        }
        $listProvinceSn = ConvertHelper::toArray($strListProvinceSn);
        $promotionGroup->{PromotionGroup::COL_LIST_PROVINCE_SN} = $listProvinceSn;
        if ($listProvinceSn) {
            $promotionGroup->{PromotionGroup::VAR_PROVINCE_NAME_LIST} = Province::whereIn(Province::COL_SN, $listProvinceSn)->pluck(Province::COL_NAME)->toArray();
        } else {
            $promotionGroup->{PromotionGroup::VAR_PROVINCE_NAME_LIST} = null;
        }
        return GetPromotionGroupOutputDTO::assemble($promotionGroup);
    }
}
