<?php

namespace App\Actions\Promotion\SA;

use App\DTOs\Web\SA\Promotion\GetUserAppliedInputDTO;
use App\DTOs\Web\SA\Promotion\GetUserAppliedOutputDTO;
use App\Repositories\Interfaces\CouponIssuedRepositoryInterface;

class GetUserApplied
{
    protected $couponIssuedRepository;

    public function __construct(
        CouponIssuedRepositoryInterface $couponIssuedRepository
    )
    {
        $this->couponIssuedRepository = $couponIssuedRepository;
    }

    public function handle(GetUserAppliedInputDTO $getUserAppliedInputDTO)
    {
        $promotionSn = $getUserAppliedInputDTO->getPromotionSn();
        $keyword = $getUserAppliedInputDTO->getKeyword();
        $status = $getUserAppliedInputDTO->getStatus();
        $limit = $getUserAppliedInputDTO->getLimit();
        $export = $getUserAppliedInputDTO->getExport();
        $getUserApplied = $this->couponIssuedRepository->getUserApplied($keyword, $promotionSn, $status, $limit, $export);

        if ($getUserApplied->isEmpty()) {
            return new GetUserAppliedOutputDTO();
        }

        return GetUserAppliedOutputDTO::assemble($getUserApplied);
    }
}
