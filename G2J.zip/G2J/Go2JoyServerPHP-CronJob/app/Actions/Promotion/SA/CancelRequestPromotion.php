<?php

namespace App\Actions\Promotion\SA;

use App\DTOs\Web\SA\Promotion\CancelRequestPromotionDTO;
use App\Models\Coupon;
use App\Models\CouponForHotel;
use App\Models\CouponForUserGroup;
use App\Models\HotelAcceptPromotion;
use App\Models\IssueCondition;
use App\Models\Promotion;
use App\Models\PromotionImage;
use App\Models\PromotionTimeFrame;
use App\Models\PromotionTransitionRequest;
use App\Models\UseCondition;
use App\Repositories\Interfaces\CouponRepositoryInterface;

class CancelRequestPromotion
{
    protected $couponRepository;

    public function __construct(
        CouponRepositoryInterface $couponRepository
    )
    {
        $this->couponRepository = $couponRepository;
    }

    public function handle(CancelRequestPromotionDTO $cancelRequestPromotionDTO): void
    {
        $promotionSn = $cancelRequestPromotionDTO->getPromotionSn();
        PromotionImage::where(PromotionImage::COL_PROMOTION_SN, $promotionSn)->delete();
        PromotionTimeFrame::where(PromotionTimeFrame::COL_PROMOTION_SN, $promotionSn)->delete();
        HotelAcceptPromotion::where(HotelAcceptPromotion::COL_PROMOTION_SN, $promotionSn)->delete();
        PromotionTransitionRequest::where(PromotionTransitionRequest::COL_CLONE_PROMOTION_SN, $promotionSn)->delete();
        $coupon = $this->couponRepository->findByField(Coupon::COL_PROMOTION_SN, $promotionSn)->first();
        if (!empty($coupon)) {
            UseCondition::where(UseCondition::COL_COUPON_SN, $coupon->{Coupon::COL_SN})->delete();
            CouponForHotel::where(CouponForHotel::COL_COUPON_SN, $coupon->{Coupon::COL_SN})->delete();
            CouponForUserGroup::where(CouponForUserGroup::COL_COUPON_SN, $coupon->{Coupon::COL_SN})->delete();
            IssueCondition::where(IssueCondition::COL_COUPON_SN, $coupon->{Coupon::COL_SN})->delete();
        }
        Coupon::where(Coupon::COL_PROMOTION_SN, $promotionSn)->delete();
        Promotion::where(Promotion::COL_SN, $promotionSn)->delete();
    }
}
