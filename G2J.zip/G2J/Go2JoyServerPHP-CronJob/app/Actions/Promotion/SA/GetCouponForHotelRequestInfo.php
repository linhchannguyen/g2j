<?php

namespace App\Actions\Promotion\SA;

use App\Constants\RoomType as RoomTypeConst;
use App\DTOs\Web\SA\Promotion\GetCouponForHotelRequestInfoInputDTO;
use App\DTOs\Web\SA\Promotion\GetCouponForHotelRequestInfoOutputDTO;
use App\Helpers\ConvertHelper;
use App\Models\CouponForHotel;
use App\Models\Hotel;
use App\Models\RoomType;
use App\Repositories\Interfaces\CouponForHotelRepositoryInterface;

class GetCouponForHotelRequestInfo
{
    protected $couponForHotelRepository;

    public function __construct(
        CouponForHotelRepositoryInterface $couponForHotelRepository
    )
    {
        $this->couponForHotelRepository = $couponForHotelRepository;
    }

    public function handle(GetCouponForHotelRequestInfoInputDTO $getCouponForHotelRequestInfoInputDTO): GetCouponForHotelRequestInfoOutputDTO
    {
        $couponSn = $getCouponForHotelRequestInfoInputDTO->getCouponSn();
        $type = $getCouponForHotelRequestInfoInputDTO->getType();
        $keyword = $getCouponForHotelRequestInfoInputDTO->getKeyword();
        $limit = $getCouponForHotelRequestInfoInputDTO->getLimit();
        $couponForHotels = $this->couponForHotelRepository->findHotelAcceptCouponRequest($couponSn, $type, $keyword, $limit);

        if ($couponForHotels->isEmpty()) {
            return new GetCouponForHotelRequestInfoOutputDTO();
        }

        foreach ($couponForHotels as $values) {
            $strRoomTypeSnList = $values->{CouponForHotel::COL_ROOM_TYPE_SN_LIST} ? trim($values->{CouponForHotel::COL_ROOM_TYPE_SN_LIST}, ',') : '';
            if (!str_starts_with($strRoomTypeSnList, '[')) {
                $strRoomTypeSnList = '[' . $strRoomTypeSnList . ']';
            }
            $values->{CouponForHotel::VAR_ROOM_TYPE_ACCEPT_COUPON} = ConvertHelper::toArray($strRoomTypeSnList);
            $numOfRoomType = RoomType::where(RoomType::COL_HOTEL_SN, $values->{Hotel::COL_SN})
                ->whereIn(RoomType::COL_STATUS, [RoomTypeConst::STATUS['ACTIVE'], RoomTypeConst::STATUS['LOCK']])
                ->count();
            $values->{CouponForHotel::VAR_NUM_OF_ROOM_TYPE} = $numOfRoomType;
        }

        return GetCouponForHotelRequestInfoOutputDTO::assemble($couponForHotels);
    }
}
