<?php

namespace App\Actions\Promotion\SA;

use App\DTOs\Web\SA\Promotion\AddDraftPromotionInputDTO;
use App\DTOs\Web\SA\Promotion\InfoDraftPromotionOutputDTO;
use App\Helpers\UploadHelper;
use App\Models\DraftPromotion;
use App\Models\PromotionGroup;
use stdClass;

class AddDraftPromotion
{
    public function handle(AddDraftPromotionInputDTO $addDraftPromotionInputDTO): InfoDraftPromotionOutputDTO
    {
        // create draft promotion
        $draftSession = $addDraftPromotionInputDTO->getDraftSession();
        $images = $addDraftPromotionInputDTO->getImages();
        $addDraftPromotionInputDTO->setPromotionGroupSn($addDraftPromotionInputDTO->getPromotionGroupSn());
        // create promotion image
        $preSignedUrl = new stdClass;
        $extension = pathinfo($images, PATHINFO_EXTENSION);
        $pathName = UploadHelper::getPathFromExtension($extension, UploadHelper::FOLDER['PROMOTION']);
        if (!empty($pathName)) {
            $preSignedUrl = UploadHelper::getPreSigned($pathName);
        }
        $nameNoUploadFileCopy = explode("promotion/", $images)[1] ?? "";
        if ($nameNoUploadFileCopy) {
            $pathName = $images;
            $images = $addDraftPromotionInputDTO->getOriginalName();
        }
        $draftSession['session1']['imagePath'] = $pathName;
        $draftSession['session1']['originalName'] = $images;
        $draftSession['session1']['preSignedUrl'] = $preSignedUrl;
        $addDraftPromotionInputDTO->setDraftSession(json_encode($draftSession));
        $promotionData = $addDraftPromotionInputDTO->except(['images'])->toArray();
        $promotion = DraftPromotion::create($promotionData);
        $promotion = $promotion->find($promotion->{DraftPromotion::COL_SN});
        $promotion->{DraftPromotion::COL_DRAFT_SESSION} = json_decode($promotion->{DraftPromotion::COL_DRAFT_SESSION}, true);
        $promotionGroup = PromotionGroup::where(PromotionGroup::COL_SN, $promotion->{DraftPromotion::COL_PROMOTION_GROUP_SN})->first();
        $promotion->{DraftPromotion::VAR_PROMOTION_GROUP_NAME} = $promotionGroup->{PromotionGroup::COL_TITLE} ?? "";

        return InfoDraftPromotionOutputDTO::assemble($promotion);
    }
}
