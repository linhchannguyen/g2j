<?php

namespace App\Actions\Promotion\SA;

use App\Constants\RoomType as RoomTypeConst;
use App\DTOs\Web\SA\Promotion\GetCouponForHotelInputDTO;
use App\DTOs\Web\SA\Promotion\GetCouponForHotelOutputDTO;
use App\Helpers\ConvertHelper;
use App\Models\CouponForHotel;
use App\Models\Hotel;
use App\Models\RoomType;
use App\Repositories\Interfaces\CouponForHotelRepositoryInterface;

class GetCouponForHotel
{
    protected $couponForHotelRepository;

    public function __construct(
        CouponForHotelRepositoryInterface $couponForHotelRepository
    )
    {
        $this->couponForHotelRepository = $couponForHotelRepository;
    }

    public function handle(GetCouponForHotelInputDTO $getCouponForHotelInputDTO): GetCouponForHotelOutputDTO
    {
        $couponSn = $getCouponForHotelInputDTO->getCouponSn();
        $type = $getCouponForHotelInputDTO->getType();
        $couponForHotels = $this->couponForHotelRepository->findHotelAcceptCoupon($couponSn, $type);

        if ($couponForHotels->isEmpty()) {
            return new GetCouponForHotelOutputDTO();
        }

        foreach ($couponForHotels as $values) {
            $strRoomTypeSnList = $values->{CouponForHotel::COL_ROOM_TYPE_SN_LIST} ? trim($values->{CouponForHotel::COL_ROOM_TYPE_SN_LIST}, ',') : '';
            if (!str_starts_with($strRoomTypeSnList, '[')) {
                $strRoomTypeSnList = '[' . $strRoomTypeSnList . ']';
            }
            $values->{CouponForHotel::VAR_ROOM_TYPE_ACCEPT_COUPON} = ConvertHelper::toArray($strRoomTypeSnList);
            $values->{CouponForHotel::VAR_ROOM_TYPE_LIST} = $this->_getRoomTypeOfHotel($values->{Hotel::COL_SN});
        }

        return GetCouponForHotelOutputDTO::assemble($couponForHotels);
    }

    private function _getRoomTypeOfHotel(int $hotelSn): array
    {
        $roomTypeList = [];
        $roomTypes = RoomType::where(RoomType::COL_HOTEL_SN, $hotelSn)
        ->whereIn(RoomType::COL_STATUS, [RoomTypeConst::STATUS['ACTIVE'], RoomTypeConst::STATUS['LOCK']])
        ->get([
            RoomType::COL_SN,
            RoomType::COL_NAME,
            RoomType::COL_SHORT_NAME,
        ]);
        foreach ($roomTypes as $value) {
            $roomTypeList[] = [
                'sn' => $value->{RoomType::COL_SN},
                'name' => $value->{RoomType::COL_NAME},
                'shortName' => $value->{RoomType::COL_SHORT_NAME},
            ];
        }

        return $roomTypeList;
    }
}
