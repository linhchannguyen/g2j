<?php

namespace App\Actions\Promotion\SA;

use App\Constants\Activity as ActivityConst;
use App\Constants\CouponForHotel as CouponForHotelConst;
use App\Constants\PromotionImage as PromotionImageConst;
use App\DTOs\Web\SA\Promotion\GetPromotionRequestInfoInputDTO;
use App\DTOs\Web\SA\Promotion\GetPromotionRequestInfoOutputDTO;
use App\Helpers\ConvertHelper;
use App\Models\Coupon;
use App\Models\CouponForHotel;
use App\Models\CouponForUserGroup;
use App\Models\IssueCondition;
use App\Models\Promotion;
use App\Models\PromotionGroup;
use App\Models\PromotionImage;
use App\Models\PromotionTimeFrame;
use App\Models\PromotionTransitionRequest;
use App\Models\Province;
use App\Models\UseCondition;
use App\Models\VoucherCondition;
use App\Repositories\Interfaces\CouponForHotelRepositoryInterface;
use App\Repositories\Interfaces\CouponForUserGroupRepositoryInterface;
use App\Repositories\Interfaces\CouponRepositoryInterface;
use App\Repositories\Interfaces\HotelRepositoryInterface;
use App\Repositories\Interfaces\IssueConditionRepositoryInterface;
use App\Repositories\Interfaces\PromotionGroupRepositoryInterface;
use App\Repositories\Interfaces\PromotionImageRepositoryInterface;
use App\Repositories\Interfaces\PromotionRepositoryInterface;
use App\Repositories\Interfaces\PromotionTimeFrameRepositoryInterface;
use App\Repositories\Interfaces\UseConditionRepositoryInterface;
use App\Repositories\Interfaces\VoucherCodeRepositoryInterface;
use App\Repositories\Interfaces\VoucherConditionRepositoryInterface;
use Carbon\Carbon;

class GetPromotionRequestInfo
{
    const FILE_LANGUAGE_NAME = 'sa/promotion';

    protected $promotionRepository;

    protected $promotionGroupRepository;

    protected $promotionTimeFrameRepository;

    protected $promotionImageRepository;

    protected $voucherConditionRepository;

    protected $useConditionRepository;

    protected $couponForUserGroupRepository;

    protected $couponForHotelRepository;

    protected $hotelRepository;

    protected $issueConditionRepository;

    protected $couponRepository;

    protected $voucherCodeRepository;

    public function __construct(
        PromotionGroupRepositoryInterface     $promotionGroupRepository,
        PromotionRepositoryInterface          $promotionRepository,
        PromotionTimeFrameRepositoryInterface $promotionTimeFrameRepository,
        PromotionImageRepositoryInterface     $promotionImageRepository,
        VoucherConditionRepositoryInterface   $voucherConditionRepository,
        UseConditionRepositoryInterface       $useConditionRepository,
        CouponForUserGroupRepositoryInterface $couponForUserGroupRepository,
        CouponForHotelRepositoryInterface     $couponForHotelRepository,
        HotelRepositoryInterface              $hotelRepository,
        IssueConditionRepositoryInterface     $issueConditionRepository,
        CouponRepositoryInterface             $couponRepository,
        VoucherCodeRepositoryInterface        $voucherCodeRepository
    )
    {
        $this->promotionGroupRepository = $promotionGroupRepository;
        $this->promotionRepository = $promotionRepository;
        $this->promotionTimeFrameRepository = $promotionTimeFrameRepository;
        $this->promotionImageRepository = $promotionImageRepository;
        $this->voucherConditionRepository = $voucherConditionRepository;
        $this->useConditionRepository = $useConditionRepository;
        $this->couponForUserGroupRepository = $couponForUserGroupRepository;
        $this->couponForHotelRepository = $couponForHotelRepository;
        $this->hotelRepository = $hotelRepository;
        $this->issueConditionRepository = $issueConditionRepository;
        $this->couponRepository = $couponRepository;
        $this->voucherCodeRepository = $voucherCodeRepository;
    }

    public function handle(GetPromotionRequestInfoInputDTO $getPromotionRequestInfoInputDTO): GetPromotionRequestInfoOutputDTO
    {
        $promotionSn = $getPromotionRequestInfoInputDTO->getPromotionSn();
        $oldPromotionSn = $promotionSn;
        $activityStatus = $getPromotionRequestInfoInputDTO->getActivityStatus();
        $promotionTransitionRequest = PromotionTransitionRequest::where(PromotionTransitionRequest::COL_SOURCE_PROMOTION_SN, $promotionSn)->first();
        $promotionImages = $this->promotionImageRepository->findByField(PromotionImage::COL_PROMOTION_SN, $promotionSn);
        if ($activityStatus == ActivityConst::STATUS['WAITING'] && !empty($promotionTransitionRequest)) {
            $promotionSn = $promotionTransitionRequest->{PromotionTransitionRequest::COL_CLONE_PROMOTION_SN};
            $promotionImagesClone = $this->promotionImageRepository->findByField(PromotionImage::COL_PROMOTION_SN, $promotionSn);
            foreach ($promotionImagesClone as $value) {
                if ($value->{PromotionImage::COL_TYPE_DISPLAY} == PromotionImageConst::TYPE['DETAIL']) {
                    $promotionImages = $value;
                }
            }
        }
        $promotion = $this->promotionRepository->find($promotionSn);
        $coupon = $this->couponRepository->findByField(Coupon::COL_PROMOTION_SN, $promotionSn)->first();
        $oldCoupon = $this->couponRepository->findByField(Coupon::COL_PROMOTION_SN, $oldPromotionSn)->first();
        $promotionTimeFrame = $this->promotionTimeFrameRepository->findByField(PromotionTimeFrame::COL_PROMOTION_SN, $promotionSn)->first();
        $useCondition = $this->useConditionRepository->findByField(UseCondition::COL_COUPON_SN, $coupon->{Coupon::COL_SN})->first();
        $couponForUserGroup = $this->couponForUserGroupRepository->findByField(CouponForUserGroup::COL_COUPON_SN, $coupon->{Coupon::COL_SN})->first();
        $voucherCondition = $this->voucherConditionRepository->findByField(VoucherCondition::COL_COUPON_SN, $oldCoupon->{Coupon::COL_SN})->first();
        $numOfCouponVoucherCode = $this->voucherCodeRepository->countVoucherCodeByCouponSn($oldCoupon->{Coupon::COL_SN});
        $issueCondition = $this->issueConditionRepository->findByField(CouponForUserGroup::COL_COUPON_SN, $coupon->{Coupon::COL_SN})->first();

        $this->_getPromotion($promotion);
        $promotionImage = null;
        $this->_getPromotionImage($promotionImages, $promotionImage);
        $this->_getCouponForUserGroup($couponForUserGroup);
        $this->_getUseCondition($useCondition);
        $this->_getIssueCondition($issueCondition);

        return GetPromotionRequestInfoOutputDTO::assemble(
            $promotion,
            $coupon,
            $promotionImage,
            $promotionTimeFrame,
            $useCondition,
            $couponForUserGroup,
            $voucherCondition,
            $numOfCouponVoucherCode,
            $issueCondition
        );
    }

    private static function _getCouponForUserGroup(&$couponForUserGroup)
    {
        if (!empty($couponForUserGroup)) {
            $couponForUserGroup->{CouponForUserGroup::VAR_PROVINCE_LIST} = [];
            $strProvinceSnList = $couponForUserGroup->{CouponForUserGroup::COL_PROVINCE_SN_LIST} ? trim($couponForUserGroup->{CouponForUserGroup::COL_PROVINCE_SN_LIST}, ',') : '';
            if (!str_starts_with($strProvinceSnList, '[')) {
                $strProvinceSnList = '[' . $strProvinceSnList . ']';
            }
            $provinceSnList = ConvertHelper::toArray($strProvinceSnList);
            if (!empty($provinceSnList)) {
                $provinces = Province::whereIn(Province::COL_SN, $provinceSnList)->get([Province::COL_SN, Province::COL_NAME]);
                $_provinces = [];
                foreach ($provinces as $value) {
                    $_provinces[] = [
                        'sn' => $value->{Province::COL_SN} ?? null,
                        'name' => $value->{Province::COL_NAME} ?? null,
                    ];
                }
                $couponForUserGroup->{CouponForUserGroup::VAR_PROVINCE_LIST} = $_provinces;
            }
        }
    }

    private static function _getPromotionImage($promotionImages, &$promotionImage)
    {
        foreach ($promotionImages as $value) {
            if ($value->{PromotionImage::COL_TYPE_DISPLAY} == PromotionImageConst::TYPE['DETAIL']) {
                $promotionImage = $value;
            }
        }
    }

    private static function _getPromotion(&$promotion)
    {
        $_promotionGroups = [];
        $strPromotionGroupSnList = $promotion->{Promotion::COL_LIST_PROMOTION_GROUP_SN} ? trim($promotion->{Promotion::COL_LIST_PROMOTION_GROUP_SN}, ',') : '';
        if (!str_starts_with($strPromotionGroupSnList, '[')) {
            $strPromotionGroupSnList = '[' . $strPromotionGroupSnList . ']';
        }
        $promotionGroupList = ConvertHelper::toArray($strPromotionGroupSnList);
        $promotion->{Promotion::VAR_PROMOTION_GROUP} = [];
        if (!empty($promotionGroupList)) {
            $promotionGroups = PromotionGroup::whereIn(PromotionGroup::COL_SN, $promotionGroupList)->get([
                PromotionGroup::COL_SN,
                PromotionGroup::COL_TITLE,
                PromotionGroup::COL_STATUS,
                PromotionGroup::COL_LIST_PROVINCE_SN,
            ]);
            foreach ($promotionGroups as $values) {
                $strProvinceSnList = $values->{PromotionGroup::COL_LIST_PROVINCE_SN} ? trim($values->{PromotionGroup::COL_LIST_PROVINCE_SN}, ',') : '';
                if (!str_starts_with($strProvinceSnList, '[')) {
                    $strProvinceSnList = '[' . $strProvinceSnList . ']';
                }
                $provinceSnList = ConvertHelper::toArray($strProvinceSnList);
                $provinceNameList = [];
                if ($provinceSnList) {
                    $provinceNameList = Province::whereIn(Province::COL_SN, $provinceSnList)->pluck(Province::COL_NAME)->toArray();
                }
                $_promotionGroups[] = [
                    'sn' => $values->{PromotionGroup::COL_SN} ?? null,
                    'title' => $values->{PromotionGroup::COL_TITLE} ?? null,
                    'status' => $values->{PromotionGroup::COL_STATUS} ?? null,
                    'numDisplayArea' => count($provinceNameList) ?? 0,
                    'provinceNameList' => $provinceNameList,
                ];
            }
            $promotion->{Promotion::VAR_PROMOTION_GROUP} = $_promotionGroups;
        }
        $promotion->{Promotion::VAR_PROMOTION_VERSION_FLAG} = true;
        $dateRelease = Carbon::parse(config('go2joy.promotion_phase2_released_time'))->timestamp;
        $promotionCreateTime = $promotion->{Promotion::COL_CREATE_TIME} ?? null;
        if (empty($promotionCreateTime) || (!empty($promotionCreateTime) && $promotionCreateTime->timestamp < $dateRelease)) {
            $promotion->{Promotion::VAR_PROMOTION_VERSION_FLAG} = false;
        }
    }

    private static function _getUseCondition(&$useCondition)
    {
        if (!empty($useCondition)) {
            $useCondition->{Promotion::VAR_TOTAL_USE_COND_COUPON_FOR_HOTEL} = 0;
            $totalUseCondForHotel = CouponForHotel::where([
                CouponForHotel::COL_COUPON_SN => $useCondition->{UseCondition::COL_COUPON_SN},
                CouponForHotel::COL_TYPE => CouponForHotelConst::TYPE['USE']
            ])->count();
            $useCondition->{Promotion::VAR_TOTAL_USE_COND_COUPON_FOR_HOTEL} = $totalUseCondForHotel;
            $useConditionStartTime = $useCondition->{UseCondition::COL_START_TIME} ?? null;
            $useConditionEndTime = $useCondition->{UseCondition::COL_END_TIME} ?? null;
            $useCondition->{UseCondition::COL_START_TIME} = empty($useConditionStartTime) ? null : Carbon::createFromTimeString($useConditionStartTime)->format('H:i');
            $useCondition->{UseCondition::COL_END_TIME} = empty($useConditionEndTime) ? null : Carbon::createFromTimeString($useConditionEndTime)->format('H:i');
        }
    }

    private static function _getIssueCondition(&$issueCondition)
    {
        if (!empty($issueCondition)) {
            $issueCondition->{Promotion::VAR_TOTAL_ISSUE_COND_COUPON_FOR_HOTEL} = 0;
            $totalIssueCondForHotel = CouponForHotel::where([
                CouponForHotel::COL_COUPON_SN => $issueCondition->{IssueCondition::COL_COUPON_SN},
                CouponForHotel::COL_TYPE => CouponForHotelConst::TYPE['ISSUE']
            ])->count();
            $issueCondition->{Promotion::VAR_TOTAL_ISSUE_COND_COUPON_FOR_HOTEL} = $totalIssueCondForHotel;
            $issueConditionStartTime = $issueCondition->{IssueCondition::COL_START_TIME} ?? null;
            $issueConditionEndTime = $issueCondition->{IssueCondition::COL_END_TIME} ?? null;
            $issueConditionHourlyStartTime = $issueCondition->{IssueCondition::COL_HOURLY_START_TIME} ?? null;
            $issueConditionHourlyEndTime = $issueCondition->{IssueCondition::COL_HOURLY_END_TIME} ?? null;
            $issueCondition->{IssueCondition::COL_START_TIME} = empty($issueConditionStartTime) ? null : Carbon::createFromTimeString($issueConditionStartTime)->format('H:i');
            $issueCondition->{IssueCondition::COL_END_TIME} = empty($issueConditionEndTime) ? null : Carbon::createFromTimeString($issueConditionEndTime)->format('H:i');
            $issueCondition->{IssueCondition::COL_HOURLY_START_TIME} = empty($issueConditionHourlyStartTime) ? null : Carbon::createFromTimeString($issueConditionHourlyStartTime)->format('H:i');
            $issueCondition->{IssueCondition::COL_HOURLY_END_TIME} = empty($issueConditionHourlyEndTime) ? null : Carbon::createFromTimeString($issueConditionHourlyEndTime)->format('H:i');
        }
    }
}
