<?php

namespace App\Actions\Promotion\SA;

use App\DTOs\Web\SA\PromotionGroup\GetPromotionGroupDisplayListOutputDTO;
use App\Helpers\ConvertHelper;
use App\Models\PromotionGroup;
use App\Models\Province;
use App\Repositories\Interfaces\PromotionGroupRepositoryInterface;

class GetPromotionGroupDisplayList
{
    /** @var PromotionGroupRepositoryInterface */
    protected $promotionGroupRepository;

    public function __construct(
        PromotionGroupRepositoryInterface $promotionGroupRepository
    )
    {
        $this->promotionGroupRepository = $promotionGroupRepository;
    }

    public function handle(): GetPromotionGroupDisplayListOutputDTO
    {
        $promotionGroupList = $this->promotionGroupRepository->showDisplaySettingPromotionGroup();

        if ($promotionGroupList->isEmpty()) {
            return new GetPromotionGroupDisplayListOutputDTO();
        }

        foreach ($promotionGroupList as $promotionGroup) {
            $strPromotionSnList = $promotionGroup->{PromotionGroup::COL_PROMOTION_SN_LIST} ? trim($promotionGroup->{PromotionGroup::COL_PROMOTION_SN_LIST}, ',') : '';
            if (!str_starts_with($strPromotionSnList, '[')) {
                $strPromotionSnList = '[' . $strPromotionSnList . ']';
            }
            $promotionGroup->{PromotionGroup::COL_PROMOTION_SN_LIST} = ConvertHelper::toArray($strPromotionSnList);
            $promotionGroup->{PromotionGroup::VAR_TOTAL_COUPON_PROMOTION} = count((is_countable($promotionGroup->{PromotionGroup::COL_PROMOTION_SN_LIST}) ? $promotionGroup->{PromotionGroup::COL_PROMOTION_SN_LIST} : []));
            #Convert to array
            $strProvinceSnList = $promotionGroup->{PromotionGroup::COL_LIST_PROVINCE_SN} ? trim($promotionGroup->{PromotionGroup::COL_LIST_PROVINCE_SN}, ',') : '';
            if (!str_starts_with($strProvinceSnList, '[')) {
                $strProvinceSnList = '[' . $strProvinceSnList . ']';
            }
            $promotionGroup->{PromotionGroup::COL_LIST_PROVINCE_SN} = ConvertHelper::toArray($strProvinceSnList);
            $promotionGroup->{PromotionGroup::VAR_PROVINCE_NAME_LIST} = Province::whereIn(Province::COL_SN, $promotionGroup->{PromotionGroup::COL_LIST_PROVINCE_SN})->pluck(Province::COL_NAME)->toArray();
        }

        return GetPromotionGroupDisplayListOutputDTO::assemble($promotionGroupList);
    }
}
