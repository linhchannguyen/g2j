<?php

namespace App\Actions\Promotion\SA;

use App\Constants\PromotionGroup as PromotionGroupConst;
use App\DTOs\Web\SA\PromotionGroup\SwapMultipleIdxInputDTO;
use Illuminate\Support\Facades\DB;

class SwapMultipleIdx
{
    public function handle(SwapMultipleIdxInputDTO $swapMultipleIdxInputDTO): void
    {
        // Update swap IDX
        $swapData = $swapMultipleIdxInputDTO->getSwapData();
        $caseString = 'case sn';
        $ids = '';
        foreach ($swapData as $value) {
            $id = $value['sn'];
            $displayIndex = $value['idx'];
            $caseString .= " when $id then $displayIndex";
            $ids .= " $id,";
        }
        $ids = trim($ids, ',');
        $activeStatus = PromotionGroupConst::STATUS['ACTIVE'];
        DB::update("update PROMOTION_GROUP set IDX = $caseString end where SN in ($ids) and STATUS = $activeStatus");
        // End update swap IDX
    }
}
