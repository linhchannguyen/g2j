<?php

namespace App\Actions\Promotion\SA;

use App\Constants\Globals\Code as CodeConst;
use App\Constants\Globals\Message as MessageConst;
use App\Constants\PromotionGroup as PromotionGroupConst;
use App\DTOs\Web\SA\PromotionGroup\SettingDisplayPromotionGroupInputDTO;
use App\Exceptions\ServiceException;
use App\Helpers\ConvertHelper;
use App\Models\Promotion;
use App\Models\PromotionGroup;
use App\Repositories\Interfaces\PromotionGroupRepositoryInterface;

class SettingDisplayPromotionGroup
{
    const FILE_LANGUAGE_NAME = 'sa/promotion';
    /** @var PromotionGroupRepositoryInterface */
    protected $promotionGroupRepository;

    public function __construct(
        PromotionGroupRepositoryInterface $promotionGroupRepository
    )
    {
        $this->promotionGroupRepository = $promotionGroupRepository;
    }

    public function handle(SettingDisplayPromotionGroupInputDTO $settingDisplayPromotionGroupInputDTO): void
    {
        $oldPromotionGroup = $this->promotionGroupRepository->find($settingDisplayPromotionGroupInputDTO->getSn(), [PromotionGroup::COL_PROMOTION_SN_LIST]);
        $strPromotionSnList = $oldPromotionGroup->{PromotionGroup::COL_PROMOTION_SN_LIST} ? trim($oldPromotionGroup->{PromotionGroup::COL_PROMOTION_SN_LIST}, ',') : '';
        $hasActive = false;
        if (!str_starts_with($strPromotionSnList, '[')) {
            $strPromotionSnList = '[' . $strPromotionSnList . ']';
        }
        $promotionSnList = ConvertHelper::toArray($strPromotionSnList);
        if ($promotionSnList) {
            $couponStatusList = Promotion::whereIn(Promotion::COL_SN, $promotionSnList)->pluck(Promotion::COL_STATUS)->toArray();
        }
        if (in_array(PromotionGroupConst::STATUS['ACTIVE'], $couponStatusList ?? [])) {
            $hasActive = true;
        }
        $status = $settingDisplayPromotionGroupInputDTO->getStatus();
        if ($status == PromotionGroupConst::STATUS['ACTIVE'] && !$hasActive) {
            throw new ServiceException(ConvertHelper::getMessage(self::FILE_LANGUAGE_NAME, CodeConst::API_PRN_020), CodeConst::API_PRN_020);
        }
        $this->promotionGroupRepository->update([Promotion::COL_STATUS => $status], $settingDisplayPromotionGroupInputDTO->getSn());
    }
}
