<?php

namespace App\Actions\Promotion\SA;

use App\Constants\Globals\Code as CodeConst;
use App\Constants\VoucherCode as VoucherCodeConst;
use App\DTOs\Web\SA\Promotion\UpdateVoucherCodeInputDTO;
use App\DTOs\Web\SA\Promotion\UpdateVoucherCodeOutputDTO;
use App\Exceptions\ServiceException;
use App\Helpers\ConvertHelper;
use App\Models\VoucherCode;
use App\Models\VoucherCondition;
use App\Repositories\Interfaces\VoucherCodeRepositoryInterface;
use App\Repositories\Interfaces\VoucherConditionRepositoryInterface;

class UpdateVoucherCode
{
    const FILE_LANGUAGE_NAME = 'sa/promotion';

    protected $voucherCodeRepository;

    protected $voucherConditionRepository;

    public function __construct(
        VoucherCodeRepositoryInterface      $voucherCodeRepository,
        VoucherConditionRepositoryInterface $voucherConditionRepository
    )
    {
        $this->voucherCodeRepository = $voucherCodeRepository;
        $this->voucherConditionRepository = $voucherConditionRepository;
    }

    public function handle(UpdateVoucherCodeInputDTO $updateVoucherCodeInputDTO): UpdateVoucherCodeOutputDTO
    {
        $numErrorFormat = 0;
        $numErrorExist = 0;
        $couponSn = $updateVoucherCodeInputDTO->getCouponSn();
        $type = $updateVoucherCodeInputDTO->getType();
        $code = $updateVoucherCodeInputDTO->getCode();
        $voucherCondition = $this->voucherConditionRepository->findByField(VoucherCondition::COL_COUPON_SN, $couponSn)->first();
        if (empty($voucherCondition)) {
            $voucherCondition = new VoucherCondition();
            $voucherCondition->{VoucherCondition::COL_COUPON_SN} = $couponSn;
            $voucherCondition->{VoucherCondition::COL_TYPE} = $type;
            $voucherCondition = $this->voucherConditionRepository->create($voucherCondition->toArray());
        }
        $voucherCondition->{VoucherCondition::COL_TYPE} = $type;

        if (VoucherCodeConst::TYPE_APPLY['COMMON'] == $type) {
            $len = strlen($code);
            if ($len >= 6 && $len <= 12) {
                if (!str_starts_with($code, 'G2J')) {
                    throw new ServiceException(ConvertHelper::getMessage(self::FILE_LANGUAGE_NAME, CodeConst::API_PRN_025), CodeConst::API_PRN_025);
                }
            } else {
                throw new ServiceException(ConvertHelper::getMessage(self::FILE_LANGUAGE_NAME, CodeConst::API_PRN_024), CodeConst::API_PRN_024);
            }
            $lst = $this->voucherCodeRepository->getVoucherExists($couponSn);
            $oldVoucher = null;
            if ($lst->count() > 0) {
                $oldVoucher = $lst->first();
            }

            if (empty($oldVoucher) || $oldVoucher->{VoucherCode::COL_CODE} != $code) {
                if ($this->voucherCodeRepository->checkVoucherExists($code)) {
                    throw new ServiceException(ConvertHelper::getMessage(self::FILE_LANGUAGE_NAME, CodeConst::API_PRN_023), CodeConst::API_PRN_023);
                }
                $voucher = new VoucherCode();
                $voucher->{VoucherCode::COL_COUPON_SN} = $couponSn;
                $voucher->{VoucherCode::COL_TYPE} = $type;
                $voucher->{VoucherCode::COL_CODE} = $code;
                $voucher->{VoucherCode::COL_SOURCE} = VoucherCodeConst::SOURCE['G2J'];
                $this->voucherCodeRepository->create($voucher->toArray());
            }
            $voucherCondition->{VoucherCondition::COL_CODE} = $code;
            $voucherCondition->{VoucherCondition::COL_TYPE} = $type;
        } else {
            $voucherCodeList = $updateVoucherCodeInputDTO->getVoucherCodeList();
            $vouchers = [];
            foreach ($voucherCodeList as $values) {
                $len = strlen($values);
                if (($len >= 6 && $len <= 12) && str_starts_with($values, 'G2J')) {
                    $vouchers[] = $values;
                } else {
                    $numErrorFormat++;
                }
            }
            if (!empty($vouchers)) {
                $vouchers = array_diff(array_unique($vouchers), ["", null]);
                if (!empty($vouchers)) {
                    $voucherCodes = VoucherCode::whereIn(VoucherCode::COL_CODE, $vouchers)
                        ->groupBy(VoucherCode::COL_CODE)
                        ->pluck(VoucherCode::COL_CODE)
                        ->toArray();
                    if (!empty($voucherCodes)) {
                        $numErrorExist += count($voucherCodes);
                        $vouchers = array_diff($vouchers, $voucherCodes);
                    }
                    $batchInsert = [];
                    foreach ($vouchers as $code) {
                        $voucher = new VoucherCode();
                        $voucher->{VoucherCode::COL_COUPON_SN} = $couponSn;
                        $voucher->{VoucherCode::COL_TYPE} = $type;
                        $voucher->{VoucherCode::COL_CODE} = $code;
                        $voucher->{VoucherCode::COL_SOURCE} = VoucherCodeConst::SOURCE['G2J'];
                        $batchInsert[] = $voucher->toArray();
                    }
                    if (!empty($batchInsert)) {
                        $this->voucherCodeRepository->batchInsert($batchInsert);
                    }
                }
            }
            $voucherCondition->{VoucherCondition::COL_TYPE} = $type;
            $voucherCondition->{VoucherCondition::COL_CODE} = null;
        }
        $this->voucherConditionRepository->update($voucherCondition->toArray(), $voucherCondition->{VoucherCondition::COL_SN});
        return UpdateVoucherCodeOutputDTO::assemble($numErrorFormat, $numErrorExist);
    }
}
