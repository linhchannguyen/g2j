<?php

namespace App\Actions\Promotion\SA;

use App\DTOs\Web\SA\Promotion\DeleteDraftVoucherCodeInputDTO;
use App\Models\DraftVoucherCondition;

class DeleteDraftVoucherCode
{
    public function handle(DeleteDraftVoucherCodeInputDTO $deleteDraftVoucherCodeInputDTO): void
    {
        DraftVoucherCondition::where(DraftVoucherCondition::COL_SN, $deleteDraftVoucherCodeInputDTO->getSn())->delete();
    }
}
