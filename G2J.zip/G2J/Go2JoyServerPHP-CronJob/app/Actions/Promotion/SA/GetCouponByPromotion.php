<?php

namespace App\Actions\Promotion\SA;

use App\Constants\CouponForHotel as CouponForHotelConst;
use App\Constants\CouponIssued as CouponIssuedConst;
use App\Constants\DraftPromotion as DraftPromotionConst;
use App\Constants\Hotel as HotelConst;
use App\Constants\PaymentTransaction as PaymentTransactionConst;
use App\Constants\UseCondition as UseConditionConst;
use App\Constants\UserBooking as UserBookingConst;
use App\DTOs\Web\SA\Promotion\GetPromotionListOutputDTO;
use App\DTOs\Web\SA\Promotion\GetPromotionListInputDTO;
use App\Helpers\ConvertHelper;
use App\Models\CouponForHotel;
use App\Models\CouponIssued;
use App\Models\Hotel;
use App\Models\HotelAcceptPromotion;
use App\Models\Promotion;
use App\Models\PromotionGroup;
use App\Models\UserBooking;
use App\Repositories\Interfaces\CouponIssuedRepositoryInterface;
use App\Repositories\Interfaces\PromotionGroupRepositoryInterface;
use App\Repositories\Interfaces\PromotionRepositoryInterface;
use App\Repositories\Interfaces\UserBookingRepositoryInterface;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;

class GetCouponByPromotion
{
    protected $promotionRepository;

    protected $userBookingRepository;

    protected $couponIssuedRepository;

    protected $promotionGroupRepository;

    public function __construct(
        PromotionGroupRepositoryInterface $promotionGroupRepository,
        PromotionRepositoryInterface      $promotionRepository,
        UserBookingRepositoryInterface    $userBookingRepository,
        CouponIssuedRepositoryInterface   $couponIssuedRepository
    )
    {
        $this->promotionGroupRepository = $promotionGroupRepository;
        $this->promotionRepository = $promotionRepository;
        $this->userBookingRepository = $userBookingRepository;
        $this->couponIssuedRepository = $couponIssuedRepository;
    }

    public function handle(GetPromotionListInputDTO $getPromotionListInputDTO): GetPromotionListOutputDTO
    {
        $promotionGroup = $this->promotionGroupRepository->find($getPromotionListInputDTO->getPromotionGroupSn(), [PromotionGroup::COL_PROMOTION_SN_LIST]);
        $strPromotionSnList = $promotionGroup->{PromotionGroup::COL_PROMOTION_SN_LIST} ? trim($promotionGroup->{PromotionGroup::COL_PROMOTION_SN_LIST}, ',') : '';
        $promotionSnList = [];
        if (!str_starts_with($strPromotionSnList, '[')) {
            $strPromotionSnList = '[' . $strPromotionSnList . ']';
        }
        $promotionSnList = ConvertHelper::toArray($strPromotionSnList);

        $promotionList = $this->promotionRepository->findCouponByPromotion(
            $getPromotionListInputDTO->getKeyword(),
            $getPromotionListInputDTO->getType(),
            $getPromotionListInputDTO->getLimit(),
            $getPromotionListInputDTO->getStatus(),
            $getPromotionListInputDTO->getDiscountType(),
            $getPromotionListInputDTO->getFormOfSponsor(),
            $getPromotionListInputDTO->getPromotionGroupSn(),
            $promotionSnList
        );

        if ($promotionList->isEmpty()) {
            return new GetPromotionListOutputDTO();
        }

        foreach ($promotionList as $promotion) {
            $this->_getStatisticPromotion($promotion);
        }
        return GetPromotionListOutputDTO::assemble($promotionList);
    }

    private function _getStatisticPromotion(&$promotion)
    {
        $totalApplyHotel = 0;
        $totalHotelApplied = 0;
        $totalHotel = Hotel::where(Hotel::COL_HOTEL_STATUS, HotelConst::STATUS['CONTRACTED'])->where(Hotel::COL_ORIGIN, HotelConst::ORIGIN['GO2JOY'])->count();
        $totalHotelApplied = HotelAcceptPromotion::where(HotelAcceptPromotion::COL_PROMOTION_SN, $promotion->{Promotion::COL_SN})->count();
        if (UseConditionConst::APPLY_TARGET['ALL'] == $promotion->{Promotion::COL_APPLY_TARGET}) {
            if ($promotion->{Promotion::COL_HOTEL_DISCOUNT} == 0) {
                $totalHotelApplied = $totalHotel;
            }
            $totalApplyHotel = $totalHotel;
        } else {
            $numOfHotel = CouponForHotel::where(CouponForHotel::COL_COUPON_SN, $promotion->{Promotion::COL_COUPON_SN})->where(CouponForHotel::COL_TYPE, CouponForHotelConst::TYPE['USE'])->count();
            if (UseConditionConst::APPLY_TARGET['ALL_BUT_EXCLUDE'] == $promotion->{Promotion::COL_APPLY_TARGET}) {
                $totalApplyHotel = $totalHotel - $numOfHotel;
            } else {
                $totalApplyHotel = $numOfHotel;
            }
        }

        $promotion->{Promotion::VAR_TOTAL_HOTEL_APPLIED} = $totalHotelApplied;
        $promotion->{Promotion::VAR_TOTAL_APPLY_HOTEL} = $totalApplyHotel;
        $promotion->{Promotion::VAR_TOTAL_USER_APPLIED} = $this->couponIssuedRepository->countAllUserApplied($promotion->{Promotion::COL_COUPON_SN});
        $promotion->{Promotion::VAR_TOTAL_COUPON_ISSUED} = CouponIssued::where(CouponIssued::COL_COUPON_SN, $promotion->{Promotion::COL_COUPON_SN})->count();
        $numOfCoupon = CouponIssued::where(CouponIssued::COL_COUPON_SN, $promotion->{Promotion::COL_COUPON_SN})->where(CouponIssued::COL_USED, CouponIssuedConst::USED['USED']);
        $promotion->{Promotion::VAR_TOTAL_CONSUMED_COUPON} = $numOfCoupon->count();
        if ($promotion->{Promotion::COL_STATUS} == DraftPromotionConst::STATUS['DRAFT']) {
            $promotion->{Promotion::VAR_TOTAL_HOTEL_APPLIED} = 0;
            $promotion->{Promotion::VAR_TOTAL_APPLY_HOTEL} = 0;
            $promotion->{Promotion::VAR_TOTAL_USER_APPLIED} = 0;
            $promotion->{Promotion::VAR_TOTAL_COUPON_ISSUED} = 0;
            $promotion->{Promotion::VAR_TOTAL_CONSUMED_COUPON} = 0;
            $promotion->{Promotion::COL_TOTAL_DISCOUNT} = 0;
            $this->_convertEmptyStr($promotion);
        } else {
            $this->_getTotalDiscount($promotion);
        }
        $promotion->{Promotion::VAR_PROMOTION_VERSION_FLAG} = true;
        $dateRelease = Carbon::parse(config('go2joy.promotion_phase2_released_time'))->timestamp;
        $promotionCreateTime = $promotion->{Promotion::COL_CREATE_TIME} ?? null;
        if (empty($promotionCreateTime) || (!empty($promotionCreateTime) && $promotionCreateTime->timestamp < $dateRelease)) {
            $promotion->{Promotion::VAR_PROMOTION_VERSION_FLAG} = false;
        }
    }

    private function _convertEmptyStr($promotion)
    {
        $discountType = $promotion->{Promotion::COL_DISCOUNT_TYPE};
        $applyStart = $promotion->{Promotion::COL_APPLY_START};
        $applyEnd = $promotion->{Promotion::COL_APPLY_END};
        $numActiveDay = $promotion->{Promotion::COL_NUM_ACTIVE_DAY};
        $couponStart = $promotion->{Promotion::COL_START_DATE};
        $couponEnd = $promotion->{Promotion::COL_END_DATE};
        $promotion->{Promotion::COL_DISCOUNT_TYPE} = empty($discountType) || ConvertHelper::isEmptyStr($discountType) ? null : intval($discountType);
        $promotion->{Promotion::COL_APPLY_START} = empty($applyStart) || ConvertHelper::isEmptyStr($applyStart) ? null : $applyStart;
        $promotion->{Promotion::COL_APPLY_END} = empty($applyEnd) || ConvertHelper::isEmptyStr($applyEnd) ? null : $applyEnd;
        $promotion->{Promotion::COL_NUM_ACTIVE_DAY} = empty($numActiveDay) || ConvertHelper::isEmptyStr($numActiveDay) ? null : intval($numActiveDay);
        $promotion->{Promotion::COL_START_DATE} = empty($couponStart) || ConvertHelper::isEmptyStr($couponStart) ? null : $couponStart;
        $promotion->{Promotion::COL_END_DATE} = empty($couponEnd) || ConvertHelper::isEmptyStr($couponEnd) ? null : $couponEnd;
    }

    private function _getTotalDiscount(&$promotion)
    {        
        $totalDiscount = 0;
        $couponIssueds = CouponIssued::where(CouponIssued::COL_COUPON_SN, $promotion->{Promotion::COL_COUPON_SN})->pluck(CouponIssued::COL_SN)->toArray();
        foreach (array_chunk($couponIssueds, 500) as $couponIssued) {
            DB::table(UserBooking::TABLE_NAME, 'booking')
            ->join('HOTEL as hotel', 'booking.HOTEL_SN', '=', 'hotel.SN')
            ->leftJoin('PAYMENT_TRANSACTION as paymentTransaction', 'paymentTransaction.USER_BOOKING_SN', '=', 'booking.SN')
            ->whereIn('booking.COUPON_ISSUED_SN', $couponIssued)
            ->where(function ($query) {
                $query->orWhere('booking.BOOKING_STATUS', UserBookingConst::BOOKING_STATUS['COMPLETED']);
                $query->orWhere(function ($query1) {
                    $query1->orWhere(function ($query2) {
                        $query2->where('booking.BOOKING_STATUS', '=', UserBookingConst::BOOKING_STATUS['NO_SHOW']);
                        $query2->where('hotel.ORIGIN', '=', HotelConst::ORIGIN['GO2JOY']);
                        $query2->where('booking.PAYMENT_PROVIDER', '!=', UserBookingConst::PAYMENT_PROVIDER['AT_HOTEL']);
                        $query2->where('booking.PREPAY_AMOUNT', '>', 0);
                        $query2->where(function ($query3) {
                            $query3->orWhere('paymentTransaction.PAYMENT_STATUS', '=', PaymentTransactionConst::PAYMENT_STATUS['SUCCESSFUL']);
                            $query3->orWhereNull('paymentTransaction.PAYMENT_STATUS');
                        });
                        $query2->where('booking.REFUNDED', '=', 0);
                        $query2->where('booking.CREATE_TIME', '>=', UserBookingConst::DATETIME_RELEASE_NEW_BOOKING_PROCESS);
                    });
                });
            })
            ->selectRaw("
                booking.SN,
                booking.GO2JOY_DISCOUNT,
                booking.HOTEL_DISCOUNT,
                booking.SPONSOR_DISCOUNT,
                booking.PROMOTION_DISCOUNT
            ")
            ->orderBy('booking.SN')
            ->chunk(500, function ($userBooking) use (&$totalDiscount) {
                foreach ($userBooking as $value) {
                    $totalG2jDiscount = $value->{UserBooking::COL_GO2JOY_DISCOUNT} ?? 0;
                    $totalHotelDiscount = $value->{UserBooking::COL_HOTEL_DISCOUNT} ?? 0;
                    $totalSponsorDiscount = $value->{UserBooking::COL_SPONSOR_DISCOUNT} ?? 0;
                    $totalPromotionDiscount = $value->{UserBooking::COL_PROMOTION_DISCOUNT} ?? 0;
                    $totalDiscount += $totalG2jDiscount + $totalHotelDiscount + $totalSponsorDiscount + $totalPromotionDiscount;
                }
            });
        }
        $promotion->{Promotion::COL_TOTAL_DISCOUNT} = $totalDiscount;
    }
}
