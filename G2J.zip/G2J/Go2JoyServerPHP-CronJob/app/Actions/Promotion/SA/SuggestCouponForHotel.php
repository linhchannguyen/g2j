<?php

namespace App\Actions\Promotion\SA;

use App\DTOs\Web\SA\Promotion\SuggestCouponForHotelInputDTO;
use App\DTOs\Web\SA\Promotion\SuggestCouponForHotelOutputDTO;
use App\Models\CouponForHotel;
use App\Repositories\Interfaces\HotelRepositoryInterface;

class SuggestCouponForHotel
{
    protected $hotelRepository;

    public function __construct(
        HotelRepositoryInterface $hotelRepository
    )
    {
        $this->hotelRepository = $hotelRepository;
    }

    public function handle(SuggestCouponForHotelInputDTO $suggestCouponForHotelInputDTO): SuggestCouponForHotelOutputDTO
    {
        $keyword = $suggestCouponForHotelInputDTO->getKeyword();
        $provinceSn = $suggestCouponForHotelInputDTO->getProvinceSn();
        $districtSn = $suggestCouponForHotelInputDTO->getDistrictSn();
        $couponForHotels = $this->hotelRepository->suggestCouponForHotel($keyword, $provinceSn, $districtSn);
        if ($couponForHotels->isEmpty()) {
            return new SuggestCouponForHotelOutputDTO();
        }

        foreach ($couponForHotels as $values) {
            $values->{CouponForHotel::VAR_ROOM_TYPE_LIST} = json_decode($values->{CouponForHotel::VAR_ROOM_TYPE_LIST}, true);
        }

        return SuggestCouponForHotelOutputDTO::assemble($couponForHotels);
    }
}
