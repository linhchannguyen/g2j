<?php

namespace App\Actions\Promotion\SA;

use App\DTOs\Web\SA\Promotion\GetDraftPromotionInputDTO;
use App\DTOs\Web\SA\Promotion\InfoDraftPromotionOutputDTO;
use App\Models\DraftPromotion;
use App\Models\Hotel;
use App\Models\PromotionGroup;
use App\Models\RoomType;
use App\Repositories\Interfaces\DraftPromotionRepositoryInterface;
use Illuminate\Support\Collection;
use stdClass;

class GetDraftPromotion
{
    protected $draftPromotionRepository;

    public function __construct(
        DraftPromotionRepositoryInterface $draftPromotionRepository
    )
    {
        $this->draftPromotionRepository = $draftPromotionRepository;
    }

    public function handle(GetDraftPromotionInputDTO $getDraftPromotionInputDTO): InfoDraftPromotionOutputDTO
    {
        $sn = $getDraftPromotionInputDTO->getSn();
        $promotion = $this->draftPromotionRepository->find($sn);
        $draftSession = json_decode($promotion->{DraftPromotion::COL_DRAFT_SESSION}, true);
        if (!empty($draftSession)) {
            $session2 = $draftSession['session2'] ?? [];
            $session3 = $draftSession['session3'] ?? [];
            if (!empty($session2) && isset($session2['hotelSnList'])) {
                $hotelSnList = $session2['hotelSnList'];
                $hotelList = $this->_getHotelRoomTypeList($hotelSnList);
                $draftSession['session2']['hotelSnList'] = $hotelList;
            }
            if (!empty($session3) && isset($session3['hotelSnList'])) {
                $hotelSnList = $session3['hotelSnList'];
                $hotelList = $this->_getHotelRoomTypeList($hotelSnList);
                $draftSession['session3']['hotelSnList'] = $hotelList;
            }
        }
        $promotion->{DraftPromotion::COL_DRAFT_SESSION} = $draftSession;
        $promotionGroup = PromotionGroup::where(PromotionGroup::COL_SN, $promotion->{DraftPromotion::COL_PROMOTION_GROUP_SN})->first();
        $promotion->{DraftPromotion::VAR_PROMOTION_GROUP_NAME} = $promotionGroup->{PromotionGroup::COL_TITLE} ?? "";
        return InfoDraftPromotionOutputDTO::assemble($promotion);
    }

    private function _getHotelRoomTypeList(array $hotelSnList)
    {
        $hotelList = [];
        foreach ($hotelSnList as $value) {
            $hotelSn = $value['sn'] ?? null;
            $roomTypeList = $value['roomTypeList'] ?? [];
            if (!empty($hotelSn) && !empty($roomTypeList)) {
                $hotel = Hotel::where(Hotel::COL_SN, $hotelSn)->first([
                    Hotel::COL_SN,
                    Hotel::COL_CODE,
                    Hotel::COL_NAME,
                    Hotel::COL_HOTEL_STATUS,
                    Hotel::COL_ADDRESS,
                    Hotel::COL_DISTRICT_SN,
                    Hotel::COL_PROVINCE_SN,
                ]);
                $_roomTypeSnList = $this->_getRoomTypeSnList($roomTypeList);
                $roomTypes = RoomType::whereIn(RoomType::COL_SN, $_roomTypeSnList)->get([
                    RoomType::COL_SN,
                    RoomType::COL_NAME,
                    RoomType::COL_SHORT_NAME,
                ]);
                $roomTypeForHotel = $this->_toHotel($hotel, $roomTypes, $_roomTypeSnList);
                $hotelList[] = $roomTypeForHotel;
            }
        }
        return $hotelList;
    }

    private function _getRoomTypeSnList(array $roomTypeList)
    {
        $_roomTypeSnList = [];
        foreach ($roomTypeList as $roomType) {
            if ($roomType['status'] == true) {
                $_roomTypeSnList[] = $roomType['sn'];
            }
        }
        return $_roomTypeSnList;
    }

    private function _toHotel(Hotel $hotel, Collection $roomType, array $roomTypeSnList)
    {
        $_hotel['sn'] = $hotel->{Hotel::COL_SN};
        $_hotel['code'] = $hotel->{Hotel::COL_CODE};
        $_hotel['name'] = $hotel->{Hotel::COL_NAME};
        $_hotel['status'] = $hotel->{Hotel::COL_HOTEL_STATUS};
        $_hotel['address'] = $hotel->{Hotel::COL_ADDRESS};
        $_hotel['districtSn'] = $hotel->{Hotel::COL_DISTRICT_SN};
        $_hotel['provinceSn'] = $hotel->{Hotel::COL_PROVINCE_SN};
        $_hotel['roomTypeList'] = $this->_toRoomType($roomType, $roomTypeSnList);
        return $_hotel;
    }

    private function _toRoomType(Collection $roomTypes, array $roomTypeSnList)
    {
        $roomTypeList = [];
        foreach ($roomTypes as $roomType) {
            $roomTypeList[] = [
                'sn' => $roomType->{RoomType::COL_SN},
                'name' => $roomType->{RoomType::COL_NAME},
                'shortName' => $roomType->{RoomType::COL_SHORT_NAME},
                'status' => in_array($roomType->{RoomType::COL_SN}, $roomTypeSnList) ? true : false,
            ];
        }
        return $roomTypeList;
    }
}
