<?php

namespace App\Actions\Promotion\SA;

use App\DTOs\Web\SA\Promotion\GetVoucherCodeInputDTO;
use App\DTOs\Web\SA\Promotion\GetVoucherCodeOutputDTO;
use App\Repositories\Interfaces\VoucherCodeRepositoryInterface;

class GetVoucherCode
{
    protected $voucherCodeRepository;

    public function __construct(
        VoucherCodeRepositoryInterface $voucherCodeRepository
    )
    {
        $this->voucherCodeRepository = $voucherCodeRepository;
    }

    public function handle(GetVoucherCodeInputDTO $getVoucherCodeInputDTO): GetVoucherCodeOutputDTO
    {
        $couponSn = $getVoucherCodeInputDTO->getCouponSn();
        $excludeVoucherSn = $getVoucherCodeInputDTO->getExcludeVoucherSn();
        $keyword = $getVoucherCodeInputDTO->getKeyword();
        $limit = $getVoucherCodeInputDTO->getLimit();
        $voucherCodes = $this->voucherCodeRepository->getVoucherCode($couponSn, $excludeVoucherSn, $keyword, $limit);

        if ($voucherCodes->isEmpty()) {
            return new GetVoucherCodeOutputDTO();
        }

        return GetVoucherCodeOutputDTO::assemble($voucherCodes);
    }
}
