<?php

namespace App\Actions\Promotion\SA;

use App\Constants\VoucherCode as VoucherCodeConst;
use App\Constants\VoucherCondition as VoucherConditionConst;
use App\DTOs\Web\SA\Promotion\ImportsVoucherCodeInputDTO;
use App\DTOs\Web\SA\Promotion\ImportsVoucherCodeOutputDTO;
use App\DTOs\Web\SA\Promotion\UpdateVoucherCodeInputDTO;
use App\Libraries\Maatwebsite\Excel\Imports\VoucherCodeImport;
use Exception;
use Illuminate\Support\Facades\DB;
use Maatwebsite\Excel\Facades\Excel;

class ImportsVoucherCode
{
    public function handle(ImportsVoucherCodeInputDTO $importsVoucherCodeInputDTO): ImportsVoucherCodeOutputDTO
    {
        DB::connection('mysql')->beginTransaction();
        try {
            $type = $importsVoucherCodeInputDTO->getType();
            $code = $importsVoucherCodeInputDTO->getCode();
            $couponSn = $importsVoucherCodeInputDTO->getCouponSn();
            $voucherCodeList = [];
            if ($type != VoucherCodeConst::TYPE_APPLY['COMMON']) {
                $file = $importsVoucherCodeInputDTO->getFile();
                if (!empty($file)) {
                    $vouchers = Excel::toArray(new VoucherCodeImport(), $file)[0];
                    foreach ($vouchers as $values) {
                        $voucherCodeList[] = $values[0];
                    }
                }
            }

            $updateVoucherCode = app(UpdateVoucherCode::class);
            $updateVoucherCodeInputDTO = new UpdateVoucherCodeInputDTO();
            $updateVoucherCodeInputDTO->setCouponSn($couponSn);
            $updateVoucherCodeInputDTO->setType($type);
            if ($type == VoucherConditionConst::TYPE['COMMON']) {
                $updateVoucherCodeInputDTO->setCode($code);
            } else {
                $updateVoucherCodeInputDTO->setVoucherCodeList($voucherCodeList);
            }
            $updateVoucherCodeOutputDTO = $updateVoucherCode->handle($updateVoucherCodeInputDTO);
            DB::connection('mysql')->commit();
            return ImportsVoucherCodeOutputDTO::assemble(
                $updateVoucherCodeOutputDTO->getNumErrorFormat(),
                $updateVoucherCodeOutputDTO->getNumErrorExist()
            );
        } catch (Exception $e) {
            DB::connection('mysql')->rollBack();
            report($e);
            throw $e;
        }
    }
}
