<?php

namespace App\Actions\Promotion\SA;

use App\DTOs\Web\SA\PromotionGroup\AddPromotionGroupInputDTO;
use App\DTOs\Web\SA\PromotionGroup\AddPromotionGroupOutputDTO;
use App\Models\PromotionGroup;
use App\Repositories\Interfaces\PromotionGroupRepositoryInterface;

class AddPromotionGroup
{
    protected $promotionGroupRepository;

    public function __construct(
        PromotionGroupRepositoryInterface $promotionGroupRepository
    )
    {
        $this->promotionGroupRepository = $promotionGroupRepository;
    }

    public function handle(AddPromotionGroupInputDTO $addPromotionGroupInputDTO): AddPromotionGroupOutputDTO
    {
        $addPromotionGroup = PromotionGroup::create($addPromotionGroupInputDTO->toArray());
        // Update idx
        $this->promotionGroupRepository->update([PromotionGroup::COL_IDX => $addPromotionGroup->{PromotionGroup::COL_SN}], $addPromotionGroup->{PromotionGroup::COL_SN});
        $promotionGroup = PromotionGroup::find($addPromotionGroup->{PromotionGroup::COL_SN});
        return AddPromotionGroupOutputDTO::assemble($promotionGroup);
    }
}
