<?php

namespace App\Actions\Promotion\SA;

use App\Constants\Globals\QueueName as QueueNameConst;
use App\DTOs\Web\SA\Promotion\ExportUserAppliedV1InputDTO;
use App\Jobs\Exports\Promotion\ExportJob;
use App\Repositories\Interfaces\CouponIssuedRepositoryInterface;

class ExportUserAppliedV1
{
    protected $couponIssuedRepository;

    public function __construct(
        CouponIssuedRepositoryInterface $couponIssuedRepository
    )
    {
        $this->couponIssuedRepository = $couponIssuedRepository;
    }

    public function handle(ExportUserAppliedV1InputDTO $exportUserAppliedV1InputDTO): void
    {
        $promotionSn = $exportUserAppliedV1InputDTO->getPromotionSn();
        $keyword = $exportUserAppliedV1InputDTO->getKeyword();
        $status = $exportUserAppliedV1InputDTO->getStatus();
        $limit = $exportUserAppliedV1InputDTO->getLimit();
        $export = $exportUserAppliedV1InputDTO->getExport();
        $getUserApplied = $this->couponIssuedRepository->getUserApplied($keyword, $promotionSn, $status, $limit, $export);

        $export = new ExportJob(authInfo()->getSn(), $getUserApplied);
        dispatch($export->onQueue(QueueNameConst::INIT_POINT_EXPORTS));
    }
}
