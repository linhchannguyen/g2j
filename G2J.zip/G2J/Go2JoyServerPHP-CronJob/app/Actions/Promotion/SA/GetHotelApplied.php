<?php

namespace App\Actions\Promotion\SA;

use App\Constants\CouponForHotel as CouponForHotelConst;
use App\Constants\Globals\HotelAction as HotelActionConst;
use App\Constants\Hotel as HotelConst;
use App\Constants\UseCondition as UseConditionConst;
use App\DTOs\Web\SA\Promotion\GetHotelAppliedInputDTO;
use App\DTOs\Web\SA\Promotion\GetHotelAppliedOutputDTO;
use App\Models\Hotel;
use App\Models\HotelAcceptPromotion;
use App\Repositories\Interfaces\PromotionRepositoryInterface;

class GetHotelApplied
{
    protected $promotionRepository;

    public function __construct(
        PromotionRepositoryInterface $promotionRepository
    )
    {
        $this->promotionRepository = $promotionRepository;
    }

    public function handle(GetHotelAppliedInputDTO $getHotelAppliedInputDTO): GetHotelAppliedOutputDTO
    {
        $promotionSn = $getHotelAppliedInputDTO->getPromotionSn();
        $keyword = $getHotelAppliedInputDTO->getKeyword();
        $applyTarget = $getHotelAppliedInputDTO->getApplyTarget();
        $hotelDiscount = $getHotelAppliedInputDTO->getHotelDiscount();
        $couponSn = $getHotelAppliedInputDTO->getCouponSn();
        $status = $getHotelAppliedInputDTO->getStatus();
        $limit = $getHotelAppliedInputDTO->getLimit();
        $hotelApplied = $this->promotionRepository->getHotelAppliedAll($keyword, [], HotelConst::STATUS['CONTRACTED'], HotelConst::ORIGIN['GO2JOY'], $limit);
        $hotelAppliedList = $this->promotionRepository->getHotelApplied($promotionSn, null, false, $limit);
        if ($applyTarget == UseConditionConst::APPLY_TARGET['ALL']) {
            if ($hotelDiscount != 0) {
                if ($status == HotelActionConst::APPLY_COUPON_HOTEL['NOT_YET']) {
                    $hotelApplied = $this->promotionRepository->getHotelAppliedAll($keyword, $hotelAppliedList ?? [], HotelConst::STATUS['CONTRACTED'], HotelConst::ORIGIN['GO2JOY'], $limit);
                } else if ($status == HotelActionConst::APPLY_COUPON_HOTEL['JOINED']) {
                    $hotelApplied = $this->promotionRepository->getHotelApplied($promotionSn, $keyword, true, $limit);
                }
            } else {
                if ($status == HotelActionConst::APPLY_COUPON_HOTEL['NOT_YET']) {
                    return new GetHotelAppliedOutputDTO();
                }
            }
        } else {
            $couponHotelList = $this->promotionRepository->getHotelAppliedWithOutApplyTargetAll($couponSn, CouponForHotelConst::TYPE['USE'], null, [], false, $limit);
            if ($applyTarget == UseConditionConst::APPLY_TARGET['ALL_BUT_EXCLUDE']) {
                $hotelApplied = $this->promotionRepository->getHotelAppliedAll($keyword, $couponHotelList ?? [], HotelConst::STATUS['CONTRACTED'], HotelConst::ORIGIN['GO2JOY'], $limit);
                if ($status == HotelActionConst::APPLY_COUPON_HOTEL['NOT_YET']) {
                    $mergedArray = array_merge($hotelAppliedList, $couponHotelList);
                    $hotelAppliedList = $mergedArray;
                    $hotelApplied = $this->promotionRepository->getHotelAppliedAll($keyword, $mergedArray ?? [], HotelConst::STATUS['CONTRACTED'], HotelConst::ORIGIN['GO2JOY'], $limit);
                } else if ($status == HotelActionConst::APPLY_COUPON_HOTEL['JOINED']) {
                    $hotelApplied = $this->promotionRepository->getHotelApplied($promotionSn, $keyword, true, $limit);
                }
            } else {
                $hotelApplied = $this->promotionRepository->getHotelAppliedWithOutApplyTargetAll($couponSn, CouponForHotelConst::TYPE['USE'], $keyword, [], true, $limit);
                if ($status == HotelActionConst::APPLY_COUPON_HOTEL['NOT_YET']) {
                    $hotelApplied = $this->promotionRepository->getHotelAppliedWithOutApplyTargetAll($couponSn, CouponForHotelConst::TYPE['USE'], $keyword, $hotelAppliedList ?? [], true, $limit);
                } else if ($status == HotelActionConst::APPLY_COUPON_HOTEL['JOINED']) {
                    $hotelApplied = $this->promotionRepository->getHotelApplied($promotionSn, $keyword, true, $limit);
                }
            }
        }

        if ($hotelApplied->isEmpty()) {
            return new GetHotelAppliedOutputDTO();
        }
        $this->checkHotelAcceptPromotion($hotelApplied, $hotelAppliedList, $promotionSn, $applyTarget, $hotelDiscount);
        return GetHotelAppliedOutputDTO::assemble($hotelApplied);
    }

    public function checkHotelAcceptPromotion($hotelApplied, $hotelAppliedList, $promotionSn, $applyTarget, $hotelDiscount)
    {
        $hotelAccept = HotelAcceptPromotion::where([
            HotelAcceptPromotion::COL_PROMOTION_SN => $promotionSn
        ])->pluck(HotelAcceptPromotion::COL_HOTEL_SN)->toArray();
        foreach ($hotelApplied as $value) {
            if ($applyTarget == UseConditionConst::APPLY_TARGET['ALL']) {
                $value->{Hotel::COL_HOTEL_STATUS} = 1;
                if ((empty($hotelAccept) || !in_array($value->{Hotel::COL_SN}, $hotelAccept)) && $hotelDiscount != 0) {
                    $value->{Hotel::COL_HOTEL_STATUS} = 0;
                }
            } else {
                $value->{Hotel::COL_HOTEL_STATUS} = in_array($value->{Hotel::COL_SN}, ($hotelAppliedList ?? [])) ? 1 : 0;
            }
        }
    }
}
