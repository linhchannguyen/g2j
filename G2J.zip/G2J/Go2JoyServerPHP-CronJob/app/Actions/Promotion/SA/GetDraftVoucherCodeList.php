<?php

namespace App\Actions\Promotion\SA;

use App\DTOs\Web\SA\Promotion\GetDraftVoucherCodeListInputDTO;
use App\DTOs\Web\SA\Promotion\GetDraftVoucherCodeListOutputDTO;
use App\Repositories\Interfaces\DraftVoucherConditionRepositoryInterface;

class GetDraftVoucherCodeList
{
    protected $draftVoucherConditionRepository;

    public function __construct(
        DraftVoucherConditionRepositoryInterface $draftVoucherConditionRepository
    )
    {
        $this->draftVoucherConditionRepository = $draftVoucherConditionRepository;
    }

    public function handle(GetDraftVoucherCodeListInputDTO $getDraftVoucherCodeListInputDTO): GetDraftVoucherCodeListOutputDTO
    {
        $limit = $getDraftVoucherCodeListInputDTO->getLimit();
        $keyword = $getDraftVoucherCodeListInputDTO->getKeyword();
        $draftPromotionSn = $getDraftVoucherCodeListInputDTO->getDraftPromotionSn();
        $draftVoucherConditionList = $this->draftVoucherConditionRepository->getDraftVoucherCodeList($keyword, $draftPromotionSn, $limit);

        if ($draftVoucherConditionList->isEmpty()) {
            return new GetDraftVoucherCodeListOutputDTO();
        }

        return GetDraftVoucherCodeListOutputDTO::assemble($draftVoucherConditionList);
    }
}
