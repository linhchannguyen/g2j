<?php

namespace App\Actions\Promotion\SA;


use App\DTOs\Web\SA\PromotionGroup\UpdatePromotionGroupInputDTO;
use App\Models\PromotionGroup;
use App\Repositories\Interfaces\PromotionGroupRepositoryInterface;

class UpdatePromotionGroup
{
    protected $promotionGroupRepository;

    public function __construct(
        PromotionGroupRepositoryInterface $promotionGroupRepository
    )
    {
        $this->promotionGroupRepository = $promotionGroupRepository;
    }

    public function handle(UpdatePromotionGroupInputDTO $updatePromotionGroupInputDTO): void
    {
        $oldPromotionGroup = $this->promotionGroupRepository->find($updatePromotionGroupInputDTO->getSn(), ['*']);
        $oldPromotionGroup->{PromotionGroup::COL_TITLE} = $updatePromotionGroupInputDTO->getTitle();
        $oldPromotionGroup->{PromotionGroup::COL_UPDATE_STAFF_SN} = $updatePromotionGroupInputDTO->getUpdateStaffSn();
        $oldPromotionGroup->{PromotionGroup::COL_LIST_PROVINCE_SN} = $updatePromotionGroupInputDTO->getListProvinceSn();
        $this->promotionGroupRepository->update($oldPromotionGroup->toArray(), $updatePromotionGroupInputDTO->getSn());
    }
}
