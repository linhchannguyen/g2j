<?php

namespace App\Actions\Promotion\SA;

use App\Constants\Globals\Code as CodeConst;
use App\Constants\CouponForHotel as CouponForHotelConst;
use App\Constants\CouponForUserGroup as CouponForUserGroupConst;
use App\Constants\IssueCondition as IssueConditionConst;
use App\Constants\Promotion as PromotionConst;
use App\Constants\PromotionImage as PromotionImageConst;
use App\Constants\VoucherCondition as VoucherConditionConst;
use App\DTOs\Web\SA\Promotion\AddPromotionInputDTO;
use App\DTOs\Web\SA\Promotion\AddPromotionOutputDTO;
use App\DTOs\Web\SA\Promotion\SaveApplyingHotelDTO;
use App\DTOs\Web\SA\Promotion\UpdateVoucherCodeInputDTO;
use App\Exceptions\ServiceException;
use App\Helpers\ConvertHelper;
use App\Models\Coupon;
use App\Models\CouponForUserGroup;
use App\Models\DraftPromotion;
use App\Models\DraftVoucherCondition;
use App\Models\IssueCondition;
use App\Models\Promotion;
use App\Models\PromotionGroup;
use App\Models\PromotionImage;
use App\Models\PromotionTimeFrame;
use App\Models\UseCondition;
use App\Repositories\Interfaces\CouponForHotelRepositoryInterface;
use App\Repositories\Interfaces\CouponForUserGroupRepositoryInterface;
use App\Repositories\Interfaces\CouponRepositoryInterface;
use App\Repositories\Interfaces\HotelAcceptPromotionRepositoryInterface;
use App\Repositories\Interfaces\HotelRepositoryInterface;
use App\Repositories\Interfaces\IssueConditionRepositoryInterface;
use App\Repositories\Interfaces\PromotionGroupRepositoryInterface;
use App\Repositories\Interfaces\PromotionImageRepositoryInterface;
use App\Repositories\Interfaces\PromotionRepositoryInterface;
use App\Repositories\Interfaces\PromotionTimeFrameRepositoryInterface;
use App\Repositories\Interfaces\UseConditionRepositoryInterface;
use App\Repositories\Interfaces\VoucherConditionRepositoryInterface;
use Exception;
use Illuminate\Support\Facades\DB;
use stdClass;

class AddPromotion
{
    const FILE_LANGUAGE_NAME = 'sa/promotion';

    protected $promotionRepository;

    protected $promotionGroupRepository;

    protected $promotionTimeFrameRepository;

    protected $promotionImageRepository;

    protected $voucherConditionRepository;

    protected $useConditionRepository;

    protected $couponForUserGroupRepository;

    protected $couponForHotelRepository;

    protected $hotelRepository;

    protected $issueConditionRepository;

    protected $couponRepository;

    protected $hotelAcceptPromotionRepository;

    public function __construct(
        PromotionGroupRepositoryInterface       $promotionGroupRepository,
        PromotionRepositoryInterface            $promotionRepository,
        PromotionTimeFrameRepositoryInterface   $promotionTimeFrameRepository,
        PromotionImageRepositoryInterface       $promotionImageRepository,
        VoucherConditionRepositoryInterface     $voucherConditionRepository,
        UseConditionRepositoryInterface         $useConditionRepository,
        CouponForUserGroupRepositoryInterface   $couponForUserGroupRepository,
        CouponForHotelRepositoryInterface       $couponForHotelRepository,
        HotelRepositoryInterface                $hotelRepository,
        IssueConditionRepositoryInterface       $issueConditionRepository,
        CouponRepositoryInterface               $couponRepository,
        HotelAcceptPromotionRepositoryInterface $hotelAcceptPromotionRepository
    )
    {
        $this->promotionGroupRepository = $promotionGroupRepository;
        $this->promotionRepository = $promotionRepository;
        $this->promotionTimeFrameRepository = $promotionTimeFrameRepository;
        $this->promotionImageRepository = $promotionImageRepository;
        $this->voucherConditionRepository = $voucherConditionRepository;
        $this->useConditionRepository = $useConditionRepository;
        $this->couponForUserGroupRepository = $couponForUserGroupRepository;
        $this->couponForHotelRepository = $couponForHotelRepository;
        $this->hotelRepository = $hotelRepository;
        $this->issueConditionRepository = $issueConditionRepository;
        $this->couponRepository = $couponRepository;
        $this->hotelAcceptPromotionRepository = $hotelAcceptPromotionRepository;
    }

    public function handle(AddPromotionInputDTO $addPromotionInputDTO): AddPromotionOutputDTO
    {
        DB::connection('mysql')->beginTransaction();
        try {
            $createStaffSn = $addPromotionInputDTO->getCreateStaffSn();
            // Create promotion
            $getDraftPromotionSn = $addPromotionInputDTO->getDraftPromotionSn();
            $draftPromotion = DraftPromotion::find($getDraftPromotionSn);
            $listPromotionGroupSn = $draftPromotion->{DraftPromotion::COL_PROMOTION_GROUP_SN};
            $promotionGroup = PromotionGroup::find($listPromotionGroupSn);
            if (empty($promotionGroup)) {
                throw new ServiceException(ConvertHelper::getMessage(self::FILE_LANGUAGE_NAME, CodeConst::API_PRN_021), CodeConst::API_PRN_021);
            }
            $addPromotionInputDTO->setListPromotionGroupSn($listPromotionGroupSn);
            $promotionData = [
                Promotion::COL_TITLE => $addPromotionInputDTO->getTitle(),
                Promotion::COL_TITLE_EN => $addPromotionInputDTO->getTitleEn(),
                Promotion::COL_FORM_OF_SPONSOR => $addPromotionInputDTO->getFormOfSponsor(),
                Promotion::COL_CONTENT => $addPromotionInputDTO->getContent(),
                Promotion::COL_CONTENT_EN => $addPromotionInputDTO->getContentEn(),
                Promotion::COL_TYPE => $addPromotionInputDTO->getType(),
                Promotion::COL_DISPLAY_HOTEL => $addPromotionInputDTO->getDisplayHotel(),
                Promotion::COL_NUM_OF_COUPON => $addPromotionInputDTO->getNumOfCoupon(),
                Promotion::COL_APPLY_START => $addPromotionInputDTO->getApplyStart(),
                Promotion::COL_APPLY_END => $addPromotionInputDTO->getApplyEnd(),
                Promotion::COL_STATUS => $addPromotionInputDTO->getStatus(),
                Promotion::COL_GO2JOY_DISCOUNT => $addPromotionInputDTO->getGo2joyDiscount(),
                Promotion::COL_HOTEL_DISCOUNT => $addPromotionInputDTO->getHotelDiscount(),
                Promotion::COL_CREATE_STAFF_SN => $createStaffSn,
                Promotion::COL_LIST_PROMOTION_GROUP_SN => $addPromotionInputDTO->getListPromotionGroupSn()
            ];
            $newPromotion = $this->promotionRepository->create($promotionData);
            $newPromotionSn = $newPromotion->{Promotion::COL_SN};

            $this->_addPromotionToPromotionGroup($promotionGroup, $newPromotionSn);
            $draftPromotion->delete();
            // End create promotion

            // Create promotion image
            $promotionImageData = [
                PromotionImage::COL_PROMOTION_SN => $newPromotionSn,
                PromotionImage::COL_TYPE_DISPLAY => PromotionImageConst::TYPE['DETAIL'],
                PromotionImage::COL_IMAGE_PATH => $addPromotionInputDTO->getImagePath(),
                PromotionImage::COL_ORIGINAL_NAME => $addPromotionInputDTO->getOriginalName(),
            ];
            $this->promotionImageRepository->create($promotionImageData);
            // End create promotion image

            // Create promotion time frame
            if (!empty($addPromotionInputDTO->getStartTime()) && !empty($addPromotionInputDTO->getEndTime())) {
                $promotionTimeFrameData = [
                    PromotionTimeFrame::COL_PROMOTION_SN => $newPromotionSn,
                    PromotionTimeFrame::COL_START_TIME => $addPromotionInputDTO->getStartTime(),
                    PromotionTimeFrame::COL_END_TIME => $addPromotionInputDTO->getEndTime()
                ];
                $this->promotionTimeFrameRepository->create($promotionTimeFrameData);
            }
            // End create promotion time frame

            // Create coupon
            $roomApplyInfo = new stdClass();
            $roomApplyInfo->flashsale = false;
            $roomApplyInfo->normal = true;
            $roomApplyInfo->roomTypeSnList = [];
            $roomApplyInfo = ConvertHelper::toJson($roomApplyInfo);
            $couponData = [
                Coupon::COL_PROMOTION_SN => $newPromotionSn,
                Coupon::COL_ROOM_APPLY_INFO => $roomApplyInfo,
                Coupon::COL_TITLE => $addPromotionInputDTO->getTitle(),
                Coupon::COL_CODE => $addPromotionInputDTO->getCode(),
                Coupon::COL_START_DATE => $addPromotionInputDTO->getStartDate(),
                Coupon::COL_END_DATE => $addPromotionInputDTO->getEndDate(),
                Coupon::COL_NUM_ACTIVE_DAY => $addPromotionInputDTO->getNumActiveDay(),
                Coupon::COL_DISCOUNT_TYPE => $addPromotionInputDTO->getDiscountType(),
                Coupon::COL_DISCOUNT => $addPromotionInputDTO->getDiscount(),
                Coupon::COL_MAX_NUM => $addPromotionInputDTO->getMaxNum(),
                Coupon::COL_MAX_DISCOUNT => $addPromotionInputDTO->getMaxDiscount(),
                Coupon::COL_DIRECT_DISCOUNT => $addPromotionInputDTO->getDirectDiscount(),
                Coupon::COL_GIFT_NAME => $addPromotionInputDTO->getGiftName(),
                Coupon::COL_NUM_GIVE_HOURS => $addPromotionInputDTO->getNumGiveHours()
            ];
            $newCoupon = $this->couponRepository->create($couponData);
            $newCouponSn = $newCoupon->{Coupon::COL_SN};
            // End create coupon

            // Create use condition
            $getUseConditionApplyTarget = $addPromotionInputDTO->getUseConditionApplyTarget();
            $useConditionData = [
                UseCondition::COL_COUPON_SN => $newCouponSn,
                UseCondition::COL_HOTEL_ACCEPT => "[]",
                UseCondition::COL_APPLY_TARGET => $getUseConditionApplyTarget,
                UseCondition::COL_HOURLY => $addPromotionInputDTO->getUseConditionHourly(),
                UseCondition::COL_NUM_HOURS_CONDITION => $addPromotionInputDTO->getNumHoursCondition(),
                UseCondition::COL_NUM_HOURS => $addPromotionInputDTO->getUseConditionNumHours(),
                UseCondition::COL_START_TIME => $addPromotionInputDTO->getUseConditionStartTime(),
                UseCondition::COL_END_TIME => $addPromotionInputDTO->getUseConditionEndTime(),
                UseCondition::COL_DAILY => $addPromotionInputDTO->getUseConditionDaily(),
                UseCondition::COL_NUM_DAYS_CONDITION => $addPromotionInputDTO->getNumDaysCondition(),
                UseCondition::COL_NUM_DAYS => $addPromotionInputDTO->getUseConditionNumDays(),
                UseCondition::COL_OVERNIGHT => $addPromotionInputDTO->getUseConditionOvernight(),
                UseCondition::COL_SUNDAY => $addPromotionInputDTO->getUseConditionSunday(),
                UseCondition::COL_MONDAY => $addPromotionInputDTO->getUseConditionMonday(),
                UseCondition::COL_TUESDAY => $addPromotionInputDTO->getUseConditionTuesday(),
                UseCondition::COL_WEDNESDAY => $addPromotionInputDTO->getUseConditionWednesday(),
                UseCondition::COL_THURSDAY => $addPromotionInputDTO->getUseConditionThursday(),
                UseCondition::COL_FRIDAY => $addPromotionInputDTO->getUseConditionFriday(),
                UseCondition::COL_SATURDAY => $addPromotionInputDTO->getUseConditionSaturday(),
                UseCondition::COL_PAYMENT_METHOD => $addPromotionInputDTO->getUseConditionPaymentMethod(),
                UseCondition::COL_MIN_MONEY => $addPromotionInputDTO->getUseConditionMinMoney(),
                UseCondition::COL_NUM_COUPON_LIMIT => $addPromotionInputDTO->getUseConditionNumCouponLimit(),
                UseCondition::COL_MAX_ONE_DAY => $addPromotionInputDTO->getUseConditionMaxOneDay(),
                UseCondition::COL_MAX_ONE_HOTEL => $addPromotionInputDTO->getUseConditionMaxOneHotel(),
            ];
            $this->useConditionRepository->create($useConditionData);
            $getUseConditionHotelSnList = $addPromotionInputDTO->getUseConditionHotelSnList();
            $getUseConditionRoomTypeList = $addPromotionInputDTO->getUseConditionRoomTypeList();
            $strUseConditionHotelSnList = $getUseConditionHotelSnList ? trim($getUseConditionHotelSnList, ',') : '';
            if (!str_starts_with($strUseConditionHotelSnList, '[')) {
                $strUseConditionHotelSnList = '[' . $strUseConditionHotelSnList . ']';
            }
            $useConditionHotelSnList = ConvertHelper::toArray($strUseConditionHotelSnList);
            $saveApplyingHotelDTO = SaveApplyingHotelDTO::fromParameter(
                $getUseConditionApplyTarget,
                CouponForHotelConst::TYPE['USE'],
                $newCouponSn,
                $useConditionHotelSnList,
                $getUseConditionRoomTypeList
            );
            $saveApplyingHotel = app(SaveApplyingHotel::class);
            $saveApplyingHotel->handle($saveApplyingHotelDTO);
            // End create use condition

            $type = $addPromotionInputDTO->getType();
            $typeDetail = $addPromotionInputDTO->getApplyTypeDetail();
            $getIssueConditionApplyTarget = $addPromotionInputDTO->getIssueConditionApplyTarget();
            if ($type == PromotionConst::TYPE['APPLY']) { // Create coupon for user group
                $strProvinceSnList = $addPromotionInputDTO->getApplyProvinceSnList();
                $strProvinceSnList = $strProvinceSnList ? trim($strProvinceSnList, ',') : '';
                if (!str_starts_with($strProvinceSnList, '[')) {
                    $strProvinceSnList = '[' . $strProvinceSnList . ']';
                }
                $couponForUserGroupData = [
                    CouponForUserGroup::COL_COUPON_SN => $newCouponSn,
                    CouponForUserGroup::COL_TYPE => ($typeDetail == CouponForUserGroupConst::TYPE_DETAIL['ALL']) ? CouponForUserGroupConst::TYPE['ALL'] : CouponForUserGroupConst::TYPE['JUST_APPLY'],
                    CouponForUserGroup::COL_TYPE_DETAIL => $typeDetail,
                    CouponForUserGroup::COL_NUM_CHECK_IN => $addPromotionInputDTO->getApplyNumCheckin(),
                    CouponForUserGroup::COL_START_DATE => $addPromotionInputDTO->getApplyStartDate(),
                    CouponForUserGroup::COL_END_DATE => $addPromotionInputDTO->getApplyEndDate(),
                    CouponForUserGroup::COL_CREATE_STAFF_SN => $createStaffSn,
                    CouponForUserGroup::COL_PROVINCE_SN_LIST => $strProvinceSnList,
                ];
                $this->couponForUserGroupRepository->create($couponForUserGroupData);
            } else if ($type == PromotionConst::TYPE['VOUCHER_CODE']) { // Create voucher condition
                $getVoucherType = $addPromotionInputDTO->getVoucherType();
                $updateVoucherCode = app(UpdateVoucherCode::class);
                $updateVoucherCodeInputDTO = new UpdateVoucherCodeInputDTO();
                $updateVoucherCodeInputDTO->setCouponSn($newCouponSn);
                $updateVoucherCodeInputDTO->setType($getVoucherType);
                $draftVoucherCondition = DraftVoucherCondition::where(DraftVoucherCondition::COL_DRAFT_PROMOTION_SN, $getDraftPromotionSn)->pluck(DraftVoucherCondition::COL_CODE)->toArray();
                if (!empty($draftVoucherCondition)) {
                    if ($getVoucherType == VoucherConditionConst::TYPE['COMMON']) {
                        $updateVoucherCodeInputDTO->setCode($draftVoucherCondition[0]);
                    } else {
                        $updateVoucherCodeInputDTO->setVoucherCodeList($draftVoucherCondition);
                    }
                    $updateVoucherCode->handle($updateVoucherCodeInputDTO);
                    DraftVoucherCondition::where(DraftVoucherCondition::COL_DRAFT_PROMOTION_SN, $getDraftPromotionSn)->delete();
                }
            } else {
                if ($type != PromotionConst::TYPE['BOOKING']) {
                    $getIssueConditionApplyTarget = IssueConditionConst::APPLY_TARGET['ALL'];
                } else {
                    $getIssueConditionHotelSnList = $addPromotionInputDTO->getIssueConditionHotelSnList();
                    $getIssueConditionRoomTypeList = $addPromotionInputDTO->getIssueConditionRoomTypeList();
                    $strIssueConditionHotelSnList = $getIssueConditionHotelSnList ? trim($getIssueConditionHotelSnList, ',') : '';
                    if (!str_starts_with($strIssueConditionHotelSnList, '[')) {
                        $strIssueConditionHotelSnList = '[' . $strIssueConditionHotelSnList . ']';
                    }
                    $issueConditionHotelSnList = ConvertHelper::toArray($strIssueConditionHotelSnList);
                    $saveApplyingHotelDTO = SaveApplyingHotelDTO::fromParameter(
                        $getIssueConditionApplyTarget,
                        CouponForHotelConst::TYPE['ISSUE'],
                        $newCouponSn,
                        $issueConditionHotelSnList,
                        $getIssueConditionRoomTypeList
                    );
                    $saveApplyingHotel->handle($saveApplyingHotelDTO);
                }
            }
            $issueConditionUpData = [
                IssueCondition::COL_COUPON_SN => $newCouponSn,
                IssueCondition::COL_APPLY_TARGET => $getIssueConditionApplyTarget,
                IssueCondition::COL_HOURLY => $addPromotionInputDTO->getIssueConditionHourly(),
                IssueCondition::COL_HOURLY_START_TIME => $addPromotionInputDTO->getIssueConditionHourlyStartTime(),
                IssueCondition::COL_HOURLY_END_TIME => $addPromotionInputDTO->getIssueConditionHourlyEndTime(),
                IssueCondition::COL_OVERNIGHT => $addPromotionInputDTO->getIssueConditionOvernight(),
                IssueCondition::COL_DAILY => $addPromotionInputDTO->getIssueConditionDaily(),
                IssueCondition::COL_PAY_IN_ADVANCE => $addPromotionInputDTO->getIssueConditionPayInAdvance(),
                IssueCondition::COL_SUNDAY => $addPromotionInputDTO->getIssueConditionSunday(),
                IssueCondition::COL_MONDAY => $addPromotionInputDTO->getIssueConditionMonday(),
                IssueCondition::COL_TUESDAY => $addPromotionInputDTO->getIssueConditionTuesday(),
                IssueCondition::COL_WEDNESDAY => $addPromotionInputDTO->getIssueConditionWednesday(),
                IssueCondition::COL_THURSDAY => $addPromotionInputDTO->getIssueConditionThursday(),
                IssueCondition::COL_FRIDAY => $addPromotionInputDTO->getIssueConditionFriday(),
                IssueCondition::COL_SATURDAY => $addPromotionInputDTO->getIssueConditionSaturday(),
                IssueCondition::COL_START_TIME => $addPromotionInputDTO->getIssueConditionStartTime(),
                IssueCondition::COL_END_TIME => $addPromotionInputDTO->getIssueConditionEndTime(),
                IssueCondition::COL_COUPON => $addPromotionInputDTO->getIssueConditionCoupon(),
                IssueCondition::COL_APPLY_TO_USER => $addPromotionInputDTO->getIssueConditionApplyToUser(),
                IssueCondition::COL_NUM_CHECKIN => $addPromotionInputDTO->getIssueConditionNumCheckin(),
            ];
            $this->issueConditionRepository->create($issueConditionUpData);
            DB::connection('mysql')->commit();
            $response = new stdClass();
            $response->couponSn = $newCouponSn;
            $response->promotionSn = $newPromotionSn;
            return AddPromotionOutputDTO::assemble($response);
        } catch (Exception $e) {
            DB::connection('mysql')->rollBack();
            report($e);
            throw $e;
        }
    }

    private function _addPromotionToPromotionGroup($promotionGroup, $promotionSn)
    {
        $strPromotionList = $promotionGroup->{PromotionGroup::COL_PROMOTION_SN_LIST} ? trim($promotionGroup->{PromotionGroup::COL_PROMOTION_SN_LIST}, ',') : '';
        if (!str_starts_with($strPromotionList, '[')) {
            $strPromotionList = '[' . $strPromotionList . ']';
        }
        $promotionSnList = ConvertHelper::toArray($strPromotionList);
        if (empty($promotionSnList)) {
            $promotionSnList = [];
        }
        $promotionSnList[] = $promotionSn;
        $promotionSnList = array_values(array_unique($promotionSnList));
        if (!empty($promotionSnList)) {
            $this->promotionGroupRepository->update([PromotionGroup::COL_PROMOTION_SN_LIST => ConvertHelper::toJson($promotionSnList)], $promotionGroup->{PromotionGroup::COL_SN});
        }
    }
}
