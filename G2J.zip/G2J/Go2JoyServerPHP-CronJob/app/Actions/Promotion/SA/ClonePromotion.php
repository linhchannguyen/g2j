<?php

namespace App\Actions\Promotion\SA;

use App\Constants\Globals\Code as CodeConst;
use App\Constants\CouponForHotel as CouponForHotelConst;
use App\Constants\CouponForUserGroup as CouponForUserGroupConst;
use App\Constants\IssueCondition as IssueConditionConst;
use App\Constants\Promotion as PromotionConst;
use App\Constants\PromotionImage as PromotionImageConst;
use App\Constants\VoucherCondition as VoucherConditionConst;
use App\DTOs\Web\SA\Promotion\SaveApplyingHotelDTO;
use App\DTOs\Web\SA\Promotion\UpdatePromotionInputDTO;
use App\DTOs\Web\SA\Promotion\UpdateVoucherCodeInputDTO;
use App\Exceptions\ServiceException;
use App\Helpers\ConvertHelper;
use App\Helpers\UploadHelper;
use App\Models\Coupon;
use App\Models\CouponForUserGroup;
use App\Models\IssueCondition;
use App\Models\Promotion;
use App\Models\PromotionImage;
use App\Models\PromotionTimeFrame;
use App\Models\PromotionTransitionRequest;
use App\Models\UseCondition;
use App\Models\VoucherCode;
use App\Repositories\Interfaces\CouponForUserGroupRepositoryInterface;
use App\Repositories\Interfaces\CouponRepositoryInterface;
use App\Repositories\Interfaces\IssueConditionRepositoryInterface;
use App\Repositories\Interfaces\PromotionGroupRepositoryInterface;
use App\Repositories\Interfaces\PromotionImageRepositoryInterface;
use App\Repositories\Interfaces\PromotionRepositoryInterface;
use App\Repositories\Interfaces\PromotionTimeFrameRepositoryInterface;
use App\Repositories\Interfaces\PromotionTransitionRequestRepositoryInterface;
use App\Repositories\Interfaces\UseConditionRepositoryInterface;
use stdClass;

class ClonePromotion
{
    const FILE_LANGUAGE_NAME = 'sa/promotion';

    protected $promotionRepository;

    protected $promotionGroupRepository;

    protected $promotionTimeFrameRepository;

    protected $promotionImageRepository;

    protected $useConditionRepository;

    protected $couponForUserGroupRepository;

    protected $issueConditionRepository;

    protected $couponRepository;

    protected $promotionTransitionRequestRepository;

    public function __construct(
        PromotionGroupRepositoryInterface             $promotionGroupRepository,
        PromotionRepositoryInterface                  $promotionRepository,
        PromotionTimeFrameRepositoryInterface         $promotionTimeFrameRepository,
        PromotionImageRepositoryInterface             $promotionImageRepository,
        UseConditionRepositoryInterface               $useConditionRepository,
        CouponForUserGroupRepositoryInterface         $couponForUserGroupRepository,
        IssueConditionRepositoryInterface             $issueConditionRepository,
        CouponRepositoryInterface                     $couponRepository,
        PromotionTransitionRequestRepositoryInterface $promotionTransitionRequestRepository
    )
    {
        $this->promotionGroupRepository = $promotionGroupRepository;
        $this->promotionRepository = $promotionRepository;
        $this->promotionTimeFrameRepository = $promotionTimeFrameRepository;
        $this->promotionImageRepository = $promotionImageRepository;
        $this->useConditionRepository = $useConditionRepository;
        $this->couponForUserGroupRepository = $couponForUserGroupRepository;
        $this->issueConditionRepository = $issueConditionRepository;
        $this->couponRepository = $couponRepository;
        $this->promotionTransitionRequestRepository = $promotionTransitionRequestRepository;
    }

    public function handle(UpdatePromotionInputDTO $updatePromotionInputDTO): stdClass
    {
        $createStaffSn = $updatePromotionInputDTO->getCreateStaffSn();
        $getPromotionSn = $updatePromotionInputDTO->getPromotionSn();
        $promotion = $this->promotionRepository->find($getPromotionSn);
        $listPromotionGroupSn = $updatePromotionInputDTO->getListPromotionGroupSn();
        $promotion->{Promotion::COL_STATUS} = PromotionConst::STATUS['AWAITING_CONFIRMATION'];
        $promotion->{Promotion::COL_TITLE} = $updatePromotionInputDTO->getTitle();
        $promotion->{Promotion::COL_TITLE_EN} = $updatePromotionInputDTO->getTitleEn();
        $promotion->{Promotion::COL_CONTENT} = $updatePromotionInputDTO->getContent();
        $promotion->{Promotion::COL_CONTENT_EN} = $updatePromotionInputDTO->getContentEn();
        $promotion->{Promotion::COL_NUM_OF_COUPON} = $updatePromotionInputDTO->getNumOfCoupon();
        $promotion->{Promotion::COL_APPLY_START} = $updatePromotionInputDTO->getApplyStart();
        $promotion->{Promotion::COL_APPLY_END} = $updatePromotionInputDTO->getApplyEnd();
        $promotion->{Promotion::COL_GO2JOY_DISCOUNT} = $updatePromotionInputDTO->getGo2joyDiscount();
        $promotion->{Promotion::COL_HOTEL_DISCOUNT} = $updatePromotionInputDTO->getHotelDiscount();
        $promotion->{Promotion::COL_UPDATE_STAFF_SN} = $createStaffSn;
        $promotion->{Promotion::COL_LIST_PROMOTION_GROUP_SN} = $listPromotionGroupSn;
        $promotionData = $promotion->toArray();
        unset($promotionData[Promotion::COL_SN]);
        $newPromotion = $this->promotionRepository->create($promotionData);
        $newPromotionSn = $newPromotion->{Promotion::COL_SN};

        $getOriginalName = $updatePromotionInputDTO->getOriginalName();
        $preSignedUrl = new stdClass;
        if (!empty($getOriginalName)) {
            $extension = pathinfo($getOriginalName, PATHINFO_EXTENSION);
            $pathName = UploadHelper::getPathFromExtension($extension, UploadHelper::FOLDER['PROMOTION']);
            if (!empty($pathName)) {
                $preSignedUrl = UploadHelper::getPreSigned($pathName);
                $promotionImageData = [
                    PromotionImage::COL_PROMOTION_SN => $newPromotionSn,
                    PromotionImage::COL_TYPE_DISPLAY => PromotionImageConst::TYPE['DETAIL'],
                    PromotionImage::COL_IMAGE_PATH => $pathName,
                    PromotionImage::COL_ORIGINAL_NAME => $updatePromotionInputDTO->getOriginalName(),
                ];
                $this->promotionImageRepository->create($promotionImageData);
            }
        }

        if (!empty($updatePromotionInputDTO->getStartTime()) && !empty($updatePromotionInputDTO->getEndTime())) {
            $promotionTimeFrameData = [
                PromotionTimeFrame::COL_PROMOTION_SN => $newPromotionSn,
                PromotionTimeFrame::COL_START_TIME => $updatePromotionInputDTO->getStartTime(),
                PromotionTimeFrame::COL_END_TIME => $updatePromotionInputDTO->getEndTime()
            ];
            $this->promotionTimeFrameRepository->create($promotionTimeFrameData);
        }

        $coupon = $this->couponRepository->findByField(Coupon::COL_PROMOTION_SN, $getPromotionSn)->first();
        if (empty($coupon)) {
            throw new ServiceException(ConvertHelper::getMessage(self::FILE_LANGUAGE_NAME, CodeConst::API_PRN_022), CodeConst::API_PRN_022);
        }
        $coupon->{Coupon::COL_PROMOTION_SN} = $newPromotionSn;
        $coupon->{Coupon::COL_TITLE} = $updatePromotionInputDTO->getTitle();
        $coupon->{Coupon::COL_CODE} = '+' . $updatePromotionInputDTO->getCode();
        $coupon->{Coupon::COL_START_DATE} = $updatePromotionInputDTO->getStartDate();
        $coupon->{Coupon::COL_END_DATE} = $updatePromotionInputDTO->getEndDate();
        $coupon->{Coupon::COL_NUM_ACTIVE_DAY} = $updatePromotionInputDTO->getNumActiveDay();
        $coupon->{Coupon::COL_DISCOUNT} = $updatePromotionInputDTO->getDiscount();
        $coupon->{Coupon::COL_MAX_NUM} = $updatePromotionInputDTO->getMaxNum();
        $coupon->{Coupon::COL_MAX_DISCOUNT} = $updatePromotionInputDTO->getMaxDiscount();
        $coupon->{Coupon::COL_DIRECT_DISCOUNT} = $updatePromotionInputDTO->getDirectDiscount();
        $coupon->{Coupon::COL_GIFT_NAME} = $updatePromotionInputDTO->getGiftName();
        $coupon->{Coupon::COL_NUM_GIVE_HOURS} = $updatePromotionInputDTO->getNumGiveHours();
        $couponSn = $coupon->{Coupon::COL_SN};
        $couponData = $coupon->toArray();
        unset($couponData[Coupon::COL_SN]);
        $newCoupon = $this->couponRepository->create($couponData);
        $newCouponSn = $newCoupon->{Coupon::COL_SN};

        $useCondition = $this->useConditionRepository->findByField(UseCondition::COL_COUPON_SN, $couponSn)->first();
        if (empty($useCondition)) {
            throw new ServiceException(ConvertHelper::getMessage(self::FILE_LANGUAGE_NAME, CodeConst::API_PRN_022), CodeConst::API_PRN_022);
        }
        $getUseConditionApplyTarget = $updatePromotionInputDTO->getUseConditionApplyTarget();
        $useCondition->{UseCondition::COL_COUPON_SN} = $newCouponSn;
        $useCondition->{UseCondition::COL_APPLY_TARGET} = $getUseConditionApplyTarget;
        $useCondition->{UseCondition::COL_HOURLY} = $updatePromotionInputDTO->getUseConditionHourly();
        $useCondition->{UseCondition::COL_NUM_HOURS_CONDITION} = $updatePromotionInputDTO->getNumHoursCondition();
        $useCondition->{UseCondition::COL_NUM_HOURS} = $updatePromotionInputDTO->getUseConditionNumHours();
        $useCondition->{UseCondition::COL_START_TIME} = $updatePromotionInputDTO->getUseConditionStartTime();
        $useCondition->{UseCondition::COL_END_TIME} = $updatePromotionInputDTO->getUseConditionEndTime();
        $useCondition->{UseCondition::COL_DAILY} = $updatePromotionInputDTO->getUseConditionDaily();
        $useCondition->{UseCondition::COL_NUM_DAYS_CONDITION} = $updatePromotionInputDTO->getNumDaysCondition();
        $useCondition->{UseCondition::COL_NUM_DAYS} = $updatePromotionInputDTO->getUseConditionNumDays();
        $useCondition->{UseCondition::COL_OVERNIGHT} = $updatePromotionInputDTO->getUseConditionOvernight();
        $useCondition->{UseCondition::COL_SUNDAY} = $updatePromotionInputDTO->getUseConditionSunday();
        $useCondition->{UseCondition::COL_MONDAY} = $updatePromotionInputDTO->getUseConditionMonday();
        $useCondition->{UseCondition::COL_TUESDAY} = $updatePromotionInputDTO->getUseConditionTuesday();
        $useCondition->{UseCondition::COL_WEDNESDAY} = $updatePromotionInputDTO->getUseConditionWednesday();
        $useCondition->{UseCondition::COL_THURSDAY} = $updatePromotionInputDTO->getUseConditionThursday();
        $useCondition->{UseCondition::COL_FRIDAY} = $updatePromotionInputDTO->getUseConditionFriday();
        $useCondition->{UseCondition::COL_SATURDAY} = $updatePromotionInputDTO->getUseConditionSaturday();
        $useCondition->{UseCondition::COL_PAYMENT_METHOD} = $updatePromotionInputDTO->getUseConditionPaymentMethod();
        $useCondition->{UseCondition::COL_MIN_MONEY} = $updatePromotionInputDTO->getUseConditionMinMoney();
        $useCondition->{UseCondition::COL_NUM_COUPON_LIMIT} = $updatePromotionInputDTO->getUseConditionNumCouponLimit();
        $useCondition->{UseCondition::COL_MAX_ONE_DAY} = $updatePromotionInputDTO->getUseConditionMaxOneDay();
        $useCondition->{UseCondition::COL_MAX_ONE_HOTEL} = $updatePromotionInputDTO->getUseConditionMaxOneHotel();
        $useConditionData = $useCondition->toArray();
        unset($useConditionData[UseCondition::COL_SN]);
        $this->useConditionRepository->create($useConditionData);
        $getUseConditionHotelSnList = $updatePromotionInputDTO->getUseConditionHotelSnList();
        $getUseConditionRoomTypeList = $updatePromotionInputDTO->getUseConditionRoomTypeList();
        $strUseConditionHotelSnList = $getUseConditionHotelSnList ? trim($getUseConditionHotelSnList, ',') : '';
        if (!str_starts_with($strUseConditionHotelSnList, '[')) {
            $strUseConditionHotelSnList = '[' . $strUseConditionHotelSnList . ']';
        }
        $useConditionHotelSnList = ConvertHelper::toArray($strUseConditionHotelSnList);
        $saveApplyingHotelDTO = SaveApplyingHotelDTO::fromParameter(
            $getUseConditionApplyTarget,
            CouponForHotelConst::TYPE['USE'],
            $newCouponSn,
            $useConditionHotelSnList,
            $getUseConditionRoomTypeList
        );
        $saveApplyingHotel = app(SaveApplyingHotel::class);
        $saveApplyingHotel->handle($saveApplyingHotelDTO);

        $type = $promotion->{Promotion::COL_TYPE};
        $typeDetail = $updatePromotionInputDTO->getApplyTypeDetail();
        $getIssueConditionApplyTarget = $updatePromotionInputDTO->getIssueConditionApplyTarget();
        if ($type == PromotionConst::TYPE['APPLY']) { // Update coupon for user group
            $strProvinceSnList = $updatePromotionInputDTO->getApplyProvinceSnList();
            $strProvinceSnList = $strProvinceSnList ? trim($strProvinceSnList, ',') : '';
            if (!str_starts_with($strProvinceSnList, '[')) {
                $strProvinceSnList = '[' . $strProvinceSnList . ']';
            }
            $couponForUserGroup = $this->couponForUserGroupRepository->findByField(CouponForUserGroup::COL_COUPON_SN, $couponSn)->first();
            if (empty($couponForUserGroup)) {
                throw new ServiceException(ConvertHelper::getMessage(self::FILE_LANGUAGE_NAME, CodeConst::API_PRN_022), CodeConst::API_PRN_022);
            }
            $couponForUserGroup->{CouponForUserGroup::COL_COUPON_SN} = $newCouponSn;
            $couponForUserGroup->{CouponForUserGroup::COL_TYPE} = ($typeDetail == CouponForUserGroupConst::TYPE_DETAIL['ALL']) ? CouponForUserGroupConst::TYPE['ALL'] : CouponForUserGroupConst::TYPE['JUST_APPLY'];
            $couponForUserGroup->{CouponForUserGroup::COL_TYPE_DETAIL} = $typeDetail;
            $couponForUserGroup->{CouponForUserGroup::COL_NUM_CHECK_IN} = $updatePromotionInputDTO->getApplyNumCheckin();
            $couponForUserGroup->{CouponForUserGroup::COL_START_DATE} = $updatePromotionInputDTO->getApplyStartDate();
            $couponForUserGroup->{CouponForUserGroup::COL_END_DATE} = $updatePromotionInputDTO->getApplyEndDate();
            $couponForUserGroup->{CouponForUserGroup::COL_UPDATE_STAFF_SN} = $createStaffSn;
            $couponForUserGroup->{CouponForUserGroup::COL_PROVINCE_SN_LIST} = $strProvinceSnList;
            $couponForUserGroupData = $couponForUserGroup->toArray();
            unset($couponForUserGroupData[CouponForUserGroup::COL_SN]);
            $this->couponForUserGroupRepository->create($couponForUserGroupData);
        } else if ($type == PromotionConst::TYPE['VOUCHER_CODE']) { // Update voucher condition
            $getVoucherType = $updatePromotionInputDTO->getVoucherType();
            $updateVoucherCode = app(UpdateVoucherCode::class);
            $updateVoucherCodeInputDTO = new UpdateVoucherCodeInputDTO();
            $updateVoucherCodeInputDTO->setCouponSn($couponSn);
            $updateVoucherCodeInputDTO->setType($getVoucherType);
            if ($getVoucherType == VoucherConditionConst::TYPE['COMMON']) {
                $updateVoucherCodeInputDTO->setCode($updatePromotionInputDTO->getVoucherCode());
                VoucherCode::where([
                    VoucherCode::COL_COUPON_SN => $couponSn,
                    VoucherCode::COL_TYPE => VoucherConditionConst::TYPE['PRIVATE']
                ])->delete();
                $updateVoucherCode->handle($updateVoucherCodeInputDTO);
            } else {
                $getVoucherCodeDeleteList = $updatePromotionInputDTO->getVoucherCodeDeleteList();
                if (!empty($getVoucherCodeDeleteList)) {
                    VoucherCode::whereIn([
                        VoucherCode::COL_SN => $getVoucherCodeDeleteList
                    ])->delete();
                }
            }
        } else {
            if ($type != PromotionConst::TYPE['BOOKING']) {
                $getIssueConditionApplyTarget = IssueConditionConst::APPLY_TARGET['ALL'];
            } else {
                $getIssueConditionHotelSnList = $updatePromotionInputDTO->getIssueConditionHotelSnList();
                $getIssueConditionRoomTypeList = $updatePromotionInputDTO->getIssueConditionRoomTypeList();
                $strIssueConditionHotelSnList = $getIssueConditionHotelSnList ? trim($getIssueConditionHotelSnList, ',') : '';
                if (!str_starts_with($strIssueConditionHotelSnList, '[')) {
                    $strIssueConditionHotelSnList = '[' . $strIssueConditionHotelSnList . ']';
                }
                $issueConditionHotelSnList = ConvertHelper::toArray($strIssueConditionHotelSnList);
                $saveApplyingHotelDTO = SaveApplyingHotelDTO::fromParameter(
                    $getIssueConditionApplyTarget,
                    CouponForHotelConst::TYPE['ISSUE'],
                    $newCouponSn,
                    $issueConditionHotelSnList,
                    $getIssueConditionRoomTypeList
                );
                $saveApplyingHotel->handle($saveApplyingHotelDTO);
            }
        }
        $issueCondition = $this->issueConditionRepository->findByField(IssueCondition::COL_COUPON_SN, $couponSn)->first();
        if (empty($issueCondition)) {
            throw new ServiceException(ConvertHelper::getMessage(self::FILE_LANGUAGE_NAME, CodeConst::API_PRN_022), CodeConst::API_PRN_022);
        }
        $issueCondition->{IssueCondition::COL_COUPON_SN} = $newCouponSn;
        $issueCondition->{IssueCondition::COL_APPLY_TARGET} = $getIssueConditionApplyTarget;
        $issueCondition->{IssueCondition::COL_HOURLY} = $updatePromotionInputDTO->getIssueConditionHourly();
        $issueCondition->{IssueCondition::COL_HOURLY_START_TIME} = $updatePromotionInputDTO->getIssueConditionHourlyStartTime();
        $issueCondition->{IssueCondition::COL_HOURLY_END_TIME} = $updatePromotionInputDTO->getIssueConditionHourlyEndTime();
        $issueCondition->{IssueCondition::COL_OVERNIGHT} = $updatePromotionInputDTO->getIssueConditionOvernight();
        $issueCondition->{IssueCondition::COL_DAILY} = $updatePromotionInputDTO->getIssueConditionDaily();
        $issueCondition->{IssueCondition::COL_PAY_IN_ADVANCE} = $updatePromotionInputDTO->getIssueConditionPayInAdvance();
        $issueCondition->{IssueCondition::COL_SUNDAY} = $updatePromotionInputDTO->getIssueConditionSunday();
        $issueCondition->{IssueCondition::COL_MONDAY} = $updatePromotionInputDTO->getIssueConditionMonday();
        $issueCondition->{IssueCondition::COL_TUESDAY} = $updatePromotionInputDTO->getIssueConditionTuesday();
        $issueCondition->{IssueCondition::COL_WEDNESDAY} = $updatePromotionInputDTO->getIssueConditionWednesday();
        $issueCondition->{IssueCondition::COL_THURSDAY} = $updatePromotionInputDTO->getIssueConditionThursday();
        $issueCondition->{IssueCondition::COL_FRIDAY} = $updatePromotionInputDTO->getIssueConditionFriday();
        $issueCondition->{IssueCondition::COL_SATURDAY} = $updatePromotionInputDTO->getIssueConditionSaturday();
        $issueCondition->{IssueCondition::COL_START_TIME} = $updatePromotionInputDTO->getIssueConditionStartTime();
        $issueCondition->{IssueCondition::COL_END_TIME} = $updatePromotionInputDTO->getIssueConditionEndTime();
        $issueCondition->{IssueCondition::COL_COUPON} = $updatePromotionInputDTO->getIssueConditionCoupon();
        $issueCondition->{IssueCondition::COL_APPLY_TO_USER} = $updatePromotionInputDTO->getIssueConditionApplyToUser();
        $issueCondition->{IssueCondition::COL_NUM_CHECKIN} = $updatePromotionInputDTO->getIssueConditionNumCheckin();
        $issueConditionUpData = $issueCondition->toArray();
        unset($issueConditionUpData[IssueCondition::COL_SN]);
        $this->issueConditionRepository->create($issueConditionUpData);
        PromotionTransitionRequest::where(PromotionTransitionRequest::COL_SOURCE_PROMOTION_SN, $getPromotionSn)->delete();
        $this->promotionTransitionRequestRepository->create([
            PromotionTransitionRequest::COL_SOURCE_PROMOTION_SN => $getPromotionSn,
            PromotionTransitionRequest::COL_CLONE_PROMOTION_SN => $newPromotionSn,
            PromotionTransitionRequest::COL_REQUEST_STAFF_SN => $createStaffSn,
        ]);
        $response = new stdClass();
        $response->couponSn = $couponSn;
        $response->promotionSn = $getPromotionSn;
        $response->preSignedUrl = $preSignedUrl;
        return $response;
    }
}
