<?php

namespace App\Actions\Promotion\SA;

use App\Constants\Globals\Code as CodeConst;
use App\Constants\VoucherCode as VoucherCodeConst;
use App\DTOs\Web\SA\Promotion\ImportsDraftVoucherCodeInputDTO;
use App\DTOs\Web\SA\Promotion\ImportsDraftVoucherCodeOutputDTO;
use App\Exceptions\ServiceException;
use App\Helpers\ConvertHelper;
use App\Libraries\Maatwebsite\Excel\Imports\VoucherCodeImport;
use App\Models\DraftVoucherCondition;
use App\Models\VoucherCode;
use App\Repositories\Interfaces\DraftVoucherConditionRepositoryInterface;
use App\Repositories\Interfaces\VoucherCodeRepositoryInterface;
use Exception;
use Maatwebsite\Excel\Facades\Excel;

class ImportsDraftVoucherCode
{
    const FILE_LANGUAGE_NAME = 'sa/promotion';

    protected $voucherCodeRepository;

    protected $draftVoucherConditionRepository;

    public function __construct(
        VoucherCodeRepositoryInterface           $voucherCodeRepository,
        DraftVoucherConditionRepositoryInterface $draftVoucherConditionRepository
    )
    {
        $this->voucherCodeRepository = $voucherCodeRepository;
        $this->draftVoucherConditionRepository = $draftVoucherConditionRepository;
    }

    public function handle(ImportsDraftVoucherCodeInputDTO $importsDraftVoucherCodeInputDTO): ImportsDraftVoucherCodeOutputDTO
    {
        $numErrorFormat = 0;
        $numErrorExist = 0;
        $type = $importsDraftVoucherCodeInputDTO->getType();
        $draftPromotionSn = $importsDraftVoucherCodeInputDTO->getDraftPromotionSn();
        if ($type == VoucherCodeConst::TYPE_APPLY['COMMON']) {
            $code = $importsDraftVoucherCodeInputDTO->getCode();
            $len = strlen($code);
            if ($len >= 6 && $len <= 12) {
                if (!str_starts_with($code, 'G2J')) {
                    throw new ServiceException(ConvertHelper::getMessage(self::FILE_LANGUAGE_NAME, CodeConst::API_PRN_025), CodeConst::API_PRN_025);
                }
            } else {
                throw new ServiceException(ConvertHelper::getMessage(self::FILE_LANGUAGE_NAME, CodeConst::API_PRN_024), CodeConst::API_PRN_024);
            }
            DraftVoucherCondition::where(DraftVoucherCondition::COL_DRAFT_PROMOTION_SN, $draftPromotionSn)->delete();
            $draftVoucherCondData = [
                DraftVoucherCondition::COL_TYPE => $type,
                DraftVoucherCondition::COL_CODE => $code,
                DraftVoucherCondition::COL_DRAFT_PROMOTION_SN => $draftPromotionSn,
            ];
            $this->draftVoucherConditionRepository->create($draftVoucherCondData);
        } else {
            $file = $importsDraftVoucherCodeInputDTO->getFile();
            if (!empty($file)) {
                $vouchers = Excel::toArray(new VoucherCodeImport(), $file)[0];
                $voucherCodeList = [];
                foreach ($vouchers as $values) {
                    $len = strlen($values[0]);
                    if (($len >= 6 && $len <= 12) && str_starts_with($values[0], 'G2J')) {
                        $voucherCodeList[] = $values[0];
                    } else {
                        $numErrorFormat++;
                    }
                }
                if (!empty($voucherCodeList)) {
                    $voucherCodeList = array_diff(array_unique($voucherCodeList), ["", null]);
                    if (!empty($voucherCodeList)) {
                        $draftVoucherCondList = DraftVoucherCondition::whereIn(DraftVoucherCondition::COL_CODE, $voucherCodeList)
                            ->groupBy(DraftVoucherCondition::COL_CODE)
                            ->pluck(DraftVoucherCondition::COL_CODE)
                            ->toArray();
                        if (!empty($draftVoucherCondList)) {
                            $numErrorExist += count($draftVoucherCondList);
                            $voucherCodeList = array_diff($voucherCodeList, $draftVoucherCondList);
                        }
                        if (!empty($voucherCodeList)) {
                            $voucherCodes = VoucherCode::whereIn(VoucherCode::COL_CODE, $voucherCodeList)
                                ->groupBy(VoucherCode::COL_CODE)
                                ->pluck(VoucherCode::COL_CODE)
                                ->toArray();
                            if (!empty($voucherCodes)) {
                                $numErrorExist += count($voucherCodes);
                                $voucherCodeList = array_diff($voucherCodeList, $voucherCodes);
                            }
                        }
                        $batchInsert = [];
                        foreach ($voucherCodeList as $code) {
                            $voucher = [
                                DraftVoucherCondition::COL_TYPE => $type,
                                DraftVoucherCondition::COL_CODE => $code,
                                DraftVoucherCondition::COL_DRAFT_PROMOTION_SN => $draftPromotionSn,
                            ];
                            $batchInsert[] = $voucher;
                        }
                        if (!empty($batchInsert)) {
                            DraftVoucherCondition::where([
                                DraftVoucherCondition::COL_DRAFT_PROMOTION_SN => $draftPromotionSn,
                                DraftVoucherCondition::COL_TYPE => VoucherCodeConst::TYPE_APPLY['COMMON']
                            ])->delete();
                            $this->draftVoucherConditionRepository->batchInsert($batchInsert);
                        }
                    }
                }
            }
        }
        return ImportsDraftVoucherCodeOutputDTO::assemble($numErrorFormat, $numErrorExist);
    }
}
