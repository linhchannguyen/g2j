<?php

namespace App\Actions\Hotel\SA;

use App\DTOs\Web\SA\Hotel\GetWardListInputDTO;
use App\DTOs\Web\SA\Hotel\GetWardListOutputDTO;
use App\Repositories\Interfaces\WardRepositoryInterface;

class GetWardList
{
    public $wardRepository;

    public function __construct()
    {
        $this->wardRepository = app(WardRepositoryInterface::class);
    }

    public function handle(GetWardListInputDTO $getWardListInputDTO): GetWardListOutputDTO
    {
        $wardList = $this->wardRepository->findWardList($getWardListInputDTO->getDistrictSn());

        return GetWardListOutputDTO::assemble($wardList);
    }
}
