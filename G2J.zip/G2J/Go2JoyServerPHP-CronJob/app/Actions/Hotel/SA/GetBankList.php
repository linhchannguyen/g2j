<?php

namespace App\Actions\Hotel\SA;

use App\DTOs\Web\SA\Hotel\GetBankListInputDTO;
use App\DTOs\Web\SA\Hotel\GetBankListOutputDTO;
use App\Repositories\Interfaces\BankRepositoryInterface;

class GetBankList
{
    public $bankRepository;

    public function __construct()
    {
        $this->bankRepository = app(BankRepositoryInterface::class);
    }

    public function handle(GetBankListInputDTO $getBankListInputDTO): GetBankListOutputDTO
    {
        $bankList = $this->bankRepository->findBankList($getBankListInputDTO->getKeyword(), $getBankListInputDTO->getLimit());

        return GetBankListOutputDTO::assemble($bankList);
    }
}
