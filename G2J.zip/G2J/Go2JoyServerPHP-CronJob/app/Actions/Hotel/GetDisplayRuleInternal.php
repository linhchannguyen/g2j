<?php

namespace App\Actions\Hotel;

use App\API\Internal\HotelPricing\HotelPricingProcessor;
use App\Constants\Coupon as CouponConst;
use App\Constants\RoomType as RoomTypeConst;
use App\DTOs\Hotel\GetDisplayRuleInternalInputDTO;
use App\Helpers\ConvertHelper;

class GetDisplayRuleInternal
{
    public function handle(GetDisplayRuleInternalInputDTO $getDisplayRuleInternalInputDTO)
    {
        if (empty($getDisplayRuleInternalInputDTO->getHotelSnList())) {
            return [];
        }
        $hotelPricingProcessor = new HotelPricingProcessor();
        $getHotelPriceAnyTimeListOutputDTO = $hotelPricingProcessor->getHotelPriceAnyTimeList($getDisplayRuleInternalInputDTO->getCheckin(), $getDisplayRuleInternalInputDTO->getCheckout(), $getDisplayRuleInternalInputDTO->getFlashSale(), $getDisplayRuleInternalInputDTO->getHotelSnList());
        $_hotelList = [];
        $hotelList = !empty($getHotelPriceAnyTimeListOutputDTO->hotelList) ? $getHotelPriceAnyTimeListOutputDTO->hotelList : [];
        foreach ($hotelList as $hotel) {
            if (!isset($_hotelList[$hotel['hotelSn']])) {
                $_hotelList[$hotel['hotelSn']] = [
                    'sn'            => $hotel['roomTypeSn'],
                    'available'     => 1,
                    'bookingType'   => $hotel['bookingType'],
                    'mode'          => $hotel['mode'],
                    'coupon'        => self::_getCouponDisplay($hotel['coupon']),
                    'originPrice'   => $hotel['originPrice'],
                    'discountPrice' => $hotel['discountPrice'],
                    'numOfRoom'     => $hotel['numOfRoom'],
                    'percent'       => self::_getPercentDiscount($hotel['originPrice'], $hotel['discountPrice']),
                    'timeDuration'  => $hotel['timeDuration'],
                    'hasExtraFee'   => $hotel['hasExtraFee'],
                ];
            }
        }

        return $_hotelList;
    }

    private static function _getCouponDisplay($coupon)
    {
        $_coupon = null;
        $discount = ConvertHelper::formatPriceCouponDiscount($coupon['discount'], app()->getLocale());
        switch ($coupon['discountType']) {
            case CouponConst::DISCOUNT_TYPE['MONEY']:
                $_coupon = [
                    'couponSn'     => $coupon['couponSn'],
                    'discountText' => ConvertHelper::getMessage('mobile/promotion', 'title.discount', ['discount' => $discount]),
                ];
                break;
            case CouponConst::DISCOUNT_TYPE['PERCENT']:
                $_coupon = [
                    'couponSn'     => $coupon['couponSn'],
                    'discountText' => ConvertHelper::getMessage('mobile/promotion', 'title.discount', ['discount' => $coupon['discount'] . ConvertHelper::PERCENT]),
                ];
                break;
            case CouponConst::DISCOUNT_TYPE['SAME_PRICE']:
                $_coupon = [
                    'couponSn'     => $coupon['couponSn'],
                    'discountText' => ConvertHelper::getMessage('mobile/promotion', 'title.samePrice', ['discount' => $discount]),
                ];
                break;
            default:
                break;
        }

        return $_coupon;
    }

    private static function _getPercentDiscount($originPrice, $discountPrice)
    {
        $percent = 0;
        if ($originPrice > $discountPrice) {
            $percent = max(intval(round((($originPrice - $discountPrice) / $originPrice) * 100)), RoomTypeConst::MIN_DISCOUNT_PERCENT);
        }

        return $percent;
    }
}