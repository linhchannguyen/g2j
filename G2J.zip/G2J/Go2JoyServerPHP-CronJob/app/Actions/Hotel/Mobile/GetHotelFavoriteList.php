<?php

namespace App\Actions\Hotel\Mobile;

use App\Actions\Hotel\GetDisplayRule;
use App\Actions\Hotel\GetDisplayRuleInternal;
use App\Constants\Hotel as HotelConst;
use App\Constants\RoomType as RoomTypeConst;
use App\Constants\UserBooking as UserBookingConst;
use App\DTOs\Hotel\GetDisplayRuleInputDTO;
use App\DTOs\Hotel\GetDisplayRuleInternalInputDTO;
use App\DTOs\Hotel\Mobile\GetHotelFavoriteListInputDTO;
use App\DTOs\Hotel\Mobile\GetHotelFavoriteListOutputDTO;
use App\Models\Hotel;
use App\Repositories\Interfaces\UserFavoriteRepositoryInterface;
use Illuminate\Support\Carbon;
use stdClass;

class GetHotelFavoriteList
{
    public $hotelRepository;

    public $userFavoriteRepository;

    public function __construct()
    {
        $this->userFavoriteRepository = app(UserFavoriteRepositoryInterface::class);
    }

    public function handle(GetHotelFavoriteListInputDTO $getHotelFavoriteListInputDTO)
    {
        $hotelList = $this->userFavoriteRepository->findHotelFavoriteList($getHotelFavoriteListInputDTO->getAppUserSn(), $getHotelFavoriteListInputDTO->getLimit());
        $hotelList = $this->_generateDataHotel($hotelList);

        return GetHotelFavoriteListOutputDTO::assemble($hotelList);
    }

    private function _generateDataHotel($hotelList)
    {
        $getDisplayRule = new GetDisplayRule();
        $getDisplayRuleInputDTO = new GetDisplayRuleInputDTO();
        $getDisplayRuleInputDTO->setCheckin(Carbon::now()->toDateString());
        $getDisplayRuleInputDTO->setCheckout(Carbon::now()->addDay()->toDateString());

        $getDisplayRuleInternal = new GetDisplayRuleInternal();
        $getDisplayRuleInternalInputDTO = new GetDisplayRuleInternalInputDTO();
        $getDisplayRuleInternalInputDTO->setCheckin(Carbon::now()->toDateString());
        $getDisplayRuleInternalInputDTO->setCheckout(Carbon::now()->toDateString());
        $getDisplayRuleInternalInputDTO->setHotelSnList($hotelList->pluck('SN')->toArray());
        $getDisplayRuleInternalOutputDTO = $getDisplayRuleInternal->handle($getDisplayRuleInternalInputDTO);
        $_data = [];
        foreach ($hotelList as $hotel) {
            switch ($hotel->{Hotel::COL_ORIGIN}) {
                case HotelConst::ORIGIN['AGODA']:
                {
                    $getDisplayRuleInputDTO->setHotelSnList([$hotel->{Hotel::COL_SN}]);
                    $data = $getDisplayRule->handle($getDisplayRuleInputDTO);
                    $data = reset($data);
                    $roomAvailable = $data['roomAvailable'];
                    $displayRule = $data['displayRule'];
                    break;
                }
                default:
                    {
                        $roomAvailable = boolval($hotel->{Hotel::COL_ROOM_AVAILABLE});
                        if (empty($getDisplayRuleInternalOutputDTO) || !isset($getDisplayRuleInternalOutputDTO[$hotel->{Hotel::COL_SN}])) {
                            $displayRule = json_decode($hotel->{Hotel::ALIAS_HOTEL_DISPLAY_RULE}, true);
                            if (!empty($hotel->{Hotel::ALIAS_FS_SN})) {
                                $displayRule = $this->_getDisplayRule($displayRule, true, $hotel->{Hotel::AS_FS_PRICE_FLASH_SALE}, $hotel->{Hotel::AS_FS_OVERNIGHT_ORIGIN});
                            } else {
                                $displayRule = $this->_getDisplayRule($displayRule, false, 0, 0);
                            }
                        } else {
                            $displayRule = $getDisplayRuleInternalOutputDTO[$hotel->{Hotel::COL_SN}];
                        }

                    }
                    break;
            }

            $_data[] = [
                'sn'            => $hotel->{Hotel::COL_SN},
                'name'          => $hotel->{Hotel::COL_NAME},
                'imagePath'     => $hotel->{Hotel::COL_IMAGE_PATH},
                'newHotel'      => boolval($hotel->{Hotel::COL_NEW_HOTEL}),
                'hotHotel'      => boolval($hotel->{Hotel::COL_HOT_HOTEL}),
                'averageMark'   => $hotel->{Hotel::COL_AVERAGE_MARK},
                'totalReview'   => $hotel->{Hotel::COL_TOTAL_REVIEW},
                'roomAvailable' => $roomAvailable,
                'favorite'      => true,
                'displayRule'   => $displayRule,
                'origin'        => $hotel->{Hotel::COL_ORIGIN},
            ];
        }

        return $_data;
    }

    private function _getDisplayRule($displayRule, $isFlashSale, $originFlashSale, $priceFlashSale)
    {
        $displayRuleNew = new stdClass();
        $displayRuleNew->daysLeft = $displayRule['daysLeft'];
        $displayRuleNew->roomsLeft = $displayRule['roomsLeft'];
        $displayRuleNew->samePriceType = $displayRule['samePriceType'];
        $displayRuleNew->samePriceHours = $displayRule['samePriceHours'];
        $displayRuleNew->samePricePrice = $displayRule['samePricePrice'];
        $displayRuleNew->typeDisplayText = [];
        $displayRuleNew->coupon = null;
        $displayRuleNew->hasExtraFee = false;
        $displayRuleNew->timeDuration = 0;
        $displayRuleNew->mode = RoomTypeConst::MODE['NORMAL'];
        if ($displayRule['firstHoursOrigin'] > 0) {
            $displayRuleNew->originPrice = $displayRule['firstHoursOrigin'];
            $displayRuleNew->discountPrice = $displayRule['priceFirstHours'];
            $displayRuleNew->bookingType = UserBookingConst::BOOKING_TYPE['HOURLY'];
            $displayRuleNew->timeDuration = 0;
        } elseif ($displayRule['overnightOrigin'] > 0) {
            $displayRuleNew->originPrice = $displayRule['overnightOrigin'];
            $displayRuleNew->discountPrice = $displayRule['priceOvernight'];
            $displayRuleNew->bookingType = UserBookingConst::BOOKING_TYPE['OVERNIGHT'];
        } else {
            $displayRuleNew->originPrice = $displayRule['oneDayOrigin'];
            $displayRuleNew->discountPrice = $displayRule['priceOneDay'];
            $displayRuleNew->bookingType = UserBookingConst::BOOKING_TYPE['DAILY'];
        }

        if (!empty($isFlashSale) && $displayRuleNew->bookingType = UserBookingConst::BOOKING_TYPE['OVERNIGHT'] && $priceFlashSale <= $displayRuleNew->discountPrice) {
            $displayRuleNew->originPrice = $originFlashSale;
            $displayRuleNew->discountPrice = $priceFlashSale;
            $displayRuleNew->bookingType = UserBookingConst::BOOKING_TYPE['OVERNIGHT'];
            $displayRuleNew->mode = RoomTypeConst::MODE['FLASH_SALE'];
        }

        // percent
        if ($displayRuleNew->originPrice > 0) {
            $displayRuleNew->percent = (($displayRuleNew->originPrice - $displayRuleNew->discountPrice) / $displayRuleNew->originPrice) * 100;
            $displayRuleNew->percent = ceil($displayRuleNew->percent);
        } else {
            $displayRuleNew->percent = 0;
        }

        return $displayRuleNew;
    }
}