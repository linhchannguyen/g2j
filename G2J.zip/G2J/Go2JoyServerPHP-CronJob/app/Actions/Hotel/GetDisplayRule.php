<?php

namespace App\Actions\Hotel;

use App\Constants\Globals\FunctionName;
use App\Constants\Globals\Integration;
use App\Constants\Hotel as HotelConst;
use App\Constants\UserBooking as UserBookingConst;
use App\DTOs\Hotel\GetDisplayRuleInputDTO;
use App\DTOs\Integration\Agoda\GetHotelDetailInputDTO;
use App\Factories\IntegrationFactory;
use App\Helpers\ConvertHelper;
use App\Helpers\GenerateHelper;
use App\Libraries\DataStructures\Agoda\SearchResponse\Hotel\Rooms\Room;
use App\Models\Hotel;
use Exception;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Cache;

class GetDisplayRule
{
    public function handle(GetDisplayRuleInputDTO $getDisplayRuleInputDTO)
    {
        $checkIn = Carbon::parse($getDisplayRuleInputDTO->getCheckin())->toDateString();
        $checkOut = Carbon::parse($getDisplayRuleInputDTO->getCheckout())->toDateString();
        $data = [];
        foreach ($getDisplayRuleInputDTO->getHotelSnList() as $hotelSn) {
            $hotelSn = intval($hotelSn);
            $ttl = Carbon::now()->addMinutes(30);
            $key = GenerateHelper::cacheName(function() use ($hotelSn, $checkIn, $checkOut) {
                return sprintf('%s:%s:%s:%s', FunctionName::GET_DISPLAY_RULE, $hotelSn, $checkIn, $checkOut);
            });

            $cachedData = Cache::store('redis')->remember($key, $ttl, function() use ($hotelSn, $checkIn, $checkOut) {
                $hotel = Hotel::where(Hotel::COL_SN, $hotelSn)
                    ->first([
                        Hotel::COL_SN,
                        Hotel::COL_NAME,
                        Hotel::COL_ROOM_AVAILABLE,
                        Hotel::COL_ORIGIN,
                        Hotel::COL_PARTNER_HOTEL_ID,
                    ]);
                //$roomAvailable = $hotel->{Hotel::COL_ROOM_AVAILABLE} == HotelConst::ROOM_AVAILABLE['AVAILABLE'];
                $roomAvailable = false;
                $displayRule = [
                    'roomsLeft'       => 0,
                    'originPrice'     => 0,
                    'discountPrice'   => 0,
                    'typeDisplayText' => [],
                    'percent'         => 0,
                    'bookingType'     => UserBookingConst::BOOKING_TYPE['DAILY'],
                    'flashSale'       => false,
                ];
                $data = [
                    'sn'            => $hotelSn,
                    'name'          => $hotel->{Hotel::COL_NAME},
                    'roomAvailable' => $roomAvailable,
                    'displayRule'   => $displayRule,
                ];

                $origin = $hotel->{Hotel::COL_ORIGIN};
                try {
                    switch ($origin) {
                        case HotelConst::ORIGIN['AGODA']:
                        {
                            $partner = Integration::PARTNER['AGODA'];
                            $partnerHotelId = intval($hotel->{Hotel::COL_PARTNER_HOTEL_ID});

                            $integrationFactory = new IntegrationFactory();
                            $agodaProcessor = $integrationFactory->createProcessor($partner);
                            $getHotelDetailInputDTO = new GetHotelDetailInputDTO();
                            $getHotelDetailInputDTO->setHotelIdList([$partnerHotelId]);
                            $getHotelDetailInputDTO->setCheckIn(Carbon::parse($checkIn)->format('Y-m-d'));
                            $getHotelDetailInputDTO->setCheckOut(Carbon::parse($checkOut)->format('Y-m-d'));
                            $getHotelDetailOutputDTO = $agodaProcessor->getHotelDetail($getHotelDetailInputDTO);
                            $searchResponse = $getHotelDetailOutputDTO->getSearchResponse();
                            if (!empty($searchResponse->getErrorMessage())) {
                                return $data;
                            }

                            $hotel = current($searchResponse->getHotels());
                            $rooms = [];
                            if (!empty($hotel)) { // If long search return data
                                $rooms = $hotel->getMinPriceEachRoomType();
                            }

                            $cheapestRoom = [];

                            foreach ($rooms as /** @var Room $room */ $room) {
                                $totalDays = \App\Helpers\DateTimeHelper::daysBetween($checkIn, $checkOut);
                                $numOfRoom = intval($room->getRemainingRooms());
                                // Room price display on app without tax and fee => choose "Exclusive"
                                $oneDayOrigin = $priceOneDay = intval($room->getRateInfo()->getRate()->getExclusive());
                                $savings = intval($room->getRateInfo()->getPromotion()->getSavingAmount());
                                $oneDayOrigin = $oneDayOrigin + ($savings * intval($totalDays));

                                if (empty($cheapestRoom)) {
                                    $cheapestRoom = [
                                        'roomsLeft'       => $numOfRoom,
                                        'originPrice'     => $oneDayOrigin,
                                        'discountPrice'   => $priceOneDay,
                                        'typeDisplayText' => $savings == 0 ? [ConvertHelper::getMessage('mobile/price', 'promotion')] : [],
                                        'percent'         => $this->getPercentDiscount($oneDayOrigin, $priceOneDay),
                                        'bookingType'     => UserBookingConst::BOOKING_TYPE['DAILY'],
                                    ];
                                }

                                if (!empty($cheapestRoom) && $priceOneDay < $cheapestRoom['discountPrice']) {
                                    $cheapestRoom = [
                                        'roomsLeft'       => $numOfRoom,
                                        'originPrice'     => $oneDayOrigin,
                                        'discountPrice'   => $priceOneDay,
                                        'typeDisplayText' => $savings != 0 ? [ConvertHelper::getMessage('mobile/price', 'promotion')] : [],
                                        'percent'         => $this->getPercentDiscount($oneDayOrigin, $priceOneDay),
                                        'bookingType'     => UserBookingConst::BOOKING_TYPE['DAILY'],
                                    ];
                                }
                            }

                            if (empty($cheapestRoom)) {
                                $data['roomAvailable'] = false;
                                $data['displayRule'] = $displayRule;
                            } else {
                                $data['roomAvailable'] = true;
                                $data['displayRule'] = $cheapestRoom;
                            }

                            return $data;
                        }
                        default:
                            return $data;
                    }
                } catch (Exception $exception) {
                    return $data;
                }
            });

            $data[] = $cachedData;
        }

        return $data;
    }

    private function getPercentDiscount($originPrice, $discountPrice)
    {
        if ($originPrice > 0) {
            $percent = (($originPrice - $discountPrice) / $originPrice) * 100;

            return ceil($percent);
        }

        return 0;
    }
}