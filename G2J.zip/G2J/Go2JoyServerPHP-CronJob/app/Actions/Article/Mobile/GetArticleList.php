<?php

namespace App\Actions\Article\Mobile;

use App\Constants\Globals\Pagination as PaginationConst;
use App\DTOs\Article\Mobile\GetArticleListInputDTO;
use App\DTOs\Article\Mobile\GetArticleListOutputDTO;
use App\Repositories\Interfaces\ArticleRepositoryInterface;

class GetArticleList
{
    public $articleRepository;

    public function __construct()
    {
        $this->articleRepository = app(ArticleRepositoryInterface::class);
    }

    public function handle(GetArticleListInputDTO $getArticleListInputDTO)
    {
        $articleList = $this->articleRepository->findLimitArticles(null, PaginationConst::LIMIT['DEFAULT']);
        if (empty($articleList)) {
            return new GetArticleListOutputDTO();
        }

        return GetArticleListOutputDTO::assemble($articleList);
    }
}