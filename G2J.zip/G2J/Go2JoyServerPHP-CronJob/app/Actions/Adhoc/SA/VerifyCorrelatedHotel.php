<?php

namespace App\Actions\Adhoc\SA;

use App\DTOs\Adhoc\Booking\VerifyCorrelatedHotelInputDTO;
use App\DTOs\Adhoc\Booking\VerifyCorrelatedHotelOutputDTO;
use App\Models\Hotel;

class VerifyCorrelatedHotel
{
    public function handle(VerifyCorrelatedHotelInputDTO $verifyCorrelatedHotelInputDTO): VerifyCorrelatedHotelOutputDTO
    {
        $origin = $verifyCorrelatedHotelInputDTO->getOrigin();
        $hotelCode = $verifyCorrelatedHotelInputDTO->getCode();

        $hotel = Hotel::where(Hotel::COL_CODE, $hotelCode)
            ->where(Hotel::COL_ORIGIN, $origin)
            ->first([
                Hotel::COL_SN,
                Hotel::COL_CODE,
                Hotel::COL_NAME,
            ]);

        if (empty($hotel)) {
            return new VerifyCorrelatedHotelOutputDTO();
        }

        return VerifyCorrelatedHotelOutputDTO::assemble($hotel);
    }
}
