<?php

namespace App\Actions\Adhoc\SA;

use App\Constants\Globals\Code as CodeConst;
use App\Constants\Hotel as HotelConst;
use App\DTOs\Adhoc\Booking\RemoveCorrelatedAgodaHotelInputDTO;
use App\Exceptions\ServiceException;
use App\Helpers\CommonHelper;
use App\Models\CorrelatedHotelHistory;
use App\Models\Hotel;
use App\Repositories\Interfaces\CorrelatedHotelHistoryRepositoryInterface;

class RemoveCorrelatedAgodaHotel
{
    const FILE_LANGUAGE_NAME = 'adhoc/booking';

    public $correlatedHotelHistoryRepository;

    public function __construct(
        CorrelatedHotelHistoryRepositoryInterface $correlatedHotelHistoryRepository
    )
    {
        $this->correlatedHotelHistoryRepository = $correlatedHotelHistoryRepository;
    }

    public function handle(RemoveCorrelatedAgodaHotelInputDTO $removeCorrelatedAgodaHotelInputDTO): void
    {
        $correlateHotelList = $removeCorrelatedAgodaHotelInputDTO->getCorrelateHotelList();
        $acctionStaffSn = $removeCorrelatedAgodaHotelInputDTO->getStaffSn();
        $correlatedHotelHistoryData = [];
        foreach ($correlateHotelList as $values) {
            $g2jHotel = Hotel::where(Hotel::COL_CODE, $values['g2j']['code'])
                ->where(Hotel::COL_ORIGIN, HotelConst::ORIGIN['GO2JOY'])
                ->first([
                    Hotel::COL_SN,
                ]);
            if (!$g2jHotel) {
                throw new ServiceException(CommonHelper::getMessage(self::FILE_LANGUAGE_NAME, CodeConst::API_ADH_002), CodeConst::API_ADH_002);
            }

            $agodaHotel = Hotel::where(Hotel::COL_CODE, $values['agoda']['code'])
                ->where(Hotel::COL_ORIGIN, HotelConst::ORIGIN['AGODA'])
                ->first([
                    Hotel::COL_SN,
                ]);
            if (!$agodaHotel) {
                throw new ServiceException(CommonHelper::getMessage(self::FILE_LANGUAGE_NAME, CodeConst::API_ADH_001), CodeConst::API_ADH_001);
            }
            $correlatedHotelHistoryData[] = [
                CorrelatedHotelHistory::COL_G2J_HOTEL_SN => $g2jHotel->{Hotel::COL_SN},
                CorrelatedHotelHistory::COL_G2J_HOTEL_CODE => $values['g2j']['code'],
                CorrelatedHotelHistory::COL_G2J_HOTEL_NAME => $values['g2j']['name'],
                CorrelatedHotelHistory::COL_AGODA_HOTEL_SN => $agodaHotel->{Hotel::COL_SN},
                CorrelatedHotelHistory::COL_AGODA_HOTEL_CODE => $values['agoda']['code'],
                CorrelatedHotelHistory::COL_AGODA_HOTEL_NAME => $values['agoda']['name'],
                CorrelatedHotelHistory::COL_ACTION_STAFF_SN => $acctionStaffSn,
            ];
        }
        if (!empty($correlatedHotelHistoryData)) {
            CorrelatedHotelHistory::whereNull(CorrelatedHotelHistory::COL_ACTIVITY_SN)->delete();
            $this->correlatedHotelHistoryRepository->batchInsert($correlatedHotelHistoryData);
        }
    }
}
