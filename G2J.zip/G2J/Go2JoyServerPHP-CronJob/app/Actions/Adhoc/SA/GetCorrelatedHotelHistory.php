<?php

namespace App\Actions\Adhoc\SA;

use App\DTOs\Adhoc\Booking\GetCorrelatedHotelHistoryInputDTO;
use App\DTOs\Adhoc\Booking\GetCorrelatedHotelHistoryOutputDTO;
use App\Models\Activity;
use App\Models\CorrelatedHotelHistory;
use App\Repositories\Interfaces\ActivityRepositoryInterface;
use App\Repositories\Interfaces\CorrelatedHotelHistoryRepositoryInterface;

class GetCorrelatedHotelHistory
{
    public $activityRepository;

    public function __construct(
        CorrelatedHotelHistoryRepositoryInterface $correlatedHotelHistoryRepository,
        ActivityRepositoryInterface               $activityRepository
    )
    {
        $this->correlatedHotelHistoryRepository = $correlatedHotelHistoryRepository;
        $this->activityRepository = $activityRepository;
    }

    public function handle(GetCorrelatedHotelHistoryInputDTO $getCorrelatedHotelHistoryInputDTO): GetCorrelatedHotelHistoryOutputDTO
    {
        $type = $getCorrelatedHotelHistoryInputDTO->getType();
        $limit = $getCorrelatedHotelHistoryInputDTO->getLimit();
        $activitySn = $getCorrelatedHotelHistoryInputDTO->getActivitySn();
        $activityCorrelated = $this->activityRepository->findActivityByField($type, $activitySn, $limit);

        if ($activityCorrelated->isEmpty()) {
            return new GetCorrelatedHotelHistoryOutputDTO();
        }

        foreach ($activityCorrelated as $value) {
            $correlatedHotel = $this->correlatedHotelHistoryRepository->findByField(CorrelatedHotelHistory::COL_ACTIVITY_SN, $value->{Activity::COL_SN}, [
                CorrelatedHotelHistory::COL_AGODA_HOTEL_CODE,
                CorrelatedHotelHistory::COL_AGODA_HOTEL_NAME,
                CorrelatedHotelHistory::COL_G2J_HOTEL_CODE,
                CorrelatedHotelHistory::COL_G2J_HOTEL_NAME,
            ]);
            $value->{CorrelatedHotelHistory::VAR_CORRELATED_HOTEL_LIST} = $this->_toCorrelatedHotel($correlatedHotel);
        }

        return GetCorrelatedHotelHistoryOutputDTO::assemble($activityCorrelated);
    }

    private function _toCorrelatedHotel($correlatedHotel)
    {
        $_correlatedHotel = [];
        foreach ($correlatedHotel as $value) {
            $_correlatedHotel[] = [
                'agodaCode' => $value->{CorrelatedHotelHistory::COL_AGODA_HOTEL_CODE},
                'agodaName' => $value->{CorrelatedHotelHistory::COL_AGODA_HOTEL_NAME},
                'g2jCode' => $value->{CorrelatedHotelHistory::COL_G2J_HOTEL_CODE},
                'g2jName' => $value->{CorrelatedHotelHistory::COL_G2J_HOTEL_NAME},
            ];
        }
        return $_correlatedHotel;
    }
}
