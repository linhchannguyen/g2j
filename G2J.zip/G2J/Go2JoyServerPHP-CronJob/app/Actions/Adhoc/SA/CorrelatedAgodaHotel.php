<?php

namespace App\Actions\Adhoc\SA;

use App\Console\Commands\Adhoc\RemoveCorrelatedAgodaHotel as RemoveCorrelatedAgodaHotelCommand;
use App\Models\CorrelatedHotelHistory;
use App\Repositories\Interfaces\CorrelatedHotelHistoryRepositoryInterface;
use Exception;
use Illuminate\Support\Facades\Artisan;

class CorrelatedAgodaHotel
{
    const FILE_LANGUAGE_NAME = 'adhoc/booking';

    public $correlatedHotelHistoryRepository;

    public function __construct(
        CorrelatedHotelHistoryRepositoryInterface $correlatedHotelHistoryRepository
    )
    {
        $this->correlatedHotelHistoryRepository = $correlatedHotelHistoryRepository;
    }

    public function handle(int $activitySn): void
    {
        $correlatedHotels = $this->correlatedHotelHistoryRepository->findByField(CorrelatedHotelHistory::COL_ACTIVITY_SN, $activitySn);
        foreach($correlatedHotels as $hotel) {
            $command = RemoveCorrelatedAgodaHotelCommand::class;
            $params = [
                '--agodaHotelSn'  => $hotel->{CorrelatedHotelHistory::COL_AGODA_HOTEL_SN},
                '--go2joyHotelSn' => $hotel->{CorrelatedHotelHistory::COL_G2J_HOTEL_SN},
            ];
            Artisan::call($command, $params);
            $output = Artisan::output();
            if (!empty($output)) {
                throw new Exception($output);
            }
        }
    }
}
