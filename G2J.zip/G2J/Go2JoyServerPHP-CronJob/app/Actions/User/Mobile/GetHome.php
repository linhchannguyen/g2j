<?php

namespace App\Actions\User\Mobile;

class GetUser
{
    public function handle()
    {

    }
}