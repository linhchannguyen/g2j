<?php

namespace App\Actions\User\SA;

use App\Constants\AppUser as AppUserConst;
use App\Constants\MobileDevice as MobileDeviceConst;
use App\Constants\UserStatistic as UserStatisticConst;
use App\DTOs\User\SA\GetStatisticsInputDTO;
use App\DTOs\User\SA\GetStatisticsOutputDTO;
use App\Repositories\Interfaces\AppUserRepositoryInterface;
use App\Repositories\Interfaces\MobileDeviceRepositoryInterface;
use App\Repositories\Interfaces\UserStatisticRepositoryInterface;
use App\Repositories\Interfaces\WebDeviceRepositoryInterface;

class GetStatistics
{
    const FILE_LANGUAGE_NAME = 'sa/user';

    /** @var AppUserRepositoryInterface */
    protected $appUserRepository;

    /** @var MobileDeviceRepositoryInterface */
    protected $mobileDeviceRepository;

    /** @var WebDeviceRepositoryInterface */
    protected $webDeviceRepository;

    /** @var UserStatisticRepositoryInterface */
    protected $userStatisticRepository;

    public function __construct(
        AppUserRepositoryInterface $appUserRepository,
        MobileDeviceRepositoryInterface $mobileDeviceRepository,
        WebDeviceRepositoryInterface $webDeviceRepository,
        UserStatisticRepositoryInterface $userStatisticRepository
    )
    {
        $this->appUserRepository = $appUserRepository;
        $this->mobileDeviceRepository = $mobileDeviceRepository;
        $this->webDeviceRepository = $webDeviceRepository;
        $this->userStatisticRepository = $userStatisticRepository;
    }

    public function handle(GetStatisticsInputDTO $getStatisticsInputDTO): GetStatisticsOutputDTO
    {
        $totalAppUser = $this->userStatisticRepository->countTotalAppUser(
            $getStatisticsInputDTO->getKeyword(),
            $getStatisticsInputDTO->getStartDate(),
            $getStatisticsInputDTO->getEndDate(),
            [UserStatisticConst::OS['IOS'], UserStatisticConst::OS['ANDROID'], UserStatisticConst::OS['WEB_BROWSER']],
            [UserStatisticConst::STATUS['DELETED'], UserStatisticConst::STATUS['ACTIVE'], UserStatisticConst::STATUS['LOCKED']]
        );

        $totalAppUserRegisterByIOS = $this->userStatisticRepository->countTotalAppUserRegisterByIOS(
            $getStatisticsInputDTO->getKeyword(),
            $getStatisticsInputDTO->getStartDate(),
            $getStatisticsInputDTO->getEndDate(),
            [AppUserConst::STATUS['ACTIVE']]
        );

        $totalAppUserDeletedRegisterByIOS = $this->userStatisticRepository->countTotalAppUserRegisterByIOS(
            $getStatisticsInputDTO->getKeyword(),
            $getStatisticsInputDTO->getStartDate(),
            $getStatisticsInputDTO->getEndDate(),
            [AppUserConst::STATUS['DELETED'], AppUserConst::STATUS['LOCKED']]
        );

        $totalAppUserRegisterByAndroid = $this->userStatisticRepository->countTotalAppUserRegisterByAndroid(
            $getStatisticsInputDTO->getKeyword(),
            $getStatisticsInputDTO->getStartDate(),
            $getStatisticsInputDTO->getEndDate(),
            [AppUserConst::STATUS['ACTIVE']]
        );

        $totalAppUserDeletedRegisterByAndroid = $this->userStatisticRepository->countTotalAppUserRegisterByAndroid(
            $getStatisticsInputDTO->getKeyword(),
            $getStatisticsInputDTO->getStartDate(),
            $getStatisticsInputDTO->getEndDate(),
            [AppUserConst::STATUS['DELETED'], AppUserConst::STATUS['LOCKED']]
        );

        $totalAppUserRegisterByWebBrowser = $this->userStatisticRepository->countTotalAppUserRegisterByWebBrowser(
            $getStatisticsInputDTO->getKeyword(),
            $getStatisticsInputDTO->getStartDate(),
            $getStatisticsInputDTO->getEndDate(),
            [AppUserConst::STATUS['ACTIVE']]
        );

        $totalAppUserDeletedRegisterByWebBrowser = $this->userStatisticRepository->countTotalAppUserRegisterByWebBrowser(
            $getStatisticsInputDTO->getKeyword(),
            $getStatisticsInputDTO->getStartDate(),
            $getStatisticsInputDTO->getEndDate(),
            [AppUserConst::STATUS['DELETED'], AppUserConst::STATUS['LOCKED']]
        );

        $userStatistics = [
            'totalAccount'           => $totalAppUser,
            'totalIOS'               => $totalAppUserRegisterByIOS,
            'totalIOSDeleted'        => $totalAppUserDeletedRegisterByIOS,
            'totalAndroid'           => $totalAppUserRegisterByAndroid,
            'totalAndroidDeleted'    => $totalAppUserDeletedRegisterByAndroid,
            'totalWebBrowser'        => $totalAppUserRegisterByWebBrowser,
            'totalWebBrowserDeleted' => $totalAppUserDeletedRegisterByWebBrowser,
        ];

        $totalMobileDevice = $this->mobileDeviceRepository->countTotalMobileDevice(
            $getStatisticsInputDTO->getStartDate(),
            $getStatisticsInputDTO->getEndDate(),
            [MobileDeviceConst::OS['ANDROID'], MobileDeviceConst::OS['IOS'], MobileDeviceConst::OS['WEB']]
        );
        $totalWebBrowser = $this->webDeviceRepository->countTotalWebBrowser(
            $getStatisticsInputDTO->getStartDate(),
            $getStatisticsInputDTO->getEndDate()
        );
        $totalDevice = $totalMobileDevice + $totalWebBrowser;

        $totalIOS = $this->mobileDeviceRepository->countTotalMobileDevice(
            $getStatisticsInputDTO->getStartDate(),
            $getStatisticsInputDTO->getEndDate(),
            [MobileDeviceConst::OS['IOS']]
        );

        $totalAndroid = $this->mobileDeviceRepository->countTotalMobileDevice(
            $getStatisticsInputDTO->getStartDate(),
            $getStatisticsInputDTO->getEndDate(),
            [MobileDeviceConst::OS['ANDROID']]
        );

        $deviceStatistics = [
            'totalDevice'     => $totalDevice,
            'totalIOS'        => $totalIOS,
            'totalAndroid'    => $totalAndroid,
            'totalWebBrowser' => $totalWebBrowser,
        ];

        return GetStatisticsOutputDTO::assemble($userStatistics, $deviceStatistics);
    }
}
