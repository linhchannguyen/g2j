<?php

namespace App\Actions\User\SA;

use App\DTOs\User\SA\GetAppUserInfoInputDTO;
use App\DTOs\User\SA\GetUserStatusHistoryListInputDTO;
use App\DTOs\User\SA\GetUserStatusHistoryListOutputDTO;
use App\Models\UserStatusHistory;
use App\Repositories\Interfaces\UserStatusHistoryRepositoryInterface;

class GetUserStatusHistoryList
{
    const FILE_LANGUAGE_NAME = 'sa/user';

    /** @var UserStatusHistoryRepositoryInterface */
    protected $userStatusHistoryRepository;

    /** @var GetAppUserInfo */
    protected $getAppUserInfo;

    public function __construct(
        UserStatusHistoryRepositoryInterface $userStatusHistoryRepository,
        GetAppUserInfo $getAppUserInfo
    )
    {
        $this->userStatusHistoryRepository = $userStatusHistoryRepository;
        $this->getAppUserInfo = $getAppUserInfo;
    }

    public function handle(GetUserStatusHistoryListInputDTO $getUserStatusHistoryListInputDTO): GetUserStatusHistoryListOutputDTO
    {
        $getAppUserInfoInputDTO = new GetAppUserInfoInputDTO();
        $getAppUserInfoInputDTO->setSn($getUserStatusHistoryListInputDTO->getAppUserSn());
        $getAppUserInfoOutputDTO = $this->getAppUserInfo->handle($getAppUserInfoInputDTO);
        if ($getAppUserInfoOutputDTO->isEmpty()) {
            return new GetUserStatusHistoryListOutputDTO();
        }

        $userStatusHistoryList = $this->userStatusHistoryRepository->findUserStatusHistoryList($getUserStatusHistoryListInputDTO->getAppUserSn());

        if (empty($userStatusHistoryList)) {
            return new GetUserStatusHistoryListOutputDTO();
        }

        foreach ($userStatusHistoryList as $userStatusHistory) {
            $description = json_decode($userStatusHistory->{UserStatusHistory::COL_DESCRIPTION}, true);
            $reason = $description['reason'] ?? null;
            $requestStaffName = $description['requestStaffName'] ?? null;
            $confirmStaffName = $description['confirmStaffName'] ?? null;

            $userStatusHistory->{UserStatusHistory::VAR_REASON} = $reason;
            $userStatusHistory->{UserStatusHistory::VAR_REQUEST_STAFF_NAME} = $requestStaffName;
            $userStatusHistory->{UserStatusHistory::VAR_CONFIRM_STAFF_NAME} = $confirmStaffName;
        }

        return GetUserStatusHistoryListOutputDTO::assemble($userStatusHistoryList);
    }
}
