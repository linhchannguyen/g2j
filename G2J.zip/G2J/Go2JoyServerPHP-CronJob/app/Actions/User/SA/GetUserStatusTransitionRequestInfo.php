<?php

namespace App\Actions\User\SA;

use App\DTOs\User\SA\GetUserStatusTransitionRequestInfoInputDTO;
use App\DTOs\User\SA\GetUserStatusTransitionRequestInfoOutputDTO;
use App\Models\UserStatusTransitionRequest;
use App\Repositories\Interfaces\UserStatusTransitionRequestRepositoryInterface;

class GetUserStatusTransitionRequestInfo
{
    const FILE_LANGUAGE_NAME = 'sa/user';

    /** @var UserStatusTransitionRequestRepositoryInterface */
    protected $userStatusTransitionRequestRepository;

    public function __construct(
        UserStatusTransitionRequestRepositoryInterface $userStatusTransitionRequestRepository
    )
    {
        $this->userStatusTransitionRequestRepository = $userStatusTransitionRequestRepository;
    }

    public function handle(GetUserStatusTransitionRequestInfoInputDTO $getUserStatusTransitionRequestInfoInputDTO): GetUserStatusTransitionRequestInfoOutputDTO
    {
        $userStatusTransitionRequest = $this->userStatusTransitionRequestRepository->find($getUserStatusTransitionRequestInfoInputDTO->getUserStatusTransitionRequestSn(), [
            UserStatusTransitionRequest::COL_APP_USER_SN,
            UserStatusTransitionRequest::COL_REASON,
            UserStatusTransitionRequest::COL_SNAPSHOT,
        ]);

        if (empty($userStatusTransitionRequest)) {
            return new GetUserStatusTransitionRequestInfoOutputDTO();
        }

        return GetUserStatusTransitionRequestInfoOutputDTO::assemble($userStatusTransitionRequest);
    }
}
