<?php

namespace App\Actions\User\SA;

use App\Constants\AppUser as AppUserConst;
use App\Constants\Globals\LoginStatus as LoginStatusConst;
use App\Constants\LogInOutHistory as LogInOutHistoryConst;
use App\Constants\UserStatusHistory as UserStatusHistoryConst;
use App\DTOs\User\SA\GetAppUserInfoInputDTO;
use App\DTOs\User\SA\GetAppUserInfoOutputDTO;
use App\Models\AppUser;
use App\Models\LogInOutHistory;
use App\Models\MobileDevice;
use App\Repositories\Interfaces\AppUserRepositoryInterface;
use App\Repositories\Interfaces\LogInOutHistoryRepositoryInterface;
use App\Repositories\Interfaces\MobileDeviceRepositoryInterface;
use App\Repositories\Interfaces\UserStatusTransitionRequestRepositoryInterface;

class GetAppUserInfo
{
    const FILE_LANGUAGE_NAME = 'sa/user';

    /** @var AppUserRepositoryInterface */
    protected $appUserRepository;

    /** @var MobileDeviceRepositoryInterface */
    protected $mobileDeviceRepository;

    /** @var UserStatusTransitionRequestRepositoryInterface */
    protected $userStatusTransitionRequestRepository;

    /** @var LogInOutHistoryRepositoryInterface */
    protected $logInOutHistoryRepository;

    public function __construct(
        AppUserRepositoryInterface $appUserRepository,
        MobileDeviceRepositoryInterface $mobileDeviceRepository,
        UserStatusTransitionRequestRepositoryInterface $userStatusTransitionRequestRepository,
        LogInOutHistoryRepositoryInterface $logInOutHistoryRepository
    )
    {
        $this->appUserRepository = $appUserRepository;
        $this->mobileDeviceRepository = $mobileDeviceRepository;
        $this->userStatusTransitionRequestRepository = $userStatusTransitionRequestRepository;
        $this->logInOutHistoryRepository = $logInOutHistoryRepository;
    }

    public function handle(GetAppUserInfoInputDTO $getAppUserInfoInputDTO): GetAppUserInfoOutputDTO
    {
        $appUser = $this->appUserRepository->find($getAppUserInfoInputDTO->getSn(), [
            AppUser::COL_SN,
            AppUser::COL_MEMBER_ID,
            AppUser::COL_MOBILE,
            AppUser::COL_NICK_NAME,
            AppUser::COL_GENDER,
            AppUser::COL_BIRTHDAY,
            AppUser::COL_EMAIL,
            AppUser::COL_ADDRESS,
            AppUser::COL_STATUS,
            AppUser::COL_REGISTER_TIME,
            AppUser::COL_VIA_APP,
            AppUser::COL_NUM_OPEN_APP,
            AppUser::COL_LAST_OPEN_APP,
        ]);

        if (!empty($appUser)) {
            if ($appUser->{AppUser::COL_STATUS} == AppUserConst::STATUS['DELETED']) {
                return new GetAppUserInfoOutputDTO();
            }

            // Currently, only show last login mobile device info, not show web device info
            $mobileDevice = $this->mobileDeviceRepository->findWhere(array(
                [MobileDevice::COL_APP_USER_SN, '=', $appUser->{AppUser::COL_SN}]
            ), [
                MobileDevice::COL_OS,
                MobileDevice::COL_OS_VERSION,
                MobileDevice::COL_LANGUAGE,
                MobileDevice::COL_APP_VERSION,
                MobileDevice::COL_PHONE_MODEL,
                MobileDevice::COL_REGISTER_TIME,
            ])->first();

            $workingStatus = UserStatusHistoryConst::WORKING_STATUS['RECEIVED'];
            $userStatusTransitionRequest = $this->userStatusTransitionRequestRepository->findAwaitingApprovalRequest($appUser->{AppUser::COL_SN});
            if (!empty($userStatusTransitionRequest)) {
                $workingStatus = UserStatusHistoryConst::WORKING_STATUS['AWAITING_APPROVAL'];
            }

            $loginStatus = LoginStatusConst::LOGOUT;
            $logInOutHistory = $this->logInOutHistoryRepository->findLastMobileAppLoginStatus($appUser->{AppUser::COL_SN});
            if (!empty($logInOutHistory) && $logInOutHistory->{LogInOutHistory::COL_STATUS} == LogInOutHistoryConst::STATUS['LOG-IN']) {
                $loginStatus = LoginStatusConst::LOGIN;
            }
            return GetAppUserInfoOutputDTO::assemble($appUser, $mobileDevice, $workingStatus, $loginStatus);
        }

        return new GetAppUserInfoOutputDTO();
    }
}
