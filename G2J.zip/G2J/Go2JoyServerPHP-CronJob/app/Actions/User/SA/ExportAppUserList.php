<?php

namespace App\Actions\User\SA;

use App\Constants\Globals\QueueName;
use App\DTOs\User\SA\ExportAppUserListInputDTO;
use App\Jobs\Exports\AppUser\ExportV2Job;
use Illuminate\Support\Carbon;

class ExportAppUserList
{
    const MONTHS_IN_BETWEEN_MIN = 0;
    const MONTHS_IN_BETWEEN_MAX = 6;

    public function handle(ExportAppUserListInputDTO $exportAppUserListInputDTO): void
    {
        if (empty($exportAppUserListInputDTO->getStartDate())) {
            $exportAppUserListInputDTO->setStartDate(Carbon::now()->subMonths(self::MONTHS_IN_BETWEEN_MAX)->format('Y-m-d'));
        }
        if (empty($exportAppUserListInputDTO->getEndDate())) {
            $exportAppUserListInputDTO->setEndDate(Carbon::now()->format('Y-m-d'));
        }

        $job = new ExportV2Job(
            $exportAppUserListInputDTO->getStaffSn(),
            $exportAppUserListInputDTO->getKeyword(),
            $exportAppUserListInputDTO->getStartDate(),
            $exportAppUserListInputDTO->getEndDate(),
            $exportAppUserListInputDTO->getRestrictedProvinceSnList()
        );
        dispatch($job->onQueue(QueueName::EXPORTS));
    }
}
