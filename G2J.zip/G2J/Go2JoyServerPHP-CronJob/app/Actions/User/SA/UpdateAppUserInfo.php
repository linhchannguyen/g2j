<?php

namespace App\Actions\User\SA;

use App\Constants\Globals\Code as CodeConst;
use App\Constants\Globals\Common as CommonConst;
use App\DTOs\User\SA\UpdateAppUserInfoInputDTO;
use App\DTOs\User\SA\UpdateAppUserInfoOutputDTO;
use App\Exceptions\ServiceException;
use App\Helpers\CommonHelper;
use App\Models\AppUser;
use App\Models\UserStatistic;
use App\Repositories\Interfaces\AppUserRepositoryInterface;
use App\Repositories\Interfaces\UserStatisticRepositoryInterface;
use App\Repositories\Interfaces\UserStatusTransitionRequestRepositoryInterface;
use Illuminate\Support\Facades\DB;
use Throwable;

class UpdateAppUserInfo
{
    const FILE_LANGUAGE_NAME = 'sa/user';

    /** @var AppUserRepositoryInterface */
    protected $appUserRepository;

    /** @var UserStatusTransitionRequestRepositoryInterface */
    protected $userStatusTransitionRequestRepository;

    /** @var UserStatisticRepositoryInterface */
    protected $userStatisticRepository;

    public function __construct(
        AppUserRepositoryInterface $appUserRepository,
        UserStatusTransitionRequestRepositoryInterface $userStatusTransitionRequestRepository,
        UserStatisticRepositoryInterface $userStatisticRepository
    )
    {
        $this->appUserRepository = $appUserRepository;
        $this->userStatusTransitionRequestRepository = $userStatusTransitionRequestRepository;
        $this->userStatisticRepository = $userStatisticRepository;
    }

    /**
     * @throws ServiceException|Throwable
     */
    public function handle(UpdateAppUserInfoInputDTO $updateAppUserInfoInputDTO): UpdateAppUserInfoOutputDTO
    {
        return DB::connection('mysql')->transaction(function () use ($updateAppUserInfoInputDTO) {
            $numOfRecords = AppUser::lockForUpdate()->where(AppUser::COL_SN, $updateAppUserInfoInputDTO->getSn())->count();
            if ($numOfRecords == 0) {
                throw new ServiceException(CommonHelper::getMessage(self::FILE_LANGUAGE_NAME, CodeConst::API_USR_001), CodeConst::API_USR_001);
            }

            $userStatusTransitionRequest = $this->userStatusTransitionRequestRepository->findAwaitingApprovalRequest($updateAppUserInfoInputDTO->getSn());
            if (!empty($userStatusTransitionRequest)) {
                throw new ServiceException(CommonHelper::getMessage(self::FILE_LANGUAGE_NAME, CodeConst::API_USR_003), CodeConst::API_USR_003);
            }

            $appUserUpdate = new AppUser();
            $appUserUpdate{AppUser::COL_NICK_NAME} = $updateAppUserInfoInputDTO->getNickName();
            $appUserUpdate{AppUser::COL_GENDER} = $updateAppUserInfoInputDTO->getGender();
            $appUserUpdate{AppUser::COL_BIRTHDAY} = $updateAppUserInfoInputDTO->getBirthday();
            $appUserUpdate{AppUser::COL_EMAIL} = $updateAppUserInfoInputDTO->getEmail();
            $appUserUpdate{AppUser::COL_ADDRESS} = $updateAppUserInfoInputDTO->getAddress();
            $numOfRecords = $this->appUserRepository->update($appUserUpdate->toArray(), $updateAppUserInfoInputDTO->getSn());
            if ($numOfRecords > 0) {

                $this->userStatisticRepository->update([
                    UserStatistic::COL_NICK_NAME => $updateAppUserInfoInputDTO->getNickName()
                ], $updateAppUserInfoInputDTO->getSn());

                return UpdateAppUserInfoOutputDTO::assemble($appUserUpdate);
            }

            throw new ServiceException(CommonHelper::getMessage(CommonConst::FILE_MESSAGE_LANGUAGE_NAME, CodeConst::API_GNR_006), CodeConst::API_GNR_006);
        });
    }
}
