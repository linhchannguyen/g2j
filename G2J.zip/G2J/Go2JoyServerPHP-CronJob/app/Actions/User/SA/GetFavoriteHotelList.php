<?php

namespace App\Actions\User\SA;

use App\DTOs\User\SA\GetFavoriteHotelListInputDTO;
use App\DTOs\User\SA\GetFavoriteHotelListOutputDTO;
use App\DTOs\User\SA\GetAppUserInfoInputDTO;
use App\Repositories\Interfaces\UserFavoriteRepositoryInterface;

class GetFavoriteHotelList
{
    const FILE_LANGUAGE_NAME = 'sa/user';

    /** @var UserFavoriteRepositoryInterface */
    protected $userFavoriteRepository;

    /** @var GetAppUserInfo */
    protected $getAppUserInfo;

    public function __construct(
        UserFavoriteRepositoryInterface $userFavoriteRepository,
        GetAppUserInfo $getAppUserInfo
    )
    {
        $this->userFavoriteRepository = $userFavoriteRepository;
        $this->getAppUserInfo = $getAppUserInfo;
    }

    public function handle(GetFavoriteHotelListInputDTO $getFavoriteHotelListInputDTO): GetFavoriteHotelListOutputDTO
    {
        $getAppUserInfoInputDTO = new GetAppUserInfoInputDTO();
        $getAppUserInfoInputDTO->setSn($getFavoriteHotelListInputDTO->getAppUserSn());
        $getAppUserInfoOutputDTO = $this->getAppUserInfo->handle($getAppUserInfoInputDTO);
        if ($getAppUserInfoOutputDTO->isEmpty()) {
            return new GetFavoriteHotelListOutputDTO();
        }

        $favoriteHotelList = $this->userFavoriteRepository->findFavoriteHotelList(
            $getFavoriteHotelListInputDTO->getAppUserSn(),
            $getFavoriteHotelListInputDTO->getLimit()
        );

        if ($favoriteHotelList->isEmpty()) {
            return new GetFavoriteHotelListOutputDTO();
        }

        return GetFavoriteHotelListOutputDTO::assemble($favoriteHotelList);
    }
}
