<?php

namespace App\Actions\User\SA;

use App\Constants\Activity as ActivityConst;
use App\Constants\AppUser as AppUserConst;
use App\Constants\Globals\Code as CodeConst;
use App\Constants\UserStatusTransitionRequest as UserStatusTransitionRequestConst;
use App\DTOs\User\SA\GetAppUserInfoInputDTO;
use App\DTOs\User\SA\RequestLockAppUserInputDTO;
use App\DTOs\User\SA\RequestLockAppUserOutputDTO;
use App\Exceptions\ServiceException;
use App\Helpers\CommonHelper;
use App\Models\AppUser;
use App\Models\Staff;
use App\Models\UserStatusTransitionRequest;
use App\Repositories\Interfaces\AppUserRepositoryInterface;
use App\Repositories\Interfaces\StaffRepositoryInterface;
use App\Repositories\Interfaces\UserStatusHistoryRepositoryInterface;
use App\Repositories\Interfaces\UserStatusTransitionRequestRepositoryInterface;
use App\Services\Web\SA\ActivityService;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\DB;
use Throwable;

class RequestLockAppUser
{
    const FILE_LANGUAGE_NAME = 'sa/user';

    /** @var AppUserRepositoryInterface */
    protected $appUserRepository;

    /** @var UserStatusTransitionRequestRepositoryInterface */
    protected $userStatusTransitionRequestRepository;

    /** @var UserStatusHistoryRepositoryInterface */
    protected $userStatusHistoryRepository;

    /** @var StaffRepositoryInterface */
    protected $staffRepository;

    /** @var GetAppUserInfo */
    protected $getAppUserInfo;

    /** @var ActivityService */
    protected $activityService;

    public function __construct(
        AppUserRepositoryInterface $appUserRepository,
        UserStatusTransitionRequestRepositoryInterface $userStatusTransitionRequestRepository,
        UserStatusHistoryRepositoryInterface $userStatusHistoryRepository,
        StaffRepositoryInterface $staffRepository,
        GetAppUserInfo $getAppUserInfo,
        ActivityService $activityService
    )
    {
        $this->appUserRepository = $appUserRepository;
        $this->userStatusTransitionRequestRepository = $userStatusTransitionRequestRepository;
        $this->userStatusHistoryRepository = $userStatusHistoryRepository;
        $this->staffRepository = $staffRepository;
        $this->getAppUserInfo = $getAppUserInfo;
        $this->activityService = $activityService;
    }

    /**
     * @throws ServiceException|Throwable
     */
    public function handle(RequestLockAppUserInputDTO $requestLockAppUserInputDTO): RequestLockAppUserOutputDTO
    {
        DB::connection('mysql')->transaction(function () use ($requestLockAppUserInputDTO) {
            $appUser = AppUser::lockForUpdate()->where(AppUser::COL_SN, $requestLockAppUserInputDTO->getAppUserSn())->first();
            if (empty($appUser)) {
                throw new ServiceException(CommonHelper::getMessage(self::FILE_LANGUAGE_NAME, CodeConst::API_USR_001), CodeConst::API_USR_001);
            }

            if ($appUser->{AppUser::COL_STATUS} != AppUserConst::STATUS['ACTIVE']) {
                throw new ServiceException(CommonHelper::getMessage(self::FILE_LANGUAGE_NAME, CodeConst::API_USR_004), CodeConst::API_USR_004);
            }

            $userStatusTransitionRequest = $this->userStatusTransitionRequestRepository->findAwaitingApprovalRequest($appUser->{AppUser::COL_SN});
            if (!empty($userStatusTransitionRequest)) {
                throw new ServiceException(CommonHelper::getMessage(self::FILE_LANGUAGE_NAME, CodeConst::API_USR_004), CodeConst::API_USR_004);
            }

            $getAppUserInfoInputDTO = new GetAppUserInfoInputDTO();
            $getAppUserInfoInputDTO->setSn($appUser->{AppUser::COL_SN});
            $getAppUserInfoOutputDTO = $this->getAppUserInfo->handle($getAppUserInfoInputDTO);
            $snapshot = $getAppUserInfoOutputDTO->toTransport();
            $userStatusTransitionRequest = $this->userStatusTransitionRequestRepository->create([
                UserStatusTransitionRequest::COL_STATUS              => UserStatusTransitionRequestConst::STATUS['WAITING'],
                UserStatusTransitionRequest::COL_APP_USER_SN         => $appUser->{AppUser::COL_SN},
                UserStatusTransitionRequest::COL_INITIAL_USER_STATUS => $appUser->{AppUser::COL_STATUS},
                UserStatusTransitionRequest::COL_CHANGED_USER_STATUS => AppUserConst::STATUS['LOCKED'],
                UserStatusTransitionRequest::COL_REASON              => $requestLockAppUserInputDTO->getReason(),
                UserStatusTransitionRequest::COL_SNAPSHOT            => json_encode($snapshot),
                UserStatusTransitionRequest::COL_REQUEST_STAFF_SN    => $requestLockAppUserInputDTO->getStaffSn(),
            ]);

            //TODO: Improve by rewrite store activity in activity service class to action class
            $this->activityService->store($userStatusTransitionRequest->{UserStatusTransitionRequest::COL_SN}, ActivityConst::TYPE['USER_STATUS']);

            $staff = $this->staffRepository->find($requestLockAppUserInputDTO->getStaffSn(), [Staff::COL_USER_ID]);
            $this->userStatusHistoryRepository->createAwaitingApprovalHistory(
                $appUser->{AppUser::COL_SN},
                $appUser->{AppUser::COL_STATUS},
                $requestLockAppUserInputDTO->getStaffSn(),
                $staff->{Staff::COL_USER_ID},
                null,
                null,
                $requestLockAppUserInputDTO->getReason(),
                Carbon::now()
            );
        });

        return new RequestLockAppUserOutputDTO();
    }
}
