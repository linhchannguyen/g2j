<?php

namespace App\Actions\User\SA;

use App\Constants\UserStatusHistory as UserStatusHistoryConst;
use App\DTOs\User\SA\GetAppUserListInputDTO;
use App\DTOs\User\SA\GetAppUserListOutputDTO;
use App\Models\AppUser;
use App\Models\Province;
use App\Models\UserStatusHistory;
use App\Repositories\Interfaces\AppUserRepositoryInterface;
use App\Repositories\Interfaces\ProvinceRepositoryInterface;
use App\Repositories\Interfaces\UserStatusTransitionRequestRepositoryInterface;

class GetAppUserList
{
    const FILE_LANGUAGE_NAME = 'sa/user';

    /** @var AppUserRepositoryInterface */
    protected $appUserRepository;

    /** @var UserStatusTransitionRequestRepositoryInterface */
    protected $userStatusTransitionRequestRepository;

    /** @var ProvinceRepositoryInterface */
    protected $provinceRepository;

    public function __construct(
        AppUserRepositoryInterface $appUserRepository,
        UserStatusTransitionRequestRepositoryInterface $userStatusTransitionRequestRepository,
        ProvinceRepositoryInterface $provinceRepository
    )
    {
        $this->appUserRepository = $appUserRepository;
        $this->userStatusTransitionRequestRepository = $userStatusTransitionRequestRepository;
        $this->provinceRepository = $provinceRepository;
    }

    public function handle(GetAppUserListInputDTO $getAppUserListInputDTO): GetAppUserListOutputDTO
    {
        $appUserList = $this->appUserRepository->findAppUserList(
            $getAppUserListInputDTO->getKeyword(),
            $getAppUserListInputDTO->getStartDate(),
            $getAppUserListInputDTO->getEndDate(),
            $getAppUserListInputDTO->getLimit()
        );

        if ($appUserList->isEmpty()) {
            return new GetAppUserListOutputDTO();
        }

        foreach ($appUserList as $appUser) {
            $appUser->{UserStatusHistory::COL_WORKING_STATUS} = UserStatusHistoryConst::WORKING_STATUS['RECEIVED'];
            $userStatusTransitionRequest = $this->userStatusTransitionRequestRepository->findAwaitingApprovalRequest($appUser->{AppUser::COL_SN});
            if (!empty($userStatusTransitionRequest)) {
                $appUser->{UserStatusHistory::COL_WORKING_STATUS} = UserStatusHistoryConst::WORKING_STATUS['AWAITING_APPROVAL'];
            }

            $appUser->{AppUser::AS_FIRST_PROVINCE_NAME} = null;
            if (!empty($appUser->{AppUser::COL_FIRST_PROVINCE_SN})) {
                $province = $this->provinceRepository->find($appUser->{AppUser::COL_FIRST_PROVINCE_SN}, [Province::COL_NAME]);
                $appUser->{AppUser::AS_FIRST_PROVINCE_NAME} = $province->{Province::COL_NAME};
            }
        }

        return GetAppUserListOutputDTO::assemble($appUserList);
    }
}
