<?php

namespace App\Actions\Suggestion;

use App\DTOs\Web\SA\Suggestion\SuggestionStaffOutputDTO;
use App\DTOs\Web\SA\Suggestion\SuggestionStaffInputDTO;
use App\Repositories\Interfaces\StaffRepositoryInterface;

class SuggestionStaff
{
    protected $staffRepository;

    public function __construct(
        StaffRepositoryInterface $staffRepository
    )
    {
        $this->staffRepository = $staffRepository;
    }

    public function handle(SuggestionStaffInputDTO $suggestionStaffInputDTO): SuggestionStaffOutputDTO
    {
        $keyword = $suggestionStaffInputDTO->getKeyword();
        $limit = $suggestionStaffInputDTO->getLimit();
        $staffs = $this->staffRepository->suggestStaff($keyword, $limit);

        if($staffs->isEmpty()) {
            return new SuggestionStaffOutputDTO();
        }

        return SuggestionStaffOutputDTO::assemble($staffs);
    }
}
