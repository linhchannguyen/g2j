<?php

namespace App\Actions\Reward;

use App\Constants\Globals\Code as CodeConst;
use App\Constants\Globals\Common as CommonConst;
use App\Constants\MileagePointHistory as MileagePointHistoryConst;
use App\Constants\MileagePointTransactionHistory as MileagePointTransactionHistoryConst;
use App\Constants\PaymentTransaction;
use App\Constants\UserBooking as UserBookingConst;
use App\DTOs\Reward\WithdrawActivePointInputDTO;
use App\DTOs\Reward\WithdrawActivePointOutputDTO;
use App\Exceptions\ServiceException;
use App\Helpers\CommonHelper;
use App\Helpers\LoggingHelper;
use App\Models\AppUser;
use App\Models\MileagePointHistory;
use App\Models\MileagePointTransactionHistory;
use App\Models\UserBooking;
use App\Repositories\Interfaces\AppUserRepositoryInterface;
use App\Repositories\Interfaces\BookingActionHistoryRepositoryInterface;
use App\Repositories\Interfaces\MileagePointHistoryRepositoryInterface;
use App\Repositories\Interfaces\MileagePointTransactionHistoryRepositoryInterface;
use Exception;
use Illuminate\Support\Facades\DB;

class WithdrawActivePoint
{
    const FILE_LANGUAGE_NAME = 'reward';

    /** @var AppUserRepositoryInterface */
    protected $appUserRepository;

    /** @var MileagePointTransactionHistoryRepositoryInterface */
    protected $mileagePointTransactionHistoryRepository;

    /** @var MileagePointHistoryRepositoryInterface */
    protected $mileagePointHistoryRepository;

    /** @var BookingActionHistoryRepositoryInterface */
    protected $bookingActionHistoryRepository;

    public function __construct(
        AppUserRepositoryInterface                        $appUserRepository,
        MileagePointTransactionHistoryRepositoryInterface $mileagePointTransactionHistoryRepository,
        MileagePointHistoryRepositoryInterface            $mileagePointHistoryRepository,
        BookingActionHistoryRepositoryInterface           $bookingActionHistoryRepository
    ) {
        $this->appUserRepository = $appUserRepository;
        $this->mileagePointTransactionHistoryRepository = $mileagePointTransactionHistoryRepository;
        $this->mileagePointHistoryRepository = $mileagePointHistoryRepository;
        $this->bookingActionHistoryRepository = $bookingActionHistoryRepository;
    }

    public function handle(WithdrawActivePointInputDTO $withdrawActivePointInputDTO): WithdrawActivePointOutputDTO
    {
        $userBooking = UserBooking::where(UserBooking::COL_SN, $withdrawActivePointInputDTO->getUserBookingSn())->first([
            UserBooking::COL_SN,
            UserBooking::COL_BOOKING_STATUS,
            UserBooking::COL_VIA_OBJECT,
            UserBooking::COL_TYPE,
            UserBooking::COL_CHECK_IN_DATE_PLAN,
            UserBooking::COL_START_TIME,
            UserBooking::COL_END_TIME,
            UserBooking::COL_HOTEL_SN,
            UserBooking::COL_END_DATE,
            UserBooking::COL_APP_USER_SN,
            UserBooking::COL_BOOKING_NO,
            UserBooking::COL_AMOUNT_FROM_USER,
            UserBooking::COL_REFUNDED,
            UserBooking::COL_PAYMENT_PROVIDER
        ]);

        if (empty($userBooking)) {
            throw new ServiceException(CommonHelper::getMessage(CommonConst::FILE_MESSAGE_LANGUAGE_NAME, CodeConst::API_GNR_005), CodeConst::API_GNR_005);
        }

        if (empty($userBooking->{UserBooking::COL_APP_USER_SN})) {
            return WithdrawActivePointOutputDTO::assemble(false);
        }

        if (!in_array($userBooking->{UserBooking::COL_BOOKING_STATUS}, [
                UserBookingConst::BOOKING_STATUS['CANCELLED'],
                UserBookingConst::BOOKING_STATUS['NO_SHOW'],
            ])
        ) {
            return WithdrawActivePointOutputDTO::assemble(false);
        }

        $paymentStatus = CommonHelper::preCheckPaymentStatus(
            $userBooking->{UserBooking::COL_SN},
            $userBooking->{UserBooking::COL_BOOKING_STATUS},
            $userBooking->{UserBooking::COL_REFUNDED},
            $userBooking->{UserBooking::COL_PAYMENT_PROVIDER}
        );
        if ($userBooking->{UserBooking::COL_BOOKING_STATUS} == UserBookingConst::BOOKING_STATUS['NO_SHOW']
            && $paymentStatus == PaymentTransaction::PAYMENT_STATUS['SUCCESSFUL']
        ) {
            return WithdrawActivePointOutputDTO::assemble(false);
        }

        $isOldActivePoint = $this->mileagePointTransactionHistoryRepository->isOldActivePoint($userBooking->{UserBooking::COL_SN});
        if (!$isOldActivePoint) {
            $isExpiredTimeProcessingBooking = CommonHelper::isExpiredTimeProcessingBookingOfPoint($userBooking);
            if (!$isExpiredTimeProcessingBooking) {
                return WithdrawActivePointOutputDTO::assemble(false);
            }
        }

        $isWithdrawn = MileagePointTransactionHistory::where(MileagePointTransactionHistory::COL_USER_BOOKING_SN, $withdrawActivePointInputDTO->getUserBookingSn())
            ->where(MileagePointTransactionHistory::COL_STATUS, MileagePointTransactionHistoryConst::STATUS['WITHDRAW_REWARD'])
            ->exists();
        if ($isWithdrawn) {
            return WithdrawActivePointOutputDTO::assemble(false);
        }

        DB::connection('mysql')->beginTransaction();
        try {
            $appUser = AppUser::lockForUpdate()
                ->where(AppUser::COL_SN, $userBooking->{UserBooking::COL_APP_USER_SN})
                ->first([
                    AppUser::COL_MILEAGE_AMOUNT,
                    AppUser::COL_MILEAGE_EARNED,
                ]);

            $mileageAmount = $appUser->{AppUser::COL_MILEAGE_AMOUNT};
            $mileageEarned = $appUser->{AppUser::COL_MILEAGE_EARNED};

            $mileagePointTransactionHistory = MileagePointTransactionHistory::lockForUpdate()
                ->where(MileagePointTransactionHistory::COL_USER_BOOKING_SN, $withdrawActivePointInputDTO->getUserBookingSn())
                ->where(MileagePointTransactionHistory::COL_STATUS, MileagePointTransactionHistoryConst::STATUS['ACTIVE'])
                ->first([
                    MileagePointTransactionHistory::COL_SN,
                    MileagePointTransactionHistory::COL_APP_USER_SN,
                    MileagePointTransactionHistory::COL_TYPE_PROGRAM,
                    MileagePointTransactionHistory::COL_PROGRAM_SN,
                    MileagePointTransactionHistory::COL_USER_BOOKING_SN,
                    MileagePointTransactionHistory::COL_TOTAL_ACTIVE_POINT,
                    MileagePointTransactionHistory::COL_ACTUAL_POINT,
                    MileagePointTransactionHistory::COL_EXPECTED_POINT,
                ]);
            if (empty($mileagePointTransactionHistory)) {
                DB::connection('mysql')->commit();
                return WithdrawActivePointOutputDTO::assemble(false);
            }
            $actualPoint = $mileagePointTransactionHistory->{MileagePointTransactionHistory::COL_ACTUAL_POINT};
            $mileagePointTransactionHistorySn = $mileagePointTransactionHistory->{MileagePointTransactionHistory::COL_SN};

            $_mileagePointTransactionHistory = MileagePointTransactionHistory::create([
                MileagePointTransactionHistory::COL_APP_USER_SN        => $mileagePointTransactionHistory->{MileagePointTransactionHistory::COL_APP_USER_SN},
                MileagePointTransactionHistory::COL_TYPE_PROGRAM       => $mileagePointTransactionHistory->{MileagePointTransactionHistory::COL_TYPE_PROGRAM},
                MileagePointTransactionHistory::COL_PROGRAM_SN         => $mileagePointTransactionHistory->{MileagePointTransactionHistory::COL_PROGRAM_SN},
                MileagePointTransactionHistory::COL_USER_BOOKING_SN    => $mileagePointTransactionHistory->{MileagePointTransactionHistory::COL_USER_BOOKING_SN},
                MileagePointTransactionHistory::COL_TOTAL_ACTIVE_POINT => $mileagePointTransactionHistory->{MileagePointTransactionHistory::COL_TOTAL_ACTIVE_POINT},
                MileagePointTransactionHistory::COL_ACTUAL_POINT       => -$actualPoint,
                MileagePointTransactionHistory::COL_EXPECTED_POINT     => $mileagePointTransactionHistory->{MileagePointTransactionHistory::COL_EXPECTED_POINT},
                MileagePointTransactionHistory::COL_STATUS             => MileagePointTransactionHistoryConst::STATUS['WITHDRAW_REWARD'],
            ]);
            $_mileagePointTransactionHistorySn = $_mileagePointTransactionHistory->{MileagePointTransactionHistory::COL_SN};

            MileagePointHistory::where(MileagePointHistory::COL_USER_BOOKING_SN, $withdrawActivePointInputDTO->getUserBookingSn())
                ->where(MileagePointHistory::COL_STATUS, MileagePointHistoryConst::STATUS['ACTIVE'])
                ->whereJsonContains(MileagePointHistory::COL_MILEAGE_POINT_TRANSACTION_HISTORY_LIST, $mileagePointTransactionHistorySn)
                ->update([
                    MileagePointHistory::COL_ACTUAL_POINT                           => 0,
                    MileagePointHistory::COL_ACTIVE_TIME_FROM                       => null,
                    MileagePointHistory::COL_ACTIVE_TIME_TO                         => null,
                    MileagePointHistory::COL_STATUS                                 => MileagePointHistoryConst::STATUS['WITHDRAW'],
                    MileagePointHistory::COL_MILEAGE_POINT_TRANSACTION_HISTORY_LIST => json_encode([$mileagePointTransactionHistorySn, $_mileagePointTransactionHistorySn]),
                ]);

            $mileageAmount = $mileageAmount - $actualPoint;
            $mileageEarned = $mileageEarned - $actualPoint;
            $this->appUserRepository->update([
                AppUser::COL_MILEAGE_AMOUNT => $mileageAmount,
                AppUser::COL_MILEAGE_EARNED => $mileageEarned,
            ], $userBooking->{UserBooking::COL_APP_USER_SN});

            DB::connection('mysql')->commit();

            return WithdrawActivePointOutputDTO::assemble(true);
        } catch (Exception $exception) {
            LoggingHelper::logException($exception);
            DB::connection('mysql')->rollBack();
            throw $exception;
        }
    }
}
