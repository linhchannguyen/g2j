<?php

namespace App\Actions\Reward;

use App\Constants\Globals\Code as CodeConst;
use App\Constants\Globals\Common as CommonConst;
use App\Constants\Globals\Pagination as PaginationConst;
use App\Constants\MileagePointHistory as MileagePointHistoryConst;
use App\Constants\MileagePointTransactionHistory as MileagePointTransactionHistoryConst;
use App\Constants\MileageReward as MileageRewardConst;
use App\Constants\MileageTarget as MileageTargetConst;
use App\Constants\PaymentTransaction as PaymentTransactionConst;
use App\Constants\RoomType as RoomTypeConst;
use App\Constants\Setting as SettingConst;
use App\Constants\UserBooking as UserBookingConst;
use App\DTOs\Reward\PendingRewardPointFromBookingInputDTO;
use App\DTOs\Reward\PendingRewardPointFromBookingOutputDTO;
use App\Exceptions\ServiceException;
use App\Helpers\CommonHelper;
use App\Helpers\LoggingHelper;
use App\Models\AppUser;
use App\Models\Hotel;
use App\Models\MileagePointHistory;
use App\Models\MileagePointTransactionHistory;
use App\Models\MileageReward;
use App\Models\MileageTarget;
use App\Models\RoomType;
use App\Models\Setting;
use App\Models\UserBooking;
use App\Repositories\Interfaces\AppUserRepositoryInterface;
use App\Repositories\Interfaces\HotelRepositoryInterface;
use App\Repositories\Interfaces\MileagePointHistoryRepositoryInterface;
use App\Repositories\Interfaces\MileagePointTransactionHistoryRepositoryInterface;
use App\Repositories\Interfaces\MileageRewardRepositoryInterface;
use App\Repositories\Interfaces\MileageTargetRepositoryInterface;
use App\Repositories\Interfaces\UserBookingRepositoryInterface;
use Exception;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\DB;

class PendingRewardPointFromBooking
{
    const FILE_LANGUAGE_NAME = 'reward';

    /** @var AppUserRepositoryInterface */
    protected $appUserRepository;

    /** @var UserBookingRepositoryInterface */
    protected $userBookingRepository;

    /** @var HotelRepositoryInterface */
    protected $hotelRepository;

    /** @var MileageRewardRepositoryInterface */
    protected $mileageRewardRepository;

    /** @var MileageTargetRepositoryInterface */
    protected $mileageTargetRepository;

    /** @var MileagePointTransactionHistoryRepositoryInterface */
    protected $mileagePointTransactionHistoryRepository;

    /** @var MileagePointHistoryRepositoryInterface */
    protected $mileagePointHistoryRepository;

    public function __construct(
        AppUserRepositoryInterface                        $appUserRepository,
        UserBookingRepositoryInterface                    $userBookingRepository,
        HotelRepositoryInterface                          $hotelRepository,
        MileageRewardRepositoryInterface                  $mileageRewardRepository,
        MileageTargetRepositoryInterface                  $mileageTargetRepository,
        MileagePointTransactionHistoryRepositoryInterface $mileagePointTransactionHistoryRepository,
        MileagePointHistoryRepositoryInterface            $mileagePointHistoryRepository
    ) {
        $this->appUserRepository = $appUserRepository;
        $this->userBookingRepository = $userBookingRepository;
        $this->hotelRepository = $hotelRepository;
        $this->mileageRewardRepository = $mileageRewardRepository;
        $this->mileageTargetRepository = $mileageTargetRepository;
        $this->mileagePointTransactionHistoryRepository = $mileagePointTransactionHistoryRepository;
        $this->mileagePointHistoryRepository = $mileagePointHistoryRepository;
    }

    public function handle(PendingRewardPointFromBookingInputDTO $pendingRewardPointFromBookingInputDTO): PendingRewardPointFromBookingOutputDTO
    {
        $now = Carbon::now();
        $expectedPoint = 0;

        $userBooking = $this->userBookingRepository->find($pendingRewardPointFromBookingInputDTO->getUserBookingSn(), [
            UserBooking::COL_SN,
            UserBooking::COL_BOOKING_NO,
            UserBooking::COL_APP_USER_SN,
            UserBooking::COL_BOOKING_STATUS,
            UserBooking::COL_REFUNDED,
            UserBooking::COL_PAYMENT_PROVIDER,
            UserBooking::COL_AMOUNT_FROM_USER,
            UserBooking::COL_TYPE,
            UserBooking::COL_CHECK_IN_DATE_PLAN,
            UserBooking::COL_START_TIME,
            UserBooking::COL_END_TIME,
            UserBooking::COL_HOTEL_SN,
            UserBooking::COL_END_DATE,
            UserBooking::COL_ROOM_TYPE_SN,
            UserBooking::COL_FLASH_SALE_HISTORY_SN,
            UserBooking::COL_COUPON_ISSUED_SN,
            UserBooking::COL_PAYMENT_PROVIDER,
            UserBooking::COL_PAYMENT_CODE,
        ]);

        if (empty($userBooking)) {
            throw new ServiceException(CommonHelper::getMessage(CommonConst::FILE_MESSAGE_LANGUAGE_NAME, CodeConst::API_GNR_005), CodeConst::API_GNR_005);
        }

        if (empty($userBooking->{UserBooking::COL_APP_USER_SN})) {
            return PendingRewardPointFromBookingOutputDTO::assemble($expectedPoint);
        }

        if (!in_array($userBooking->{UserBooking::COL_BOOKING_STATUS}, [
                UserBookingConst::BOOKING_STATUS['COMPLETED'],
                UserBookingConst::BOOKING_STATUS['NO_SHOW']
            ])
        ) {
            return PendingRewardPointFromBookingOutputDTO::assemble($expectedPoint);
        }

        $paymentStatus = CommonHelper::preCheckPaymentStatus(
            $userBooking->{UserBooking::COL_SN},
            $userBooking->{UserBooking::COL_BOOKING_STATUS},
            $userBooking->{UserBooking::COL_REFUNDED},
            $userBooking->{UserBooking::COL_PAYMENT_PROVIDER}
        );

        if (PaymentTransactionConst::PAYMENT_STATUS['SUCCESSFUL'] != $paymentStatus) {
            return PendingRewardPointFromBookingOutputDTO::assemble($expectedPoint);
        }

        $amountFromUser = $userBooking->{UserBooking::COL_AMOUNT_FROM_USER};
        if ($amountFromUser <= 0) {
            return PendingRewardPointFromBookingOutputDTO::assemble($expectedPoint);
        }

        $isExpiredTimeProcessingBooking = CommonHelper::isExpiredTimeProcessingBookingOfPoint($userBooking);
        if ($isExpiredTimeProcessingBooking && !$pendingRewardPointFromBookingInputDTO->isAllowExceedExpirationTime()) {
            return PendingRewardPointFromBookingOutputDTO::assemble($expectedPoint);
        }

        $havePendingReward = $this->mileagePointTransactionHistoryRepository->havePendingRewardPoint($pendingRewardPointFromBookingInputDTO->getUserBookingSn());
        if ($havePendingReward) {
            return PendingRewardPointFromBookingOutputDTO::assemble($expectedPoint);
        }

        $haveRewarded = $this->mileagePointTransactionHistoryRepository->haveRewardedPoint($pendingRewardPointFromBookingInputDTO->getUserBookingSn());
        if ($haveRewarded) {
            $isOldActivePoint = $this->mileagePointTransactionHistoryRepository->isOldActivePoint($pendingRewardPointFromBookingInputDTO->getUserBookingSn());
            if (!$isOldActivePoint) {
                return PendingRewardPointFromBookingOutputDTO::assemble($expectedPoint);
            }
        }

        /**
         * 1. Change reward point 1%
         * 2. PRD: https://www.notion.so/SA-F15-4_Mileage-Point-Improvement-53a4aabd83b249169428e9d9f2e51c55
         **/
        [$numPoint, $mileageRewardSn] = $this->_getNumPointExchange($userBooking);
        $expectedPoint = intval(($amountFromUser / MileageRewardConst::MONEY_UNIT_DEFAULT) * $numPoint);

        if (!empty($mileageRewardSn)) {
            $mileageReward = MileageReward::where(MileageReward::COL_SN, $mileageRewardSn)->first([MileageReward::COL_NAME]);
            $programName = $mileageReward->{MileageReward::COL_NAME};
        } else {
            $programName = null;
        }

        $appUserSn = $userBooking->{UserBooking::COL_APP_USER_SN};

        DB::connection('mysql')->beginTransaction();
        try {
            $appUser = AppUser::lockForUpdate()
                ->where(AppUser::COL_SN, $appUserSn)
                ->first([
                    AppUser::COL_MILEAGE_AMOUNT,
                    AppUser::COL_MILEAGE_PENDING,
                ]);

            $totalActivePoint = $appUser->{AppUser::COL_MILEAGE_AMOUNT};
            $mileagePending = $appUser->{AppUser::COL_MILEAGE_PENDING};

            $mileagePointTransactionHistory = MileagePointTransactionHistory::create([
                MileagePointTransactionHistory::COL_APP_USER_SN        => $appUserSn,
                MileagePointTransactionHistory::COL_TYPE_PROGRAM       => $mileageRewardSn ? MileagePointTransactionHistoryConst::TYPE_PROGRAM['REWARD'] : MileagePointTransactionHistoryConst::TYPE_PROGRAM['BOOKING'],
                MileagePointTransactionHistory::COL_PROGRAM_SN         => $mileageRewardSn,
                MileagePointTransactionHistory::COL_USER_BOOKING_SN    => $pendingRewardPointFromBookingInputDTO->getUserBookingSn(),
                MileagePointTransactionHistory::COL_TOTAL_ACTIVE_POINT => $totalActivePoint,
                MileagePointTransactionHistory::COL_ACTUAL_POINT       => 0,
                MileagePointTransactionHistory::COL_EXPECTED_POINT     => $expectedPoint,
                MileagePointTransactionHistory::COL_STATUS             => MileagePointTransactionHistoryConst::STATUS['PENDING_REWARD'],
            ]);
            $mileagePointTransactionHistorySn = $mileagePointTransactionHistory->{MileagePointTransactionHistory::COL_SN};

            $rangeActiveTime = CommonHelper::getRangeActiveTimeOfPoint($userBooking);
            $activeTimeFrom = $rangeActiveTime->activeTimeFrom;
            $activeTimeTo = $rangeActiveTime->activeTimeTo;

            $hotelSn = $userBooking->{UserBooking::COL_HOTEL_SN};
            $hotel = $this->hotelRepository->find($hotelSn, [Hotel::COL_NAME]);
            $hotelName = $hotel->{Hotel::COL_NAME};
            $checkin = CommonHelper::getBookingCheckinDateTime($userBooking);
            $checkout = CommonHelper::getBookingCheckoutDateTime($userBooking);

            MileagePointHistory::create([
                MileagePointHistory::COL_APP_USER_SN                            => $appUserSn,
                MileagePointHistory::COL_PROGRAM_NAME                           => $programName,
                MileagePointHistory::COL_PROGRAM_SN                             => $mileageRewardSn,
                MileagePointHistory::COL_BOOKING_NO                             => $userBooking->{UserBooking::COL_BOOKING_NO},
                MileagePointHistory::COL_HOTEL_NAME                             => $hotelName,
                MileagePointHistory::COL_CHECKIN                                => $checkin,
                MileagePointHistory::COL_CHECKOUT                               => $checkout,
                MileagePointHistory::COL_USER_BOOKING_SN                        => $userBooking->{UserBooking::COL_SN},
                MileagePointHistory::COL_TYPE_PROGRAM                           => $mileageRewardSn ? MileagePointHistoryConst::TYPE_PROGRAM['REWARD'] : MileagePointHistoryConst::TYPE_PROGRAM['BOOKING'],
                MileagePointHistory::COL_STATUS                                 => MileagePointHistoryConst::STATUS['PENDING_REWARD'],
                MileagePointHistory::COL_TOTAL_ACTIVE_POINT                     => $totalActivePoint,
                MileagePointHistory::COL_ACTUAL_POINT                           => 0,
                MileagePointHistory::COL_EXPECTED_POINT                         => $expectedPoint,
                MileagePointHistory::COL_USER_PAID                              => $userBooking->{UserBooking::COL_AMOUNT_FROM_USER},
                MileagePointHistory::COL_ACTIVE_TIME_FROM                       => $activeTimeFrom,
                MileagePointHistory::COL_ACTIVE_TIME_TO                         => $activeTimeTo,
                MileagePointHistory::COL_CLAIM_TIME                             => null,
                MileagePointHistory::COL_REFUND_TIME                            => null,
                MileagePointHistory::COL_EXPIRATION_TIME                        => $activeTimeTo,
                MileagePointHistory::COL_MILEAGE_POINT_TRANSACTION_HISTORY_LIST => json_encode([$mileagePointTransactionHistorySn]),
            ]);

            $mileagePending += $expectedPoint;

            $this->appUserRepository->update([
                AppUser::COL_MILEAGE_PENDING => $mileagePending,
            ], $appUserSn);

            DB::connection('mysql')->commit();

            return PendingRewardPointFromBookingOutputDTO::assemble($expectedPoint);
        } catch (Exception $exception) {
            DB::connection('mysql')->rollBack();
            LoggingHelper::logException($exception);
            throw $exception;
        }
    }

    private function _getNumPointExchange(object $userBooking): array
    {
        $numPoint = MileageRewardConst::NUM_POINT_DEFAULT;
        $mileageRewardSn = null;
        $mileageRewardList = $this->mileageRewardRepository->findMileageRewardList(null, [MileageRewardConst::ACTIVE], null, null, PaginationConst::LIMIT['NO_LIMIT']);
        foreach ($mileageRewardList as $mileageReward) {
            if ($this->_isMatchMileagePointCondition($mileageReward, $userBooking)) {
                if ($mileageReward->{MileageReward::COL_NUM_POINT} > $numPoint) {
                    $numPoint = $mileageReward->{MileageReward::COL_NUM_POINT};
                    $mileageRewardSn = $mileageReward->{MileageReward::COL_SN};
                }
            }
        }
        return [$numPoint, $mileageRewardSn];
    }

    private function _isMatchMileagePointCondition(object $mileageReward, object $userBooking): bool
    {
        if (!$mileageReward->{MileageReward::COL_HOURLY} && $userBooking->{UserBooking::COL_TYPE} == UserBookingConst::BOOKING_TYPE['HOURLY']) {
            return false;
        }
        if (!$mileageReward->{MileageReward::COL_OVERNIGHT} && $userBooking->{UserBooking::COL_TYPE} == UserBookingConst::BOOKING_TYPE['OVERNIGHT']) {
            return false;
        }
        if (!$mileageReward->{MileageReward::COL_DAILY} && $userBooking->{UserBooking::COL_TYPE} == UserBookingConst::BOOKING_TYPE['DAILY']) {
            return false;
        }

        $dayOfWeek = Carbon::parse($userBooking->{UserBooking::COL_CHECK_IN_DATE_PLAN})->dayOfWeek;
        if (!$mileageReward->{MileageReward::COL_SUNDAY} && $dayOfWeek == Carbon::SUNDAY) {
            return false;
        }
        if (!$mileageReward->{MileageReward::COL_MONDAY} && $dayOfWeek == Carbon::MONDAY) {
            return false;
        }
        if (!$mileageReward->{MileageReward::COL_TUESDAY} && $dayOfWeek == Carbon::TUESDAY) {
            return false;
        }
        if (!$mileageReward->{MileageReward::COL_WEDNESDAY} && $dayOfWeek == Carbon::WEDNESDAY) {
            return false;
        }
        if (!$mileageReward->{MileageReward::COL_THURSDAY} && $dayOfWeek == Carbon::THURSDAY) {
            return false;
        }
        if (!$mileageReward->{MileageReward::COL_FRIDAY} && $dayOfWeek == Carbon::FRIDAY) {
            return false;
        }
        if (!$mileageReward->{MileageReward::COL_SATURDAY} && $dayOfWeek == Carbon::SATURDAY) {
            return false;
        }

        $roomType = RoomType::where(RoomType::COL_SN, $userBooking->{UserBooking::COL_ROOM_TYPE_SN})->first([RoomType::COL_MODE]);
        if (!empty($roomType)) {
            if (!$mileageReward->{MileageReward::COL_NORMAL_ROOM} && $roomType->{RoomType::COL_MODE} == RoomTypeConst::MODE['NORMAL']) {
                return false;
            }
            if (!$mileageReward->{MileageReward::COL_FLASHSALE_ROOM} && !empty($userBooking->{UserBooking::COL_FLASH_SALE_HISTORY_SN})) {
                return false;
            }
        }

        if ($userBooking->{UserBooking::COL_AMOUNT_FROM_USER} < $mileageReward->{MileageReward::COL_MIN_FEE}) {
            return false;
        }
        if (!$mileageReward->{MileageReward::COL_COMBINE_PROMOTION} && !empty($userBooking->{UserBooking::COL_COUPON_ISSUED_SN})) {
            return false;
        }
        if (!$mileageReward->{MileageReward::COL_PAY_AT_HOTEL} && $userBooking->{UserBooking::COL_PAYMENT_PROVIDER} == UserBookingConst::PAYMENT_PROVIDER['AT_HOTEL']) {
            return false;
        }

        #region Outdated payment method
        if (!$mileageReward->{MileageReward::COL_PAY_AT_STORE} && $userBooking->{UserBooking::COL_PAYMENT_PROVIDER} == UserBookingConst::PAYMENT_PROVIDER['PAYOO_STORE'] && !empty($userBooking->{UserBooking::COL_PAYMENT_CODE})) {
            return false;
        }
        if (!$mileageReward->{MileageReward::COL_ZALO_CREDIT} && $userBooking->{UserBooking::COL_PAYMENT_PROVIDER} == UserBookingConst::PAYMENT_PROVIDER['CREDIT']) {
            return false;
        }
        if (!$mileageReward->{MileageReward::COL_ZALO_DEBIT} && $userBooking->{UserBooking::COL_PAYMENT_PROVIDER} == UserBookingConst::PAYMENT_PROVIDER['DEBIT']) {
            return false;
        }
        #endregion Outdated payment method

        if (!$this->_isMatchMileageTarget($mileageReward, $userBooking->{UserBooking::COL_HOTEL_SN})) {
            return false;
        }

        return true;
    }

    private function _isMatchMileageTarget(object $mileageReward, int $hotelSn): bool
    {
        if ($mileageReward->{MileageReward::COL_TARGET_APPLY} == MileageTargetConst::TARGET_TYPE['ALL_HOTEL']) {
            return true;
        }

        $mileageTargetList = $this->mileageTargetRepository->findWhere([
            [MileageTarget::COL_MILEAGE_REWARD_SN, '=', $mileageReward->{MileageReward::COL_SN}]
        ]);

        if ($mileageTargetList->count() > 0) {
            switch ($mileageReward->{MileageReward::COL_TARGET_APPLY}) {
                case MileageTargetConst::TARGET_TYPE['ALL_REJECT']: {
                    foreach ($mileageTargetList as $mileageTarget) {
                        if (!empty($mileageTarget->{MileageTarget::COL_HOTEL_SN}) && $hotelSn == $mileageTarget->{MileageTarget::COL_HOTEL_SN}) {
                            return false;
                        }
                    }

                    return true;
                }
                case MileageTargetConst::TARGET_TYPE['SPECIFY_HOTEL']: {
                    foreach ($mileageTargetList as $mileageTarget) {
                        if (!empty($mileageTarget->{MileageTarget::COL_HOTEL_SN}) && $hotelSn == $mileageTarget->{MileageTarget::COL_HOTEL_SN}) {
                            return true;
                        }
                    }

                    return false;
                }
                case MileageTargetConst::TARGET_TYPE['SPECIFY_PROVINCE']: {
                    $hotel = Hotel::where(Hotel::COL_SN, $hotelSn)->first([Hotel::COL_PROVINCE_SN]);
                    if (!empty($hotel)) {
                        foreach ($mileageTargetList as $mileageTarget) {
                            if (!empty($mileageTarget->{MileageTarget::COL_PROVINCE_SN}) && $hotel->{Hotel::COL_PROVINCE_SN} == $mileageTarget->{MileageTarget::COL_PROVINCE_SN}) {
                                return true;
                            }
                        }

                        return false;
                    }
                }
            }
        }

        return false;
    }
}
