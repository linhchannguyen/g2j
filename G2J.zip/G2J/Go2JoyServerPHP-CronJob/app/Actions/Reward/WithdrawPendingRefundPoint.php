<?php

namespace App\Actions\Reward;

use App\Constants\Globals\Code as CodeConst;
use App\Constants\Globals\Common as CommonConst;
use App\Constants\MileagePointHistory as MileagePointHistoryConst;
use App\Constants\MileagePointTransactionHistory as MileagePointTransactionHistoryConst;
use App\Constants\UserBooking as UserBookingConst;
use App\DTOs\Reward\WithdrawPendingRefundPointInputDTO;
use App\DTOs\Reward\WithdrawPendingRefundPointOutputDTO;
use App\Exceptions\ServiceException;
use App\Helpers\CommonHelper;
use App\Helpers\LoggingHelper;
use App\Models\AppUser;
use App\Models\MileagePointHistory;
use App\Models\MileagePointTransactionHistory;
use App\Models\UserBooking;
use App\Repositories\Interfaces\AppUserRepositoryInterface;
use App\Repositories\Interfaces\BookingActionHistoryRepositoryInterface;
use App\Repositories\Interfaces\MileagePointHistoryRepositoryInterface;
use App\Repositories\Interfaces\MileagePointTransactionHistoryRepositoryInterface;
use Exception;
use Illuminate\Support\Facades\DB;

class WithdrawPendingRefundPoint
{
    const FILE_LANGUAGE_NAME = 'reward';

    /** @var AppUserRepositoryInterface */
    protected $appUserRepository;

    /** @var MileagePointTransactionHistoryRepositoryInterface */
    protected $mileagePointTransactionHistoryRepository;

    /** @var MileagePointHistoryRepositoryInterface */
    protected $mileagePointHistoryRepository;

    /** @var BookingActionHistoryRepositoryInterface */
    protected $bookingActionHistoryRepository;

    public function __construct(
        AppUserRepositoryInterface                        $appUserRepository,
        MileagePointTransactionHistoryRepositoryInterface $mileagePointTransactionHistoryRepository,
        MileagePointHistoryRepositoryInterface            $mileagePointHistoryRepository,
        BookingActionHistoryRepositoryInterface           $bookingActionHistoryRepository
    ) {
        $this->appUserRepository = $appUserRepository;
        $this->mileagePointTransactionHistoryRepository = $mileagePointTransactionHistoryRepository;
        $this->mileagePointHistoryRepository = $mileagePointHistoryRepository;
        $this->bookingActionHistoryRepository = $bookingActionHistoryRepository;
    }

    public function handle(WithdrawPendingRefundPointInputDTO $withdrawPendingRefundPointInputDTO): WithdrawPendingRefundPointOutputDTO
    {
        $userBooking = UserBooking::where(UserBooking::COL_SN, $withdrawPendingRefundPointInputDTO->getUserBookingSn())->first([
            UserBooking::COL_SN,
            UserBooking::COL_BOOKING_STATUS,
            UserBooking::COL_VIA_OBJECT,
            UserBooking::COL_TYPE,
            UserBooking::COL_CHECK_IN_DATE_PLAN,
            UserBooking::COL_START_TIME,
            UserBooking::COL_END_TIME,
            UserBooking::COL_HOTEL_SN,
            UserBooking::COL_END_DATE,
            UserBooking::COL_APP_USER_SN,
            UserBooking::COL_BOOKING_NO,
            UserBooking::COL_AMOUNT_FROM_USER,
            UserBooking::COL_REFUNDED,
            UserBooking::COL_PAYMENT_PROVIDER
        ]);

        if (empty($userBooking)) {
            throw new ServiceException(CommonHelper::getMessage(CommonConst::FILE_MESSAGE_LANGUAGE_NAME, CodeConst::API_GNR_005), CodeConst::API_GNR_005);
        }

        if (!in_array($userBooking->{UserBooking::COL_BOOKING_STATUS}, [
                UserBookingConst::BOOKING_STATUS['COMPLETED'],
                UserBookingConst::BOOKING_STATUS['NO_SHOW'],
            ])
        ) {
            return WithdrawPendingRefundPointOutputDTO::assemble(false);
        }

        $isExpiredTimeProcessingBooking = CommonHelper::isExpiredTimeProcessingBookingOfPoint($userBooking);
        if (!$isExpiredTimeProcessingBooking) {
            return WithdrawPendingRefundPointOutputDTO::assemble(false);
        }

        $haveWithdrawnRefund = $this->mileagePointTransactionHistoryRepository->haveWithdrawnRefundPoint($withdrawPendingRefundPointInputDTO->getUserBookingSn());
        if ($haveWithdrawnRefund) {
            return WithdrawPendingRefundPointOutputDTO::assemble(false);
        }

        $haveRefunded = $this->mileagePointTransactionHistoryRepository->haveRefundedPoint($withdrawPendingRefundPointInputDTO->getUserBookingSn());
        if ($haveRefunded) {
            return WithdrawPendingRefundPointOutputDTO::assemble(false);
        }

        DB::connection('mysql')->beginTransaction();
        try {
            $mileagePointTransactionHistory = MileagePointTransactionHistory::lockForUpdate()
                ->where(MileagePointTransactionHistory::COL_USER_BOOKING_SN, $withdrawPendingRefundPointInputDTO->getUserBookingSn())
                ->where(MileagePointTransactionHistory::COL_STATUS, MileagePointTransactionHistoryConst::STATUS['PENDING_REFUND'])
                ->first([
                    MileagePointTransactionHistory::COL_SN,
                    MileagePointTransactionHistory::COL_APP_USER_SN,
                    MileagePointTransactionHistory::COL_TYPE_PROGRAM,
                    MileagePointTransactionHistory::COL_PROGRAM_SN,
                    MileagePointTransactionHistory::COL_USER_BOOKING_SN,
                    MileagePointTransactionHistory::COL_TOTAL_ACTIVE_POINT,
                    MileagePointTransactionHistory::COL_ACTUAL_POINT,
                    MileagePointTransactionHistory::COL_EXPECTED_POINT,
                ]);
            if (empty($mileagePointTransactionHistory)) {
                DB::connection('mysql')->commit();
                return WithdrawPendingRefundPointOutputDTO::assemble(false);
            }
            $mileagePointTransactionHistorySn = $mileagePointTransactionHistory->{MileagePointTransactionHistory::COL_SN};

            $_mileagePointTransactionHistory = MileagePointTransactionHistory::create([
                MileagePointTransactionHistory::COL_APP_USER_SN        => $mileagePointTransactionHistory->{MileagePointTransactionHistory::COL_APP_USER_SN},
                MileagePointTransactionHistory::COL_TYPE_PROGRAM       => $mileagePointTransactionHistory->{MileagePointTransactionHistory::COL_TYPE_PROGRAM},
                MileagePointTransactionHistory::COL_PROGRAM_SN         => $mileagePointTransactionHistory->{MileagePointTransactionHistory::COL_PROGRAM_SN},
                MileagePointTransactionHistory::COL_USER_BOOKING_SN    => $mileagePointTransactionHistory->{MileagePointTransactionHistory::COL_USER_BOOKING_SN},
                MileagePointTransactionHistory::COL_TOTAL_ACTIVE_POINT => $mileagePointTransactionHistory->{MileagePointTransactionHistory::COL_TOTAL_ACTIVE_POINT},
                MileagePointTransactionHistory::COL_ACTUAL_POINT       => 0,
                MileagePointTransactionHistory::COL_EXPECTED_POINT     => $mileagePointTransactionHistory->{MileagePointTransactionHistory::COL_EXPECTED_POINT},
                MileagePointTransactionHistory::COL_STATUS             => MileagePointTransactionHistoryConst::STATUS['WITHDRAW_REFUND'],
            ]);
            $_mileagePointTransactionHistorySn = $_mileagePointTransactionHistory->{MileagePointTransactionHistory::COL_SN};

            MileagePointHistory::where(MileagePointHistory::COL_USER_BOOKING_SN, $withdrawPendingRefundPointInputDTO->getUserBookingSn())
                ->where(MileagePointHistory::COL_STATUS, MileagePointHistoryConst::STATUS['PENDING_REFUND'])
                ->whereJsonContains(MileagePointHistory::COL_MILEAGE_POINT_TRANSACTION_HISTORY_LIST, $mileagePointTransactionHistorySn)
                ->update([
                    MileagePointHistory::COL_ACTUAL_POINT                           => 0,
                    MileagePointHistory::COL_ACTIVE_TIME_FROM                       => null,
                    MileagePointHistory::COL_ACTIVE_TIME_TO                         => null,
                    MileagePointHistory::COL_STATUS                                 => MileagePointHistoryConst::STATUS['WITHDRAW'],
                    MileagePointHistory::COL_MILEAGE_POINT_TRANSACTION_HISTORY_LIST => json_encode([$mileagePointTransactionHistorySn, $_mileagePointTransactionHistorySn]),
                ]);

            $appUser = AppUser::lockForUpdate()
                ->where(AppUser::COL_SN, $mileagePointTransactionHistory->{MileagePointTransactionHistory::COL_APP_USER_SN})
                ->first([
                    AppUser::COL_MILEAGE_PENDING,
                ]);

            $mileagePending = $appUser->{AppUser::COL_MILEAGE_PENDING};
            $mileagePending = $mileagePending - $mileagePointTransactionHistory->{MileagePointTransactionHistory::COL_EXPECTED_POINT};

            $this->appUserRepository->update([
                AppUser::COL_MILEAGE_PENDING => max($mileagePending, 0),
            ], $mileagePointTransactionHistory->{MileagePointTransactionHistory::COL_APP_USER_SN});

            DB::connection('mysql')->commit();

            return WithdrawPendingRefundPointOutputDTO::assemble(true);
        } catch (Exception $exception) {
            LoggingHelper::logException($exception);
            DB::connection('mysql')->rollBack();
            throw $exception;
        }
    }
}
