<?php

namespace App\Actions\Reward;

use App\Constants\Globals\Code as CodeConst;
use App\Constants\MileagePointExpiration as MileagePointExpirationConst;
use App\Constants\MileagePointHistory as MileagePointHistoryConst;
use App\Constants\MileagePointTransactionHistory as MileagePointTransactionHistoryConst;
use App\DTOs\Reward\DeductPointInputDTO;
use App\DTOs\Reward\DeductPointOutputDTO;
use App\Exceptions\ServiceException;
use App\Helpers\CommonHelper;
use App\Helpers\LoggingHelper;
use App\Models\AppUser;
use App\Models\Hotel;
use App\Models\MileagePointExpiration;
use App\Models\MileagePointHistory;
use App\Models\MileagePointTransactionHistory;
use App\Models\MileagePointUsage;
use App\Models\MileageReward;
use App\Models\Program;
use App\Models\ReferralProgram;
use App\Models\UserBooking;
use App\Repositories\Interfaces\AppUserRepositoryInterface;
use App\Repositories\Interfaces\HotelRepositoryInterface;
use App\Repositories\Interfaces\MileagePointExpirationRepositoryInterface;
use App\Repositories\Interfaces\MileagePointHistoryRepositoryInterface;
use App\Repositories\Interfaces\MileagePointTransactionHistoryRepositoryInterface;
use App\Repositories\Interfaces\MileagePointUsageRepositoryInterface;
use App\Repositories\Interfaces\UserBookingRepositoryInterface;
use Exception;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\DB;

class DeductPoint
{
    const FILE_LANGUAGE_NAME = 'reward';

    const TYPE_PROGRAM = array(
        'BOOKING'   => 1,
        'REWARD'    => 2,
        'REFERRAL'  => 3,
        'MINI_GAME' => 4,
    );

    /** @var AppUserRepositoryInterface */
    protected $appUserRepository;

    /** @var UserBookingRepositoryInterface */
    protected $userBookingRepository;

    /** @var HotelRepositoryInterface */
    protected $hotelRepository;

    /** @var MileagePointTransactionHistoryRepositoryInterface */
    protected $mileagePointTransactionHistoryRepository;

    /** @var MileagePointExpirationRepositoryInterface */
    protected $mileagePointExpirationRepository;

    /** @var MileagePointUsageRepositoryInterface */
    protected $mileagePointUsageRepository;

    /** @var MileagePointHistoryRepositoryInterface */
    protected $mileagePointHistoryRepository;

    public function __construct(
        AppUserRepositoryInterface                        $appUserRepository,
        UserBookingRepositoryInterface                    $userBookingRepository,
        HotelRepositoryInterface                          $hotelRepository,
        MileagePointTransactionHistoryRepositoryInterface $mileagePointTransactionHistoryRepository,
        MileagePointExpirationRepositoryInterface         $mileagePointExpirationRepository,
        MileagePointUsageRepositoryInterface              $mileagePointUsageRepository,
        MileagePointHistoryRepositoryInterface            $mileagePointHistoryRepository
    ) {
        $this->appUserRepository = $appUserRepository;
        $this->userBookingRepository = $userBookingRepository;
        $this->hotelRepository = $hotelRepository;
        $this->mileagePointTransactionHistoryRepository = $mileagePointTransactionHistoryRepository;
        $this->mileagePointExpirationRepository = $mileagePointExpirationRepository;
        $this->mileagePointUsageRepository = $mileagePointUsageRepository;
        $this->mileagePointHistoryRepository = $mileagePointHistoryRepository;
    }

    public function handle(DeductPointInputDTO $deductPointInputDTO): DeductPointOutputDTO
    {
        $now = Carbon::now();

        if (empty($deductPointInputDTO->getAppUserSn())) {
            return DeductPointOutputDTO::assemble(false);
        }

        if ($deductPointInputDTO->getNumOfPoint() <= 0) {
            return DeductPointOutputDTO::assemble(false);
        }

        switch ($deductPointInputDTO->getTypeProgram()) {
            case self::TYPE_PROGRAM['REWARD']: {
                $mileagePointTransactionHistoryTypeProgram = MileagePointTransactionHistoryConst::TYPE_PROGRAM['REWARD'];
                $mileagePointHistoryTypeProgram = MileagePointHistoryConst::TYPE_PROGRAM['REWARD'];
                $mileageReward = MileageReward::where(MileageReward::COL_SN, $deductPointInputDTO->getProgramSn())->first([MileageReward::COL_NAME]);
                $programName = $mileageReward->{MileageReward::COL_NAME};
                break;
            }
            case self::TYPE_PROGRAM['REFERRAL']: {
                $mileagePointTransactionHistoryTypeProgram = MileagePointTransactionHistoryConst::TYPE_PROGRAM['REFERRAL'];
                $mileagePointHistoryTypeProgram = MileagePointHistoryConst::TYPE_PROGRAM['REFERRAL'];
                $program = ReferralProgram::where(ReferralProgram::COL_SN, $deductPointInputDTO->getProgramSn())->first([ReferralProgram::COL_TITLE]);
                $programName = $program->{ReferralProgram::COL_TITLE};
                break;
            }
            case self::TYPE_PROGRAM['MINI_GAME']: {
                $mileagePointTransactionHistoryTypeProgram = MileagePointTransactionHistoryConst::TYPE_PROGRAM['MINI_GAME'];
                $mileagePointHistoryTypeProgram = MileagePointHistoryConst::TYPE_PROGRAM['MINI_GAME'];
                $program = Program::where(Program::COL_SN, $deductPointInputDTO->getProgramSn())->first([Program::COL_TITLE]);
                $programName = $program->{MileageReward::COL_NAME};
                break;
            }
            case self::TYPE_PROGRAM['BOOKING']: {
                $mileagePointTransactionHistoryTypeProgram = MileagePointTransactionHistoryConst::TYPE_PROGRAM['BOOKING'];
                $mileagePointHistoryTypeProgram = MileagePointHistoryConst::TYPE_PROGRAM['BOOKING'];
                $programName = null;
                break;
            }
            default:
                $mileagePointTransactionHistoryTypeProgram = MileagePointTransactionHistoryConst::TYPE_PROGRAM['DONATE'];
                $mileagePointHistoryTypeProgram = MileagePointHistoryConst::TYPE_PROGRAM['DONATE'];
                $programName = 'Go2Joy';
        }

        DB::connection('mysql')->beginTransaction();
        try {
            $appUser = AppUser::lockForUpdate()
                ->where(AppUser::COL_SN, $deductPointInputDTO->getAppUserSn())
                ->first([
                    AppUser::COL_MILEAGE_AMOUNT,
                    AppUser::COL_MILEAGE_USED,
                ]);

            $mileageAmount = $appUser->{AppUser::COL_MILEAGE_AMOUNT};
            $mileageUsed = $appUser->{AppUser::COL_MILEAGE_USED};

            if ($mileageAmount <= 0) {
                throw new ServiceException(CommonHelper::getMessage(self::FILE_LANGUAGE_NAME, CodeConst::API_RWD_001), CodeConst::API_RWD_001);
            }

            $mileagePointExpirationList = $this->mileagePointExpirationRepository->findOldestMileagePointExpirationListHaveRemainingPoint($deductPointInputDTO->getAppUserSn());
            if ($mileagePointExpirationList->isEmpty()) {
                throw new ServiceException(CommonHelper::getMessage(self::FILE_LANGUAGE_NAME, CodeConst::API_RWD_001), CodeConst::API_RWD_001);
            }

            $totalActivePoint = $mileageAmount - $deductPointInputDTO->getNumOfPoint();
            $mileagePointTransactionHistory = MileagePointTransactionHistory::create([
                MileagePointTransactionHistory::COL_APP_USER_SN        => $deductPointInputDTO->getAppUserSn(),
                MileagePointTransactionHistory::COL_TYPE_PROGRAM       => $mileagePointTransactionHistoryTypeProgram,
                MileagePointTransactionHistory::COL_PROGRAM_SN         => $deductPointInputDTO->getProgramSn(),
                MileagePointTransactionHistory::COL_USER_BOOKING_SN    => $deductPointInputDTO->getUserBookingSn(),
                MileagePointTransactionHistory::COL_TOTAL_ACTIVE_POINT => $totalActivePoint,
                MileagePointTransactionHistory::COL_ACTUAL_POINT       => -$deductPointInputDTO->getNumOfPoint(),
                MileagePointTransactionHistory::COL_EXPECTED_POINT     => -$deductPointInputDTO->getNumOfPoint(),
                MileagePointTransactionHistory::COL_STATUS             => MileagePointTransactionHistoryConst::STATUS['USED'],
            ]);
            $mileagePointTransactionHistorySn = $mileagePointTransactionHistory->{MileagePointTransactionHistory::COL_SN};

            $numOfPointNeedToDeduct = $deductPointInputDTO->getNumOfPoint();
            $createMileagePointUsageDataList = [];
            foreach ($mileagePointExpirationList as $mileagePointExpiration) {
                $mileagePointExpirationSn = $mileagePointExpiration->{MileagePointExpiration::COL_SN};
                $_mileagePointTransactionHistorySn = $mileagePointExpiration->{MileagePointExpiration::COL_MILEAGE_POINT_TRANSACTION_HISTORY_SN};
                $remainingPoint = $mileagePointExpiration->{MileagePointExpiration::COL_REMAINING_POINT};

                $_remainingPoint = $remainingPoint - $numOfPointNeedToDeduct;
                if ($_remainingPoint < 0) {
                    // Not enough point
                    $this->mileagePointExpirationRepository->update([
                        MileagePointExpiration::COL_REMAINING_POINT => 0,
                    ], $mileagePointExpirationSn);

                    $createMileagePointUsageDataList[] = [
                        MileagePointUsage::COL_MILEAGE_POINT_TRANSACTION_PRODUCER => $_mileagePointTransactionHistorySn,
                        MileagePointUsage::COL_MILEAGE_POINT_TRANSACTION_CONSUMER => $mileagePointTransactionHistorySn,
                        MileagePointUsage::COL_USAGE_POINT                        => $remainingPoint,
                    ];

                    $numOfPointNeedToDeduct = abs($_remainingPoint);
                } else {
                    // Residual or just enough point
                    $this->mileagePointExpirationRepository->update([
                        MileagePointExpiration::COL_REMAINING_POINT => $_remainingPoint,
                    ], $mileagePointExpirationSn);

                    $createMileagePointUsageDataList[] = [
                        MileagePointUsage::COL_MILEAGE_POINT_TRANSACTION_PRODUCER => $_mileagePointTransactionHistorySn,
                        MileagePointUsage::COL_MILEAGE_POINT_TRANSACTION_CONSUMER => $mileagePointTransactionHistorySn,
                        MileagePointUsage::COL_USAGE_POINT                        => $numOfPointNeedToDeduct,
                    ];
                    break;
                }
            }

            $this->mileagePointUsageRepository->batchInsert($createMileagePointUsageDataList);

            $userBooking = $this->userBookingRepository->find($deductPointInputDTO->getUserBookingSn(), [
                UserBooking::COL_BOOKING_NO,
                UserBooking::COL_AMOUNT_FROM_USER,
                UserBooking::COL_HOTEL_SN,
                UserBooking::COL_CHECK_IN_DATE_PLAN,
                UserBooking::COL_TYPE,
                UserBooking::COL_START_TIME,
                UserBooking::COL_END_TIME,
                UserBooking::COL_END_DATE,
            ]);

            $bookingNo = $userBooking->{UserBooking::COL_BOOKING_NO};
            $amountFromUser = $userBooking->{UserBooking::COL_AMOUNT_FROM_USER};
            $hotelSn = $userBooking->{UserBooking::COL_HOTEL_SN};
            $hotel = $this->hotelRepository->find($hotelSn, [Hotel::COL_NAME]);
            $hotelName = $hotel->{Hotel::COL_NAME};
            $checkin = CommonHelper::getBookingCheckinDateTime($userBooking);
            $checkout = CommonHelper::getBookingCheckoutDateTime($userBooking);

            MileagePointHistory::create([
                MileagePointHistory::COL_APP_USER_SN                            => $deductPointInputDTO->getAppUserSn(),
                MileagePointHistory::COL_PROGRAM_NAME                           => $programName,
                MileagePointHistory::COL_PROGRAM_SN                             => $deductPointInputDTO->getProgramSn(),
                MileagePointHistory::COL_BOOKING_NO                             => $bookingNo,
                MileagePointHistory::COL_HOTEL_NAME                             => $hotelName,
                MileagePointHistory::COL_CHECKIN                                => $checkin,
                MileagePointHistory::COL_CHECKOUT                               => $checkout,
                MileagePointHistory::COL_USER_BOOKING_SN                        => $deductPointInputDTO->getUserBookingSn(),
                MileagePointHistory::COL_TYPE_PROGRAM                           => $mileagePointHistoryTypeProgram,
                MileagePointHistory::COL_STATUS                                 => MileagePointHistoryConst::STATUS['USED'],
                MileagePointHistory::COL_TOTAL_ACTIVE_POINT                     => $totalActivePoint,
                MileagePointHistory::COL_ACTUAL_POINT                           => -$deductPointInputDTO->getNumOfPoint(),
                MileagePointHistory::COL_EXPECTED_POINT                         => -$deductPointInputDTO->getNumOfPoint(),
                MileagePointHistory::COL_USER_PAID                              => $amountFromUser,
                MileagePointHistory::COL_ACTIVE_TIME_FROM                       => null,
                MileagePointHistory::COL_ACTIVE_TIME_TO                         => null,
                MileagePointHistory::COL_CLAIM_TIME                             => $now,
                MileagePointHistory::COL_REFUND_TIME                            => null,
                MileagePointHistory::COL_EXPIRATION_TIME                        => null,
                MileagePointHistory::COL_MILEAGE_POINT_TRANSACTION_HISTORY_LIST => json_encode([$mileagePointTransactionHistorySn]),
            ]);

            $mileageAmount = $mileageAmount - $deductPointInputDTO->getNumOfPoint();
            $mileageUsed = $mileageUsed + $deductPointInputDTO->getNumOfPoint();
            $this->appUserRepository->update([
                AppUser::COL_MILEAGE_AMOUNT => $mileageAmount,
                AppUser::COL_MILEAGE_USED   => $mileageUsed,
            ], $deductPointInputDTO->getAppUserSn());

            DB::connection('mysql')->commit();

            return DeductPointOutputDTO::assemble(true);
        } catch (Exception $exception) {
            LoggingHelper::logException($exception);
            DB::connection('mysql')->rollBack();
            throw $exception;
        }
    }
}
