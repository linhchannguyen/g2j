<?php

namespace App\Actions\Reward;

use App\Constants\Globals\Code as CodeConst;
use App\Constants\Globals\Common as CommonConst;
use App\Constants\Hotel as HotelConst;
use App\Constants\MileagePointHistory as MileagePointHistoryConst;
use App\Constants\MileagePointTransactionHistory as MileagePointTransactionHistoryConst;
use App\Constants\UserBooking as UserBookingConst;
use App\DTOs\Reward\RefundPointInputDTO;
use App\DTOs\Reward\RefundPointOutputDTO;
use App\Exceptions\ServiceException;
use App\Helpers\CommonHelper;
use App\Helpers\LoggingHelper;
use App\Models\AppUser;
use App\Models\CancellationPolicy;
use App\Models\Hotel;
use App\Models\MileagePointExpiration;
use App\Models\MileagePointHistory;
use App\Models\MileagePointTransactionHistory;
use App\Models\MileagePointUsage;
use App\Models\MileageReward;
use App\Models\ReferralProgram;
use App\Models\UserBooking;
use App\Repositories\Interfaces\AppUserRepositoryInterface;
use App\Repositories\Interfaces\BookingActionHistoryRepositoryInterface;
use App\Repositories\Interfaces\HotelRepositoryInterface;
use App\Repositories\Interfaces\MileagePointExpirationRepositoryInterface;
use App\Repositories\Interfaces\MileagePointHistoryRepositoryInterface;
use App\Repositories\Interfaces\MileagePointTransactionHistoryRepositoryInterface;
use App\Repositories\Interfaces\MileagePointUsageRepositoryInterface;
use Exception;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\DB;
use Psr\SimpleCache\InvalidArgumentException;

class RefundPoint
{
    const FILE_LANGUAGE_NAME = 'reward';

    /** @var AppUserRepositoryInterface */
    protected $appUserRepository;

    /** @var HotelRepositoryInterface */
    protected $hotelRepository;

    /** @var MileagePointTransactionHistoryRepositoryInterface */
    protected $mileagePointTransactionHistoryRepository;

    /** @var MileagePointExpirationRepositoryInterface */
    protected $mileagePointExpirationRepository;

    /** @var MileagePointUsageRepositoryInterface */
    protected $mileagePointUsageRepository;

    /** @var MileagePointHistoryRepositoryInterface */
    protected $mileagePointHistoryRepository;

    /** @var BookingActionHistoryRepositoryInterface */
    protected $bookingActionHistoryRepository;

    public function __construct(
        AppUserRepositoryInterface                        $appUserRepository,
        HotelRepositoryInterface                          $hotelRepository,
        MileagePointTransactionHistoryRepositoryInterface $mileagePointTransactionHistoryRepository,
        MileagePointExpirationRepositoryInterface         $mileagePointExpirationRepository,
        MileagePointUsageRepositoryInterface              $mileagePointUsageRepository,
        MileagePointHistoryRepositoryInterface            $mileagePointHistoryRepository,
        BookingActionHistoryRepositoryInterface           $bookingActionHistoryRepository
    ) {
        $this->appUserRepository = $appUserRepository;
        $this->hotelRepository = $hotelRepository;
        $this->mileagePointTransactionHistoryRepository = $mileagePointTransactionHistoryRepository;
        $this->mileagePointExpirationRepository = $mileagePointExpirationRepository;
        $this->mileagePointUsageRepository = $mileagePointUsageRepository;
        $this->mileagePointHistoryRepository = $mileagePointHistoryRepository;
        $this->bookingActionHistoryRepository = $bookingActionHistoryRepository;
    }

    public function handle(RefundPointInputDTO $refundPointInputDTO): RefundPointOutputDTO
    {
        $refundedPoint = 0;

        $userBooking = UserBooking::where(UserBooking::COL_SN, $refundPointInputDTO->getUserBookingSn())->first([
            UserBooking::COL_BOOKING_STATUS,
            UserBooking::COL_VIA_OBJECT,
            UserBooking::COL_TYPE,
            UserBooking::COL_CHECK_IN_DATE_PLAN,
            UserBooking::COL_START_TIME,
            UserBooking::COL_END_TIME,
            UserBooking::COL_HOTEL_SN,
            UserBooking::COL_END_DATE,
            UserBooking::COL_APP_USER_SN,
            UserBooking::COL_BOOKING_NO,
            UserBooking::COL_AMOUNT_FROM_USER,
            UserBooking::COL_MILEAGE_POINT,
            UserBooking::COL_CREATE_TIME,
        ]);

        if (empty($userBooking)) {
            throw new ServiceException(CommonHelper::getMessage(CommonConst::FILE_MESSAGE_LANGUAGE_NAME, CodeConst::API_GNR_005), CodeConst::API_GNR_005);
        }

        if ($userBooking->{UserBooking::COL_MILEAGE_POINT} == 0) {
            return RefundPointOutputDTO::assemble($refundedPoint);
        }

        if ($userBooking->{UserBooking::COL_BOOKING_STATUS} != UserBookingConst::BOOKING_STATUS['CANCELLED']) {
            return RefundPointOutputDTO::assemble($refundedPoint);
        }

        $isExpiredTimeProcessingBooking = CommonHelper::isExpiredTimeProcessingBookingOfPoint($userBooking);
        $isRequestRefundPointAction = $this->bookingActionHistoryRepository->isRequestRefundPointAction($refundPointInputDTO->getUserBookingSn());
        $valid = false;
        if ($isExpiredTimeProcessingBooking) {
            $valid = true;
        }
        if (!$isExpiredTimeProcessingBooking && $isRequestRefundPointAction) {
            $valid = true;
        }
        if (!$isExpiredTimeProcessingBooking && in_array($userBooking->{UserBooking::COL_VIA_OBJECT}, [
                UserBookingConst::VIA_OBJECT['HOTEL'],
                UserBookingConst::VIA_OBJECT['USER'],
                UserBookingConst::VIA_OBJECT['SYSTEM'],
            ])
        ) {
            $valid = true;
        }

        $isPendingRefund = (
                !$isExpiredTimeProcessingBooking
                || ($refundPointInputDTO->isAllowExceedExpirationTime())
            )
            && $userBooking->{UserBooking::COL_VIA_OBJECT} == UserBookingConst::VIA_OBJECT['GO2JOY'] && !$isRequestRefundPointAction;
        if ($isPendingRefund) {
            $valid = true;

            $havePendingRefund = $this->mileagePointTransactionHistoryRepository->havePendingRefundPoint($refundPointInputDTO->getUserBookingSn());
            if ($havePendingRefund && !$isExpiredTimeProcessingBooking && !$isRequestRefundPointAction) {
                return RefundPointOutputDTO::assemble($refundedPoint);
            }
        }

        if (!$valid) {
            return RefundPointOutputDTO::assemble($refundedPoint);
        }

        $isExistsRefunded = $this->mileagePointTransactionHistoryRepository->haveRefundedPoint($refundPointInputDTO->getUserBookingSn());
        if ($isExistsRefunded) {
            return RefundPointOutputDTO::assemble($refundedPoint);
        }

        $isExistsWithdrawnRefund = $this->mileagePointTransactionHistoryRepository->haveWithdrawnRefundPoint($refundPointInputDTO->getUserBookingSn());
        if ($isExistsWithdrawnRefund) {
            return RefundPointOutputDTO::assemble($refundedPoint);
        }

        $mileagePointTransactionHistory = MileagePointTransactionHistory::where(MileagePointTransactionHistory::COL_USER_BOOKING_SN, $refundPointInputDTO->getUserBookingSn())
            ->where(MileagePointTransactionHistory::COL_STATUS, MileagePointTransactionHistoryConst::STATUS['USED'])
            ->first([
                MileagePointTransactionHistory::COL_SN,
                MileagePointTransactionHistory::COL_APP_USER_SN,
                MileagePointTransactionHistory::COL_TYPE_PROGRAM,
                MileagePointTransactionHistory::COL_PROGRAM_SN,
                MileagePointTransactionHistory::COL_USER_BOOKING_SN,
                MileagePointTransactionHistory::COL_ACTUAL_POINT,
                MileagePointTransactionHistory::COL_EXPECTED_POINT,
            ]);
        if (empty($mileagePointTransactionHistory)) {
            return RefundPointOutputDTO::assemble($refundedPoint);
        }
        $totalPointNeedToRefund = abs($mileagePointTransactionHistory->{MileagePointTransactionHistory::COL_EXPECTED_POINT});

        DB::connection('mysql')->beginTransaction();
        try {
            $appUser = AppUser::lockForUpdate()
                ->where(AppUser::COL_SN, $userBooking->{UserBooking::COL_APP_USER_SN})
                ->first([
                    AppUser::COL_MILEAGE_AMOUNT,
                    AppUser::COL_MILEAGE_USED,
                    AppUser::COL_MILEAGE_PENDING,
                ]);

            $hotelSn = $userBooking->{UserBooking::COL_HOTEL_SN};
            $hotel = $this->hotelRepository->find($hotelSn, [Hotel::COL_NAME, Hotel::COL_ORIGIN]);
            if ($hotel->{Hotel::COL_ORIGIN} == HotelConst::ORIGIN['AGODA']) {
                $cancellationPolicy = CancellationPolicy::where(CancellationPolicy::COL_USER_BOOKING_SN, $refundPointInputDTO->getUserBookingSn())->first();
                if (!empty($cancellationPolicy)) {
                    $refundingAmount = $cancellationPolicy->{CancellationPolicy::COL_REFUNDING_AMOUNT};
                    if (isset($refundingAmount)) {
                        // Only action when have value on col refunding amount (Had call API cancel booking to Agoda, prevent case user cancel when payment failed)
                        $amountFromUser = $userBooking->{UserBooking::COL_AMOUNT_FROM_USER};
                        $mileagePoint = $userBooking->{UserBooking::COL_MILEAGE_POINT};
                        $differenceAmount = abs($refundingAmount - ($amountFromUser + $mileagePoint));
                        if ($differenceAmount > 1) { // Only accept +- 1 VND
                            // If Agoda booking not free cancellation, we'll not refund point to user
                            $totalPointNeedToRefund = 0;
                        }
                    }
                }
            }

            if ($isPendingRefund) {
                $hotelName = $hotel->{Hotel::COL_NAME};
                $checkin = CommonHelper::getBookingCheckinDateTime($userBooking);
                $checkout = CommonHelper::getBookingCheckoutDateTime($userBooking);
                $refundTime = CommonHelper::getEstimatedRefundTimeOfPoint($userBooking);

                [$refundedPoint, $mileagePointTransactionHistorySn] = self::_pendingRefundAction($appUser, $mileagePointTransactionHistory, $totalPointNeedToRefund, $hotelName, $checkin, $checkout, $refundTime);
            } else {
                [$refundedPoint, $mileagePointTransactionHistorySn] = self::_refundAction($appUser, $mileagePointTransactionHistory, $totalPointNeedToRefund, $userBooking, $isRequestRefundPointAction);
            }

            DB::connection('mysql')->commit();

            return RefundPointOutputDTO::assemble($refundedPoint, $mileagePointTransactionHistorySn);
        } catch (Exception|InvalidArgumentException $exception) {
            DB::connection('mysql')->rollBack();
            LoggingHelper::logException($exception);
            throw $exception;
        }
    }

    private function _pendingRefundAction(object $appUser, object $mileagePointTransactionHistory, int $totalPointNeedToRefund, string $hotelName, string $checkin, string $checkout, string $refundTime): array
    {
        $totalActivePoint = $appUser->{AppUser::COL_MILEAGE_AMOUNT};
        $actualPoint = 0;

        $mileagePointTransactionHistoryStatus = MileagePointTransactionHistoryConst::STATUS['PENDING_REFUND'];
        $mileagePointHistoryStatus = MileagePointHistoryConst::STATUS['PENDING_REFUND'];

        $mileagePointTransactionHistory = MileagePointTransactionHistory::create([
            MileagePointTransactionHistory::COL_APP_USER_SN        => $mileagePointTransactionHistory->{MileagePointTransactionHistory::COL_APP_USER_SN},
            MileagePointTransactionHistory::COL_TYPE_PROGRAM       => $mileagePointTransactionHistory->{MileagePointTransactionHistory::COL_TYPE_PROGRAM},
            MileagePointTransactionHistory::COL_PROGRAM_SN         => $mileagePointTransactionHistory->{MileagePointTransactionHistory::COL_PROGRAM_SN},
            MileagePointTransactionHistory::COL_USER_BOOKING_SN    => $mileagePointTransactionHistory->{MileagePointTransactionHistory::COL_USER_BOOKING_SN},
            MileagePointTransactionHistory::COL_TOTAL_ACTIVE_POINT => $totalActivePoint,
            MileagePointTransactionHistory::COL_ACTUAL_POINT       => $actualPoint,
            MileagePointTransactionHistory::COL_EXPECTED_POINT     => $totalPointNeedToRefund,
            MileagePointTransactionHistory::COL_STATUS             => $mileagePointTransactionHistoryStatus,
        ]);
        $mileagePointTransactionHistorySn = $mileagePointTransactionHistory->{MileagePointTransactionHistory::COL_SN};

        [$programName] = $this->_getProgramInfo($mileagePointTransactionHistory->{MileagePointTransactionHistory::COL_TYPE_PROGRAM}, $mileagePointTransactionHistory->{MileagePointTransactionHistory::COL_PROGRAM_SN} ?? null);

        switch ($mileagePointTransactionHistory->{MileagePointTransactionHistory::COL_TYPE_PROGRAM}) {
            case MileagePointTransactionHistoryConst::TYPE_PROGRAM['REWARD']: {
                $mileagePointHistoryTypeProgram = MileagePointHistoryConst::TYPE_PROGRAM['REWARD'];
                break;
            }
            case MileagePointTransactionHistoryConst::TYPE_PROGRAM['BOOKING']: {
                $mileagePointHistoryTypeProgram = MileagePointHistoryConst::TYPE_PROGRAM['BOOKING'];
                break;
            }
            case MileagePointTransactionHistoryConst::TYPE_PROGRAM['REFERRAL']: {
                $mileagePointHistoryTypeProgram = MileagePointHistoryConst::TYPE_PROGRAM['REFERRAL'];
                break;
            }
            default: throw new ServiceException(CommonHelper::getMessage(CommonConst::FILE_MESSAGE_LANGUAGE_NAME, CodeConst::API_RWD_002), CodeConst::API_RWD_002);
        }

        $mileagePointHistory = MileagePointHistory::where(MileagePointHistory::COL_APP_USER_SN, $mileagePointTransactionHistory->{MileagePointTransactionHistory::COL_APP_USER_SN})
            ->where(MileagePointHistory::COL_USER_BOOKING_SN, $mileagePointTransactionHistory->{MileagePointTransactionHistory::COL_USER_BOOKING_SN})
            ->where(MileagePointHistory::COL_STATUS, MileagePointHistoryConst::STATUS['USED'])
            ->first([
                MileagePointHistory::COL_BOOKING_NO,
                MileagePointHistory::COL_USER_PAID,
                MileagePointHistory::COL_CLAIM_TIME,
            ]);

        $bookingNo = $mileagePointHistory->{MileagePointHistory::COL_BOOKING_NO};
        $userPaid = $mileagePointHistory->{MileagePointHistory::COL_USER_PAID};

        MileagePointHistory::create([
            MileagePointHistory::COL_APP_USER_SN                            => $mileagePointTransactionHistory->{MileagePointTransactionHistory::COL_APP_USER_SN},
            MileagePointHistory::COL_PROGRAM_NAME                           => $programName,
            MileagePointHistory::COL_PROGRAM_SN                             => $mileagePointTransactionHistory->{MileagePointTransactionHistory::COL_PROGRAM_SN},
            MileagePointHistory::COL_BOOKING_NO                             => $bookingNo,
            MileagePointHistory::COL_HOTEL_NAME                             => $hotelName,
            MileagePointHistory::COL_CHECKIN                                => $checkin,
            MileagePointHistory::COL_CHECKOUT                               => $checkout,
            MileagePointHistory::COL_USER_BOOKING_SN                        => $mileagePointTransactionHistory->{MileagePointTransactionHistory::COL_USER_BOOKING_SN},
            MileagePointHistory::COL_TYPE_PROGRAM                           => $mileagePointHistoryTypeProgram,
            MileagePointHistory::COL_STATUS                                 => $mileagePointHistoryStatus,
            MileagePointHistory::COL_TOTAL_ACTIVE_POINT                     => $totalActivePoint,
            MileagePointHistory::COL_ACTUAL_POINT                           => $actualPoint,
            MileagePointHistory::COL_EXPECTED_POINT                         => $totalPointNeedToRefund,
            MileagePointHistory::COL_USER_PAID                              => $userPaid,
            MileagePointHistory::COL_ACTIVE_TIME_FROM                       => null,
            MileagePointHistory::COL_ACTIVE_TIME_TO                         => null,
            MileagePointHistory::COL_CLAIM_TIME                             => $mileagePointHistory->{MileagePointHistory::COL_CLAIM_TIME},
            MileagePointHistory::COL_REFUND_TIME                            => $refundTime,
            MileagePointHistory::COL_EXPIRATION_TIME                        => null,
            MileagePointHistory::COL_MILEAGE_POINT_TRANSACTION_HISTORY_LIST => json_encode([$mileagePointTransactionHistorySn]),
        ]);

        $mileagePending = $appUser->{AppUser::COL_MILEAGE_PENDING};
        $mileagePending += $totalPointNeedToRefund;

        $this->appUserRepository->update([
            AppUser::COL_MILEAGE_PENDING => $mileagePending,
        ], $mileagePointTransactionHistory->{MileagePointTransactionHistory::COL_APP_USER_SN});

        return [$actualPoint, $mileagePointTransactionHistorySn];
    }

    private function _refundAction(object $appUser, object $mileagePointTransactionHistory, int $totalPointNeedToRefund, object $userBooking, int $isRequestRefundPointAction): array
    {
        $now = Carbon::now();

        $mileageAmount = $appUser->{AppUser::COL_MILEAGE_AMOUNT};
        $mileageUsed = $appUser->{AppUser::COL_MILEAGE_USED};
        $mileagePending = $appUser->{AppUser::COL_MILEAGE_PENDING};

        $totalActivePoint = $mileageAmount + $totalPointNeedToRefund;

        $actualPoint = $totalPointNeedToRefund;

        $mileagePointUsageList = $this->mileagePointUsageRepository->findMileagePointUsageByConsumer($mileagePointTransactionHistory->{MileagePointTransactionHistory::COL_SN});
        $mileagePointUsageSnList = $mileagePointUsageList->pluck(MileagePointUsage::COL_SN)->toArray();
        $usagePointByProducer = [];
        foreach ($mileagePointUsageList as $mileagePointUsage) {
            $mileagePointTransactionProducer = $mileagePointUsage->{MileagePointUsage::COL_MILEAGE_POINT_TRANSACTION_PRODUCER};
            $usagePoint = $mileagePointUsage->{MileagePointUsage::COL_USAGE_POINT};
            $usagePointByProducer[$mileagePointTransactionProducer] = ($usagePointByProducer[$mileagePointTransactionProducer] ?? 0) + $usagePoint;
        }

        $totalPointExpired = 0;
        foreach ($usagePointByProducer as $mileagePointTransactionProducer => $usagePoint) {
            $mileagePointExpiration = $this->mileagePointExpirationRepository->findMileagePointExpirationNotProcessedYet($mileagePointTransactionProducer);
            if (!empty($mileagePointExpiration)) {
                $mileagePointExpirationSn = $mileagePointExpiration->{MileagePointExpiration::COL_SN};
                $remainingPoint = $mileagePointExpiration->{MileagePointExpiration::COL_REMAINING_POINT};

                $this->mileagePointExpirationRepository->update([
                    MileagePointExpiration::COL_REMAINING_POINT => $remainingPoint + $usagePoint
                ], $mileagePointExpirationSn);
            } else {
                $totalPointExpired = $totalPointExpired + $usagePoint;
            }
        }

        if (!empty($mileagePointUsageSnList)) {
            MileagePointUsage::whereIn(MileagePointUsage::COL_SN, $mileagePointUsageSnList)->update([MileagePointUsage::COL_DELETED_AT => $now]);
        }

        $actualPoint = max($actualPoint - $totalPointExpired, 0);

        $mileagePointTransactionHistory = MileagePointTransactionHistory::create([
            MileagePointTransactionHistory::COL_APP_USER_SN        => $mileagePointTransactionHistory->{MileagePointTransactionHistory::COL_APP_USER_SN},
            MileagePointTransactionHistory::COL_TYPE_PROGRAM       => $mileagePointTransactionHistory->{MileagePointTransactionHistory::COL_TYPE_PROGRAM},
            MileagePointTransactionHistory::COL_PROGRAM_SN         => $mileagePointTransactionHistory->{MileagePointTransactionHistory::COL_PROGRAM_SN},
            MileagePointTransactionHistory::COL_USER_BOOKING_SN    => $mileagePointTransactionHistory->{MileagePointTransactionHistory::COL_USER_BOOKING_SN},
            MileagePointTransactionHistory::COL_TOTAL_ACTIVE_POINT => $totalActivePoint,
            MileagePointTransactionHistory::COL_ACTUAL_POINT       => $actualPoint,
            MileagePointTransactionHistory::COL_EXPECTED_POINT     => $totalPointNeedToRefund,
            MileagePointTransactionHistory::COL_STATUS             => MileagePointTransactionHistoryConst::STATUS['REFUNDED'],
        ]);

        $appUserSn = $mileagePointTransactionHistory->{MileagePointTransactionHistory::COL_APP_USER_SN};
        $userBookingSn = $mileagePointTransactionHistory->{MileagePointTransactionHistory::COL_USER_BOOKING_SN};
        $mileagePointTransactionHistorySn = $mileagePointTransactionHistory->{MileagePointTransactionHistory::COL_SN};

        [$programName] = $this->_getProgramInfo($mileagePointTransactionHistory->{MileagePointTransactionHistory::COL_TYPE_PROGRAM}, $mileagePointTransactionHistory->{MileagePointTransactionHistory::COL_PROGRAM_SN} ?? null);

        $hotelSn = $userBooking->{UserBooking::COL_HOTEL_SN};
        $hotel = $this->hotelRepository->find($hotelSn, [Hotel::COL_NAME]);
        $hotelName = $hotel->{Hotel::COL_NAME};
        $checkin = CommonHelper::getBookingCheckinDateTime($userBooking);
        $checkout = CommonHelper::getBookingCheckoutDateTime($userBooking);

        $pendingRefundHistory = MileagePointHistory::where(MileagePointHistory::COL_APP_USER_SN, $appUserSn)
            ->where(MileagePointHistory::COL_USER_BOOKING_SN, $userBookingSn)
            ->where(MileagePointHistory::COL_STATUS, MileagePointHistoryConst::STATUS['PENDING_REFUND'])
            ->first([MileagePointHistory::COL_SN]);

        if (!$isRequestRefundPointAction) {
            if (!empty($pendingRefundHistory)) {
                // Case: auto refund in background after M+1
                $_mileagePointHistorySn = $pendingRefundHistory->{MileagePointHistory::COL_SN};

                MileagePointHistory::where(MileagePointHistory::COL_SN, $_mileagePointHistorySn)
                    ->update([
                        MileagePointHistory::COL_TOTAL_ACTIVE_POINT                     => $totalActivePoint,
                        MileagePointHistory::COL_ACTUAL_POINT                           => $actualPoint,
                        MileagePointHistory::COL_STATUS                                 => MileagePointHistoryConst::STATUS['REFUNDED'],
                        MileagePointHistory::COL_REFUND_TIME                            => $now,
                        MileagePointHistory::COL_EXPIRATION_TIME                        => null,
                        MileagePointHistory::COL_MILEAGE_POINT_TRANSACTION_HISTORY_LIST => json_encode([$mileagePointTransactionHistorySn]),
                    ]);
            } else {
                // Case: auto refund when user cancel but booking not pay yet
                MileagePointHistory::create([
                    MileagePointHistory::COL_APP_USER_SN                            => $mileagePointTransactionHistory->{MileagePointTransactionHistory::COL_APP_USER_SN},
                    MileagePointHistory::COL_PROGRAM_NAME                           => $programName,
                    MileagePointHistory::COL_PROGRAM_SN                             => $mileagePointTransactionHistory->{MileagePointTransactionHistory::COL_PROGRAM_SN},
                    MileagePointHistory::COL_BOOKING_NO                             => $userBooking->{UserBooking::COL_BOOKING_NO},
                    MileagePointHistory::COL_HOTEL_NAME                             => $hotelName,
                    MileagePointHistory::COL_CHECKIN                                => $checkin,
                    MileagePointHistory::COL_CHECKOUT                               => $checkout,
                    MileagePointHistory::COL_USER_BOOKING_SN                        => $mileagePointTransactionHistory->{MileagePointTransactionHistory::COL_USER_BOOKING_SN},
                    MileagePointHistory::COL_TYPE_PROGRAM                           => $mileagePointTransactionHistory->{MileagePointTransactionHistory::COL_TYPE_PROGRAM},
                    MileagePointHistory::COL_STATUS                                 => MileagePointHistoryConst::STATUS['REFUNDED'],
                    MileagePointHistory::COL_TOTAL_ACTIVE_POINT                     => $totalActivePoint,
                    MileagePointHistory::COL_ACTUAL_POINT                           => $actualPoint,
                    MileagePointHistory::COL_EXPECTED_POINT                         => $totalPointNeedToRefund,
                    MileagePointHistory::COL_USER_PAID                              => $userBooking->{UserBooking::COL_AMOUNT_FROM_USER},
                    MileagePointHistory::COL_ACTIVE_TIME_FROM                       => null,
                    MileagePointHistory::COL_ACTIVE_TIME_TO                         => null,
                    MileagePointHistory::COL_CLAIM_TIME                             => $userBooking->{UserBooking::COL_CREATE_TIME},
                    MileagePointHistory::COL_REFUND_TIME                            => $now,
                    MileagePointHistory::COL_EXPIRATION_TIME                        => null,
                    MileagePointHistory::COL_MILEAGE_POINT_TRANSACTION_HISTORY_LIST => json_encode([$mileagePointTransactionHistorySn]),
                ]);

                $this->bookingActionHistoryRepository->createSolvedRefundPointAction($userBookingSn);

                $mileageAmount = $mileageAmount + $actualPoint;
                $mileageUsed = $mileageUsed - $actualPoint;
                $this->appUserRepository->update([
                    AppUser::COL_MILEAGE_AMOUNT  => $mileageAmount,
                    AppUser::COL_MILEAGE_USED    => $mileageUsed,
                ], $appUserSn);

                return [$actualPoint, $mileagePointTransactionHistorySn];
            }

            $this->bookingActionHistoryRepository->createSolvedRefundPointAction($userBookingSn);
        } else {
            if (empty($pendingRefundHistory)) {
                throw new ServiceException(CommonHelper::getMessage(CommonConst::FILE_MESSAGE_LANGUAGE_NAME, CodeConst::API_RWD_002), CodeConst::API_RWD_002);
            }

            $_mileagePointHistorySn = $pendingRefundHistory->{MileagePointHistory::COL_SN};

            $claimTime = $pendingRefundHistory->{MileagePointHistory::COL_CLAIM_TIME} ?? $userBooking->{UserBooking::COL_CREATE_TIME};

            MileagePointHistory::where(MileagePointHistory::COL_SN, $_mileagePointHistorySn)
                ->update([
                    MileagePointHistory::COL_TOTAL_ACTIVE_POINT                     => $totalActivePoint,
                    MileagePointHistory::COL_ACTUAL_POINT                           => $actualPoint,
                    MileagePointHistory::COL_STATUS                                 => MileagePointHistoryConst::STATUS['REFUNDED'],
                    MileagePointHistory::COL_REFUND_TIME                            => $now,
                    MileagePointHistory::COL_CLAIM_TIME                             => $claimTime,
                    MileagePointHistory::COL_EXPIRATION_TIME                        => null,
                    MileagePointHistory::COL_MILEAGE_POINT_TRANSACTION_HISTORY_LIST => json_encode([$mileagePointTransactionHistorySn]),
                ]);
        }

        $mileagePending = $mileagePending - $totalPointNeedToRefund;
        $mileageAmount = $mileageAmount + $actualPoint;
        $mileageUsed = $mileageUsed - $actualPoint;
        $this->appUserRepository->update([
            AppUser::COL_MILEAGE_AMOUNT  => $mileageAmount,
            AppUser::COL_MILEAGE_USED    => $mileageUsed,
            AppUser::COL_MILEAGE_PENDING => max($mileagePending, 0),
        ], $appUserSn);

        return [$actualPoint, $mileagePointTransactionHistorySn];
    }

    private function _getProgramInfo(int $mileagePointTransactionHistoryTypeProgram, ?int $mileagePointTransactionHistoryProgramSn): array
    {
        switch ($mileagePointTransactionHistoryTypeProgram) {
            case MileagePointTransactionHistoryConst::TYPE_PROGRAM['REWARD']: {
                $mileageReward = MileageReward::where(MileageReward::COL_SN, $mileagePointTransactionHistoryProgramSn)->first([MileageReward::COL_NAME]);
                $programName = $mileageReward->{MileageReward::COL_NAME};
                break;
            }
            case MileagePointTransactionHistoryConst::TYPE_PROGRAM['BOOKING']: {
                $programName = null;
                break;
            }
            case MileagePointTransactionHistoryConst::TYPE_PROGRAM['REFERRAL']: {
                $program = ReferralProgram::where(ReferralProgram::COL_SN, $mileagePointTransactionHistoryProgramSn)->first([ReferralProgram::COL_TITLE]);
                $programName = $program->{ReferralProgram::COL_TITLE};
                break;
            }
            default: throw new ServiceException(CommonHelper::getMessage(CommonConst::FILE_MESSAGE_LANGUAGE_NAME, CodeConst::API_RWD_002), CodeConst::API_RWD_002);
        }
        return [$programName];
    }
}
