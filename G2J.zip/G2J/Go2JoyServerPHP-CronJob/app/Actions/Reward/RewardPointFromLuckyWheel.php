<?php

namespace App\Actions\Reward;

use App\Constants\MileagePointExpiration as MileagePointExpirationConst;
use App\Constants\MileagePointHistory as MileagePointHistoryConst;
use App\Constants\MileagePointTransactionHistory as MileagePointTransactionHistoryConst;
use App\Constants\Setting as SettingConst;
use App\DTOs\Reward\RewardPointFromLuckyWheelInputDTO;
use App\DTOs\Reward\RewardPointFromLuckyWheelOutputDTO;
use App\Exceptions\ServiceException;
use App\Helpers\CommonHelper;
use App\Helpers\LoggingHelper;
use App\Models\AppUser;
use App\Models\MileagePointExpiration;
use App\Models\MileagePointHistory;
use App\Models\MileagePointTransactionHistory;
use App\Models\Program;
use App\Models\Setting;
use App\Repositories\Interfaces\AppUserRepositoryInterface;
use App\Repositories\Interfaces\MileagePointHistoryRepositoryInterface;
use App\Repositories\Interfaces\MileagePointTransactionHistoryRepositoryInterface;
use Exception;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\DB;
use Psr\SimpleCache\InvalidArgumentException;

class RewardPointFromLuckyWheel
{
    const FILE_LANGUAGE_NAME = 'reward';

    /** @var AppUserRepositoryInterface */
    protected $appUserRepository;

    /** @var MileagePointTransactionHistoryRepositoryInterface */
    protected $mileagePointTransactionHistoryRepository;

    /** @var MileagePointHistoryRepositoryInterface */
    protected $mileagePointHistoryRepository;

    public function __construct(
        AppUserRepositoryInterface                        $appUserRepository,
        MileagePointTransactionHistoryRepositoryInterface $mileagePointTransactionHistoryRepository,
        MileagePointHistoryRepositoryInterface            $mileagePointHistoryRepository
    ) {
        $this->appUserRepository = $appUserRepository;
        $this->mileagePointTransactionHistoryRepository = $mileagePointTransactionHistoryRepository;
        $this->mileagePointHistoryRepository = $mileagePointHistoryRepository;
    }

    /**
     * @throws ServiceException|InvalidArgumentException
     */
    public function handle(RewardPointFromLuckyWheelInputDTO $rewardPointFromLuckyWheelInputDTO): RewardPointFromLuckyWheelOutputDTO
    {
        $setting = CommonHelper::getHotelSetting(SettingConst::COMMON_TYPE['MILEAGE_POINT'], SettingConst::CLASS_NO['01']);
        $numOfMonth = (int)$setting->{Setting::COL_NUMDATA2};
        $now = Carbon::now();
        $expiredDate = Carbon::now()->addMonths($numOfMonth);

        $program = DB::connection('mini_gaming')
            ->table(Program::TABLE_NAME)
            ->where(Program::COL_SN, $rewardPointFromLuckyWheelInputDTO->getProgramSn())
            ->first([
                Program::COL_TITLE,
            ]);
        $programTitle = $program->{Program::COL_TITLE};

        DB::connection('mysql')->beginTransaction();
        try {
            $appUser = AppUser::lockForUpdate()
                ->where(AppUser::COL_SN, $rewardPointFromLuckyWheelInputDTO->getAppUserSn())
                ->first([
                    AppUser::COL_MILEAGE_AMOUNT,
                    AppUser::COL_MILEAGE_EARNED,
                    AppUser::COL_MILEAGE_FIRST_TIME,
                ]);

            $mileageAmount = $appUser->{AppUser::COL_MILEAGE_AMOUNT};
            $mileageEarned = $appUser->{AppUser::COL_MILEAGE_EARNED};
            $mileageFirstTime = $appUser->{AppUser::COL_MILEAGE_FIRST_TIME};

            $totalActivePoint = $mileageAmount + $rewardPointFromLuckyWheelInputDTO->getNumOfPoint();
            $mileagePointTransactionHistory = MileagePointTransactionHistory::create([
                MileagePointTransactionHistory::COL_APP_USER_SN        => $rewardPointFromLuckyWheelInputDTO->getAppUserSn(),
                MileagePointTransactionHistory::COL_TYPE_PROGRAM       => MileagePointTransactionHistoryConst::TYPE_PROGRAM['MINI_GAME'],
                MileagePointTransactionHistory::COL_PROGRAM_SN         => $rewardPointFromLuckyWheelInputDTO->getProgramSn(),
                MileagePointTransactionHistory::COL_USER_BOOKING_SN    => null,
                MileagePointTransactionHistory::COL_TOTAL_ACTIVE_POINT => $totalActivePoint,
                MileagePointTransactionHistory::COL_ACTUAL_POINT       => $rewardPointFromLuckyWheelInputDTO->getNumOfPoint(),
                MileagePointTransactionHistory::COL_EXPECTED_POINT     => $rewardPointFromLuckyWheelInputDTO->getNumOfPoint(),
                MileagePointTransactionHistory::COL_STATUS             => MileagePointTransactionHistoryConst::STATUS['ACTIVE'],
            ]);
            $mileagePointTransactionHistorySn = $mileagePointTransactionHistory->{MileagePointTransactionHistory::COL_SN};

            MileagePointHistory::create([
                MileagePointHistory::COL_APP_USER_SN                            => $mileagePointTransactionHistory->{MileagePointTransactionHistory::COL_APP_USER_SN},
                MileagePointHistory::COL_PROGRAM_NAME                           => $programTitle,
                MileagePointHistory::COL_PROGRAM_SN                             => $mileagePointTransactionHistory->{MileagePointTransactionHistory::COL_PROGRAM_SN},
                MileagePointHistory::COL_BOOKING_NO                             => null,
                MileagePointHistory::COL_HOTEL_NAME                             => null,
                MileagePointHistory::COL_CHECKIN                                => null,
                MileagePointHistory::COL_CHECKOUT                               => null,
                MileagePointHistory::COL_TYPE_PROGRAM                           => MileagePointHistoryConst::TYPE_PROGRAM['MINI_GAME'],
                MileagePointHistory::COL_STATUS                                 => MileagePointHistoryConst::STATUS['ACTIVE'],
                MileagePointHistory::COL_TOTAL_ACTIVE_POINT                     => $totalActivePoint,
                MileagePointHistory::COL_ACTUAL_POINT                           => $rewardPointFromLuckyWheelInputDTO->getNumOfPoint(),
                MileagePointHistory::COL_EXPECTED_POINT                         => $rewardPointFromLuckyWheelInputDTO->getNumOfPoint(),
                MileagePointHistory::COL_USER_PAID                              => 0,
                MileagePointHistory::COL_ACTIVE_TIME_FROM                       => $now->toDateTimeString(),
                MileagePointHistory::COL_ACTIVE_TIME_TO                         => $expiredDate->toDateString(),
                MileagePointHistory::COL_CLAIM_TIME                             => null,
                MileagePointHistory::COL_REFUND_TIME                            => null,
                MileagePointHistory::COL_EXPIRATION_TIME                        => null,
                MileagePointHistory::COL_MILEAGE_POINT_TRANSACTION_HISTORY_LIST => json_encode([$mileagePointTransactionHistorySn]),
            ]);

            MileagePointExpiration::create([
                MileagePointExpiration::COL_MILEAGE_POINT_TRANSACTION_HISTORY_SN => $mileagePointTransactionHistorySn,
                MileagePointExpiration::COL_APP_USER_SN                          => $rewardPointFromLuckyWheelInputDTO->getAppUserSn(),
                MileagePointExpiration::COL_NUM_OF_POINT                         => $rewardPointFromLuckyWheelInputDTO->getNumOfPoint(),
                MileagePointExpiration::COL_REMAINING_POINT                      => $rewardPointFromLuckyWheelInputDTO->getNumOfPoint(),
                MileagePointExpiration::COL_DAY                                  => $expiredDate->day,
                MileagePointExpiration::COL_MONTH                                => $expiredDate->month,
                MileagePointExpiration::COL_YEAR                                 => $expiredDate->year,
                MileagePointExpiration::COL_PROCESSED                            => MileagePointExpirationConst::PROCESSED['NOT_YET'],
            ]);

            $mileageAmount = $mileageAmount + $rewardPointFromLuckyWheelInputDTO->getNumOfPoint();
            $mileageEarned = $mileageEarned + $rewardPointFromLuckyWheelInputDTO->getNumOfPoint();

            $updateAppUserData = [
                AppUser::COL_MILEAGE_AMOUNT     => $mileageAmount,
                AppUser::COL_MILEAGE_EARNED     => $mileageEarned,
                AppUser::COL_MILEAGE_FIRST_TIME => $mileageFirstTime,
            ];
            if (empty($mileageFirstTime)) {
                $updateAppUserData[AppUser::COL_MILEAGE_FIRST_TIME] = $now;
            }

            $this->appUserRepository->updateWhere($updateAppUserData, [
                AppUser::COL_SN => $rewardPointFromLuckyWheelInputDTO->getAppUserSn()
            ]);

            DB::connection('mysql')->commit();

            return RewardPointFromLuckyWheelOutputDTO::assemble($mileagePointTransactionHistorySn);
        } catch(Exception $exception) {
            LoggingHelper::logException($exception);
            DB::connection('mysql')->rollBack();
            throw $exception;
        }
    }
}
