<?php

namespace App\Actions\Reward\Mobile;


use App\DTOs\Reward\Mobile\GetPointHistoryListInputDTO;
use App\DTOs\Reward\Mobile\GetPointHistoryListOutputDTO;
use App\Repositories\Interfaces\MileagePointHistoryRepositoryInterface;

class GetPointHistoryList
{
    /** @var MileagePointHistoryRepositoryInterface */
    protected $mileagePointHistoryRepository;

    public function __construct(
        MileagePointHistoryRepositoryInterface $mileagePointHistoryRepository
    ) {
        $this->mileagePointHistoryRepository = $mileagePointHistoryRepository;
    }

    public function handle(GetPointHistoryListInputDTO $getPointHistoryListInputDTO): GetPointHistoryListOutputDTO
    {
        $mileagePointHistoryList = $this->mileagePointHistoryRepository->findByAppUserSnAndStatus($getPointHistoryListInputDTO->getAppUserSn(), $getPointHistoryListInputDTO->getFilterStatus(), $getPointHistoryListInputDTO->getLimit());
        if ($mileagePointHistoryList->isEmpty()) {
            return new GetPointHistoryListOutputDTO();
        }

        return GetPointHistoryListOutputDTO::assemble($mileagePointHistoryList);
    }
}
