<?php

namespace App\Actions\Reward\Mobile;

use App\Constants\AppUser as AppUserConst;
use App\DTOs\Reward\Mobile\GetPointStatisticsInputDTO;
use App\DTOs\Reward\Mobile\GetPointStatisticsOutputDTO;
use App\Models\AppUser;
use App\Repositories\Interfaces\AppUserRepositoryInterface;

class GetPointStatistics
{
    protected $appUserRepository;

    public function __construct(
        AppUserRepositoryInterface $appUserRepository
    ) {
        $this->appUserRepository = $appUserRepository;
    }

    public function handle(GetPointStatisticsInputDTO $getPointStatisticsInputDTO): GetPointStatisticsOutputDTO
    {
        $appUser = $this->appUserRepository->find($getPointStatisticsInputDTO->getAppUserSn(), [
            AppUser::COL_STATUS,
            AppUser::COL_MILEAGE_EARNED,
            AppUser::COL_MILEAGE_USED,
            AppUser::COL_MILEAGE_EXPIRED,
            AppUser::COL_MILEAGE_AMOUNT,
            AppUser::COL_MILEAGE_PENDING,
        ]);

        if (empty($appUser)
            || ($appUser->{AppUser::COL_STATUS} == AppUserConst::STATUS['DELETED'])
        ) {
            $mileageEarned = 0;
            $mileageUsed = 0;
            $mileageExpired = 0;
            $mileageAmount = 0;
            $mileagePending = 0;

            return GetPointStatisticsOutputDTO::assemble($mileageEarned, $mileageUsed, $mileageExpired, $mileageAmount, $mileagePending);
        }

        $mileageEarned = $appUser->{AppUser::COL_MILEAGE_EARNED};
        $mileageUsed = $appUser->{AppUser::COL_MILEAGE_USED};
        $mileageExpired = $appUser->{AppUser::COL_MILEAGE_EXPIRED};
        $mileageAmount = $appUser->{AppUser::COL_MILEAGE_AMOUNT};
        $mileagePending = $appUser->{AppUser::COL_MILEAGE_PENDING};

        return GetPointStatisticsOutputDTO::assemble($mileageEarned, $mileageUsed, $mileageExpired, $mileageAmount, $mileagePending);
    }
}