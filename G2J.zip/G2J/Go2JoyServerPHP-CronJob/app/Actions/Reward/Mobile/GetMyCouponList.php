<?php

namespace App\Actions\Reward\Mobile;

use App\Constants\CouponForHotel as CouponForHotelConst;
use App\Constants\CouponIssued as CouponIssuedConst;
use App\Constants\UseCondition as UseConditionConst;
use App\DTOs\Reward\Mobile\GetMyCouponListInputDTO;
use App\DTOs\Reward\Mobile\GetMyCouponListOutputDTO;
use App\Models\Coupon;
use App\Models\CouponForHotel;
use App\Models\CouponIssued;
use App\Models\UseCondition;
use App\Repositories\Interfaces\CouponIssuedRepositoryInterface;

class GetMyCouponList
{
    protected $couponIssuedRepository;

    public function __construct(
        CouponIssuedRepositoryInterface $couponIssuedRepository
    ) {
        $this->couponIssuedRepository = $couponIssuedRepository;
    }

    public function handle(GetMyCouponListInputDTO $getMyCouponListInputDTO): GetMyCouponListOutputDTO
    {
        $couponList = $this->couponIssuedRepository->findMyCouponList($getMyCouponListInputDTO->getAppUserSn(), $getMyCouponListInputDTO->getFilterType(), $getMyCouponListInputDTO->getLimit());
        if (empty($couponList)) {
            return new GetMyCouponListOutputDTO();
        }
        foreach ($couponList as $coupon) {
            if ($coupon->{Coupon::AS_NUM_COUPON_LIMIT} > 0) {
                $coupon->{Coupon::VAR_NUM_COUPON_USED} = CouponIssued::where(CouponIssued::COL_COUPON_SN, $coupon->{Coupon::COL_COUPON_SN})->where(CouponIssued::COL_USED, CouponIssuedConst::USED['USED'])->count();
            }
            if ($coupon->{UseCondition::COL_APPLY_TARGET} == UseConditionConst::APPLY_TARGET['JUST_APPLY']) {
                $couponForHotel = CouponForHotel::where(CouponForHotel::COL_COUPON_SN, $coupon->{Coupon::COL_COUPON_SN})->where(CouponForHotel::COL_TYPE, CouponForHotelConst::TYPE['USE'])->get([CouponForHotel::COL_HOTEL_SN]);
                if (count($couponForHotel) == 1) {
                    $coupon->{Coupon::VAR_HOTEL_SN} = $couponForHotel[0]->{CouponForHotel::COL_HOTEL_SN};
                }
            }
        }

        return GetMyCouponListOutputDTO::assemble($couponList);
    }
}