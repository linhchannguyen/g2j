<?php

namespace App\Actions\Reward\SA;

use App\Actions\User\SA\GetAppUserInfo;
use App\DTOs\Reward\SA\GetPointHistoryListInputDTOV2;
use App\DTOs\Reward\SA\GetPointHistoryListOutputDTOV2;
use App\DTOs\User\SA\GetAppUserInfoInputDTO;
use App\Repositories\Interfaces\MileagePointHistoryRepositoryInterface;

class GetPointHistoryListV2
{
    const FILE_LANGUAGE_NAME = 'sa/reward';

    /** @var MileagePointHistoryRepositoryInterface */
    protected $mileagePointHistoryRepository;

    /** @var GetAppUserInfo */
    protected $getAppUserInfo;

    public function __construct(
        MileagePointHistoryRepositoryInterface $mileagePointHistoryRepository,
        GetAppUserInfo $getAppUserInfo
    )
    {
        $this->mileagePointHistoryRepository = $mileagePointHistoryRepository;
        $this->getAppUserInfo = $getAppUserInfo;
    }

    public function handle(GetPointHistoryListInputDTOV2 $getPointHistoryListInputDTO): GetPointHistoryListOutputDTOV2
    {
        $getAppUserInfoInputDTO = new GetAppUserInfoInputDTO();
        $getAppUserInfoInputDTO->setSn($getPointHistoryListInputDTO->getAppUserSn());
        $getAppUserInfoOutputDTO = $this->getAppUserInfo->handle($getAppUserInfoInputDTO);
        if ($getAppUserInfoOutputDTO->isEmpty()) {
            return new GetPointHistoryListOutputDTOV2();
        }

        $mileagePointHistoryList = $this->mileagePointHistoryRepository->findByAppUserSn(
            $getPointHistoryListInputDTO->getAppUserSn(),
            $getPointHistoryListInputDTO->getLimit()
        );

        if ($mileagePointHistoryList->isEmpty()) {
            return new GetPointHistoryListOutputDTOV2();
        }

        return GetPointHistoryListOutputDTOV2::assemble($mileagePointHistoryList);
    }
}
