<?php

namespace App\Actions\Reward\SA;

use App\DTOs\Reward\SA\RefreshMileagePointHistoryStaticContentInputDTO;
use App\Helpers\CommonHelper;
use App\Models\Hotel;
use App\Models\MileagePointHistory;
use App\Models\UserBooking;
use App\Repositories\Interfaces\HotelRepositoryInterface;
use App\Repositories\Interfaces\MileagePointHistoryRepositoryInterface;
use App\Repositories\Interfaces\UserBookingRepositoryInterface;
use Illuminate\Support\Facades\DB;

class RefreshMileagePointHistoryStaticContent
{
    const FILE_LANGUAGE_NAME = 'sa/reward';

    /** @var MileagePointHistoryRepositoryInterface */
    protected $mileagePointHistoryRepository;

    /** @var UserBookingRepositoryInterface */
    protected $userBookingRepository;

    /** @var HotelRepositoryInterface */
    protected $hotelRepository;

    public function __construct(
        MileagePointHistoryRepositoryInterface $mileagePointHistoryRepository,
        UserBookingRepositoryInterface $userBookingRepository,
        HotelRepositoryInterface $hotelRepository
    )
    {
        $this->mileagePointHistoryRepository = $mileagePointHistoryRepository;
        $this->userBookingRepository = $userBookingRepository;
        $this->hotelRepository = $hotelRepository;
    }

    public function handle(RefreshMileagePointHistoryStaticContentInputDTO $refreshMileagePointHistoryStaticContentInputDTO): void
    {
        $userBooking = $this->userBookingRepository->find($refreshMileagePointHistoryStaticContentInputDTO->getUserBookingSn(), [
            UserBooking::COL_BOOKING_STATUS,
            UserBooking::COL_VIA_OBJECT,
            UserBooking::COL_TYPE,
            UserBooking::COL_CHECK_IN_DATE_PLAN,
            UserBooking::COL_START_TIME,
            UserBooking::COL_END_TIME,
            UserBooking::COL_HOTEL_SN,
            UserBooking::COL_END_DATE,
            UserBooking::COL_APP_USER_SN,
            UserBooking::COL_BOOKING_NO,
            UserBooking::COL_AMOUNT_FROM_USER,
        ]);

        $hotelSn = $userBooking->{UserBooking::COL_HOTEL_SN};
        $hotel = $this->hotelRepository->find($hotelSn, [Hotel::COL_NAME]);
        $hotelName = $hotel->{Hotel::COL_NAME};
        $checkin = CommonHelper::getBookingCheckinDateTime($userBooking);
        $checkout = CommonHelper::getBookingCheckoutDateTime($userBooking);

        $refundTime = CommonHelper::getEstimatedRefundTimeOfPoint($userBooking);
        $rangeActiveTime = CommonHelper::getRangeActiveTimeOfPoint($userBooking);
        $activeTimeFrom = $rangeActiveTime->activeTimeFrom;
        $activeTimeTo = $rangeActiveTime->activeTimeTo;
        $userBookingSn = $refreshMileagePointHistoryStaticContentInputDTO->getUserBookingSn();
        $queryString = '
            UPDATE MILEAGE_POINT_HISTORY 
            SET LAST_UPDATE = LAST_UPDATE, 
                HOTEL_NAME = :hotelName,
                CHECKIN = :checkin, 
                CHECKOUT = :checkout, 
                ACTIVE_TIME_FROM = IF(ACTIVE_TIME_FROM IS NULL, NULL, :activeTimeFrom), 
                ACTIVE_TIME_TO = IF(ACTIVE_TIME_TO IS NULL, NULL, :activeTimeTo), 
                REFUND_TIME = IF(REFUND_TIME IS NULL, NULL, :refundTime) 
            WHERE USER_BOOKING_SN = :userBookingSn
        ';
        DB::statement($queryString, [
            'hotelName'      => $hotelName,
            'checkin'        => $checkin,
            'checkout'       => $checkout,
            'activeTimeFrom' => $activeTimeFrom,
            'activeTimeTo'   => $activeTimeTo,
            'refundTime'     => $refundTime,
            'userBookingSn'  => $userBookingSn,
        ]);
    }
}
