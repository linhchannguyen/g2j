<?php

namespace App\Actions\Reward\SA;

use App\DTOs\Reward\SA\GetPointStatisticsListInputDTO;
use App\DTOs\Reward\SA\GetPointStatisticsListOutputDTO;
use App\Repositories\Interfaces\AppUserRepositoryInterface;

class GetPointStatisticsList
{
    const FILE_LANGUAGE_NAME = 'sa/reward';

    /** @var AppUserRepositoryInterface */
    protected $appUserRepository;

    public function __construct(
        AppUserRepositoryInterface $appUserRepository
    )
    {
        $this->appUserRepository = $appUserRepository;
    }

    public function handle(GetPointStatisticsListInputDTO $getPointStatisticsListInputDTO): GetPointStatisticsListOutputDTO
    {
        $pointStatisticsList = $this->appUserRepository->findPointStatisticsList(
            $getPointStatisticsListInputDTO->getKeyword(),
            $getPointStatisticsListInputDTO->getStartDate(),
            $getPointStatisticsListInputDTO->getEndDate(),
            $getPointStatisticsListInputDTO->getLimit()
        );

        return GetPointStatisticsListOutputDTO::assemble($pointStatisticsList);
    }
}
