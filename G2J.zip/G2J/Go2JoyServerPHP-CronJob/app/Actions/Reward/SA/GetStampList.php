<?php

namespace App\Actions\Reward\SA;

use App\Actions\User\SA\GetAppUserInfo;
use App\DTOs\Reward\SA\GetStampListInputDTO;
use App\DTOs\Reward\SA\GetStampListOutputDTO;
use App\DTOs\User\SA\GetAppUserInfoInputDTO;
use App\Repositories\Interfaces\UserStampRepositoryInterface;

class GetStampList
{
    const FILE_LANGUAGE_NAME = 'sa/reward';

    /** @var UserStampRepositoryInterface */
    protected $userStampRepository;

    /** @var GetAppUserInfo */
    protected $getAppUserInfo;

    public function __construct(
        UserStampRepositoryInterface $userStampRepository,
        GetAppUserInfo $getAppUserInfo
    )
    {
        $this->userStampRepository = $userStampRepository;
        $this->getAppUserInfo = $getAppUserInfo;
    }

    public function handle(GetStampListInputDTO $getStampListInputDTO): GetStampListOutputDTO
    {
        $getAppUserInfoInputDTO = new GetAppUserInfoInputDTO();
        $getAppUserInfoInputDTO->setSn($getStampListInputDTO->getAppUserSn());
        $getAppUserInfoOutputDTO = $this->getAppUserInfo->handle($getAppUserInfoInputDTO);
        if ($getAppUserInfoOutputDTO->isEmpty()) {
            return new GetStampListOutputDTO();
        }

        $userStampList = $this->userStampRepository->findUserStampListByAppUserSn(
            $getStampListInputDTO->getAppUserSn(),
            $getStampListInputDTO->getRestrictedProvinceSnList(),
            $getStampListInputDTO->getLimit()
        );

        if ($userStampList->isEmpty()) {
            return new GetStampListOutputDTO();
        }

        return GetStampListOutputDTO::assemble($userStampList);
    }
}
