<?php

namespace App\Actions\Reward\SA;

use App\Actions\User\SA\GetAppUserInfo;
use App\Constants\Globals\Locale;
use App\Constants\Globals\Pagination as PaginationConst;
use App\Constants\MileagePointTransaction as MileagePointTransactionConst;
use App\DTOs\Reward\SA\GetPointHistoryListInputDTO;
use App\DTOs\Reward\SA\GetPointHistoryListOutputDTO;
use App\DTOs\User\SA\GetAppUserInfoInputDTO;
use App\Helpers\CommonHelper;
use App\Models\MileagePointTransaction;
use App\Models\UserBooking;
use App\Repositories\Interfaces\MileageHistoryRepositoryInterface;
use App\Repositories\Interfaces\MileagePointTransactionRepositoryInterface;
use App\Repositories\Interfaces\UserBookingRepositoryInterface;

class GetPointHistoryList
{
    const FILE_LANGUAGE_NAME = 'sa/reward';

    /** @var MileagePointTransactionRepositoryInterface */
    protected $mileagePointTransactionRepository;

    /** @var MileageHistoryRepositoryInterface */
    protected $mileageHistoryRepository;

    /** @var UserBookingRepositoryInterface */
    protected $userBookingRepository;

    /** @var GetAppUserInfo */
    protected $getAppUserInfo;

    public function __construct(
        MileagePointTransactionRepositoryInterface $mileagePointTransactionRepository,
        MileageHistoryRepositoryInterface $mileageHistoryRepository,
        UserBookingRepositoryInterface $userBookingRepository,
        GetAppUserInfo $getAppUserInfo
    )
    {
        $this->mileagePointTransactionRepository = $mileagePointTransactionRepository;
        $this->mileageHistoryRepository = $mileageHistoryRepository;
        $this->userBookingRepository = $userBookingRepository;
        $this->getAppUserInfo = $getAppUserInfo;
    }

    public function handle(GetPointHistoryListInputDTO $getPointHistoryListInputDTO): GetPointHistoryListOutputDTO
    {
        $getAppUserInfoInputDTO = new GetAppUserInfoInputDTO();
        $getAppUserInfoInputDTO->setSn($getPointHistoryListInputDTO->getAppUserSn());
        $getAppUserInfoOutputDTO = $this->getAppUserInfo->handle($getAppUserInfoInputDTO);
        if ($getAppUserInfoOutputDTO->isEmpty()) {
            return new GetPointHistoryListOutputDTO();
        }

        $mileageHistoryList = $this->mileageHistoryRepository->findMileageHistoryByAppUserSn(
            $getPointHistoryListInputDTO->getAppUserSn(),
            PaginationConst::LIMIT['NO_LIMIT']
        );

        $mileagePointTransactionList = $this->mileagePointTransactionRepository->findMileagePointTransactionByAppUserSn(
            $getPointHistoryListInputDTO->getAppUserSn(),
            PaginationConst::LIMIT['NO_LIMIT']
        );

        if ($mileageHistoryList->isEmpty() && $mileagePointTransactionList->isEmpty()) {
            return new GetPointHistoryListOutputDTO();
        }

        $pointHistoryListMerged = $mileageHistoryList->merge($mileagePointTransactionList);

        $pointHistoryListSorted = collect($pointHistoryListMerged)->sortByDesc(MileagePointTransaction::COL_CREATED_TIME)->values();

        $pointHistoryListPaginated = CommonHelper::paginate($pointHistoryListSorted, $getPointHistoryListInputDTO->getLimit());

        foreach ($pointHistoryListPaginated as $item) {
            $userBookingSn = $item->{MileagePointTransaction::COL_USER_BOOKING_SN};
            $item->{UserBooking::COL_BOOKING_NO} = null;
            $item->{UserBooking::COL_AMOUNT_FROM_USER} = null;
            if (!empty($userBookingSn)) {
                $userBooking = $this->userBookingRepository->find($userBookingSn, [
                    UserBooking::COL_BOOKING_NO,
                    UserBooking::COL_AMOUNT_FROM_USER,
                ]);
                $item->{UserBooking::COL_BOOKING_NO} = $userBooking->{UserBooking::COL_BOOKING_NO};
                $item->{UserBooking::COL_AMOUNT_FROM_USER} = $userBooking->{UserBooking::COL_AMOUNT_FROM_USER};
            }

            if ($item->{MileagePointTransaction::COL_TYPE_PROGRAM} == MileagePointTransactionConst::TYPE_PROGRAM['MINI_GAME']
                && app()->getLocale() == Locale::VIETNAMESE['VI']
            ) {
                $item->{MileagePointTransaction::VAR_MILEAGE_NAME} = 'Vòng xoay may mắn';
            }
        }

        return GetPointHistoryListOutputDTO::assemble($pointHistoryListPaginated);
    }
}
