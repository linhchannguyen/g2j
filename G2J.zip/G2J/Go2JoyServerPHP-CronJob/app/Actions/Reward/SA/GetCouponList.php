<?php

namespace App\Actions\Reward\SA;

use App\Actions\User\SA\GetAppUserInfo;
use App\DTOs\Reward\SA\GetCouponListInputDTO;
use App\DTOs\Reward\SA\GetCouponListOutputDTO;
use App\DTOs\User\SA\GetAppUserInfoInputDTO;
use App\Repositories\Interfaces\CouponIssuedRepositoryInterface;

class GetCouponList
{
    const FILE_LANGUAGE_NAME = 'sa/reward';

    /** @var CouponIssuedRepositoryInterface */
    protected $couponIssuedRepository;

    /** @var GetAppUserInfo */
    protected $getAppUserInfo;

    public function __construct(
        CouponIssuedRepositoryInterface $couponIssuedRepository,
        GetAppUserInfo $getAppUserInfo
    )
    {
        $this->couponIssuedRepository = $couponIssuedRepository;
        $this->getAppUserInfo = $getAppUserInfo;
    }

    public function handle(GetCouponListInputDTO $getCouponListInputDTO): GetCouponListOutputDTO
    {
        $getAppUserInfoInputDTO = new GetAppUserInfoInputDTO();
        $getAppUserInfoInputDTO->setSn($getCouponListInputDTO->getAppUserSn());
        $getAppUserInfoOutputDTO = $this->getAppUserInfo->handle($getAppUserInfoInputDTO);
        if ($getAppUserInfoOutputDTO->isEmpty()) {
            return new GetCouponListOutputDTO();
        }

        $couponIssuedList = $this->couponIssuedRepository->findCouponIssuedListByAppUserSn(
            $getCouponListInputDTO->getAppUserSn(),
            $getCouponListInputDTO->getLimit()
        );

        if ($couponIssuedList->isEmpty()) {
            return new GetCouponListOutputDTO();
        }

        return GetCouponListOutputDTO::assemble($couponIssuedList);
    }
}
