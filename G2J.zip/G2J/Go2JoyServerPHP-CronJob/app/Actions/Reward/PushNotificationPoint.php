<?php

namespace App\Actions\Reward;

use App\Constants\AppUserSetting as AppUserSettingConst;
use App\Constants\Globals\Common;
use App\Constants\Globals\FcmNotification as FcmNotificationConst;
use App\Constants\Globals\QueueName as QueueNameConst;
use App\Constants\Globals\UserNotification as UserNotificationConst;
use App\Constants\MileagePointHistory as MileagePointHistoryConst;
use App\DTOs\Reward\PushNotificationPointInputDTO;
use App\DTOs\Reward\PushNotificationPointOutputDTO;
use App\Helpers\CommonHelper;
use App\Helpers\ConvertHelper;
use App\Jobs\Notification\PushNotificationJob;
use App\Models\MileagePointHistory;
use App\Repositories\Interfaces\MileagePointHistoryRepositoryInterface;
use App\Services\Common\NotificationService;

class PushNotificationPoint
{
    /** @var MileagePointHistoryRepositoryInterface */
    protected $mileagePointHistoryRepository;

    /** @var NotificationService */
    protected $notificationService;

    public function __construct(
        MileagePointHistoryRepositoryInterface $mileagePointHistoryRepository,
        NotificationService                    $notificationService
    ) {
        $this->mileagePointHistoryRepository = $mileagePointHistoryRepository;
        $this->notificationService = $notificationService;
    }

    public function handle(PushNotificationPointInputDTO $notificationPointInputDTO): PushNotificationPointOutputDTO
    {
        if (empty($notificationPointInputDTO->getMileagePointTransactionHistorySn())) {
            return PushNotificationPointOutputDTO::assemble(false);
        }
        $mileagePointHistory = MileagePointHistory::whereIn(MileagePointHistory::COL_STATUS, [MileagePointHistoryConst::STATUS['ACTIVE'], MileagePointHistoryConst::STATUS['REFUNDED']])
            ->where(MileagePointHistory::COL_ACTUAL_POINT, '>', 0)
            ->whereJsonContains(MileagePointHistory::COL_MILEAGE_POINT_TRANSACTION_HISTORY_LIST, $notificationPointInputDTO->getMileagePointTransactionHistorySn())
            ->select([
                MileagePointHistory::COL_APP_USER_SN,
                MileagePointHistory::COL_TYPE_PROGRAM,
                MileagePointHistory::COL_BOOKING_NO,
                MileagePointHistory::COL_USER_BOOKING_SN,
                MileagePointHistory::COL_STATUS,
                MileagePointHistory::COL_TOTAL_ACTIVE_POINT,
                MileagePointHistory::COL_ACTUAL_POINT,
            ])->first();

        if (empty($mileagePointHistory)) {
            return PushNotificationPointOutputDTO::assemble(false);
        }
        list($title, $body, $informationList) = $this->_generationContentNotification($mileagePointHistory);
        if (!empty($title) && !empty($body)) {
            //Push notification
            $pushNotificationJob = new PushNotificationJob($mileagePointHistory->{MileagePointHistory::COL_APP_USER_SN},
                [], $title, $body, $informationList, FcmNotificationConst::NOTI_MILEAGE_POINT, Common::GO2JOY, true, null, null, null, null);
            dispatch($pushNotificationJob->onQueue(QueueNameConst::NOTIFICATION)->delay($notificationPointInputDTO->getDelayTime()));

            return PushNotificationPointOutputDTO::assemble(true);
        }

        return PushNotificationPointOutputDTO::assemble(false);

    }

    private function _generationContentNotification($mileagePointHistory): array
    {
        $title = null;
        $body = null;
        $informationList = [];
        if (in_array($mileagePointHistory->{MileagePointHistory::COL_TYPE_PROGRAM}, [MileagePointHistoryConst::TYPE_PROGRAM['BOOKING'], MileagePointHistoryConst::TYPE_PROGRAM['REWARD']])) {
            switch ($mileagePointHistory->{MileagePointHistory::COL_STATUS}) {
                case MileagePointHistoryConst::STATUS['ACTIVE']:
                    $title = ConvertHelper::getMessage(UserNotificationConst::MGS_NOTIFICATION, 'title.point.booking.reward');
                    $body = ConvertHelper::getMessage(UserNotificationConst::MGS_NOTIFICATION, 'point.booking.reward');
                    $informationList = [
                        'point'            => $mileagePointHistory->{MileagePointHistory::COL_ACTUAL_POINT},
                        'bookingNo'        => $mileagePointHistory->{MileagePointHistory::COL_BOOKING_NO},
                        'totalActivePoint' => $mileagePointHistory->{MileagePointHistory::COL_TOTAL_ACTIVE_POINT},
                    ];
                    break;
                case MileagePointHistoryConst::STATUS['REFUNDED']:
                    $title = ConvertHelper::getMessage(UserNotificationConst::MGS_NOTIFICATION, 'title.point.booking.refunded');
                    $body = ConvertHelper::getMessage(UserNotificationConst::MGS_NOTIFICATION, 'point.booking.refunded');
                    $informationList = [
                        'point'            => $mileagePointHistory->{MileagePointHistory::COL_ACTUAL_POINT},
                        'bookingNo'        => $mileagePointHistory->{MileagePointHistory::COL_BOOKING_NO},
                        'totalActivePoint' => $mileagePointHistory->{MileagePointHistory::COL_TOTAL_ACTIVE_POINT},
                    ];
                    break;
                default:
                    break;

            }

        } elseif (MileagePointHistoryConst::TYPE_PROGRAM['MINI_GAME'] == $mileagePointHistory->{MileagePointHistory::COL_TYPE_PROGRAM}) {
            $title = ConvertHelper::getMessage(UserNotificationConst::MGS_NOTIFICATION, 'title.point.mini_gaming.reward');
            $body = ConvertHelper::getMessage(UserNotificationConst::MGS_NOTIFICATION, 'point.mini_gaming.reward');
            $informationList = [
                'point'            => $mileagePointHistory->{MileagePointHistory::COL_ACTUAL_POINT},
                'totalActivePoint' => $mileagePointHistory->{MileagePointHistory::COL_TOTAL_ACTIVE_POINT},
            ];
        }

        return [$title, $body, $informationList];
    }
}