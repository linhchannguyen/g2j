<?php

namespace App\Actions\Reward;

use App\Constants\Globals\Code as CodeConst;
use App\Constants\Globals\Common as CommonConst;
use App\Constants\MileagePointExpiration as MileagePointExpirationConst;
use App\Constants\MileagePointHistory as MileagePointHistoryConst;
use App\Constants\MileagePointTransactionHistory as MileagePointTransactionHistoryConst;
use App\Constants\PaymentTransaction as PaymentTransactionConst;
use App\Constants\Setting as SettingConst;
use App\Constants\UserBooking as UserBookingConst;
use App\DTOs\Reward\RewardPointFromBookingInputDTO;
use App\DTOs\Reward\RewardPointFromBookingOutputDTO;
use App\Exceptions\ServiceException;
use App\Helpers\CommonHelper;
use App\Helpers\LoggingHelper;
use App\Models\AppUser;
use App\Models\MileagePointExpiration;
use App\Models\MileagePointHistory;
use App\Models\MileagePointTransactionHistory;
use App\Models\Setting;
use App\Models\UserBooking;
use App\Repositories\Interfaces\AppUserRepositoryInterface;
use App\Repositories\Interfaces\MileagePointHistoryRepositoryInterface;
use App\Repositories\Interfaces\MileagePointTransactionHistoryRepositoryInterface;
use App\Repositories\Interfaces\UserBookingRepositoryInterface;
use Exception;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\DB;
use Psr\SimpleCache\InvalidArgumentException;

class RewardPointFromBooking
{
    const FILE_LANGUAGE_NAME = 'reward';

    /** @var AppUserRepositoryInterface */
    protected $appUserRepository;

    /** @var UserBookingRepositoryInterface */
    protected $userBookingRepository;

    /** @var MileagePointTransactionHistoryRepositoryInterface */
    protected $mileagePointTransactionHistoryRepository;

    /** @var MileagePointHistoryRepositoryInterface */
    protected $mileagePointHistoryRepository;

    public function __construct(
        AppUserRepositoryInterface                        $appUserRepository,
        UserBookingRepositoryInterface                    $userBookingRepository,
        MileagePointTransactionHistoryRepositoryInterface $mileagePointTransactionHistoryRepository,
        MileagePointHistoryRepositoryInterface            $mileagePointHistoryRepository
    ) {
        $this->appUserRepository = $appUserRepository;
        $this->userBookingRepository = $userBookingRepository;
        $this->mileagePointTransactionHistoryRepository = $mileagePointTransactionHistoryRepository;
        $this->mileagePointHistoryRepository = $mileagePointHistoryRepository;
    }

    /**
     * @throws ServiceException|InvalidArgumentException
     */
    public function handle(RewardPointFromBookingInputDTO $rewardPointFromBookingInputDTO): RewardPointFromBookingOutputDTO
    {
        $now = Carbon::now();
        $earedPoint = 0;

        $userBooking = $this->userBookingRepository->find($rewardPointFromBookingInputDTO->getUserBookingSn(), [
            UserBooking::COL_SN,
            UserBooking::COL_APP_USER_SN,
            UserBooking::COL_BOOKING_STATUS,
            UserBooking::COL_REFUNDED,
            UserBooking::COL_PAYMENT_PROVIDER,
            UserBooking::COL_AMOUNT_FROM_USER,
            UserBooking::COL_TYPE,
            UserBooking::COL_CHECK_IN_DATE_PLAN,
            UserBooking::COL_START_TIME,
            UserBooking::COL_END_TIME,
            UserBooking::COL_HOTEL_SN,
            UserBooking::COL_END_DATE,
            UserBooking::COL_ROOM_TYPE_SN,
            UserBooking::COL_FLASH_SALE_HISTORY_SN,
            UserBooking::COL_COUPON_ISSUED_SN,
            UserBooking::COL_PAYMENT_PROVIDER,
            UserBooking::COL_PAYMENT_CODE,
        ]);

        if (empty($userBooking)) {
            throw new ServiceException(CommonHelper::getMessage(CommonConst::FILE_MESSAGE_LANGUAGE_NAME, CodeConst::API_GNR_005), CodeConst::API_GNR_005);
        }

        if (empty($userBooking->{UserBooking::COL_APP_USER_SN})) {
            return RewardPointFromBookingOutputDTO::assemble($earedPoint);
        }

        if (!in_array($userBooking->{UserBooking::COL_BOOKING_STATUS}, [
            UserBookingConst::BOOKING_STATUS['COMPLETED'],
            UserBookingConst::BOOKING_STATUS['NO_SHOW'],
        ])
        ) {
            return RewardPointFromBookingOutputDTO::assemble($earedPoint);
        }

        $paymentStatus = CommonHelper::preCheckPaymentStatus(
            $userBooking->{UserBooking::COL_SN},
            $userBooking->{UserBooking::COL_BOOKING_STATUS},
            $userBooking->{UserBooking::COL_REFUNDED},
            $userBooking->{UserBooking::COL_PAYMENT_PROVIDER}
        );

        if (PaymentTransactionConst::PAYMENT_STATUS['SUCCESSFUL'] != $paymentStatus) {
            return RewardPointFromBookingOutputDTO::assemble($earedPoint);
        }

        $amountFromUser = $userBooking->{UserBooking::COL_AMOUNT_FROM_USER};
        if ($amountFromUser <= 0) {
            return RewardPointFromBookingOutputDTO::assemble($earedPoint);
        }

        $isExpiredTimeProcessingBooking = CommonHelper::isExpiredTimeProcessingBookingOfPoint($userBooking);
        if (!$isExpiredTimeProcessingBooking) {
            return RewardPointFromBookingOutputDTO::assemble($earedPoint);
        }

        $haveRewarded = $this->mileagePointTransactionHistoryRepository->haveRewardedPoint($rewardPointFromBookingInputDTO->getUserBookingSn());
        $isOldActivePoint = $this->mileagePointTransactionHistoryRepository->isOldActivePoint($rewardPointFromBookingInputDTO->getUserBookingSn());
        if ($haveRewarded && !$isOldActivePoint) {
            return RewardPointFromBookingOutputDTO::assemble($earedPoint);
        }

        $haveWithdrawnReward = $this->mileagePointTransactionHistoryRepository->haveWithdrawnRewardPoint($rewardPointFromBookingInputDTO->getUserBookingSn());
        if ($haveWithdrawnReward && !$isOldActivePoint) {
            return RewardPointFromBookingOutputDTO::assemble($earedPoint);
        }

        $mileagePointTransactionHistory = MileagePointTransactionHistory::where(MileagePointTransactionHistory::COL_USER_BOOKING_SN, $rewardPointFromBookingInputDTO->getUserBookingSn())
            ->where(MileagePointTransactionHistory::COL_STATUS, MileagePointTransactionHistoryConst::STATUS['PENDING_REWARD'])
            ->first([
                MileagePointTransactionHistory::COL_SN,
                MileagePointTransactionHistory::COL_APP_USER_SN,
                MileagePointTransactionHistory::COL_TYPE_PROGRAM,
                MileagePointTransactionHistory::COL_PROGRAM_SN,
                MileagePointTransactionHistory::COL_USER_BOOKING_SN,
                MileagePointTransactionHistory::COL_EXPECTED_POINT,
            ]);
        if (empty($mileagePointTransactionHistory)) {
            return RewardPointFromBookingOutputDTO::assemble($earedPoint);
        }

        $appUserSn = $mileagePointTransactionHistory->{MileagePointTransactionHistory::COL_APP_USER_SN};
        $typeProgram = $mileagePointTransactionHistory->{MileagePointTransactionHistory::COL_TYPE_PROGRAM};
        $programSn = $mileagePointTransactionHistory->{MileagePointTransactionHistory::COL_PROGRAM_SN};
        $userBookingSn = $mileagePointTransactionHistory->{MileagePointTransactionHistory::COL_USER_BOOKING_SN};
        $expectedPoint = $mileagePointTransactionHistory->{MileagePointTransactionHistory::COL_EXPECTED_POINT};

        DB::connection('mysql')->beginTransaction();
        try {
            $appUser = AppUser::lockForUpdate()
                ->where(AppUser::COL_SN, $userBooking->{UserBooking::COL_APP_USER_SN})
                ->first([
                    AppUser::COL_MILEAGE_AMOUNT,
                    AppUser::COL_MILEAGE_EARNED,
                    AppUser::COL_MILEAGE_FIRST_TIME,
                    AppUser::COL_MILEAGE_PENDING,
                ]);

            $mileageAmount = $appUser->{AppUser::COL_MILEAGE_AMOUNT};
            $mileageEarned = $appUser->{AppUser::COL_MILEAGE_EARNED};
            $mileageFirstTime = $appUser->{AppUser::COL_MILEAGE_FIRST_TIME};
            $mileagePending = $appUser->{AppUser::COL_MILEAGE_PENDING};

            $totalActivePoint = $mileageAmount + $expectedPoint;
            $actualPoint = $expectedPoint;

            $mileagePointTransactionHistory = MileagePointTransactionHistory::create([
                MileagePointTransactionHistory::COL_APP_USER_SN        => $appUserSn,
                MileagePointTransactionHistory::COL_TYPE_PROGRAM       => $typeProgram,
                MileagePointTransactionHistory::COL_PROGRAM_SN         => $programSn,
                MileagePointTransactionHistory::COL_USER_BOOKING_SN    => $userBookingSn,
                MileagePointTransactionHistory::COL_TOTAL_ACTIVE_POINT => $totalActivePoint,
                MileagePointTransactionHistory::COL_ACTUAL_POINT       => $actualPoint,
                MileagePointTransactionHistory::COL_EXPECTED_POINT     => $expectedPoint,
                MileagePointTransactionHistory::COL_STATUS             => MileagePointTransactionHistoryConst::STATUS['ACTIVE'],
            ]);
            $mileagePointTransactionHistorySn = $mileagePointTransactionHistory->{MileagePointTransactionHistory::COL_SN};

            $pendingRewardHistory = MileagePointHistory::where(MileagePointHistory::COL_APP_USER_SN, $mileagePointTransactionHistory->{MileagePointTransactionHistory::COL_APP_USER_SN})
                ->where(MileagePointHistory::COL_USER_BOOKING_SN, $mileagePointTransactionHistory->{MileagePointTransactionHistory::COL_USER_BOOKING_SN})
                ->where(MileagePointHistory::COL_STATUS, MileagePointHistoryConst::STATUS['PENDING_REWARD'])
                ->first([MileagePointHistory::COL_SN]);

            if (empty($pendingRewardHistory)) {
                throw new ServiceException(CommonHelper::getMessage(self::FILE_LANGUAGE_NAME, CodeConst::API_RWD_003), CodeConst::API_RWD_003);
            }

            $rangeActiveTime = CommonHelper::getRangeActiveTimeOfPoint($userBooking);
            $activeTimeFrom = $rangeActiveTime->activeTimeFrom;
            $activeTimeTo = $rangeActiveTime->activeTimeTo;
            $expiredDate = Carbon::parse($activeTimeTo);

            $mileageHistorySn = $pendingRewardHistory->{MileagePointHistory::COL_SN};
            MileagePointHistory::where(MileagePointHistory::COL_SN, $mileageHistorySn)
                ->update([
                    MileagePointHistory::COL_STATUS                                 => MileagePointHistoryConst::STATUS['ACTIVE'],
                    MileagePointHistory::COL_TOTAL_ACTIVE_POINT                     => $totalActivePoint,
                    MileagePointHistory::COL_ACTUAL_POINT                           => $actualPoint,
                    MileagePointHistory::COL_EXPECTED_POINT                         => $expectedPoint,
                    MileagePointHistory::COL_ACTIVE_TIME_FROM                       => $activeTimeFrom,
                    MileagePointHistory::COL_ACTIVE_TIME_TO                         => $activeTimeTo,
                    MileagePointHistory::COL_CLAIM_TIME                             => null,
                    MileagePointHistory::COL_REFUND_TIME                            => null,
                    MileagePointHistory::COL_EXPIRATION_TIME                        => $activeTimeTo,
                    MileagePointHistory::COL_MILEAGE_POINT_TRANSACTION_HISTORY_LIST => json_encode([$mileagePointTransactionHistorySn]),
                ]);

            MileagePointExpiration::create([
                MileagePointExpiration::COL_MILEAGE_POINT_TRANSACTION_HISTORY_SN => $mileagePointTransactionHistorySn,
                MileagePointExpiration::COL_APP_USER_SN                          => $appUserSn,
                MileagePointExpiration::COL_NUM_OF_POINT                         => $expectedPoint,
                MileagePointExpiration::COL_REMAINING_POINT                      => $expectedPoint,
                MileagePointExpiration::COL_DAY                                  => $expiredDate->day,
                MileagePointExpiration::COL_MONTH                                => $expiredDate->month,
                MileagePointExpiration::COL_YEAR                                 => $expiredDate->year,
                MileagePointExpiration::COL_PROCESSED                            => MileagePointExpirationConst::PROCESSED['NOT_YET'],
            ]);

            $mileageAmount = $mileageAmount + $expectedPoint;
            $mileageEarned = $mileageEarned + $expectedPoint;
            $mileagePending = $mileagePending - $expectedPoint;

            $updateAppUserData = [
                AppUser::COL_MILEAGE_AMOUNT     => $mileageAmount,
                AppUser::COL_MILEAGE_EARNED     => $mileageEarned,
                AppUser::COL_MILEAGE_FIRST_TIME => $mileageFirstTime,
                AppUser::COL_MILEAGE_PENDING    => max($mileagePending, 0),
            ];
            if (empty($mileageFirstTime)) {
                $updateAppUserData[AppUser::COL_MILEAGE_FIRST_TIME] = $now;
            }

            $this->appUserRepository->update($updateAppUserData, $appUserSn);

            $earedPoint = $actualPoint;

            DB::connection('mysql')->commit();

            return RewardPointFromBookingOutputDTO::assemble($earedPoint, $mileagePointTransactionHistorySn);
        } catch (Exception $exception) {
            report($exception);
            DB::connection('mysql')->rollBack();
            throw $exception;
        }
    }
}
