<?php

namespace App\Actions\Coupon\Mobile;

use App\Constants\Coupon as CouponConst;
use App\Constants\CouponIssued as CouponIssuedConst;
use App\Constants\UserBooking as UserBookingConst;
use App\DTOs\MobileV4\Hotel\GetSuggestionCouponListInputDTO;
use App\DTOs\MobileV4\Hotel\GetSuggestionCouponListOutputDTO;
use App\Helpers\DateTimeHelper;
use App\Models\Coupon;
use App\Models\CouponIssued;
use App\Models\RoomType;
use App\Models\UseCondition;
use App\Repositories\Interfaces\CouponRepositoryInterface;
use Illuminate\Support\Carbon;

class GetSuggestionCouponList
{
    protected $couponRepository;

    public function __construct()
    {
        $this->couponRepository = app(CouponRepositoryInterface::class);
    }

    public function handle(GetSuggestionCouponListInputDTO $getSuggestionCouponListInputDTO)
    {
        if (empty($getSuggestionCouponListInputDTO->getAppUserSn())) {
            return GetSuggestionCouponListOutputDTO::assemble([]);
        }
        $originPrice = 0;
        $roomType = RoomType::where(RoomType::COL_SN, $getSuggestionCouponListInputDTO->getRoomTypeSn())->first([RoomType::COL_FIRST_HOURS, RoomType::COL_ADDITIONAL_HOURS, RoomType::COL_MAX_NUM_HOUR, RoomType::COL_FIRST_HOURS_ORIGIN, RoomType::COL_ADDITIONAL_ORIGIN, RoomType::COL_OVERNIGHT_ORIGIN, RoomType::COL_ONE_DAY_ORIGIN]);

        switch ($getSuggestionCouponListInputDTO->getBookingType()) {
            case UserBookingConst::BOOKING_TYPE['HOURLY']:
                if (empty($roomType->{RoomType::COL_FIRST_HOURS_ORIGIN})) {
                    return GetSuggestionCouponListOutputDTO::assemble([]);
                }
                $startTime = Carbon::parse($getSuggestionCouponListInputDTO->getStartDate() . $getSuggestionCouponListInputDTO->getStartTime());
                $endTime = Carbon::parse($getSuggestionCouponListInputDTO->getEndDate() . $getSuggestionCouponListInputDTO->getEndTime());
                $diffInHours = $endTime->diffInHours($startTime);
                if (!empty($roomType->{RoomType::COL_MAX_NUM_HOUR}) && $diffInHours > $roomType->{RoomType::COL_MAX_NUM_HOUR}) {
                    $originPrice = $roomType->{RoomType::COL_ONE_DAY_ORIGIN} ?? 0;
                } else {
                    $originPrice = $roomType->{RoomType::COL_FIRST_HOURS_ORIGIN} + ((($diffInHours - $roomType->{RoomType::COL_FIRST_HOURS}) / $roomType->{RoomType::COL_ADDITIONAL_HOURS}) * $roomType->{RoomType::COL_ADDITIONAL_ORIGIN});
                }

                break;
            case UserBookingConst::BOOKING_TYPE['OVERNIGHT']:
                if (empty($roomType->{RoomType::COL_OVERNIGHT_ORIGIN})) {
                    return GetSuggestionCouponListOutputDTO::assemble([]);
                }
                $originPrice = $roomType->{RoomType::COL_OVERNIGHT_ORIGIN} ?? 0;
                break;
            case UserBookingConst::BOOKING_TYPE['DAILY']:
                if (empty($roomType->{RoomType::COL_ONE_DAY_ORIGIN})) {
                    return GetSuggestionCouponListOutputDTO::assemble([]);
                }
                $dateList = DateTimeHelper::getDateList($getSuggestionCouponListInputDTO->getStartDate(), $getSuggestionCouponListInputDTO->getEndDate());
                $totalDays = count($dateList) ?? 1;
                $originPrice = $roomType->{RoomType::COL_ONE_DAY_ORIGIN} * $totalDays;
                break;
        }
        $couponList = $this->couponRepository->findCouponHaveUseInRoomTypeList($getSuggestionCouponListInputDTO->getHotelSn(),null, $getSuggestionCouponListInputDTO->getStartDate())->toArray();
        foreach ($couponList as $coupon) {
            $this->_calculateDiscountCoupon($coupon, $originPrice);
            if ($coupon->{UseCondition::COL_NUM_COUPON_LIMIT} > 0) {
                $coupon->{Coupon::VAR_NUM_COUPON_USED} = CouponIssued::where(CouponIssued::COL_COUPON_SN, $coupon->{Coupon::COL_COUPON_SN})->where(CouponIssued::COL_USED, CouponIssuedConst::USED['USED'])->count();
            }
        }
        if (!empty($couponList)) {
            usort($couponList, function($coupon1, $coupon2) {
                return [[$coupon1->{Coupon::VAR_DISCOUNT_REAL}], [$coupon2->{Coupon::AS_MIN_MONEY}], [$coupon2->{Coupon::VAR_PRIORITY}]] < [[$coupon2->{Coupon::VAR_DISCOUNT_REAL}], [$coupon1->{Coupon::AS_MIN_MONEY}], [$coupon1->{Coupon::VAR_PRIORITY}]] ? 1 : -1;
            });
        }

        return GetSuggestionCouponListOutputDTO::assemble($couponList);
    }

    private function _calculateDiscountCoupon(&$coupon, $originPrice)
    {
        $discount = 0;
        $priority = 0;
        switch ($coupon->{Coupon::COL_DISCOUNT_TYPE}) {
            case CouponConst::DISCOUNT_TYPE['MONEY']:
                $priority = CouponConst::PRIORITY_SORT['MONEY'];
                $discount = $coupon->{Coupon::COL_DISCOUNT};
                break;
            case CouponConst::DISCOUNT_TYPE['PERCENT']:
                $priority = CouponConst::PRIORITY_SORT['PERCENT'];
                $discount = $originPrice * ($coupon->{Coupon::COL_DISCOUNT} / 100);
                if ($discount > $coupon->{Coupon::COL_MAX_DISCOUNT}) {
                    $discount = $coupon->{Coupon::COL_MAX_DISCOUNT};
                }
                break;
            case CouponConst::DISCOUNT_TYPE['SAME_PRICE']:
                $priority = CouponConst::PRIORITY_SORT['SAME_PRICE'];
                $discount = $originPrice - $coupon->{Coupon::COL_DISCOUNT};
                break;
            case CouponConst::DISCOUNT_TYPE['HOURS']:
                $priority = CouponConst::PRIORITY_SORT['HOURS'];
                break;
            case CouponConst::DISCOUNT_TYPE['GIFT']:
                $priority = CouponConst::PRIORITY_SORT['GIFT'];
                break;
        }
        $coupon->{Coupon::VAR_DISCOUNT_REAL} = $discount;
        $coupon->{Coupon::VAR_PRIORITY} = $priority;
    }
}