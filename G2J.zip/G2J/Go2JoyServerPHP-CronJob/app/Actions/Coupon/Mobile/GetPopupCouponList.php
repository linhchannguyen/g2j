<?php

namespace App\Actions\Coupon\Mobile;

use App\DTOs\Coupon\Mobile\GetPopupCouponListInputDTO;
use App\DTOs\Coupon\Mobile\GetPopupCouponListOutputDTO;
use App\Repositories\Interfaces\CouponIssuedRepositoryInterface;
use App\Repositories\Interfaces\PopupRepositoryInterface;

class GetPopupCouponList
{
    protected $popupRepository;

    protected $couponIssuedRepository;

    public function __construct()
    {
        $this->popupRepository = app(PopupRepositoryInterface::class);
        $this->couponIssuedRepository = app(CouponIssuedRepositoryInterface::class);
    }

    public function handle(GetPopupCouponListInputDTO $getPopupCouponListInputDTO)
    {
        if (empty($getPopupCouponListInputDTO->getAppUserSn()) || !$this->popupRepository->checkPopupCouponActive()) {
            return new GetPopupCouponListOutputDTO();
        }
        $couponIssuedList = $this->couponIssuedRepository->findPopupCouponList($getPopupCouponListInputDTO->getAppUserSn());

        return GetPopupCouponListOutputDTO::assemble($couponIssuedList);
    }
}