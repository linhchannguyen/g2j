<?php

namespace App\Actions\HotelDebt;

use App\DTOs\HotelDebt\CalculatePeriodDebtInputDTO;
use App\DTOs\HotelDebt\UpdateHotelDebtInputDTO;
use App\DTOs\HotelDebt\UpdateHotelDebtOutputDTO;
use App\Helpers\LoggingHelper;
use App\Models\HotelDebt;
use App\Repositories\Interfaces\HotelDebtRepositoryInterface;
use Exception;
use Illuminate\Support\Facades\DB;

class UpdateHotelDebt
{
    const FILE_LANGUAGE_NAME = 'hotelDebt';

    /** @var HotelDebtRepositoryInterface */
    public $hotelDebtRepository;

    /** @var CalculatePeriodDebt */
    public $calculatePeriodDebt;

    public function __construct()
    {
        $this->hotelDebtRepository = app(HotelDebtRepositoryInterface::class);
        $this->calculatePeriodDebt = app(CalculatePeriodDebt::class);
    }

    public function handle(UpdateHotelDebtInputDTO $updateHotelDebtInputDTO): UpdateHotelDebtOutputDTO
    {
        DB::connection('mysql')->beginTransaction();

        try {
            $hotelDebt = $this->hotelDebtRepository->findHotelDebtBySn($updateHotelDebtInputDTO->getHotelDebtSn());

            if (!empty($hotelDebt)) {
                $calculatePeriodDebtInputDTO = new CalculatePeriodDebtInputDTO();
                $calculatePeriodDebtInputDTO->setHotelSn($updateHotelDebtInputDTO->getHotelSn());
                $calculatePeriodDebtInputDTO->setStartDate($updateHotelDebtInputDTO->getStartDate());
                $calculatePeriodDebtInputDTO->setEndDate($updateHotelDebtInputDTO->getEndDate());
                $calculatePeriodDebtOutputDTO = $this->calculatePeriodDebt->handle($calculatePeriodDebtInputDTO);
                $periodDebt = $calculatePeriodDebtOutputDTO->getPeriodDebt();
                $currentDebt = $hotelDebt->{HotelDebt::COL_CURRENT_DEBT};
                $otherDebt = $updateHotelDebtInputDTO->getOtherDebt();
                $payAmount = $updateHotelDebtInputDTO->getPayAmount();
                $balance = ($currentDebt + $periodDebt + $otherDebt) - $payAmount;

                $finalRecord = $hotelDebt->{HotelDebt::COL_FINAL_RECORD};
                if ($finalRecord) {
                    $hotelDebtData = [
                        HotelDebt::COL_START_DATE      => $updateHotelDebtInputDTO->getStartDate(),
                        HotelDebt::COL_END_DATE        => $updateHotelDebtInputDTO->getEndDate(),
                        HotelDebt::COL_PAY_DATE        => $updateHotelDebtInputDTO->getPayDate(),
                        HotelDebt::COL_PAY_AMOUNT      => $updateHotelDebtInputDTO->getPayAmount(),
                        HotelDebt::COL_OTHER_DEBT      => $updateHotelDebtInputDTO->getOtherDebt(),
                        HotelDebt::COL_MEMO            => $updateHotelDebtInputDTO->getMemo(),
                        HotelDebt::COL_UPDATE_STAFF_SN => $updateHotelDebtInputDTO->getStaffSn(),
                        HotelDebt::COL_PERIOD_DEBT     => $periodDebt,
                        HotelDebt::COL_BALANCE         => $balance,
                    ];
                    $isUpdated = $this->hotelDebtRepository->update($hotelDebtData, $updateHotelDebtInputDTO->getHotelDebtSn());
                    if (!$isUpdated) {
                        DB::connection('mysql')->rollBack();
                        return UpdateHotelDebtOutputDTO::assemble(false);
                    }
                } else {
                    $hotelDebtData = [
                        HotelDebt::COL_PAY_DATE        => $updateHotelDebtInputDTO->getPayDate(),
                        HotelDebt::COL_PAY_AMOUNT      => $updateHotelDebtInputDTO->getPayAmount(),
                        HotelDebt::COL_OTHER_DEBT      => $updateHotelDebtInputDTO->getOtherDebt(),
                        HotelDebt::COL_MEMO            => $updateHotelDebtInputDTO->getMemo(),
                        HotelDebt::COL_UPDATE_STAFF_SN => $updateHotelDebtInputDTO->getStaffSn(),
                        HotelDebt::COL_PERIOD_DEBT     => $periodDebt,
                        HotelDebt::COL_BALANCE         => $balance,
                    ];
                    $isUpdated = $this->hotelDebtRepository->update($hotelDebtData, $updateHotelDebtInputDTO->getHotelDebtSn());
                    if (!$isUpdated) {
                        DB::connection('mysql')->rollBack();
                        return UpdateHotelDebtOutputDTO::assemble(false);
                    }

                    $hotelDebtList = $this->hotelDebtRepository->findHotelDebtListAfterDate($updateHotelDebtInputDTO->getHotelSn(), $updateHotelDebtInputDTO->getEndDate());
                    $preHotelDebtBalance = $balance;
                    foreach ($hotelDebtList as $_hotelDebt) {
                        $_hotelDebtData[HotelDebt::COL_CURRENT_DEBT] = $preHotelDebtBalance;

                        $_balance = ($_hotelDebtData[HotelDebt::COL_CURRENT_DEBT] + $_hotelDebt->{HotelDebt::COL_PERIOD_DEBT} +  $_hotelDebt->{HotelDebt::COL_OTHER_DEBT}) - $_hotelDebt->{HotelDebt::COL_PAY_AMOUNT};
                        $_hotelDebtData[HotelDebt::COL_BALANCE] = $_balance;

                        $_isUpdated = $this->hotelDebtRepository->update($_hotelDebtData, $_hotelDebt->{HotelDebt::COL_SN});
                        if (!$_isUpdated) {
                            DB::connection('mysql')->rollBack();
                            return UpdateHotelDebtOutputDTO::assemble(false);
                        }

                        $preHotelDebtBalance = $_hotelDebtData[HotelDebt::COL_BALANCE];
                    }
                }

            }

            DB::connection('mysql')->commit();

            return UpdateHotelDebtOutputDTO::assemble(true);

        } catch (Exception $exception) {
            LoggingHelper::logException($exception);

            DB::connection('mysql')->rollBack();

            return UpdateHotelDebtOutputDTO::assemble(false);
        }
    }
}