<?php

namespace App\Actions\HotelDebt;

use App\DTOs\HotelDebt\CalculatePeriodDebtInputDTO;
use App\DTOs\HotelDebt\CalculatePeriodDebtOutputDTO;
use App\Models\UserBooking;
use App\Repositories\Interfaces\UserBookingRepositoryInterface;

class CalculatePeriodDebt
{
    const FILE_LANGUAGE_NAME = 'hotelDebt';

    /** @var UserBookingRepositoryInterface */
    public $userBookingRepository;

    public function __construct()
    {
        $this->userBookingRepository = app(UserBookingRepositoryInterface::class);
    }

    public function handle(CalculatePeriodDebtInputDTO $calculatePeriodDebtInputDTO): CalculatePeriodDebtOutputDTO
    {
        $userBookingStatistics = $this->userBookingRepository->getStatistics($calculatePeriodDebtInputDTO->getHotelSn(), $calculatePeriodDebtInputDTO->getStartDate(), $calculatePeriodDebtInputDTO->getEndDate());
        $totalCommissionAmount = intval($userBookingStatistics->{UserBooking::COL_COMMISSION_AMOUNT}) + intval($userBookingStatistics->{UserBooking::COL_COMMISSION_PRODUCT_AMOUNT});
        $totalPrepayAmount = intval($userBookingStatistics->{UserBooking::COL_PREPAY_AMOUNT});
        $totalGo2JoyDiscount = intval($userBookingStatistics->{UserBooking::COL_GO2JOY_DISCOUNT});
        $totalSponsorDiscount = intval($userBookingStatistics->{UserBooking::COL_SPONSOR_DISCOUNT});
        $totalFsGo2JoyDiscount = intval($userBookingStatistics->{UserBooking::COL_FS_GO2JOY_DISCOUNT});
        $totalPromotionDiscount = intval($userBookingStatistics->{UserBooking::COL_PROMOTION_DISCOUNT});
        $totalMileagePoint = intval($userBookingStatistics->{UserBooking::COL_MILEAGE_POINT});
        $periodDebt = $totalCommissionAmount - ($totalPrepayAmount + $totalGo2JoyDiscount + $totalSponsorDiscount + $totalFsGo2JoyDiscount + $totalPromotionDiscount + $totalMileagePoint);
        return CalculatePeriodDebtOutputDTO::assemble($periodDebt);
    }
}