<?php

namespace App\Actions\Banner\SA;

use App\DTOs\Web\SA\Banner\UpdateDisplaySettingBannerInputDTO;
use App\Models\BannerSetting;

class UpdateDisplaySettingBanner
{
    public function handle(UpdateDisplaySettingBannerInputDTO $updateDisplaySettingBannerInputDTO): void
    {
        BannerSetting::where(BannerSetting::COL_TYPE, $updateDisplaySettingBannerInputDTO->getType())
            ->update([BannerSetting::COL_TYPE_DISPLAY => $updateDisplaySettingBannerInputDTO->getDisplayType()]);
    }
}
