<?php

namespace App\Actions\Banner\Mobile;

use App\Constants\Banner as BannerConst;
use App\Constants\BannerSetting as BannerSettingConst;
use App\DTOs\Banner\Mobile\GetBannerListInputDTO;
use App\DTOs\Banner\Mobile\GetBannerListOutputDTO;
use App\Helpers\CommonHelper;
use App\Models\BannerSetting;
use App\Repositories\Interfaces\BannerRepositoryInterface;

class GetBannerList
{
    protected $bannerRepository;

    public function __construct()
    {
        $this->bannerRepository = app(BannerRepositoryInterface::class);
    }

    public function handle(GetBannerListInputDTO $getBannerListInputDTO)
    {
        $bannerSetting = CommonHelper::getBannerSetting(BannerSettingConst::TYPE['APP']);
        $bannerDisplayType = !empty($bannerSetting->{BannerSetting::COL_TYPE_DISPLAY}) ? $bannerSetting->{BannerSetting::COL_TYPE_DISPLAY} : BannerConst::TYPE_OF_DISPLAY['CUSTOM'];
        $bannerList = $this->bannerRepository->findAllBannerActive($getBannerListInputDTO->getProvinceSn());
        if ($bannerDisplayType == BannerConst::TYPE_OF_DISPLAY['RANDOM']) {
            $bannerList = Collect($bannerList)->shuffle()->toArray();
        }

        return GetBannerListOutputDTO::assemble($bannerList);
    }
}