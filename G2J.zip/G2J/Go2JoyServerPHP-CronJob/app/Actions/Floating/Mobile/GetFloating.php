<?php

namespace App\Actions\Floating\Mobile;

use App\Constants\Globals\Floating as FloatingConst;
use App\DTOs\Floating\Mobile\GetFloatingInputDTO;
use App\DTOs\Floating\Mobile\GetFloatingOutputDTO;
use App\Models\ReferralProgram;
use App\Repositories\Interfaces\ReferralProgramRepositoryInterface;

class GetFloating
{
    public $referralProgramRepository;

    public $floatingImage;

    public $floatingAction;

    public $floatingTargetSn;

    public $floatingTargetLink;

    public function __construct()
    {
        $this->referralProgramRepository = app(ReferralProgramRepositoryInterface::class);
        $this->floatingImage = config('go2joy.floating.image');
        $this->floatingAction = intval(config('go2joy.floating.action'));
        $this->floatingTargetSn = intval(config('go2joy.floating.target_sn'));
        $this->floatingTargetLink = config('go2joy.floating.target_link');
    }

    public function handle(GetFloatingInputDTO $getFloatingInputDTO)
    {
        if (!empty($this->floatingImage)) {
            return GetFloatingOutputDTO::assemble($this->floatingImage, $this->floatingAction, $this->floatingTargetSn, $this->floatingTargetLink);
        } else {
            $referralProgram = $this->referralProgramRepository->getReferralProgramRunning();
            if (!empty($referralProgram)) {
                return GetFloatingOutputDTO::assemble($referralProgram->{ReferralProgram::COL_FLOATING_ICON}, FloatingConst::ACTION['REFERRAL_PROGRAM'], $referralProgram->{ReferralProgram::COL_SN}, null);
            }
        }

        return new GetFloatingOutputDTO();
    }
}