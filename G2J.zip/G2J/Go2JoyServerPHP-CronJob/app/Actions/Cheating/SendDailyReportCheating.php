<?php

namespace App\Actions\Cheating;

use App\Constants\Globals\QueueName;
use App\Helpers\UploadHelper;
use App\Jobs\Mail\SendReportCheatingMailJob;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Storage;

class SendDailyReportCheating
{
    public function handle(): void
    {
        $folder = storage_path('app/reports/report-cheating/');
        $filePath = $folder . 'report-cheating.txt';
        if (File::exists($folder)) {
            $filePath = "/reports/report-cheating/report-cheating.txt";
            $data = Storage::disk(UploadHelper::DISK_LOCAL)->get($filePath);
            SendReportCheatingMailJob::dispatch(json_decode($data, true))->onQueue(QueueName::EMAIL);
        }
    }
}
