<?php

namespace App\Actions\Cheating;

use App\Constants\UserBooking as UserBookingConst;
use App\Helpers\CommonHelper;
use App\Helpers\UploadHelper;
use App\Models\BookingLocation;
use App\Models\District;
use App\Models\Province;
use App\Models\UserBooking;
use App\Repositories\Interfaces\UserBookingRepositoryInterface;
use Carbon\Carbon;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Storage;

class DailyReportOfSuspectedHotelCheating
{
    /** @var UserBookingRepositoryInterface */
    protected $userBookingRepository;

    public function __construct(
        UserBookingRepositoryInterface $userBookingRepository
    ) {
        $this->userBookingRepository = $userBookingRepository;
    }

    public function handle(string $date): void
    {
        $cheatingList['bookingCheating01'] = [];
        $cheatingList['bookingCheating02'] = [];
        $cheatingList['bookingCheating06'] = [];
        $cheatingList['bookingCheating07'] = [];
        $cheatingList['bookingCheating10'] = [];
        $cheatingList['bookingCheating11'] = [];
        $bookingCheating01List =  $this->_checkBookingCheating(1, $date);
        $bookingCheating02List =  $this->_checkBookingCheating(2, $date);
        $bookingCheating06List =  $this->_checkBookingCheating(6, $date);
        $bookingCheating07List =  $this->_checkBookingCheating(7, $date);
        $bookingCheating10List =  $this->_checkBookingCheating(10, $date);
        $bookingCheating11List =  $this->_checkBookingCheating(11, $date);
        $this->_getCheatingInfo(1, $bookingCheating01List, $cheatingList);
        $this->_getCheatingInfo(2, $bookingCheating02List, $cheatingList);
        $this->_getCheatingInfo(6, $bookingCheating06List, $cheatingList);
        $this->_getCheatingInfo(7, $bookingCheating07List, $cheatingList);
        $this->_getCheatingInfo(10, $bookingCheating10List, $cheatingList);
        $this->_getCheatingInfo(11, $bookingCheating11List, $cheatingList);
        // Check folder already exists or not, create if not exists
        $folder = storage_path('app/reports/report-cheating/');
        if (!File::exists($folder)) {
            File::makeDirectory($folder, 0755, true, true);
        }
        $filePath = $folder . 'report-cheating.txt';
        file_put_contents($filePath, json_encode($cheatingList));
        $filePath = "/reports/report-cheating/report-cheating.txt";
        $content = Storage::disk(UploadHelper::DISK_LOCAL)->get($filePath);
        UploadHelper::uploadFile($content, UploadHelper::FOLDER['UPLOAD'] . $filePath);
    }

    private function _getCheatingInfo($position, $userBookingSnList, &$cheatingList)
    {
        if (empty($userBookingSnList)) {
            return;
        }
        $userBookingList = $this->userBookingRepository->getBookingForReportCheating($userBookingSnList);
        foreach ($userBookingList as $booking) {
            $bookingNo = $booking->{UserBooking::COL_BOOKING_NO};
            $hotelName = $booking->{UserBooking::ALIAS_HOTEL_NAME};
            $hotelSn = $booking->{UserBooking::COL_HOTEL_SN};
            $nickName = $booking->{UserBooking::ALIAS_APP_USER_NICK_NAME};
            $mobileDeviceSn = $booking->{UserBooking::COL_MOBILE_DEVICE_SN};
            $deviceModel = $booking->{UserBooking::ALIAS_APP_USER_PHONE_MODEL};
            $appUserSn = $booking->{UserBooking::COL_APP_USER_SN};
            $couponName = $booking->{UserBooking::ALIAS_COUPON_TITLE};
            $couponCode = $booking->{UserBooking::ALIAS_COUPON_CODE};
            $totalPrice = $booking->{UserBooking::COL_TOTAL_AMOUNT};
            $g2jDiscount = $booking->{UserBooking::COL_GO2JOY_DISCOUNT};
            $commissionAmount = $booking->{UserBooking::COL_COMMISSION_AMOUNT};
            $hotelDiscount = $booking->{UserBooking::COL_HOTEL_DISCOUNT};
            $bookingType = $booking->{UserBooking::COL_TYPE};
            $bookingTypeStr = strtolower(UserBookingConst::BOOKING_TYPE_STR[$bookingType] ?? "");
            $checkInDatePlan = $booking->{UserBooking::COL_CHECK_IN_DATE_PLAN};
            $checkInDatePlan = !empty($checkInDatePlan) ? Carbon::parse($checkInDatePlan)->format('Y-m-d') : null;
            $startTime = $booking->{UserBooking::COL_START_TIME};
            $startTime = !empty($startTime) ? Carbon::parse($startTime)->format('H:i') : null;
            $endTime = $booking->{UserBooking::COL_END_TIME};
            $endTime = !empty($endTime) ? Carbon::parse($endTime)->format('H:i') : null;
            $bookingStatus = strtolower(UserBookingConst::BOOKING_STATUS_STR[$booking->{UserBooking::COL_BOOKING_STATUS}] ?? '');
            $checkInTime = !empty($booking->{UserBooking::COL_CHECK_IN_TIME}) ? Carbon::parse($booking->{UserBooking::COL_CHECK_IN_TIME})->format('Y-m-d H:i:s') : null;
            $bookingTime = !empty($booking->{UserBooking::ALIAS_BOOKING_TIME}) ? Carbon::parse($booking->{UserBooking::ALIAS_BOOKING_TIME})->format('Y-m-d H:i:s') : null;

            switch ($position) {
                case 1: {
                        $bookingCheating01 = [
                            'BOOKING_NO' => $bookingNo,
                            'HOTEL_NAME' => $hotelName,
                            'HOTEL_SN' => $hotelSn,
                            'CHECK_IN_TIME' => $checkInTime,
                            'MOBILE_DEVICE_SN' => $mobileDeviceSn,
                            'DEVICE_MODEL' => $deviceModel,
                            'APP_USER_SN' => $appUserSn,
                            'NICK_NAME' => $nickName,
                            'COUPON_NAME' => $couponName,
                            'COUPON_CODE' => $couponCode,
                            'GO2JOY_DISCOUNT' => $g2jDiscount,
                            'COMMISSION' => $commissionAmount,
                        ];
                        $cheatingList['bookingCheating01'][] = $bookingCheating01;
                        break;
                    }
                case 2: {
                        $bookingLocation = BookingLocation::where(BookingLocation::COL_USER_BOOKING_SN, $booking->{UserBooking::COL_SN})
                            ->first([
                                BookingLocation::COL_PROVINCE_SN,
                                BookingLocation::COL_DISTRICT_SN,
                                BookingLocation::COL_ADDRESS,
                            ]);
                        [$provinceName, $districtName, $actionAddress] = $this->_getLocation($bookingLocation);
                        $bookingCheating02 = [
                            'HOTEL_NAME' => $hotelName,
                            'HOTEL_SN' => $hotelSn,
                            'PROVINCE' => $provinceName,
                            'DISTRICT' => $districtName,
                            'ACTION_ADDRESS' => $actionAddress,
                            'NICK_NAME' => $nickName,
                            'APP_USER_SN' => $appUserSn,
                            'BOOKING_NO' => $bookingNo,
                            'BOOKING_STATUS' => $bookingStatus,
                            'BOOKING_TIME' => $bookingTime,
                            'TOTAL_PRICE' => $totalPrice,
                            'COUPON_NAME' => $couponName,
                            'COUPON_CODE' => $couponCode,
                            'GO2JOY_DISCOUNT' => $g2jDiscount,
                            'COMMISSION' => $commissionAmount,
                        ];
                        $cheatingList['bookingCheating02'][] = $bookingCheating02;
                        break;
                    }
                case 6: {
                        $bookingCheating06 = [
                            'HOTEL_NAME' => $hotelName,
                            'HOTEL_SN' => $hotelSn,
                            'NICK_NAME' => $nickName,
                            'APP_USER_SN' => $appUserSn,
                            'BOOKING_NO' => $bookingNo,
                            'BOOKING_TYPE' => $bookingTypeStr,
                            'BOOKING_TIME' => $bookingTime,
                            'CHECKIN_TIME' => $checkInTime,
                            'CHECKIN_PLAN' => CommonHelper::getBookingCheckinDateTime($booking),
                            'CHECKOUT_PLAN' => CommonHelper::getBookingCheckoutDateTime($booking),
                            'COUPON_NAME' => $couponName,
                            'COUPON_CODE' => $couponCode,
                            'GO2JOY_DISCOUNT' => $g2jDiscount,
                            'COMMISSION' => $commissionAmount,
                            'HOTEL_DISCOUNT' => $hotelDiscount,
                        ];
                        $cheatingList['bookingCheating06'][] = $bookingCheating06;
                        break;
                    }
                case 7: {
                        $bookingCheating07 = [
                            'HOTEL_NAME' => $hotelName,
                            'HOTEL_SN' => $hotelSn,
                            'BOOKING_TYPE' => $bookingTypeStr,
                            'CHECKIN_TIME' => $checkInTime,
                            'CHECKIN_PLAN' => CommonHelper::getBookingCheckinDateTime($booking),
                            'BOOKING_TIME' => $bookingTime,
                            'APP_USER_SN' => $appUserSn,
                            'NICK_NAME' => $nickName,
                            'BOOKING_NO' => $bookingNo,
                            'TOTAL_PRICE' => $totalPrice,
                            'COUPON_NAME' => $couponName,
                            'COUPON_CODE' => $couponCode,
                            'GO2JOY_DISCOUNT' => $g2jDiscount,
                            'HOTEL_DISCOUNT' => $hotelDiscount,
                            'COMMISSION' => $commissionAmount,
                        ];
                        $cheatingList['bookingCheating07'][] = $bookingCheating07;
                        break;
                    }
                case 10: {
                        $bookingCheating10 = [
                            'BOOKING_NO' => $bookingNo,
                            'HOTEL_NAME' => $hotelName,
                            'HOTEL_SN' => $hotelSn,
                            'CHECK_IN_TIME' => $checkInTime,
                            'MOBILE_DEVICE_SN' => $mobileDeviceSn,
                            'DEVICE_MODEL' => $deviceModel,
                            'APP_USER_SN' => $appUserSn,
                            'NICK_NAME' => $nickName,
                            'COUPON_NAME' => $couponName,
                            'COUPON_CODE' => $couponCode,
                            'GO2JOY_DISCOUNT' => $g2jDiscount,
                            'COMMISSION' => $commissionAmount,
                        ];
                        $cheatingList['bookingCheating10'][] = $bookingCheating10;
                        break;
                    }
                case 11: {
                        $bookingCheating11 = [
                            'BOOKING_NO' => $bookingNo,
                            'HOTEL_NAME' => $hotelName,
                            'HOTEL_SN' => $hotelSn,
                            'MOBILE_DEVICE_SN' => $mobileDeviceSn,
                            'DEVICE_MODEL' => $deviceModel,
                            'APP_USER_SN' => $appUserSn,
                            'NICK_NAME' => $nickName,
                            'COUPON_NAME' => $couponName,
                            'COUPON_CODE' => $couponCode,
                            'GO2JOY_DISCOUNT' => $g2jDiscount,
                            'COMMISSION' => $commissionAmount,
                        ];
                        $cheatingList['bookingCheating11'][] = $bookingCheating11;
                        break;
                    }
                default:
                    break;
            }
        }
    }

    private function _getLocation(?BookingLocation $bookingLocation)
    {
        $provinceName = '';
        $districtName = '';
        if (empty($bookingLocation)) {
            return [$provinceName, $districtName, ''];
        }
        $provinceSn = $bookingLocation->{BookingLocation::COL_PROVINCE_SN};
        $districtSn = $bookingLocation->{BookingLocation::COL_DISTRICT_SN};
        $actionAddress = $bookingLocation->{BookingLocation::COL_ADDRESS};
        if (!empty($provinceSn)) {
            $provinceName = Province::where(Province::COL_SN, $provinceSn)->first([Province::COL_NAME])->{Province::COL_NAME} ?? '';
        }
        if (!empty($districtSn)) {
            $districtName = District::where(District::COL_SN, $districtSn)->first([District::COL_NAME])->{District::COL_NAME} ?? '';
        }
        return [$provinceName, $districtName, $actionAddress];
    }

    private function _checkBookingCheating(int $posCondition, string $date)
    {
        $_userBookingSnList = [];
        $bookingCheating = [];
        switch ($posCondition) {
            case 1: {
                    // Check-in action time & Stay at hotel time : Within the same day
                    // Device ID : same Device ID
                    // Coupon: using coupon
                    // Hotel : 2 or more booking made
                    $bookingCheating = $this->userBookingRepository->getBookingCheating01($date);
                    break;
                }
            case 2: {
                    // 1. Coupon : Go2Joy discount 100% coupon and same coupon
                    // 2. User : same mobile device
                    // 3. Hotel : 3 or more booking made
                    // 4. Booking: using same coupon
                    $bookingCheating = $this->userBookingRepository->getBookingCheating02($date);
                    break;
                }
            case 6: {
                    // 1. Coupon : Go2Joy 100% coupon or Go2Joy's discount over 40,000VND
                    // 2. Number of coupon : 3 or more within same day
                    // 3. Booking : Complete
                    // 4. User : Same User ID (Same Nickname or Same Device ID or Same email) check-in within same day
                    // 5. Hotel : Same hotel
                    $bookingCheating = $this->userBookingRepository->getBookingCheating06($date);
                    break;
                }
            case 7: {
                    // 1. Coupon : Total Go2Joy discount > Total Commission
                    // 2. Check-in action : More than 3 check-in
                    // 3. Hotel : Same hotel
                    $bookingCheating = $this->userBookingRepository->getBookingCheating07($date);
                    break;
                }
            case 10: {
                    // 1. 100% Go2Joy discount coupons, Same User ID (Same Device ID or Same email) has 3 or more check-in within same day
                    $bookingCheating = $this->userBookingRepository->getBookingCheating10($date);
                    break;
                }
            case 11: {
                    // 1. 100% Go2Joy discount coupons, more than 3 bookings booked by one user within 5 min
                    $bookingCheating = $this->userBookingRepository->getBookingCheating11($date);
                    break;
                }
            default:
                break;
        }
        foreach ($bookingCheating as $value) {
            $userBookingSnStr = $value->{'USER_BOOKING_SN_LIST'} ?? null;
            if (!empty($userBookingSnStr)) {
                $_userBookingSnList = array_merge($_userBookingSnList, explode(',', $userBookingSnStr));
            }
        }
        return $_userBookingSnList;
    }
}
