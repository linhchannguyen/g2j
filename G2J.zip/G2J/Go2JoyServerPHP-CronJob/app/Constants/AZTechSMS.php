<?php

namespace App\Constants;

class AZTechSMS
{
    const ERROR_CODE_OVER_QUOTA = 82;
    const ERROR_CODE_RETRY = [40, 41, 41, 51, 52, 531, 54, 55, 50, 551, 80, 81, 82];
    const EXCEPT_CARRIER = ['vinaphone'];
}