<?php

namespace App\Constants;

class DraftPromotion
{
    const STATUS = array(
        'DRAFT' => 6,
    );
}
