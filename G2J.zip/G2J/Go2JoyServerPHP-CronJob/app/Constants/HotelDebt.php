<?php

namespace App\Constants;

class HotelDebt
{
    const FINAL_RECORD = array(
        'FALSE' => 0,
        'TRUE'  => 1,
    );

    const STATUS = array(
        'INACTIVE'              => 0,
        'CREATED'               => 1,
        'NOT_RECONCILE_YET'     => 2,
        'REPORTING'             => 3,
        'COMPLETED'             => 4,
        'AWAITING_VERIFICATION' => 5,
    );
}
