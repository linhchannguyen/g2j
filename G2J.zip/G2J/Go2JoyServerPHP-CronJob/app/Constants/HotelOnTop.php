<?php


namespace App\Constants;


class HotelOnTop
{
    const TYPE = array(
        'DISTRICT'   => 1,
        'HASHTAG'    => 2,
        'COLLECTION' => 3,
        'SEARCHING'  => 4,
    );

    const STATUS = array(
        'EXPIRED'     => 0,
        'ACTIVE'      => 1,
        'WILL_ACTIVE' => 2,
    );
    const DELETE = array(
        'ACTIVE'  => 0,
        'EXPIRED' => 1,
    );
}
