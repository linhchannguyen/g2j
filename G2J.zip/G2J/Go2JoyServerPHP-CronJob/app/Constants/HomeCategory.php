<?php

namespace App\Constants;

class HomeCategory
{
    const TYPE = array(
        'NOTICE'           => 1,
        'BANNER'           => 2,
        'CHOOSE_AREA'      => 3,
        'HOTEL_COLLECTION' => 4,
        'VOUCHER_CODE'     => 5,
        'ABOUT_US'         => 6,
        'ARTICLE'          => 7,
        'COVER_PHOTO'      => 8,
    );

    const DISPLAY = array(
        'HIDE'    => 0,
        'DISPLAY' => 1,
    );
}
