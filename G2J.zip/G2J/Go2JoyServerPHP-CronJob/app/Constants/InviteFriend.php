<?php

namespace App\Constants;

class InviteFriend
{
    const STATUS = array(
        'DELETED'      => 0,
        'ACTIVE'       => 1,
        'EXPIRED'      => 2,
        'TEMP'         => 3,
        'DRAFT'        => 4,
        'WAIT_CONFIRM' => 5,
    );
    const TYPE_APPLY = array(
        'MANUAL'  => 0,
        'CHECKIN' => 1,
    );
    const EPAY_SUCCESSFUL = 0;
    const STATUS_NO_REFUND = 0;
    const STATUS_REFUND = 1;
    const NEW_FEATURE = array(
        'COUPON' => 'coupon',
        'POINT'  => 'point',
        'STAMP'  => 'stamp',
    );
}
