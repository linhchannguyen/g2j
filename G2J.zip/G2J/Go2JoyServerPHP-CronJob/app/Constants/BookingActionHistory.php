<?php

namespace App\Constants;

class BookingActionHistory
{
    const WORKING_STATUS = [
        'RECEIVED'          => 0,
        'SOLVED'            => 1,
        'AWAITING_APPROVAL' => 2,
        'REJECTED'          => 3,
    ];

    const ACTION_USER_TYPE = [
        'GO2JOY_STAFF' => 1,
        'HOTEL_STAFF'  => 2,
        'SYSTEM'       => 3,
    ];

    const ACTION_TYPE = [
        'AWAITING_GO2JOY_PROCESSING' => 0,
        'COMPLETED'                  => 1,
        'CANCELLED'                  => 2,
        'NO_SHOW'                    => 3,
        'REJECTED'                   => 4,
        'TRANSFER'                   => 5,
        'REFUND_POINT'               => 6,
    ];
}
