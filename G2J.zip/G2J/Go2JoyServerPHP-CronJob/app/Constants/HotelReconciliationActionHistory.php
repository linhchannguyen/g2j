<?php

namespace App\Constants;

class HotelReconciliationActionHistory
{
    const ACTION_USER_TYPE = [
        'GO2JOY_STAFF' => 1,
        'HOTEL_STAFF'  => 2,
        'SYSTEM'       => 3,
    ];
    const ACTION_TYPE = [
        'CREATE_RECONCILIATION'          => 1,
        'SEND_RECONCILIATION'            => 2,
        'RESEND_RECONCILIATION_TO_HOTEL' => 3,
        'COMPLETE_RECONCILIATION'        => 4,
        'EDIT_BOOKING_INFORMATION'       => 5,
        'UPDATE_BOOKING_STATUS'          => 6,
        'SEND_RESPONSE_TO_GO2JOY'        => 7,
    ];
}