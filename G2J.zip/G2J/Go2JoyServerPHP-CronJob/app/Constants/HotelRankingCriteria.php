<?php

namespace App\Constants;

class HotelRankingCriteria
{
    const CRITERIA = array(
        'BOOKING_TYPE'                           => 1,
        'ROOM_STATUS'                            => 2,
        'RADIUS'                                 => 3,
        'RATE_REVIEW'                            => 4,
        'NUMBER_OF_REVIEWS'                      => 5,
        'RATE_COMPLETED_COMPARED_TOTAL_BOOKINGS' => 6,
        'TYPE_OF_HOTEL'                          => 7,
    );
}
