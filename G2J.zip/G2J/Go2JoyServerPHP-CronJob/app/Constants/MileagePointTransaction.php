<?php

namespace App\Constants;

class MileagePointTransaction
{
    const TYPE_PROGRAM = array(
        'NORMAL'    => 1,
        'REWARD'    => 2,
        'REFERRAL'  => 3,
        'MINI_GAME' => 4,
    );
    const TYPE = array(
        'GET'     => 1,
        'USED'    => 2,
        'EXPIRED' => 3,
        'CANCEL'  => 4,
        'ADJUST'  => 5,
    );

    const TRANSFER_AUTO_INCREMENT_VALUE = 3000000;
    const NEW_AUTO_INCREMENT_VALUE = 4000000;
}