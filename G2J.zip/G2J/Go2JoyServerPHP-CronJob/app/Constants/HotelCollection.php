<?php

namespace App\Constants;

class HotelCollection
{
    const DISPLAY_TYPE = array(
        'ALL'               => 0,
        'DETAIL'            => 1,
        'COLLECTION'        => 2,
        'SUMMARY'           => 3,
        'CIRCLE'            => 4,
        'L_SQUARE'          => 5,
        'D_SQUARE'          => 6,
        'RECT_1_2'          => 7,
        'RECT_2_1'          => 8,
        'ICON'              => 9,
        'LIST_OF_HOTEL'     => 10, //for homepage web booking
        'EXPERIENCE_GO2JOY' => 11, //for homepage web booking
    );
    const DISPLAY_CATEGORY = array(
        'LOCATION'       => 1,
        'BOOKING_TYPE'   => 2,
        'GO2JOY_SPECIAL' => 3,
        'HOTEL_TYPE'     => 4,
    );
    const TYPE = array(
        'FLASH_SALE'       => 1,
        'PROMOTION'        => 2,
        'DIRECT_DISCOUNT'  => 3,
        'AMENITY_PACK'     => 4,
        'LOVE_HOTEL'       => 5,
        'TRAVEL_HOTEL'     => 6,
        'HOT_HOTEL'        => 7,
        'NEW_HOTEL'        => 8,
        'STAMP'            => 9,
        'IMAGE_360'        => 10,
        'HOTEL_REVIEW'     => 11,
        'HOTEL_SEARCHED'   => 12,
        'HOTEL_BOOKED'     => 13,
        'HOTEL_FAVORITE'   => 14,
        'HOTEL_SUGGESTION' => 15,
        'G2JCERTIFIED'     => 16,
        'QUARANTINE'       => 17,
    );
    const MSG = 'hotelCollection';
    const ERR_PLZ_CHOOSE_PROMOTION_GROUP = 1;
    const ERR_PLZ_CHOOSE_HOTEL_LIST = 2;

    const SHOW_TYPE = array(
        'APP' => 1,
        'WEB' => 2,
    );
}
