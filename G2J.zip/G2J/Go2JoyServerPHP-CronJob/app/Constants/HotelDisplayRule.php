<?php

namespace App\Constants;

class HotelDisplayRule
{

    const TYPE_DISPLAY = array(
        'PROMOTION' => 1,
        'SAME_PRICE' => 2,
        'DIRECT_DISCOUNT' => 3,
        'EXTRA_FEE' => 4,
        'GIFT' => 5,
        'EXTRA_HOURS' => 6,
    );

    const WEB_BOKING_PRICE_MSG = 'webBooking/price';
}
