<?php

namespace App\Constants\Partners;

class Agoda
{
    /*
    |--------------------------------------------------------------------------
    | Agoda Appendix
    |--------------------------------------------------------------------------
    |
    | Link: https://partners.agoda.com/DeveloperPortal/APIDoc/Appendix
    |
    */

    // API key and site id has been provided by Agoda for get data feed
    const DATA_FEED = array(
        'TOKEN' => '27210a5f408eeab3fa4f23e731fcdc2f',
        'SITE_ID' => '1895223',
    );

    const LANGUAGE_ID = array(
        'ENGLISH'    => '1',
        'VIETNAMESE' => '24',
    );

    const LANGUAGE_CODE = array(
        'ENGLISH'    => 'en-us',
        'VIETNAMESE' => 'vi-vn',
    );

    const CURRENCY_CODE = array(
        'US_DOLLAR'       => 'USD',
        'VIETNAMESE_DONG' => 'VND',
    );

    const COUNTRY_CODE = array(
        'VIETNAM' => 'VN'
    );

    /**
     * Link: http://affiliatefeed.agoda.com/datafeeds/feeddetail?feed_id=2&token=27210a5f408eeab3fa4f23e731fcdc2f&site_id=1895223
     */
    const COUNTRY_ID = array(
        'VIETNAM' => '38'
    );

    /**
     * Link: http://affiliatefeed.agoda.com/datafeeds/feeddetail?feed_id=1&token=27210a5f408eeab3fa4f23e731fcdc2f&site_id=1895223
     */
    const REGION_ID = array(
        'ASIA' => '2'
    );

    /**
     * Link: https://partners.agoda.com/DeveloperPortal/APIDoc/ContentAPI
     *
     * typeid = 1: returned hotelID has content update on date, then partner should update content
     * typeid = 2: returned hotelID are newly enabled for partner on date; then partner should map these new properties
     * typeid = 3: returned hotelID are disabled/closed for partner on date; then partner should disable these properties from search
     */
    const TYPE_ID = array(
        'CONTENT_UPDATE'     => 1,
        'NEWLY_ENABLED'      => 2,
        'DISABLED_OR_CLOSED' => 3,
    );

    const LONG_SEARCH_API = array(
        'TYPE' => array(
            'HOTEL_SEARCH'      => 4,
            'HOTEL_LIST_SEARCH' => 6,
        ),
    );

    /**
     * Get all values.
     *
     * @var string
     */
    const ALL = '-1';

    /**
     * The maximum number of booked days for a room.
     *
     * @var int
     */
    const MAX_NUM_OF_BOOKED_DAYS = 14;

    // List of property ids from Agoda
    const PROPERTY_ID = array(
        'CHECK_IN_FROM'   => 8,
        'CHECK_IN_UNTIL'  => 45,
        'CHECK_OUT_FROM'  => 44,
        'CHECK_OUT_UNTIL' => 9,
    );

    /**
     * Link: https://partners.agoda.com/DeveloperPortal/APIDoc/BestPractices
     */
    const MAXIMUM_OF_ROOMS = 20;
    const MAXIMUM_OF_ADULTS = 80;
    const MAXIMUM_OF_CHILDREN = 80;

    const HOTEL_IMAGE_SIZE = '1080x';
    const ROOM_TYPE_IMAGE_SIZE = '1080x';

    const PROCESSING_DELAY = 30; // minutes

    const REASON = array(
        'NONE'                                              => 0,
        'WILL_BOOK_WITH_HOTEL_DIRECTLY'                     => 13,
        'FORCED_TO_CANCEL_OR_POSTPONE_TRIP'                 => 14,
        'DECIDED_ON_A_DIFFERENT_HOTEL_NOT_OFFERED_BY_AGODA' => 15,
        'WILL_BOOK_A_DIFFERENT_HOTEL_THROUGH_AGODA'         => 16,
        'FOUND_LOWER_PRICE_ON_INTERNET'                     => 17,
        'FOUND_LOWER_PRICE_THROUGH_A_LOCAL_AGENT'           => 18,
        'DID_NOT_LIKE_PAYMENT_TERMS'                        => 19,
        'DID_NOT_LIKE_CANCELLATION_TERMS'                   => 20,
        'CONCERNS_ABOUT_RELIABILITY'                        => 22,
        'CONCERNS_ABOUT_SAFETY'                             => 23,
        'BOOKING_NOT_CONFIRMED_QUICKLY_ENOUGH'              => 25,
        'NATURAL_DISASTER'                                  => 44,
    );

    const EXTRA = array(
        'CONTENT'             => 'content',
        'DAILY_RATE'          => 'dailyRate',
        'META_SEARCH'         => 'metaSearch',
        'BENEFIT_DETAIL'      => 'benefitDetail',
        'CANCELLATION_DETAIL' => 'cancellationDetail',
        'PROMOTION_DETAIL'    => 'promotionDetail',
        'RATE_DETAIL'         => 'rateDetail',
        'SURCHARGE_DETAIL'    => 'surchargeDetail',
        'TAX_DETAIL'          => 'taxDetail',
    );
}
