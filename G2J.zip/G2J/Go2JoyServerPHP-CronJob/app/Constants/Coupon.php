<?php

namespace App\Constants;

class Coupon
{
    const DISCOUNT_TYPE = array(
        'MONEY'             => 1,
        'PERCENT'           => 2,
        'GIFT'              => 3,
        'HOURS'             => 4,
        'SAME_PRICE'        => 5,
        'DIRECT_DISCOUNT'   => 8,
        'EXTRA_FEE'         => 9,
    );

    const DISCOUNT = array(
        'NO'  => 0,
        'YES' => 1,
    );

    const STATUS = array(
        'DELETED' => 0,
        'ACTIVE' => 1,
        'EXPIRED' => 2,
        'TEMP' => 3,
        'DRAFT' => 4,
        'WAIT_CONFIRM' => 5,
    );

    const APPLY = array(
        'APPLY_ALL' => 1,
        'APPLY_ALL_EXCLUDE' => 2,
        'APPLY_JUST' => 3,
    );

    const ALL = 0;
    const SIGNUP = 1;

    const NEED_HOTEL_CONFIRM = array(
        'NO'  => 0,
        'YES' => 1,
    );
    const PRIORITY_SORT = array(
        'MONEY'      => 1,
        'PERCENT'    => 2,
        'SAME_PRICE' => 3,
        'HOURS'      => 4,
        'GIFT'       => 5,
    );
}

