<?php

namespace App\Constants;

class HotelProductType
{
    const STATUS = array(
        'INACTIVE' => 0,
        'ACTIVE'   => 1,
    );

    const TYPE_CALL = array(
        'IS_WEB' => 0,
        'IS_MOBILE'   => 1,
    );
}
