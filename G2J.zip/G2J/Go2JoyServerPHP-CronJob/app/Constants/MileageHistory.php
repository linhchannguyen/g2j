<?php

namespace App\Constants;

class MileageHistory
{
    const POINT_SIGNUP = 20000;

    const TYPE = array(
        'STOP' => 0,
        'ALL' => 0,
        'GET' => 1,
        'USE' => 2,
        'EXPIRED' => 3,
    );

    const TRANSFER_AUTO_INCREMENT_VALUE = 0;
}
