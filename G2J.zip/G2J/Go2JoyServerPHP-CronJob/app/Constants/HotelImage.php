<?php

namespace App\Constants;

class HotelImage
{
    const TYPE = array(
        'NORMAL' => 1,
        'EXIF'   => 2,
    );

    const FIRST_DISPLAY = array(
        'FALSE' => 0,
        'TRUE'  => 1,
    );

    const STATUS = array(
        'DELETED' => 0,
        'ACTIVE'  => 1,
    );
}
