<?php


namespace App\Constants;


class PaymentMailDetail
{
    const MSG = 'paymentMail';

    const STATUS = array(
        'NOT_SEND_YET'              =>0,
        'ERROR'                     =>1,
        'OK'                        =>2,
        'DONT_SEND'                 =>3,
        'SENT_WAITING_RESPONSE'     =>-1,
    );
}
