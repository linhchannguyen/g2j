<?php


namespace App\Constants;


class MileageReward
{
    const TEMP = 2;
    const ACTIVE = 1;
    const NUM_POINT_DEFAULT = 10;
    const MONEY_UNIT_DEFAULT = 1000;
    const COEFFICIENT_PAY_IN_ADVANCE = 2.0;
    const MONEY_UNIT_MP = 10000;

    const STATUS = array(
        'STOP'    => 0,
        'ACTIVE'  => 1,
        'TEMP'    => 2,
        'EXPIRED' => 3,
    );

    const TARGET_TYPE = array(
        'TARGET_ALL'            => 1,
        'TARGET_ALl_REJECT'     => 2,
        'TARGET_ALl_JUST_APPLY' => 3,
        'TARGET_PROVINCE'       => 4,
    );

    const TARGET_APPLY = array(
        'ALL_HOTEL'        => 1,
        'ALL_BUT_REJECT'   => 2,
        'SPECIFY_HOTEL'    => 3,
        'SPECIFY_PROVINCE' => 4,
    );
}
