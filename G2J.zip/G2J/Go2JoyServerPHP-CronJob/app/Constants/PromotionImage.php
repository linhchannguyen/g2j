<?php


namespace App\Constants;


class PromotionImage
{
    const TYPE = array(
        'HOME' => 1,
        'DETAIL' => 2,
    );

    const DISPLAY_LIST = 1;
}
