<?php


namespace App\Constants;


class BookingInstant
{
    const MSG = 'booking';
    const MAX_BOOKING = 2;
    const IDX = [1,2];
    const BOOKING_INSTANT_NOT_EXIST = 11;
    const HOTEL_EXIST = 12;
    const ROOM_TYPE_NOT_EXIST = 13;
}
