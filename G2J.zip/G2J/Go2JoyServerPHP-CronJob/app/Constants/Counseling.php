<?php

namespace App\Constants;

class Counseling
{
    const STATUS = array(
        'DELETED' => 0,
        'ACTIVE'  => 1,
    );

    const SCOPE = array(
        'PUBLIC'  => 1,
        'PRIVATE' => 2,
    );

    const QA_STATUS = array(
        'PENDING' =>  1,
        'ANSWER'  => 2,
    );

    const READ_STATUS = array(
        'USER_AND_STAFF_HAVE_READ_ALREADY' => 1,
        'ONLY_USER_HAS_READ_ALREADY_AND_STAFF_HAS_NOT_YET_READ' => 2,
        'ONLY_STAFF_HAS_READ_ALREADY_AND_USER_HAS_NOT_YET_READ' => 3,
    );
}
