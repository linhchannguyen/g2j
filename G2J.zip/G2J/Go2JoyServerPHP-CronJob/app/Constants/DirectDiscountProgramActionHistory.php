<?php

namespace App\Constants;

class DirectDiscountProgramActionHistory
{
    const ACTION_USER_TYPE = [
        'GO2JOY_STAFF' => 1,
        'HOTEL_STAFF'  => 2,
        'SYSTEM'       => 3,
    ];
    const ACTION_TYPE = [
        'CREATED'                => 1,
        'UPDATED'                => 2,
        'STOPPED'                => 3,
        'STOP_PARTICIPATED'      => 4,
        'EXPIRED'                => 5,
        'ROOM_STOP_PARTICIPATED' => 6,
    ];
}