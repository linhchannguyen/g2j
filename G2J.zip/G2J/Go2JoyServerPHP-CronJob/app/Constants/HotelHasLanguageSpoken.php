<?php

namespace App\Constants;

class HotelHasLanguageSpoken
{
    //
}
