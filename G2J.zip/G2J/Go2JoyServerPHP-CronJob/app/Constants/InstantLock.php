<?php

namespace App\Constants;

class InstantLock
{
    const NO_ROOM_LEFT = 0;
    const ONE_ROOM_LEFT = 1;
    const TWENTY_ROOM_LEFT = 20;
    const STATUS = array(
        'UNLOCK' => 0,
        'LOCK'   => 1,
    );
}