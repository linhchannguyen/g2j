<?php


namespace App\Constants;


class CouponForUserGroup
{
    const TYPE = array(
        'ALL' => 1,
        'ALL_BUT_EXCLUDE' => 2,
        'JUST_APPLY' => 3,
    );

    const TYPE_DETAIL = array(
        'ALL' => 0,
        'INPUT' => 1,
        'FILE_EXCEL' => 2,
        'NUM_CHECKIN' => 3,
        'SIGNUP_PERIOD' => 4,
        'LAST_OPEN_APP' => 5,
    );

    //error msg
    const MSG = 'couponForUserGroup';

    const ERR_USER_SN_LIST_EMP = 1;
    const ERR_FILE_EMP = 2;
    const ERR_START_LT_END = 3;
    const ERR_START_END_EMP = 4;
}
