<?php


namespace App\Constants;

class Popup
{
    const GO2JOY = 1;

    const DISPLAY = array(
        'ACTIVE' => 1,
        'INACTIVE' => 0,
    );

    const TYPE_OF_DISPLAY = array(
        'RANDOM' => 1,
        'CUSTOM' => 2,
        'BOTH' => 3,
    );

    const MSG = 'popup';
    const ERR_TITLE_EMP = 1;
    const ERR_PROVINCE_EMP = 2;
    const ERR_END_DATE_EXPERIED = 3;
    //
    const ERR_PLZ_CHOOSE_PROMOTION = 4;
    const ERR_PLZ_CHOOSE_HOTEL = 5;
    const ERR_PLZ_CHOOSE_NOITICE = 6;
    const ERR_PLZ_CHOOSE_AREA = 7;
    const ERR_PLZ_CHOOSE_PROMOTION_GROUP = 8;
    const ERR_PLZ_INPUT_LINK = 9;
}
