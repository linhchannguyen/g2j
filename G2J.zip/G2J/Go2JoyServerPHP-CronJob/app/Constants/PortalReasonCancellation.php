<?php

namespace App\Constants;

class PortalReasonCancellation
{
    const TYPE = array(
        'UNDEFINED' => 0,
        'NORMAL'    => 1,
        'SPECIAL'   => 2,
    );
}
