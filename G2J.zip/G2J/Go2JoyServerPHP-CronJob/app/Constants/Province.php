<?php

namespace App\Constants;

class Province
{
    const MSG = 'province';
    const ALL = -1;
    const PROVINCE_DEFAULT = 1;
    const PROVINCE_PROBLEM = -1;
    const DISTRICT_PROBLEM = -1;
    const REGIONS = array(
        'ALL'           => 0,
        'SOUTH'         => 1,
        'NORTH'         => 2,
        'CENTRAL'       => 3,
        'NORTH_CENTRAL' => 4,
        'SOUTH_CENTRAL' => 5,
    );
    const REGION_STR = array(
        '0' => '',
        '1' => 'South',
        '2' => 'North',
        '3' => 'Central',
        '4' => 'North central',
        '5' => 'South central',
    );
    const STATUS = array(
        'DISABLE' => 0,
        'ACTIVE'  => 1,
    );
    const EVENT_NAME = array(
        'HCM' => 'B6_3HoChiMinhProvince',
        'DNI' => 'B6_4DongNaiProvince',
        'BDU' => 'B6_5BinhDuongProvince',
        'BRV' => 'B6_6BaRiaVungTauProvince',
        'LAN' => 'B6_7LongAnProvince',
        'CTH' => 'B6_8CanThoProvince',
        'LDO' => 'B6_9LamDongProvince',
        'KHO' => 'B6_10KhanhHoaProvince',
        'KGI' => 'B6_11KienGiangProvince',
        'QNA' => 'B6_12QuangNamProvince',
        'DNA' => 'B6_13DaNangProvince',
        'NBI' => 'B6_14NinhBinhProvince',
        'HPH' => 'B6_15HaiPhongProvince',
        'HDU' => 'B6_16HaiDuongProvince',
        'HNI' => 'B6_17HaNoiProvince',
        'QNI' => 'B6_18QuangNinhProvince',
        'BNI' => 'B6_19BacNinhProvince',
        'TNG' => 'B6_20ThaiNguyenProvince',
        'LCA' => 'B6_21LaoCaiProvince',
        'VPH' => 'B6_22VinhPhucProvince',
    );
    const CODE_ADJUST = array(
        'HCM' => 'e6scs7',
        'DNI' => 'np0r6n',
        'BDU' => 'y93zjr',
        'BRV' => '9xezjm',
        'LAN' => 'ibdohl',
        'CTH' => 'y4r0v8',
        'LDO' => 'dekt6c',
        'KHO' => '3pmsia',
        'KGI' => 'fxrof0',
        'QNA' => '7s0698',
        'DNA' => '8t8rdp',
        'NBI' => '5astth',
        'HPH' => 's5iil4',
        'HDU' => 'fuolu4',
        'HNI' => '4q30ik',
        'QNI' => '4f44vp',
        'BNI' => 'r9kng2',
        'TNG' => 'ksm1mx',
        'LCA' => 'r52lio',
        'VPH' => 'g3tgxu',
    );
}
