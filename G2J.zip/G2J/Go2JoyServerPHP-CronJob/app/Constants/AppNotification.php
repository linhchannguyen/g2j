<?php

namespace App\Constants;

class AppNotification
{
    const FILTER_NONE = 0;
    const LAST_TIME_OPEN_APP = 1;
    const EMPTY = "";
    const STATUS = array(
        'ALL'     => 0,
        'DRAFT'   => 1,
        'CREATED' => 2,
        'RUNNING' => 3,
        'SENT'    => 4,
    );
    const TYPE = array(
        'ALL'    => 0,
        'NORMAL' => 1,
        'DONATE' => 2,
        'REMIND' => 3,
    );
    //1. All User, 2. Test Group, 3. All Partner, 4:Booking, 5:Favorite Hotel Area
    const SEND_TO = array(
        'NONE'           => 0,
        'ALL_USER'       => 1,
        'GO2JOY'         => 2,
        'ALL_PARTNER'    => 3,
        'ALL_TRIAL'      => 6,
        'ALL_CONTRACTED' => 7,
        'VIA_FILE'       => 8,
        'CRM_FILTER'     => 9,
        'USER'           => 10,
    );
    const SEND_VIA = array(
        'SEND_TO_ALL'    => 1,
        'SEND_TO_AREA'   => 2,
        'SEND_TO_HOTEL'  => 3,
        'SEND_TO_NUMBER' => 4,
        'SEND_TO_USER'   => 5,
        'SEND_VIA_FILE'  => 7,
    );
    const TARGET = array(
        'APP_NOTICE'       => 1,
        'PROMOTION'        => 2,
        'AP'               => 3,
        'HOTEL_AREA'       => 4,
        'FAQ'              => 5,
        'INVITE_FRIEND'    => 6,
        'OPEN_APP'         => 7,
        'MP'               => 8,
        'DIRECT_DISCOUNT'  => 9,
        'SIGNUP'           => 10,
        'PROMOTION_GROUP'  => 11,
        'AMENITY_PACK'     => 14,
        'G2J_CERTIFIED'    => 13,
        'TET'              => 105,
        'REFERRAL_PROGRAM' => 106,
    );
    const SEND_NOTIFICATION_FLAG = array (
        'NO'  => 0,
        'YES' => 1
    );
}
