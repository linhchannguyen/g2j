<?php

namespace App\Constants;

class DirectDiscountProgramRoomType
{
    const STATUS = array(
        'AVAILABLE'   => 1,
        'UNAVAILABLE' => 2,
        'PENDING'     => 3,
    );
}