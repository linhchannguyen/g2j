<?php

namespace App\Constants;

class Permission
{
    const NO_PERMISSION = 0;
    const HAS_PERMISSION = 1;
}
