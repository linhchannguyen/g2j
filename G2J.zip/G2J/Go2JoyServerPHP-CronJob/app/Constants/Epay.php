<?php


namespace App\Constants;


class Epay
{
    const RETURN_CODE = array(
        'SUCCESS'    => '00_000',
        'PROCESSING' => '99',
    );

    const STATUS = array(
        'FAIL'  => '-3',
        'PROCESSING' => '-2',
        'NOT_FOUND'  => '-1',
        'SUCCESS' => '0',
        'REFUNDED' => '2',
    );
}