<?php


namespace App\Constants;


class CrmFilter
{
    const STATUS = array(
        'ACTIVE' => 1,
        'INACTIVE' => 2,
    );

    const OPERATOR = array(
        'AND' => 1,
        'OR' => 2,
    );

    const OPERATOR_STR = array(
        1 => 'AND',
        2 => 'OR',
    );

    const COL_SUMMARY_DISCOUNT_REPORT = array(
        'RANGE_NAME' => 1,
        'COUNT_DISCOUNT' => 2,
        'AVG_TOTAL_AMOUNT' => 3,
        'AVG_DISCOUNT' => 4,
        'AVG_COMMISSION' => 5,
    );

    const SEND_MESSAGE = array(
        'SMS' => 1,
        'MAIL' => 2,
    );

}
