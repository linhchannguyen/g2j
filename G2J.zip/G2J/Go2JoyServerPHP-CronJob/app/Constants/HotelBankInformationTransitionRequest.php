<?php

namespace App\Constants;

class HotelBankInformationTransitionRequest
{
    const STATUS = array(
        'WAITING'   => 1,
        'CONFIRMED' => 2,
        'REJECTED'  => 3,
    );
}
