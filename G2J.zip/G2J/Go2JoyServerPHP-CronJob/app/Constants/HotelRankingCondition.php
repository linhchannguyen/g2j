<?php

namespace App\Constants;

class HotelRankingCondition
{
    const COLLECTION_TYPE = array(
        'NEAR_YOU'                 => 1,
        'BOOKING_TYPE_HOURLY'      => 2,
        'BOOKING_TYPE_OVERNIGHT'   => 3,
        'BOOKING_TYPE_DAILY'       => 4,
        'COLLECTION_COUPLE_HOTELS' => 5,
        'COLLECTION_TRAVEL_HOTELS' => 6,
    );
    const PRIORITY = array(
        'NUM_1' => 1,
        'NUM_2' => 2,
        'NUM_3' => 3,
        'NUM_4' => 4,
        'NUM_5' => 5,
    );
    const MAX_DISTANCE_METERS = 25000;
}
