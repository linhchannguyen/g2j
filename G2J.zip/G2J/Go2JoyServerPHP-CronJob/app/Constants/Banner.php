<?php

namespace App\Constants;

class Banner
{
    const ALL = -1;
    const VIEW = array(
        'PROMOTION'           => 1,
        'INVITE_FRIEND'       => 2,
        'EVENT'               => 3,
        'HOTEL'               => 4,
        'NOTICE'              => 5,
        'LINK'                => 6,
        'AREA'                => 7,
        'MILEAGE_POINT'       => 8,
        'COUPON'              => 9,
        'DIRECT_DISCOUNT'     => 10,
        'PROMOTION_GROUP'     => 11,
        'AMENITY_PACK_HOTEL'  => 12,
        'G2J_CERTIFIED_HOTEL' => 13,
        'LINK_IN_APP'         => 61, // Sync with view LINK
        'IMAGE_ADS'           => 107,

    );
    const TARGET = array(
        'PROMOTION'           => 1,
        'HOTEL'               => 2,
        'NOTICE'              => 3,
        'LINK'                => 4,
        'AREA'                => 5,
        'MP'                  => 6,
        'COUPON'              => 7,
        'DIRECT_DISCOUNT'     => 8,
        'INVITE_FRIEND'       => 9,
        'PROMOTION_GROUP'     => 10,
        'AMENITY_PACK_HOTEL'  => 12,
        'G2J_CERTIFIED_HOTEL' => 13,
        'LINK_IN_APP'         => 61, // Sync with view LINK
        'IMAGE_ADS'           => 107,

    );
    const DISPLAY = array(
        'INACTIVE' => 0,
        'ACTIVE'   => 1,
    );
    const FIRST_DISPLAY = array(
        'FALSE' => 0,
        'TRUE'  => 1,
    );
    const TYPE_OF_DISPLAY = array(
        'RANDOM' => 1,
        'CUSTOM' => 2,
    );
    const TYPE = array(
        'APP'         => 1,
        'WEB'         => 2,
        'HOTEL_ADMIN' => 3,
    );
    const MSG = 'banner';
    const ERR_END_DATE_EXPERIED = 1;
    const ERR_PLZ_CHOOSE_PROMOTION = 2;
    const ERR_PLZ_CHOOSE_HOTEL = 3;
    const ERR_PLZ_CHOOSE_NOITICE = 4;
    const ERR_PLZ_CHOOSE_AREA = 5;
    const ERR_PLZ_CHOOSE_PROMOTION_GROUP = 6;
    const ERR_PLZ_INPUT_LINK = 7;
    const ERR_TITLE_EMP = 8;
    const ERR_PROVINCE_EMP = 9;
    const ERR_IMAGE_ADS_EMP = 10;
}
