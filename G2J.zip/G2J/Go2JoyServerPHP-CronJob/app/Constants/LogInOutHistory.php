<?php

namespace App\Constants;

class LogInOutHistory
{
    const STATUS = array(
        'LOG-OUT-USER' => 0,
        'LOG-IN'       => 1,
        'LOG-OUT-SYS'  => 2,
    );
}
