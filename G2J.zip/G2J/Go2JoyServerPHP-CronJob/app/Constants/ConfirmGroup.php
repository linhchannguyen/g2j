<?php


namespace App\Constants;


class ConfirmGroup
{
    const LEVEL = array(
        'LEVEL_0' => 0,
        'LEVEL_1' => 1,
        'LEVEL_2' => 2,
    );

    const TYPE = array(
        'PROMOTION'        => 1,
        'INVITE_FRIEND'    => 2,
        'PRODUCT'          => 3,
        'TRANSFER_BOOKING' => 4,
        'BOOKING_STATUS'   => 5,
        'USER_STATUS'      => 6,
        'CORRELATED_HOTEL' => 7,
    );

    const CONFIRM = array(
        'VIEW' => 0,
        'CONFIRM' => 1,
    );

    const ALL_CONFIRM = array(
        'ONE_CONFIRM' => 0,
        'ALL_CONFIRM' => 1,
    );

    const MSG = 'confirmGroup';

    const ERR_STAFF_EXISTS_ON_FUNC = 1;
}
