<?php

namespace App\Constants;

class FlashSale
{
    const HASHTAG_NOTI = array(
        'HOTEL_NAME'=>'#hotelName',
        'USER_NAME'=>'#userName',
        'NUM_OF_ROOM'=>'#numOfRoom',
        'PERCENT'=>'#percent',
        'CHECK_IN_TIME'=>'#checkinTime',
        'PROMOTION_NAME'=>'#promotionName',
    );

    const STATUS = array(
        'INACTIVE' => 0,
        'ACTIVE'   => 1,
        'PENDING'  => 2,
    );
}
