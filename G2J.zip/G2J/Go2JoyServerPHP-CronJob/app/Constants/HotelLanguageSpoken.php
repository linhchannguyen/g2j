<?php

namespace App\Constants;

class HotelLanguageSpoken
{
    const ORIGIN = array(
        'GO2JOY' => 1,
        'AGODA'  => 2,
    );

    const STATUS = array(
        'DELETED' => 0,
        'ACTIVE'  => 1,
    );
}
