<?php

namespace App\Constants;

class AmplitudeChangeUserBookingStatus
{
    const SEND = array(
        'NO'   => 0,
        'YES'  => 1,
    );
}
