<?php

namespace App\Constants;

class LogSyncSearchingEngine
{
    const STATUS = array(
        'NOT_YET_SYNC' => 0,
        'SYNCED'       => 1,
        'ERROR_SYNC'   => 2,
    );

    const ACTION_TYPE = array(
        'INSERT' => 1,
        'UPDATE' => 2,
        'DELETE' => 3,
    );
}
