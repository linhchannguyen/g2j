<?php

namespace App\Constants;

class HotelDebtDetail
{
    const STATUS = array(
        'NOT_CONFIRMED_YET'    => 0,
        'CONFIRMED'            => 1,
        'REPORTING'            => 2,
        'GO2JOY_HAS_PROCESSED' => 3,
    );
    const REPORTING_TYPE = array(
        'WRONG_BOOKING_INFO' => 1,
        'NO_SHOW' => 2,
    );
}
