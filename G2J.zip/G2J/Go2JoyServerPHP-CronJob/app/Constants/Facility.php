<?php

namespace App\Constants;

class Facility
{
    const STATUS = array(
        'DELETED' => 0,
        'ACTIVE'  => 1,
    );

    const ORIGIN = array(
        'GO2JOY' => 1,
        'AGODA'  => 2,
    );

    const ERR_NAME_EXIST = 1;
    const LINK_DEFAULT = "facility/facility_default.png";
}
