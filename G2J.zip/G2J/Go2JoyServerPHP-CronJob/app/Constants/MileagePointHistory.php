<?php

namespace App\Constants;

class MileagePointHistory
{
    const TYPE_PROGRAM = array(
        'BOOKING'   => 1,
        'REWARD'    => 2,
        'REFERRAL'  => 3,
        'MINI_GAME' => 4,
        'DONATE'    => 5,
    );
    const STATUS = array(
        'ACTIVE'         => 1,
        'USED'           => 2,
        'EXPIRED'        => 3,
        'WITHDRAW'       => 4,
        'PENDING_REWARD' => 5,
        'PENDING_REFUND' => 6,
        'REFUNDED'       => 7,
    );
    const FILTER_STATUS = array(
        'ALL'        => 1,
        'EARNED'     => 2,
        'USED'       => 3,
        'EXPIRED'    => 4,
        'PROCESSING' => 5,
        'PROCESSED'  => 6,
    );
    const DONATE_PROGRAM_NAME = 'Go2Joy';
}
