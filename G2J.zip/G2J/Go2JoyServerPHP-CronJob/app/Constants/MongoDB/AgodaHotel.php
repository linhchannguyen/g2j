<?php

namespace App\Constants\MongoDB;

class AgodaHotel
{
    const STATUS = [
        'INACTIVE' => 0,
        'ACTIVE'   => 1,
    ];
}