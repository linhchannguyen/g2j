<?php

namespace App\Constants\MongoDB;

class AgodaFacility
{
    const STATUS = [
        'INACTIVE' => 0,
        'ACTIVE'   => 1,
    ];
}