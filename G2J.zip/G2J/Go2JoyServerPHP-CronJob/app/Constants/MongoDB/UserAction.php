<?php

namespace App\Constants\MongoDB;

class UserAction
{
    const IS_SNAPSHOT = [
        'TRUE' => 1,
        'FALSE' => 0,
    ];

    const PROJECT = [
        'MOBILE'      => 1,
        'WEB'         => 2,
        'WEBBOOKING'  => 3,
    ];

    const OS = [
        'IOS'     => 1,
        'ANDROID' => 2,
    ];

    const EVENT = [
        'VIEW_HOTEL_DETAIL'     => 1,
        'VIEW_PROMOTION_DETAIL' => 2,
        'VIEW_GO2JOY_MALL'      => 3
    ];

    const VIEW_GO2JOY_MENU = [
        'GO2JOY_MALL' => 1
    ];

    const EVENT_MAPPING = [
        'VIEW_HOTEL_DETAIL'     => [
            '/api/v4/mobile/hotel/getHotelDetail',
        ],
        'VIEW_PROMOTION_DETAIL' => [
            '/api/v3/mobile/reward/getPromotionDetail',
        ],
        'VIEW_GO2JOY_MALL' => [
            '/api/v2/web/ha/home-hotel/viewGo2Joy',
        ],
    ];
}