<?php

namespace App\Constants\MongoDB;

class LogExternalCallback
{
    const SERVICE = [
        'PAYMENT' => 1,
        'MAIL'    => 2,
        'SMS'     => 3,
    ];

    const PAYMENT_PROVIDER = [
        'ONE_PAY'  => 1,
        'PAYOO'    => 2,
        'MOMO'     => 3,
        'EPAY'     => 4,
        'SHOPEE_PAY'  => 5,
        'ZALO_PAY' => 6,
    ];
}