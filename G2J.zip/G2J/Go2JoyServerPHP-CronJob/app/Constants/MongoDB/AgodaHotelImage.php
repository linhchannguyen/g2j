<?php

namespace App\Constants\MongoDB;

class AgodaHotelImage
{
    const STATUS = [
        'INACTIVE' => 0,
        'ACTIVE'   => 1,
    ];
}