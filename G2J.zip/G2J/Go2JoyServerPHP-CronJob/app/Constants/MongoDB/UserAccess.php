<?php

namespace App\Constants\MongoDB;

class UserAccess
{
    const IS_SNAPSHOT = [
        'TRUE' => 1,
        'FALSE' => 0,
    ];
}