<?php

namespace App\Constants\MongoDB;

class LogExternalPaymentAPI
{
    const PAYMENT_PROVIDER = [
        'ONE_PAY'  => 1,
        'PAYOO'    => 2,
        'MOMO'     => 3,
        'EPAY'     => 4,
        'SHOPEE_PAY'  => 5,
        'ZALO_PAY' => 60,
    ];
}