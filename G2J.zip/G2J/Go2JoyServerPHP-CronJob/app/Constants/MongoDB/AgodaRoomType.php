<?php

namespace App\Constants\MongoDB;

class AgodaRoomType
{
    const STATUS = [
        'INACTIVE' => 0,
        'ACTIVE'   => 1,
    ];
}