<?php

namespace App\Constants;

class HotelBusinessInformation
{
    const BUSINESS_TYPE = array(
        'VN_ORGANIZATION' => 1,
        'VN_BUSINESS_INDIVIDUALS' => 2,
    );

    const BUSINESS_TYPE_STRING = array(
        1 => "Tổ chức Việt Nam (Mã 01)",
        2 => "Cá nhân kinh doanh VN (Mã 02)",
    );

    const TYPE_CARD = array(
        'CMND' => 1,
        'CCCD' => 2,
        'PASSPORT' => 3,
    );

    const TYPE_CARD_STRING = array(
        1 => "CMND",
        2 => "CCCD",
        3 => "Hộ chiếu",
    );
}
