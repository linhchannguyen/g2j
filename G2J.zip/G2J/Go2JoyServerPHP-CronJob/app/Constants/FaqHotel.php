<?php


namespace App\Constants;


class FaqHotel
{
    const ANSWER = array(
        'ANSWER_STATUS_FINISH' => 0,
	    'ANSWER_STATUS_SA_NOT' => 1,
        'ANSWER_STATUS_HA_NOT' => 2,
    );
}
