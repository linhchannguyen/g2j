<?php

namespace App\Constants;

class Country
{
    // Default country sn
    const VIETNAM = 1;
}
