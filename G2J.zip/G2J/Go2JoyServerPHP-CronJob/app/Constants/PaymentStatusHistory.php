<?php

namespace App\Constants;

class PaymentStatusHistory
{
    const PAYMENT_STATUS = [
        'AWAITING'   => 0,
        'SUCCESSFUL' => 1,
        'FAILED'     => 2,
        'REFUNDED'   => 3,
    ];
}