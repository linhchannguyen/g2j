<?php

namespace App\Constants;

class IssueCondition
{
    const APPLY_TO_USER = array(
        'ALL'                   => 0,
        'SIGNUP'                => 1,
        'NOT_YET_CHECKIN_ALL'   => 2,
        'NOT_YET_CHECKIN_HOTEL' => 3,
    );
    const COUPON = array(
        'NO_SELECT' => 0,
        'NO_USE'    => 1,
        'USE'       => 2,
    );
    const APPLY_TARGET = array(
        'ALL'             => 1,
        'ALL_BUT_EXCLUDE' => 2,
        'JUST_APPLY'      => 3,
    );
    const PAYMENT = array(
        'ALL'            => 0,
        'PAY_IN_ADVANCE' => 1,
        'PAY_AT_HOTEL'   => 2,
    );
}
