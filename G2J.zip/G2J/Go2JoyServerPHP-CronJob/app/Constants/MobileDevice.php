<?php

namespace App\Constants;

class MobileDevice
{
    const PUSH_NOTIFICATION = 1;
    const STATUS = 1;
    const PREFIX_ANDROID = 'AND';
    const PREFIX_IOS = 'IOS';
    const OS = array(
        'IOS'     => 1,
        'ANDROID' => 2,
        'WEB'     => 3,
    );
    const OS_STR = array(
        1 => 'iOS',
        2 => 'Android',
        3 => 'Web',
    );
    const LANGUAGE = array(
        'KOREAN'     => 1,
        'ENGLISH'    => 2,
        'VIETNAMESE' => 3,
    );
    const LANGUAGE_STR = array(
        1 => 'KOREAN',
        2 => 'ENGLISH',
        3 => 'VIETNAMESE',
    );
    const USER_ACCESS = array(
        'SPLASH_SCREEN' => 1,
        'BACKGROUND'    => 2,
        'NEAR_YOU'      => 3,
        'SETTING'       => 4,
    );

    const SOURCE = array(
        'UNDEFINED'             => 0,
        'ORGANIC'               => 1,
        'ADCASH'                => 2,
        'ADGATE_MEDIA'          => 3,
        'AMBIENT'               => 4,
        'APPIER'                => 5,
        'APP_SAMURAI'           => 6,
        'APPNEXT'               => 7,
        'AWING'                 => 8,
        'DABLE'                 => 9,
        'FACEBOOK'              => 10,
        'GOOGLE_ADS'            => 11,
        'GOOGLE_ORGANIC_SEARCH' => 12,
        'INSTAGRAM'             => 13,
        'MOLOCO'                => 14,
        'OFFLINE'               => 15,
        'ACCESSTRADE'           => 16,
        'SMS_MESSAGE'           => 17,
        'TIKTOK'                => 18,
        'ZALO'                  => 19,
        'ZOOMD'                 => 20,
        'NEWSPAPER'             => 21,
        'UNATTRIBUTED'          => 22,
        'UNTRUSTED_DEVICES'     => 23,
        'MOMO'                  => 28,
    );
    const MSG = 'mobile';
    const VIEW_HOTEL_DETAIL = 1;
    const VIEW_ROOM_DETAIL = 2;//from mobile
    const VIEW_HOTEL_IMAGE = 3;//from mobile
    const VIEW_HOTEL_INFO = 4;// from mobile
    const VIEW_HOTEL_REVIEW = 5;//from server and mobile
    const VIEW_HOTEL_ON_MAP = 6;//click at marker on map
    const VIEW_PROMOTION_MENU = 7;//from mobile
    const BOOK_FROM_HOTEL_DETAIL = 8;//from mobile
    const BOOK_FROM_ROOM_DETAIL = 9;//from mobile
    const BOOK_FROM_INFO_TAB = 10;//from mobile
    const VIEW_HOTEL_FS = 11;//from mobile
    const VIEW_PROMOTION_BANNER = 12;//view promotion from banner
    const VIEW_PROMOTION_POPUP = 13;//view promotion from popup
    const GET_COUPON_POPUP = 14;//from mobile
    const GET_COUPON_MENU = 15;//from mobile
    const VIEW_POPUP = 16;//from mobile
    const VIEW_BANNER = 17;//from mobile
    const BOOK_FROM_REVIEW = 18;//from mobile
    const BOOK_FROM_REVIEW_DETAIL = 19;//from mobile
    const VIEW_PROMOTION_NOTIFICATION = 20;//from mobile
    const GET_COUPON_RESERVATION = 21;//from mobile
    const GET_COUPON_MY_COUPON = 22;//from mobile
    const VIEW_PROMOTION_RESERVATION = 23;//from mobile
    const VIEW_PROMOTION_MY_COUPON = 24;//from mobile
    const GET_COUPON_NOTIFICATION = 25;//from mobile
    const GET_COUPON_BANNER = 26;//from mobile
    const BOOK_INTSTANT_FROM_NOW = 27;
    const CHANGE_BOOK_FROM_INTSTANT = 28;//from mobile
    const VIEW_HOTEL_REVIEW_DETAIL = 29;//from server and mobile
    const BOOK_CHANGE_TAB_OVERNIGHT = 30;//from server and mobile
    const BOOK_INTSTANT_OK_FROM_NOW = 31;//from server and mobile
    const VIEW_BANNER_DETAIL = 32;
    const VIEW_POPUP_DETAIL = 33;
    const VIEW_NOTICE_DETAIL_MENU = 34;
    const SHARE_HOTEL = 35;//from mobile
    const VIEW_NOTICE_DETAIL_HOME = 36;//from mobile
    const VIEW_ALL_COLLECTION = 37;//from mobile
    const VIEW_NEARBY = 38;//from mobile
    const VIEW_LAST_AREA = 39;//from mobile
    const VIEW_LOVEL_HOTEL = 40;//from mobile
    const VIEW_TRAVEL_HOTEL = 41;//from mobile
    const VIEW_AREA_FILTER = 42;//from mobile
    const CLICK_CALL_HOTEL = 43;//from mobile
    const BOOKING_NOW_DISPLAY_HOTEL = 44;//from mobile
    const VIEW_TOP_HOTEL_DETAIL = 45;
    const VIEW_TOP_HOTEL_MAP = 46;//from mobile
    const VIEW_HOTEL_FROM_COLLECTION = 47;//from mobile
    /////===========================

}
