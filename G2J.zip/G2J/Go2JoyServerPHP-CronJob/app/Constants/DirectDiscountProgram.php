<?php

namespace App\Constants;

class DirectDiscountProgram
{
    const LIMIT_SPECIAL_DATE = 30;
    const LIMIT_HOTEL = 100;
    
    const STATUS = array(
        'ALL'     => 0,
        'RUNNING' => 1,
        'STOPPED' => 2,
        'EXPIRED' => 3,
        'DRAFT'   => 4,
    );
    const IMPORT_TYPE = array(
        'MANUAL' => 1,
        'FILE'   => 2,
    );
    const TYPE_APPLY = array(
        'DAY_OF_WEEK'  => 1,
        'SPECIAL_DAYS' => 2,
    );
    const TYPE_SETUP = array(
        'ALL' => 1,
        'ONE' => 2,
    );
    const CREATE_NAME = array(
        'GO2JOY' => 'Go2Joy',
    );
    const ACTION_USER_TYPE = [
        'GO2JOY_STAFF' => 1,
        'HOTEL_STAFF'  => 2,
        'SYSTEM'       => 3,
    ];
}