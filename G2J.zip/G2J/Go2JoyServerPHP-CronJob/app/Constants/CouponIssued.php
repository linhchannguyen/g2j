<?php

namespace App\Constants;

class CouponIssued
{
    const USED = array(
        'ALL'           => -1,
        'NOT_YET'       => 0,
        'NOT_YET_APPLY' => 4,
        'USED'          => 1,
        'EXPIRED'       => 2, // Just update when used = 0
        'TEMP'          => 3,
    );
    const DONATE_TYPE = array(
        'MANUAL' => 1,
        'FILE'   => 2,
        'SIGNUP' => 3,
        'CRM'    => 4,
    );
    const TYPE = array(
        'APPLY'  => 1,
        'ISSUED' => 2,
        'USED'   => 3,
    );
    const CAN_USE_STATUS = array(
        'CAN_USE'     => 1,
        'CAN_APPLY'   => 2,
        'CAN_NOT_USE' => 3,
    );
    const FILTER_TYPE = array(
        'NEW'  => 1,
        'USED' => 2,
    );
    const CAN_USE = 1;
    const HOTEL_NOT_ACCEPT = 2;
    const ROOM_NOT_ACCEPT = 2;
    const NOT_ENOUGH_USE = 3;
    const CAN_NOT_USE = 4;
    const ENOUGH_HOTEL = 5;
    const ROOM_PRICE_LT_PROMOTION = 6;
}
