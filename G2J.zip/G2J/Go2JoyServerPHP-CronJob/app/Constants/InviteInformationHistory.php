<?php

namespace App\Constants;

class InviteInformationHistory
{
    const STATUS = array(
        'EDIT' => 1,
        'TEMP' => 2,
        'USED' => 3,
    );
}