<?php

namespace App\Constants;

class FaqInformation
{
    const ALLOW_ANSWER = 1;
    const STATUS_AVAILABLE = 1;
    const STATUS = array(
        'NOT_YET_ACTIVE' => 0,
        'ACTIVE'         => 1,

    );
    const HOTEL_SCOPE = array(
        'STATUS_ALL'        => 1,
        'STATUS_CONTRACTED' => 2,
        'STATUS_TRIAL'      => 3,
        'SPECIFY_HOTEL'     => 4,
    );
    const TYPE = array(
        'TYPE_FUNCTION'        => 1,
        'TYPE_PROMOTION'       => 2,
        'TYPE_POLICY'          => 3,
        'TYPE_NOTIFICATION'    => 4,
        'TYPE_NOTICE_NOSHOW'   => 5,
        'TYPE_NOTICE_CHECKINL' => 6,
    );
    const MSG = 'faqInformation';
    const FILTER_UNREAD = 0;
}
