<?php

namespace App\Constants;

class MileagePointTransactionHistory
{
    const TYPE_PROGRAM = array(
        'BOOKING'   => 1,
        'REWARD'    => 2,
        'REFERRAL'  => 3,
        'MINI_GAME' => 4,
        'DONATE'    => 5,
        'ADJUSTING' => 6,
    );

    const STATUS = array(
        'ACTIVE'          => 1,
        'USED'            => 2,
        'EXPIRED'         => 3,
        'WITHDRAW_REWARD' => 4,
        'PENDING_REWARD'  => 5,
        'PENDING_REFUND'  => 6,
        'REFUNDED'        => 7,
        'WITHDRAW_REFUND' => 8,
    );
}
