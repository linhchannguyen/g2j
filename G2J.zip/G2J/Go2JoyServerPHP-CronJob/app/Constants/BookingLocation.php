<?php


namespace App\Constants;


class BookingLocation
{
    const TYPE = array(
        'BOOKING' => 1,
        'CHECKIN' => 2,
    );
}