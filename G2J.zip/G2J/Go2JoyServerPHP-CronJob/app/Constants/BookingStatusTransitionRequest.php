<?php

namespace App\Constants;

class BookingStatusTransitionRequest
{
    const STATUS = array(
        'WAITING'   => 1,
        'CONFIRMED' => 2,
        'REJECTED'  => 3,
    );
}
