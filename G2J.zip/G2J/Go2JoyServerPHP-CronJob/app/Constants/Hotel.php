<?php

namespace App\Constants;

class Hotel
{
    /** To determine which is the account of Go2Joy **/
    const HOTEL_ALL = 0;
    const GO2JOY = 1;
    /** This is sn of "+" hotel for testing */
    const TESTING_HOTEL = 467;
    /** Default commission */
    const COMMISSION = 16.5;
    /** Hotel for test*/
    const HOTEL_EXCLUDE = 467;
    const PAYMENT_OPTION = array(
        'BOTH'              => 1,
        'JUST_PAY_AT_HOTEL' => 2,
        'JUST_PAY_ONLINE'   => 3,
    );
    const STATUS = array(
        'NO_STATUS'  => 0, // Only for Go2Joy
        'WAITING'    => 1,
        'DISPLAYED'  => 2,
        'CONTRACTED' => 3,
        'TRIAL'      => 4,
        'TERMINATED' => 5,
        'SUSPENDED'  => 6,
    );
    const STATUS_STR = array(
        0 => 'NO_STATUS', // Only for Go2Joy
        1 => 'WAITING',
        2 => 'DISPLAYED',
        3 => 'CONTRACTED',
        4 => 'TRIAL',
        5 => 'TERMINATED',
        6 => 'SUSPENDED',
    );
    const TYPE = array(
        'HOTEL'                        => 1,  // Khách sạn
        'KARAOKE'                      => 2,  // Karaoke
        'RESORT_VILLA'                 => 3,  // Biệt thự nghỉ dưỡng
        'SERVICED_APARTMENT'           => 4,  // Căn hộ dịch vụ
        'HOMESTAY'                     => 5,  // Homestay
        'CAPSULE_HOTEL'                => 6,  // Khách sạn con nhộng
        'GUESTHOUSE/BED_AND_BREAKFAST' => 7,  // Nhà khách / Nhà nghỉ B&B
        'HOSTEL'                       => 8,  // Nhà nghỉ
        'RESORT'                       => 9,  // Resort
        'ENTIRE_APARTMENT'             => 10, // Toàn bộ căn hộ
        'G2J_ROOM'                     => 11, // Khách sạn chỉ có trên app G2J
    );
    const STYLE = array(
        'NONE'           => 0,
        'COUPLES'        => 1,
        'TRAVEL'         => 2,
        'COUPLES_TRAVEL' => 3,
        'QUARANTINE'     => 4,
    );
    const STYLE_STR = array(
        0 => 'NONE',
        1 => 'COUPLES',
        2 => 'TRAVEL',
        3 => 'COUPLES_TRAVEL',
        4 => 'QUARANTINE',
    );
    const FIRST_DISPLAY = array(
        'FALSE' => 0,
        'TRUE'  => 1,
    );
    const ROOM_AVAILABLE = array(
        'NOT_AVAILABLE' => 0,
        'AVAILABLE'     => 1,
        'SUSPENDED'     => 2,
    );
    const HOT_HOTEL = array(
        'NORMAL' => 0,
        'HOT'    => 1,
    );
    const NEW_HOTEL = array(
        'OLD' => 0,
        'NEW' => 1,
    );
    const G2J_CERTIFIED = array(
        'NO'  => 0,
        'YES' => 1,
    );
    const AMENITY_PACK = array(
        'NO'  => 0,
        'YES' => 1,
    );
    const DISPLAY = array(
        'HIDE'    => 0,
        'DISPLAY' => 1,
    );
    const ALLOW_EXTRA_FEE = array(
        'NOT_ALLOW' => 0,
        'ALLOW'     => 1,
    );
    const NEW_CONTRACTED_TYPE = array(
        'NONE'                => 0,
        'TYPE_1'              => 1,
        'TYPE_2'              => 2,
        'TYPE_3'              => 3,
        'TYPE_4_RECONTRACTED' => 4,
        'TYPE_GO2JOY_ROOM'    => 5,
    );
    const INCENTIVE = array(
        'NEW_CONTRACT'              => [
            'TYPE_1'              => [
                'STAGE_1' => 600000,
                'STAGE_2' => 400000,
            ],
            'TYPE_2'              => [
                'STAGE_1' => 300000,
                'STAGE_2' => 200000,
            ],
            'TYPE_3'              => [
                'STAGE_1' => 100000,
            ],
            'TYPE_4_RECONTRACTED' => [
                'STAGE_1' => 0,
            ],
            'TYPE_GO2JOY_ROOM'    => [
                'STAGE_1' => 0,
            ],
        ],
        'STAMP'                     => 100000,
        'HOTEL_OWN_PROMOTION'       => 0.3,
        'CO_PROMOTION'              => [
            'FROM_10_TO_49_CHECKIN_EACH_MONTH'         => 50000,
            'GREATER_THAN_EQUAL_50_CHECKIN_EACH_MONTH' => 100000,
        ],
        'NEW_HOTEL_CHECK_IN_AMOUNT' => 0.3,
    );
    const CONDITION_FOR_CALCULATE_INCENTIVE_FOR_HOTEL_CONTRACTED = array(
        'NEW_CONTRACT'              => [
            'TYPE_1'              => [
                'STAGE_1' => [
                    'MONTH_RANGE' => 0,
                ],
                'STAGE_2' => [
                    'MONTH_RANGE' => 6,
                ],
            ],
            'TYPE_2'              => [
                'STAGE_1' => [
                    'MONTH_RANGE' => 1,
                ],
                'STAGE_2' => [
                    'MONTH_RANGE' => 6,
                ],
            ],
            'TYPE_3'              => [
                'STAGE_1' => [
                    'MONTH_RANGE' => 1,
                ],
            ],
            'TYPE_4_RECONTRACTED' => [
                'STAGE_1' => [
                    'MONTH_RANGE' => 1,
                ],
            ],
            'TYPE_GO2JOY_ROOM'    => [
                'STAGE_1' => [
                    'MONTH_RANGE' => 1,
                ],
            ],
        ],
        'STAMP'                     => [
            'MONTH_RANGE' => 1,
        ],
        'HOTEL_OWN_PROMOTION'       => [
            'NUMBER_OF_MONTHS' => 6,
            'MONTH_RANGE'      => 1,
        ],
        'CO_PROMOTION'              => [
            'MONTH_RANGE' => 1,
        ],
        'NEW_HOTEL_CHECK_IN_AMOUNT' => [
            'NUMBER_OF_MONTHS' => 6,
            'MONTH_RANGE'      => 1,
        ],
    );
    const SORT = array(
        'NAME'         => 0,
        'NUM_CHECKIN'  => 1,
        'TOTAL_AMOUNT' => 2,
        'NUM_BOOKING'  => 3,
    );
    const SORT_SEARCH = array(
        'NONE'                     => 0,
        'DISTANCE'                 => 1,
        'PRICE_INCREASING'         => 2,
        'PRICE_DECREASING'         => 3,
        'RATING & REVIEW OF HOTEL' => 4,
        //        'POPULARITY'               => 5,
    );
    const OLD_SORT_SEARCH = array(
        'PRICE_INCREASING'         => 1,
        'PRICE_DECREASING'         => 2,
        'RATING & REVIEW OF HOTEL' => 3,
    );
    const HOME_SEARCH = array(
        'NONE'     => 0,
        'NEAR_YOU' => 1,
    );
    const FILTER_PROMOTION = array(
        'NONE'            => 0,
        'FLASH_SALE'      => 1,
        'SPECIAL_OFFER'   => 2,
        'PROMOTION'       => 3,
        'HOT'             => 4,
        'NEW'             => 5,
        'STAMP'           => 6,
        '360_IMAGE'       => 7,
        'AMENITIES'       => 8,
        'GO2CHOICE'       => 9,
        'TET'             => 10,
        'DIRECT_DISCOUNT' => 11,
    );
    const MSG = 'hotel';
    const DATE_WILL_CALCULATE_INCENTIVE_FOR_HOTEL_CONTRACTED = '2020-10-24';
    const HOTEL_SUGGESTION_TYPE = array(
        'PAY_IN_ADVANCE' => 1,
        'BLOCK_ROOM'     => 2,
    );
    const FILTER = [
        'ALL'                             => 0,
        'HAVE_BOOKING'                    => 1,
        'HAVE_BOOKING_ALREADY_CHECKED_IN' => 2,
    ];
    const ORIGIN = [
        'ALL'    => 0,
        'GO2JOY' => 1,
        'AGODA'  => 2,
    ];
    const ORIGIN_STR = [
        0 => 'ALL',
        1 => 'Go2Joy',
        2 => 'Agoda',
    ];
    const ROOM_STATUS = [
        'ALL'         => -1,
        'UNAVAILABLE' => 0,
        'AVAILABLE'   => 1,
    ];
    const PROMOTION_TITLE = array(
        0  => 'Tất cả | All',
        1  => 'Giảm sốc | Flash Sale',
        2  => 'Ưu đãi đặc biệt | Special Offer',
        3  => 'Ưu đãi | Promotion',
        4  => 'Nổi bật | Hot',
        5  => 'Mới | New',
        6  => 'Tem | Stamp',
        7  => 'Hình ảnh 360 | 360 Image',
        8  => 'Tiện nghi | Amenities',
        9  => 'Go2choice | Go2choice',
        10 => 'Chơi TẾT | Joy TẾT',
    );
    const SORT_WEB_BOOKING_V4 = array(
        'NONE'             => 0,
        'DISTANCE'         => 1,
        'RATING'           => 2,
        'PRICE_INCREASING' => 3,
        'PRICE_DECREASING' => 4,
    );
    const ROOM_STATUS_TYPE = array(
        'OUT_OF_STOCK' => 0,
        'AVAILABLE'    => 1,
    );
    const SEARCH_RATE_REVIEW = array(
        'GREATER_4_5' => 4.5,
        'GREATER_4'   => 4,
        'GREATER_3_5' => 3.5,
    );
    const STATUS_PERFORMANCE = array(
        'INCREASE' => 1,
        'SAME'     => 2,
        'DECREASE' => 3,
    );
    const SEARCH_RATE_REVIEW_CLEAN = array(
        'GREATER_5'   => 5,
        'GREATER_4_9' => 4.9,
        'GREATER_4_8' => 4.8,
    );
}
