<?php


namespace App\Constants;


class CouponForHotel
{
    const TYPE = array(
        'USE'=>1,
        'ISSUE'=>2,
    );

    const APPLY_TARGET = array(
        'ALL'             => 1,
        'ALL_BUT_EXCLUDE' => 2,
        'JUST_APPLY'      => 3,
    );

    const MSG = 'couponForHotel';

    const ERR_HOTEL_SN_LIST_EMP = 1;
}
