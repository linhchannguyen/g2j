<?php

namespace App\Constants;

class PaymentTransaction
{
    const PREFIX_TRANSACTION = 'G2J';

    const BANK_CODE = [
        // provide by Payoo
        "NAME" => "CODE",
        "VPBank" => "VPB"
    ];

    const PAYMENT_STATUS = [
        'AWAITING'   => 0,
        'SUCCESSFUL' => 1,
        'FAILED'     => 2,
        'REFUNDED'   => 3,
    ];
}