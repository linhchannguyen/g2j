<?php

namespace App\Constants;

class HotelGroup
{
    const ALL = 0;
}
