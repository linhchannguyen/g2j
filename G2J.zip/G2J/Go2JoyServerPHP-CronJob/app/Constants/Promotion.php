<?php

namespace App\Constants;

class Promotion
{
    const ALL = -1;

    const TYPE = array(
        'ALL'              => 0,
        'APPLY'            => 1,
        'EVENT'            => 2,
        'INVITE_FRIEND'    => 3,
        'GIFT'             => 4,
        'BOOKING'          => 5,
        'REPORT_NEW_HOTEL' => 6,
        'SIGNUP'           => 7,
        'BIRTHDAY'         => 8,
        'PAYMENT'          => 9,
        'VOUCHER_CODE'     => 10,
    );

    const TYPE_DONATE = array(
        'ONE_USER'   => 1,
        'FILE_EXCEL' => 2,
        'SIGN_UP'    => 3,
        'CRM_FILTER' => 4,
    );

    const STATUS = array(
        'DELETED'               => 0,
        'ACTIVE'                => 1,
        'EXPIRED'               => 2,
        'TEMP'                  => 3, // Old version, don't use this constant anymore in new develop
        'NOT_YET'               => 3,
        'DRAFT'                 => 4, // Old version, don't use this constant anymore in new develop
        'REJECTED'              => 4,
        'WAIT_CONFIRM'          => 5, // Old version, don't use this constant anymore in new develop
        'AWAITING_CONFIRMATION' => 5,
    );

    const ACCEPT_STATUS = array(
        'UNKNOWM'        => 0,
        'COMFIRMED'      => 1,
        'EXPIRED'        => 2,
        'ADD_MORE_HOTEL' => 3,
        'TAP_TO_COMFIRM' => 4,
    );

    const CO_PROMOTION = array(
        'NO'  => 0,
        'YES' => 1,
    );

    const APPLY_STATUS = array(
        'NONE'         => 0,
        'AT_LEAST_ONE' => 1,
        'ALL'          => 2,
    );

    const APPLY_TARGET = array(
        'ALL'        => 1,
        'JUST_APPLY' => 2,
    );

    const DISPLAY = array(
        'INACTIVE' => 0, // Old version, don't use this constant anymore in new develop
        'HIDE'     => 0,
        'ACTIVE'   => 1, // Old version, don't use this constant anymore in new develop
        'SHOW'     => 1,
    );

    const DISPLAY_HOTEL = array(
        'HIDE' => 0,
        'SHOW' => 1,
    );

    const CAN_APPLY_STATUS = array(
        'WAITING' => 1,
        'APPLY'   => 2,
        'APPLIED' => 3,
    );

    const DISCOUNT_TYPE = array(
        'DISCOUNT'         => 0,
        'DISCOUNT_PERCENT' => 1,
        'EVENT'            => 2,
        'INVITE_FRIEND'    => 3,
        'GIFT'             => 4,
        'BOOKING'          => 5,
        'REPORT_NEW_HOTEL' => 6,
        'SIGNUP'           => 7,
        'BIRTHDAY'         => 8,
        'PAYMENT'          => 9,
    );

    const REWARD_HOUR_GIFT_TYPE = array(
        'HOUR'         => 1,
        'GIFT'         => 2,
    );
    const FORM_OF_SPONSOR = array(
        'G2J_HOTEL' => 0,
        'G2J'       => 1,
        'HOTEL'     => 2,
    );

    const GO2JOY = 1;
    const MSG = 'promotion';
    const ERR_TITLE_EMP = 1;
    const ERR_CONT_VI_EMP = 2;
    const ERR_CONT_EN_EMP = 3;
    const ERR_CODE_EMP = 4;
    const ERR_CODE_DUPLI = 5;
    const ERR_SUBCONT_VI_EMP = 6;
    const ERR_SUBCONT_EN_EMP = 7;
    const ERR_NAME_OF_BTN_EMP = 8;
    const ERR_COUPON_START_LT_END = 9;
    const ERR_COUPON_START_END_EMP = 10;
    const ERR_WRONG_MAX_DIS = 11;
    const ERR_WRONG_DIS = 12;
    const ERR_WRONG_DIS_PERCENT = 13;
    const ERR_WRONG_DIS_SAME = 14;
    const ERR_DIS_0 = 15;
    const ERR_NUM_ACTIVE_DATE = 16;
    const ERR_PRO_EXISTS = 17;
    const ERR_PRO_START_LT_END = 18;
    const ERR_PRO_START_END_EMP = 19;
    const ERR_USER_DONATE_EMP = 20;
    const ERR_FILE_DONATE_EMP = 21;
    const ERR_NOT_EXITS = 22;
    const ERR_EXPIRE = 23;
    const ERR_CAN_NOT_APPLY = 24;
    const ERR_REGISTER_ALREADY = 25;
    const ERR_NOT_APPLY = 26;
    const ERR_VOUCHER_EXISTS = 27;
    const ERR_TIME_APPLY = 28;
    const ERR_NOT_ENOUGH_APPLY = 29;
    const ERR_OVER_TIME_APPLY = 30;

    const ERR_EXPIRE_EVENT_MESSAGE = 'Event expires';
    const ERR_EXPIRE_PROMOTION_MESSAGE = 'Promotion expires';
    const REGISTER_ALREADY_EVENT_MESSAGE = 'Registered for the event';
    const REGISTER_ALREADY_PROMOTION_MESSAGE = 'Applied for the promotion';

    const TYPE_VIEW_HOTEL_NEAREST = 1;
    const TYPE_VIEW_HOTEL_CHEAPEST = 2;
}

