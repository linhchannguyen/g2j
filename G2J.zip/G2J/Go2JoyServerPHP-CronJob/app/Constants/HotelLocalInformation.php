<?php

namespace App\Constants;

class HotelLocalInformation
{
    const DISTANCE_UNIT = array(
        'M'  => 'm',
        'KM' => 'km',
    );

    const STATUS = array(
        'DELETED' => 0,
        'ACTIVE'  => 1,
    );

    const ORIGIN = array(
        'GO2JOY' => 1,
        'AGODA'  => 2,
    );

    const LANGUAGE = array(
        'KOREA'      => 1,
        'ENGLISH'    => 2,
        'VIETNAMESE' => 3,
    );
}
