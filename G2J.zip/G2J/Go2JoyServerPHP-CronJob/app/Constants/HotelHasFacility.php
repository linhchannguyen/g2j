<?php

namespace App\Constants;

class HotelHasFacility
{
    //
}
