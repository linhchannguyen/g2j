<?php


namespace App\Constants;


class PromotionGroup
{
    const STATUS = array(
        'ACTIVE' => 1,
        'EXPIRED' => 2,
    );
}
