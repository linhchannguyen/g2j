<?php

namespace App\Constants;

class HotelPms
{
    const TYPE = array(
        'MANUAL'                     => 0,
        'PROPERTY_MANAGEMENT_SYSTEM' => 1,
    );

    const MSG = 'hotelPms';
}
