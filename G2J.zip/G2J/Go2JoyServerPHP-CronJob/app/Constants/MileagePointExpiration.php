<?php

namespace App\Constants;

class MileagePointExpiration
{
    const PROCESSED = array(
        'NOT_YET'   => 0,
        'PROCESSED' => 1,
    );
}
