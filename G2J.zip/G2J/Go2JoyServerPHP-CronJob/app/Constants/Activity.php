<?php

namespace App\Constants;

class Activity
{
    const STATUS = array(
        'NONE'      => 0,
        'WAITING'   => 1,
        'CONFIRMED' => 2,
        'CANCELLED' => 3,
    );
    const TYPE = array(
        'PROMOTION'        => 1,
        'INVITE_FRIEND'    => 2,
        'PRODUCT'          => 3,
        'TRANSFER_BOOKING' => 4,
        'BOOKING_STATUS'   => 5,
        'USER_STATUS'      => 6,
        'CORRELATED_HOTEL' => 7,
    );
    const MSG = 'activity';
}
