<?php


namespace App\Constants;


class DeliveryActivity
{
    const CONFIRMED = array(
        'NONE'=>0,
        'CONFIRM'=>1,
        'CANCEL'=>2,
    );
}
