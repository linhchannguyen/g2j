<?php


namespace App\Constants;


class CrmFilterDetail
{
    const OPERATOR = array(
        '=' => 0,
        '>' => 1,
        '>=' => 2,
        '<' => 3,
        '<=' => 4,
        '!=' => 5,
        'BETWEEN' => 6,
        'AND' => 7,
        'IN' => 8,
        'LIKE' => 9,
    );

    const TYPE = array(
        'INPUT' => 0,
        'SELECT_VALUE' => 1,
        'SELECT_FROM' => 2,
        'SELECT_TO' => 3,
        'SELECT_PROVINCE' => 4,
        'SELECT_DISTRICT' => 5,
    );

    const OPERATOR_STR = array(
        0 => '=',
        1 => '>',
        2 => '>=',
        3 => '<',
        4 => '<=',
        5 => '!=',
        6 => 'BETWEEN',
        7 => 'AND',
        8 => 'IN',
        9 => 'LIKE',
    );


//'EQUAL' => 0,
//'GREATER' => 1,
//'GREATER_EQUAL' => 2,
//'LESS' => 3,
//'LESS_EQUAL' => 4,
//'NOT_EQUAL' => 5,
//'BETWEEN' => 6,
//'AND' => 7,
//'IN' => 8,
//'LIKE' => 9,

//OPERATOR//'=' => 0,'>' => 1,'>=' => 2,'<' => 3,'<=' => 4,'!=' => 5,'BETWEEN' => 6,'AND' => 7,'IN' => 8,'LIKE' => 9,
//TYPE//'INPUT' => 0, 'SELECT_VALUE' => 1, 'SELECT_FROM' => 2, 'SELECT_TO' => 3, 'SELECT_PROVINCE' => 4, 'SELECT_DISTRICT' => 5,
}
