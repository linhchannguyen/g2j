<?php


namespace App\Constants;


class MileageTarget
{
    const TARGET_TYPE = array(
        'ALL_HOTEL' => 1,
        'ALL_REJECT' => 2,
        'SPECIFY_HOTEL' => 3,
        'SPECIFY_PROVINCE' => 4,
    );
}
