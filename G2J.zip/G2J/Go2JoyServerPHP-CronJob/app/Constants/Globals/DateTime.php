<?php

namespace App\Constants\Globals;

class DateTime
{
    const DAY_OF_WEEK = array(
        'SUNDAY' => 0,
        'MONDAY' => 1,
        'TUESDAY' => 2,
        'WEDNESDAY' => 3,
        'THURSDAY' => 4,
        'FRIDAY' => 5,
        'SATURDAY' => 6,
    );

    /**
     * @param $date
     * @return \DateTime|null
     */
    public static function create($date)
    {
        if (empty($date))
            return null;
        return date_create($date);
    }
}
