<?php

namespace App\Constants\Globals;

class HotelAction
{
    const DID_NOT_CAME = 0;
    const CAME = 1;
    const NOT_YET = 2;
    const APPLY_COUPON_HOTEL = array(
        'NOT_YET'   => 0,
        'JOINED'    => 1,
    );
}
