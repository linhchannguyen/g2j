<?php

namespace App\Constants\Globals;

class FunctionName
{
    const APPLYING_HOTEL = 'applying_hotel';
    const APPLYING_COUPON_HOTEL = 'applying_coupon_hotel';
    const APPLYING_PROMOTION = 'applying_promotion';
    const APPLYING_HOTEL_FAQ = 'applying_hotel_faq';
    const APPLYING_HOTEL_COLLECTION = 'applying_hotel_collection';
    const APPLYING_MILEAGE_TARGET = 'applying_mileage_target';
    const APPLYING_DIRECT_DISCOUNT = 'applying_direct_discount';

    const GET_DISPLAY_RULE = 'get_display_rule';

    const USED_DAILY_REVERSE_GEOCODING_REQUEST = 'used_daily_reverse_geocoding_request';

    const USER_BOOKING_PAYMENT_INFO = 'user_booking_payment_info';

    const HOTEL_PROVINCE_DISTRICT_TOTAL_CLICK = 'total_click';

    const GET_MARKING_CHECKIN_LIST = 'get_marking_checkin_list';

    const DEDUCT_POINT_BOOKING = 'deduct_point_booking';

    const HOME_CACHE_FLASH_SALE = 'home_flash_sale';
    const HOME_CACHE_HOTEL_SUGGESTION = 'home_hotel_suggestion';
    const HOME_CACHE_HOTEL_COLLECTION_TYPE = 'home_hotel_collection_type';
    const HOME_CACHE_PROMOTION_SUGGESTION = 'home_promotion_suggestion';
    const HOME_CACHE_BANNER = 'home_banner';
    const HOME_CACHE_ARTICLE = 'home_article';

    const HOTEL_DEBT_IN_PROGRESS = 'hotel_debt_in_progress';
}
