<?php

namespace App\Constants\Globals;

class Pagination
{
    const LIMIT = [
        'NO_LIMIT'            => -1,
        'DEFAULT'             => 10,
        'DEFAULT_WEB_BOOKING' => 12,
        'LIMIT_100'           => 100,
        'LIMIT_500'           => 500,
        'LIMIT_100000'        => 100000,
    ];
    const LIMIT_TWO = 2;
    const LIMIT_FOUR = 4;
    const LIMIT_FIVE = 5;
    const LIMIT_SIX = 6;
    const LIMIT_SEVEN = 7;
    const LIMIT_FIFTEEN = 15;
    const LIMIT_FORTY = 40;
    const PAGE_DEFAULT = 1;
    const PAGE_DEFAULT_SP = 0;
}
