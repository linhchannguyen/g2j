<?php

namespace App\Constants\Globals;

class VersionCheck
{
    const PLATFORM = array(
        'HA'  => 'ha',
        'PWA' => 'pwa',
    );
}
