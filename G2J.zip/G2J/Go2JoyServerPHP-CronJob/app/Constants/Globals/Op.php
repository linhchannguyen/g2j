<?php

namespace App\Constants\Globals;

class Op
{
    const REMOVE  = 'remove';
    const ADD     = 'add';
    const REPLACE = 'replace';
}
