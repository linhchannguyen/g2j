<?php

namespace App\Constants\Globals;

class Adjust
{
    const EVENT_CHECKIN_SUCCESSFULLY = 'Checkin_successfully';
    const DEVICE_IDENTIFIER_UPDATE_FLAG = 'Update device identifier';
}
