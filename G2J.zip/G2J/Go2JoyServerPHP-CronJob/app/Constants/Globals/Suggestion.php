<?php

namespace App\Constants\Globals;

class Suggestion
{
    const JUST_HOTEL = array(
        'FALSE' => 0,
        'TRUE'  => 1,
    );
}
