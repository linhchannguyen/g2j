<?php

namespace App\Constants\Globals;

class Slack
{
    const CHANNEL = array(
        'ADHOC_MONITOR'     => 'adhoc-monitor',
        'FAILED_JOBS'       => 'failed-jobs',
        'JOB_MONITOR'       => 'job-monitor',
        'SCHEDULE_MONITOR'  => 'schedule-monitor',
        'BACKEND_MONITOR'   => 'backend-monitor',
        'AGODA_MONITOR'     => 'agoda-monitor',
        'PAYMENT_MONITOR'   => 'payment-monitor',
        'SYNCING_MONITOR'   => 'syncing-monitor',
        'JIRA-NOTIFICATION' => 'jira-notification',
        'DEBUGGING'         => 'debugging',
        'GEOCODING_MONITOR' => 'geocoding-monitor',

    );
}