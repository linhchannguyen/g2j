<?php

namespace App\Constants\Globals;

class State
{
    /** Work tracking stages */
    const TO_DO = 'to_do';
    const DOING = 'doing';
    const DONE  = 'done';
    const NO_DATA_FOUND = 'no_data_found';
}