<?php

namespace App\Constants\Globals;

class Code
{
    const ERROR = 0;
    const UNAUTHORIZED = -1;
    const SUCCESS = 1;
    const FAIL = 2;
    const MISSING_HEADERS = 3;
    const MISSING_OR_INVALID_PARAMS = 4;
    const TOKEN_EXPIRED = 5;
    const INVALID_TOKEN = 6;
    const PROCESSING = 7;
    const INTERNAL_SERVER_ERROR = 8;
    const MOBILE_ID_INVALID = 9;
    const ALREADY_EXISTS_IN_DATABASE = 10;
    const CAN_NOT_SET_TO_CURRENT_VALUE = 11;
    const HAVE_TO_CONFIRM_SALE_INCENTIVE_BEFORE_CONTINUING = 12;
    const CAN_NOT_SAVE_A_NEW_SALE_INCENTIVE_HISTORY_IN_THE_PAST = 13;
    const MUST_HAVE_CREATE_HOTEL_DEBT_BEFORE = 14;
    const NO_RESOURCE = 15;
    const DUPLICATE_CONTRACT_ID = 16;
    const VERIFY_OTP_IS_REQUIRED = 17;
    const INVALID_OTP_CODE = 18;
    const WRONG_PASSWORD = 19;
    const BUSINESS_LOGIC_ERROR = 20;
    const TOO_MANY_ATTEMPTS = 21;
    const FORCE_UPDATE = 22;
    const INVALID_IPN = 31;
    const BLOCK_ACCOUNT = 32;
    const ERROR_11 = 11;
    const ERROR_12 = 12;
    const ERROR_13 = 13;
    const ERROR_14 = 14;
    const ERROR_15 = 15;
    const ERROR_16 = 16;
    const ERROR_17 = 17;
    const ERROR_18 = 18;
    const ERROR_19 = 19;
    const ERROR_20 = 20;
    const ERROR_21 = 21;
    const ERROR_22 = 22;
    const ERROR_23 = 23;
    const ERROR_24 = 24;
    const ERROR_25 = 25;
    const ERROR_26 = 26;
    const ERROR_27 = 27;
    const ERROR_28 = 28;
    const ERROR_29 = 29;
    const ERROR_30 = 30;
    const ERROR_31 = 31;
    const ERROR_32 = 32;
    const ERROR_33 = 33;
    const ERROR_34 = 34;
    const ERROR_35 = 35;
    const PERMISSION_DENIED = 403;
    /** List of common codes */
    const API_GNR_001 = 'API_GNR_001'; // Missing or invalid headers
    const API_GNR_002 = 'API_GNR_002'; // Missing or invalid params
    const API_GNR_003 = 'API_GNR_003'; // Request timeout
    const API_GNR_004 = 'API_GNR_004'; // Service not found
    const API_GNR_005 = 'API_GNR_005'; // No resource was found
    const API_GNR_006 = 'API_GNR_006'; // Something went wrong with database
    const API_GNR_007 = 'API_GNR_007'; // Permission denied
    const API_GNR_009 = 'API_GNR_009'; // Version mismatch
    /** Passport service codes */
    const API_PSS_001 = 'API_PSS_001'; // Permission denied
    const API_PSS_002 = 'API_PSS_002'; // Invalid verification code
    const API_PSS_003 = 'API_PSS_003'; // Verification code is expired
    const API_PSS_004 = 'API_PSS_004'; // Account not exist in system
    const API_PSS_005 = 'API_PSS_005'; // Your account was disabled. Please contact Go2Joy hotline 0931836836 for support.
    const API_PSS_006 = 'API_PSS_006'; // Incorrect phone number format
    const API_PSS_007 = 'API_PSS_007'; // Need wait more time to send sms
    const API_PSS_008 = 'API_PSS_008'; // The phone number to receive the verification code does not exist
    const API_PSS_009 = 'API_PSS_009'; // The phone number already exists in system
    const API_PSS_010 = 'API_PSS_010'; // Social account not found
    const API_PSS_011 = 'API_PSS_011'; // Token not provided
    const API_PSS_012 = 'API_PSS_012'; // Provided token is expired
    const API_PSS_013 = 'API_PSS_013'; // Invalid token
    /** User */
    const API_USR_001 = 'API_USR_001'; // User doesn't exists
    const API_USR_002 = 'API_USR_002'; // Email already exists
    const API_USR_003 = 'API_USR_003'; // Can not edit user information in awaiting approval request
    const API_USR_004 = 'API_USR_004'; // Can not submit lock request
    const API_USR_005 = 'API_USR_005'; // Can not submit unlock request
    /** Reward */
    const API_RWD_001 = 'API_RWD_001'; // Don't have enough points to apply
    const API_RWD_002 = 'API_RWD_002'; // Not eligible to refund point this reservation
    const API_RWD_003 = 'API_RWD_003'; // Not eligible to reward point this reservation
    /** Booking */
    const API_BKG_001 = 1; // Please fill out Guest Information (Temporary set value is integer for mobile, because Dang Nguyen currently can't parse string)
    const API_BKG_002 = 2; // Sorry, you have missed our last room (Temporary set value is integer for mobile, because Dang Nguyen currently can't parse string)
    const API_BKG_003 = 3; // Please enter the reason for the cancellation (Temporary set value is integer for mobile, because Dang Nguyen currently can't parse string)
    const API_BKG_004 = 4; // Invalid booking (Temporary set value is integer for mobile, because Dang Nguyen currently can't parse string)
    const API_BKG_005 = 5; // Violate cancellation policy (Temporary set value is integer for mobile, because Dang Nguyen currently can't parse string)
    const API_BKG_006 = 6; // Reservation cannot be cancelled in this status (Temporary set value is integer for mobile, because Dang Nguyen currently can't parse string)
    const API_BKG_007 = 7; // Can't cancel this booking. Please contact Go2Joy hotline 0931836836 for support (Temporary set value is integer for mobile, because Dang Nguyen currently can't parse string)
    const API_BKG_008 = 8; // Can't cancel this booking due to T&C of the coupon you choose.
    /** RoomType */
    const API_RMT_001 = 'API_RMT_001'; // Please re-enter “Max num hour”
    const API_RMT_002 = 'API_RMT_002'; // Please enter “First hour price”
    const API_RMT_003 = 'API_RMT_003'; // This room is running Direct Discount. Please check again.
    const API_RMT_004 = 'API_RMT_004'; // This room is running Extra Fee. Please check again.
    const API_RMT_005 = 'API_RMT_005'; // This room is running Flash sale. Please check again.
    const API_RMT_006 = 'API_RMT_006'; // This room is running Direct Discount and Flash sale. Please check again.
    const API_RMT_007 = 'API_RMT_007'; // This room is running Extra Fee and Flash sale. Please check again.

    /** Promotion */
    const API_PRN_001 = 'API_PRN_001'; // List hotel has hotel not contracted
    const API_PRN_002 = 'API_PRN_002'; // "There are x hotels that don't have a discount set up. Do you want to skip these hotels and continue creating the program? "
    const API_PRN_003 = 'API_PRN_003'; // Please input start date
    const API_PRN_004 = 'API_PRN_004'; // Please input end date
    const API_PRN_005 = 'API_PRN_005'; // Please input start time
    const API_PRN_006 = 'API_PRN_006'; // Please input end time
    const API_PRN_007 = 'API_PRN_007'; // The end date is more than 1 year
    const API_PRN_008 = 'API_PRN_008'; // The end time is less than the start time
    const API_PRN_009 = 'API_PRN_009'; // Please input special day
    const API_PRN_010 = 'API_PRN_010'; // List of special days not more than 30 days
    const API_PRN_011 = 'API_PRN_011'; // Please input file
    const API_PRN_012 = 'API_PRN_012'; // Please input list hotel
    const API_PRN_013 = 'API_PRN_013'; // Please choose day of week
    const API_PRN_014 = 'API_PRN_014'; // Please choose Start time: 0h ~ 22h
    const API_PRN_015 = 'API_PRN_015'; // Please choose End time: 1h ~ 23h
    const API_PRN_016 = 'API_PRN_016'; // The list contains room type are participating in another program
    const API_PRN_017 = 'API_PRN_017'; // Limit hotel less than 100
    const API_PRN_018 = 'API_PRN_018'; // Not Permission Action Add Hotel
    const API_PRN_019 = 'API_PRN_019'; // Not Permission Action Delete Hotel
    const API_PRN_020 = 'API_PRN_020'; // The coupons in this promotion are not in the 'Running' status
    const API_PRN_021 = 'API_PRN_021'; // Program not existed
    const API_PRN_022 = 'API_PRN_022'; // Unexpected value
    const API_PRN_023 = 'API_PRN_023'; // Voucher Code was exists
    const API_PRN_024 = 'API_PRN_024'; // The voucher code must be between 6 and 12 characters
    const API_PRN_025 = 'API_PRN_025'; // The voucher code common must be start with G2J
    const API_PRN_026 = 'API_PRN_026'; // Overnight price must be higher than Flash sale price
    const API_PRN_027 = 'API_PRN_027'; // The system has a new version, please update the page
    const API_PRN_030 = 'API_PRN_030'; // Coupon is pending. Please try Cancel again in a few minutes!!
    const API_PRN_031 = 'API_PRN_031'; // This code is temporarily unavailable, please enter another code
    const API_PRN_040 = 'API_PRN_040'; // User name
    const API_PRN_041 = 'API_PRN_041'; // Phone number
    const API_PRN_042 = 'API_PRN_042'; // Status
    const API_PRN_043 = 'API_PRN_043'; // Not used yet
    const API_PRN_044 = 'API_PRN_044'; // Used
    const API_PRN_045 = 'API_PRN_045'; // Will be used
    const API_PRN_046 = 'API_PRN_046'; // Expired
    const API_PRN_047 = 'API_PRN_047'; // Coupon period
    const API_PRN_048 = 'API_PRN_048'; // Used Time
    const API_PRN_049 = 'API_PRN_049'; // Name of engineer
    const API_PRN_050 = 'API_PRN_050'; // Time in hotel

    /** Adhoc - Hotel */
    const API_ADH_001 = 'API_ADH_001'; // Agoda hotel code is invalid
    const API_ADH_002 = 'API_ADH_002'; // Go2Joy hotel code is invalid

    /** Hotel */
    const API_HTL_001 = 'API_HTL_001'; // Please select a participating hotel

    /** Hotel Debt */
    const API_HDT_001 = 'API_HDT_001'; // Period debt time entered invalid, please choose right date!
}
