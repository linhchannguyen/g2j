<?php

namespace App\Constants\Globals;

class Exception
{
    const CACHE_NAME = 'exception';

    const TTL = 300; // Seconds

    const CODE = array(
        'MONGODB_CONNECTION_REFUSED' => 13053,
    );

    const G2J_CODE = array(
        'FAILED_TO_DETECT_LOCATION' => 1,
    );
}