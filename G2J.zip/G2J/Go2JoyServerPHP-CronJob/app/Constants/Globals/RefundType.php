<?php

namespace App\Constants\Globals;

class RefundType
{
    const NONE      = 0;
    const ALL       = 1;
    const NO_REFUND = 2;
    const REFUNDED  = 3;
}
