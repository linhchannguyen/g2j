<?php

namespace App\Constants\Globals;

class PubSub
{
    const CHANNEL = array(
        'NEW_SIGN_UP'                            => 'new-sign-up',
        'LOGGING'                                => 'logging',
        'PROCESS_AFTER_INSTANT_LOCK_HAS_CHANGED' => 'process-after-instant-lock-has-changed',
        'CREATE_USER_STATISTIC'                  => 'create-user-statistic',
        'UPDATE_USER_STATISTIC'                  => 'update-user-statistic',
        'SYNC_HOTEL_LOCKED'                      => 'sync-hotel-locked',
        'SYNC_HOTEL_RANKING'                     => 'sync-hotel-ranking',
        'SYNC_NUM_OF_ROOM_FLASH_SALE'            => 'sync-num-of-room-flash-sale',
        'TRACKING_USER_ACTIVITY'                 => 'tracking-user-activity',
        'PUSH_NOTIFICATION'                      => 'push-notification',
        'UPDATE_VIEW_APP_NOTIFICATION_STATISTIC' => 'update-view-app-notification-statistic',
        'LOG_TOKEN_INFO'                         => 'log-token-info',
        'REFUND_BOOKING_AMOUNT'                  => 'refund-booking-amount',
    );
}