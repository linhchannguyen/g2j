<?php

namespace App\Constants\Globals;

class ReportType
{
    const CHECK_IN_DATE_PLAN = 1;
    const CHECK_IN_TIME = 2;
}
