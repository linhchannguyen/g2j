<?php

namespace App\Constants\Globals;

class TypeApply
{
    const TYPE_APPLY = [
        'REFERRER' => 1,
        'REFEREE'  => 2,
    ];
}
