<?php

namespace App\Constants\Globals;

class Filter
{
    const RATING = [
        'ALL'                          => -1,
        'UNDER_ONE'                    => 0,
        'FROM_ONE_TO_LESS_THAN_TWO'    => 1,
        'FROM_TWO_TO_LESS_THAN_THREE'  => 2,
        'FROM_THREE_TO_LESS_THAN_FOUR' => 3,
        'FROM_FOUR_TO_FIVE'            => 4,
        'IS_ZERO'                      => 5,
        'IS_ONE'                       => 6,
        'IS_TWO'                       => 7,
        'IS_THREE'                     => 8,
        'IS_FOUR'                      => 9,
        'IS_FIVE'                      => 10,
    ];

    const SOURCE = [
        'ALL'    => 0,
        'GO2JOY' => 1,
        'AGODA'  => 2,
        'MOMO'   => 3,
    ];

    const REPORT_TYPE = [
        'NONE'               => 0,
        'CHECK_IN_DATE_PLAN' => 1,
        'CHECK_IN_TIME'      => 2,
    ];

    const REFUND_TYPE = [
        'NONE'      => 0,
        'ALL'       => 1,
        'NO_REFUND' => 2,
        'REFUNDED'  => 3,
    ];

    const PAYMENT_STATUS = [
        'ALL'      => 0,
        'UNPAID'   => 1,
        'PAID'     => 2,
        'REFUNDED' => 3,
    ];

    const WORKING_STATUS = [
        'ALL'                   => 0,
        'RECEIVED'              => 1,
        'SOLVED'                => 2,
        'AWAITING_APPROVAL'     => 3,
        'REJECTED'              => 4,
        'RECEIVED_CANCELLATION' => 5,
        'RECEIVED_NO_SHOW'      => 6,
    ];

    const ACTIVITY_TYPE = array(
        'ALL'              => 0,
        'PROMOTION'        => 1,
        'INVITE_FRIEND'    => 2,
        'PRODUCT'          => 3,
        'TRANSFER_BOOKING' => 4,
        'BOOKING_STATUS'   => 5,
        'USER_STATUS'      => 6,
        'CORRELATED_HOTEL' => 7,
    );

    const BOOKING_TYPE = array(
        'ALL'       => 0,
        'HOURLY'    => 1,
        'OVERNIGHT' => 2,
        'DAILY'     => 3,
    );
}
