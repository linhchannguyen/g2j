<?php

namespace App\Constants\Globals;

class Environment
{
    const PRODUCTION = 'production';
    const UAT        = 'uat';
    const STAGING    = 'staging';
    const DEVELOP    = 'develop';
}