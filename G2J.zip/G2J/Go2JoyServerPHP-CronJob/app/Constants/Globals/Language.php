<?php

namespace App\Constants\Globals;

class Language
{
    const LANGUAGE_CODE = [
        'VIETNAMESE' => 'VN',
        'ENGLISH'    => 'EN',
    ];
    const OBJECT_ID = [
        'REFERRAL_PROGRAM_CONTENT'            => 1,
        'REFERRAL_PROGRAM_INVITATION_CONTENT' => 2,
        'PROMOTION_GROUP_CONTENT'             => 3,
        'REASON_DELETE_CONTENT'               => 4,
        'REASON_CANCEL_BOOKING_CONTENT'       => 5,
    ];
    const LOCALE_TO_LANGUAGE_CODE = [
        'vi' => 'VN',
        'vn' => 'VN',
        'en' => 'EN',
    ];
}