<?php

namespace App\Constants\Globals;

class Sorting
{
    const SORT_BY = array(
        'NEWEST_TO_OLDEST'         => 1,
        'OLDEST_TO_NEWEST'         => 2,
        'HIGHEST_TO_LOWEST_RATING' => 3,
        'LOWEST_TO_HIGHEST_RATING' => 4,
        'MOST_TO_LEAST_REVIEW'     => 5,
        'LEAST_TO_MOST_REVIEW'     => 6,
        'A-Z'                      => [
            'HOTEL_NAME' => 7,
            'USERNAME'   => 9,
        ],
        'Z-A'                      => [
            'HOTEL_NAME' => 8,
            'USERNAME'   => 10,
        ],
    );
}
