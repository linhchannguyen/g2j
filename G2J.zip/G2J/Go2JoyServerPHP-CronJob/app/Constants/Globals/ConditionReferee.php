<?php

namespace App\Constants\Globals;

class ConditionReferee
{
    const REFEREE = "Num check-in";
}
