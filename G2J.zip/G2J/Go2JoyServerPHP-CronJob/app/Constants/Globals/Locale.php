<?php

namespace App\Constants\Globals;

class Locale
{
    const VIETNAMESE = [
        'VI' => 'vi',
        'VN' => 'vn'
    ];
    const ENGLISH = 'en';
}