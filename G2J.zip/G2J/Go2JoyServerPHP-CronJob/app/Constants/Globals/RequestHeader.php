<?php

namespace App\Constants\Globals;

class RequestHeader
{
    const DEVICE_ENCODE = 'Device-Encode';
    const REQUESTER = 'Requester';
    // Internal headers
    const AUTH_INFO = 'Auth-Info';
    const DEVICE_INFO = 'Device-Info';
    const VERSION = 'Version';
}