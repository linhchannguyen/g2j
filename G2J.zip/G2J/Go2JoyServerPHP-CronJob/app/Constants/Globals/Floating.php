<?php

namespace App\Constants\Globals;

class Floating
{
    const ACTION = array(
        'PROMOTION'          => 1,
        'INVITE_FRIEND'      => 2,
        'EVENT'              => 3,
        'HOTEL'              => 4,
        'NOTICE'             => 5,
        'LINK'               => 6,
        'AREA'               => 7,
        'MILEAGE_POINT'      => 8,
        'COUPON'             => 9,
        'DIRECT_DISCOUNT'    => 10,
        'PROMOTION_GROUP'    => 11,
        'AMENITY_PACK_HOTEL' => 12,
        'G2J_CERTIFIED'      => 13,
        'TET'                => 105,
        'REFERRAL_PROGRAM'   => 106,
        'LINK_IN_APP'        => 61,
        'IMAGE_ADS'          => 107,
        'ARTICLE'            => 108,
    );
}