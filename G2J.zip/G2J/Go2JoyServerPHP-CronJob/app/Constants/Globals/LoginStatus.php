<?php

namespace App\Constants\Globals;

class LoginStatus
{
    const LOGOUT = 0;
    const LOGIN = 1;
}
