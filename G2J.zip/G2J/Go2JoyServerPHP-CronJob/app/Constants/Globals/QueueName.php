<?php

namespace App\Constants\Globals;

class QueueName
{
    /** Exports */
    const CHUNK_EXPORTS = 'chunk_exports';
    const INIT_POINT_EXPORTS = 'init_point_exports';
    const EXPORTS = 'exports';

    /** Backgrounds */
    const BACK_GROUND = 'back_ground';

    /** Promotion */
    const PROMOTION = 'promotion';

    /** Logging */
    const LOGGING = 'logging';

    /** Imports */
    const CHUNK_IMPORTS = 'chunk_imports';
    const IMPORTS = 'imports';

    /** Notice */
    const NOTIFICATION = 'notification';
    const EMAIL = 'email';
    const SMS = 'sms';
    const NOTIFICATION_DONATES = 'notification_donates';

    /** Schedule */
    const HOURLY_JOB = 'hourly_job';
    const MINUTE_JOB = 'minute_job';

    /** Donates */
    const DONATES = 'donates';

    /** Message */
    const MESSAGE = 'message';

    /** Converts */
    const CONVERTS = 'converts';

    /** Integration */
    const INTEGRATION = array(
        'AGODA_REFRESH_CONTENT' => array(
            'PULL_CITY'                    => 'integration_agoda_pull_city',
            'PULL_AREA'                    => 'integration_agoda_pull_area',
            'PULL_HOTEL_FACILITY'          => 'integration_agoda_pull_hotel_facility',
            'PULL_HOTEL_IMAGE'             => 'integration_agoda_pull_hotel_image',
            'IMPORT_HOTEL_FACILITY'        => 'integration_agoda_import_hotel_facility',
            'IMPORT_HOTEL_IMAGE'           => 'integration_agoda_import_hotel_image',
            'FETCH_HOTEL'                  => 'integration_agoda_fetch_hotel',
            'PULL_HOTEL'                   => 'integration_agoda_pull_hotel',
            'IMPORT_HOTEL'                 => 'integration_agoda_import_hotel',
            'PULL_ROOM_TYPE'               => 'integration_agoda_pull_room_type',
            'IMPORT_ROOM_TYPE'             => 'integration_agoda_import_room_type',
            'PULL_ROOM_TYPE_FACILITY'      => 'integration_agoda_pull_room_type_facility',
            'IMPORT_ROOM_TYPE_FACILITY'    => 'integration_agoda_import_room_type_facility',
            'REFRESH_HOTEL_DISPLAY_FILTER' => 'integration_agoda_refresh_hotel_display_filter',
        ),
        'AGODA_TRANSPORT_RESOURCE'         => 'integration_agoda_transport_resource',
        'AGODA_REFRESH_ROOM_PRICE_TODAY'   => 'integration_agoda_refresh_room_price_today',
        'BOOKING'                          => 'integration_booking',
    );

    /** Elastic search */
    const ELASTIC_SEARCH = 'elastic_search';
    const HOTEL_RANKING_SYNCING = 'hotel_ranking_syncing';
    const HOTEL_LOCKED_SYNCING = 'hotel_locked_syncing';
    const HOTEL_COUPON_SYNCING = 'hotel_coupon_syncing';
    const ROOM_PRICING_SYNCING = 'room_pricing_syncing';
    const USER_COUPON_SYNCING = 'user_coupon_syncing';

    /** Adjust event */
    const ADJUST = 'adjust';

    /** Hotel debt  */
    const HOTEL_DEBT_EMAIL = 'hotel_debt_email';
    const HOTEL_DEBT_CREATION = 'hotel_debt_creation';
    const HOTEL_DEBT_NOTIFICATION = 'hotel_debt_notification';
}
