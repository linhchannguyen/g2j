<?php

namespace App\Constants\Globals;

class Integration
{
    const PARTNER = array(
        'AGODA'    => 1,
        'IOT_LINK' => 2,
    );
}