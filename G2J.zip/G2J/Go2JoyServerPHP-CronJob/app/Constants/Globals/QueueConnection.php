<?php

namespace App\Constants\Globals;

class QueueConnection
{
    const LOGGING = 'logging';
}
