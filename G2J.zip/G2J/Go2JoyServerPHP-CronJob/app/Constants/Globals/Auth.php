<?php

namespace App\Constants\Globals;

class Auth
{
    const DEVICE_ENCODE = 'Device-Encode';
    const SECRET_CODE = 'Secret-Code';
    const SECRET_KEY = 'SECRET_KEY_V1';
    const GROUP_NONE = 0;
    const GROUP_SUPER_ADMIN = 1;
    const GROUP_HOTEL = 2;
    const GROUP_USER = 3;
    const SCOPE = array(
        'WEB'         => 'web',
        'MOBILE'      => 'mobile',
        'WEB-BOOKING' => 'web-booking',
        'PARTNER'     => 'partner',
    );
    const SCOPE_DEVICE = array(
        'USERS'    => 'users',
        'PARTNERS' => 'partners',
    );
    const FIELD = array(
        'EMAIL'        => 0,
        'NICK_NAME'    => 1,
        'PHONE_NUMBER' => 2,
    );
    const MSG = 'auth';
    const UNAUTHORIZED = 401;
    const ERR_MOBILE_USE_FOR_SOCIAL = 11;
    const ERR_MOBILE_NOT_EXIST = 12;
}
