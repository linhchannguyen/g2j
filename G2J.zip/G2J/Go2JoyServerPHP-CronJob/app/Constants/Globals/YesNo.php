<?php

namespace App\Constants\Globals;

class YesNo
{
    const NO  = 0;
    const YES = 1;
}
