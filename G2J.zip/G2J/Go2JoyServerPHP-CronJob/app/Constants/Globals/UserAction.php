<?php

namespace App\Constants\Globals;

class UserAction
{
    const DID_NOT_CAME = 0;
    const CAME = 1;
    const NOT_YET = 2;
}
