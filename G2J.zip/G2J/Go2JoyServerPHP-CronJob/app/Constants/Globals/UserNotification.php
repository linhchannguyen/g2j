<?php


namespace App\Constants\Globals;


class UserNotification
{
    const TYPE = array(
        'BOOKING' => 1,
        'PROMOTION' => 2,
        'OTHER' => 3
    );

    const MGS_NOTIFICATION = 'mobile/notification';
    const MGS_HOTEL_NOTIFICATION = 'ha/notification';
    const PREFIX_CONTENT = 'content_';



}
