<?php

namespace App\Constants\Globals;

class Tracking
{
    const ROOM_PLAN = [
        'REGULAR'    => 1,
        'FLASH_SALE' => 2,
    ];
    const ROOM_PLAN_STR = [
        1 => 'Regular',
        2 => 'Flash Sales',
    ];
}