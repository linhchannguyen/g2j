<?php

namespace App\Constants\Globals;

class Type
{
    const TYPE = [
        'CHECKIN' => 1,
    ];
}
