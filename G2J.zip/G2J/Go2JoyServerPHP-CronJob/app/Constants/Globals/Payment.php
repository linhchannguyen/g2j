<?php

namespace App\Constants\Globals;

class Payment
{
    const KEY_MAP_NAME = 'payment123InfoForm';

    const KEY_MAP_NAME_ZALO_PAY = 'zaloPayInfoForm';

    //OnePay
    const KEY_MAP_NAME_ONE_PAY = 'onepayInfoForm';
    const OK = '0';
    const FAILED = '-1';

    //Payoo
    const KEY_MAP_NAME_PAYOO = 'payooInfoForm';

    //MoMo
    const KEY_MAP_NAME_MOMO = 'momoInfoForm';

    //EPay-VNPT
    const KEY_MAP_NAME_E_PAY = 'ePayInfoForm';

    //ShopeePay
    const KEY_MAP_NAME_SHOPEEPAY = 'shopeePayInfoForm';

    const BANK = array(
        'MOMO' => 'MoMo',
    );

    const SUCCESS = array(
        'MOMO'      => 0,
        'PAYOO'     => 0,
        'ONEPAY'    => 0,
        'SHOPEEPAY' => 0,
        'EPAY'      => '00_000',
        'ZALO_PAY'  => 3,
    );

    const TYPE_REQUEST = array(
        'REQUEST' => 'captureMoMoWallet',
        'CHECK'   => 'transactionStatus',
    );

    const PLATFORM = [
        'APP' => 1,
        'WEB' => 2,
    ];

    const PAYMENT_PROVIDER = [
        'ONE_PAY'    => 1,
        'PAYOO'      => 2,
        'MOMO'       => 3,
        'EPAY'       => 4,
        'SHOPEE_PAY' => 5,
        'ZALO_PAY'   => 6,
    ];

    const PAYMENT_STATUS = [
        'AWAITING'   => 0,
        'SUCCESSFUL' => 1,
        'FAILED'     => 2,
        'REFUNDED'   => 3,
    ];

    const GO2JOY = 'GO2JOY';

    #region MoMo
    const MOMO_AIOV2_REQUEST_TYPE = [
        'CAPTURE_WALLET' => 'captureWallet'
    ];

    const MOMO_AIOV2_ERROR_CODE = [
        'SUCCESSFUL'                     => 0,
        'TRANSACTION_DENIED_BY_USER'     => 1006,
        'TRANSACTION_HAS_BEEN_INITIATED' => 1000,
    ];
    #endregion MoMo

    #region EPay
    const EPAY_AIOV2_ERROR_CODE = [
        'SUCCESSFUL' => '00_000',
        'PENDING'    => 99,
    ];

    const EPAY_AIOV2_STATUS = [
        'TRANSACTION_NOT_FOUND' => -1,
        'PAYMENT'               => 0,
        'VOID'                  => 1,
        'REFUND'                => 2,
    ];
    #endregion EPay

    #region ShopeePay
    const SHOPEE_PAY_CODE = [
        'SUCCESSFUL' => 0,
        'ORDER_CALL_BACK_STATUS_SUCCESS' => 20,
        'ORDER_CALL_BACK_STATUS_PROCESSING' => 20,
        'ORDER_VALIDITY_SUCCESS' => 200,
        'ORDER_VALIDITY_BAD_REQUEST' => 400
    ];

    const SHOPEE_PAY_ORDER_STATUS = [
        'SUCCESSFUL' => 20,
        'AWAITING'   => 10,
    ];
    #endregion ShopeePay

    #region ZaloPay
    const ZALO_PAY_RETURN_CODE = array(
        'SUCCESS'    => '1',
        'FAIL'       => '2',
        'PROCESSING' => '3',
    );

    const ZALO_PAY_SUB_RETURN_CODE = array(
        'EXCEPTION'  => '0',
        'SUCCESSFUL' => '1',
    );
    #endregion ZaloPay
}
