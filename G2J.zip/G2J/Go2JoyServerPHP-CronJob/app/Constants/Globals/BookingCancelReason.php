<?php

namespace App\Constants\Globals;

class BookingCancelReason
{
    const FILTER = array(
        'GO2JOY' => 1,
        'USER'   => 2,
        'HOTEL'  => 3,
        'OTHER'  => 4,
        'SYSTEM' => 5,
    );
    const STATUS = array(
        'INACTIVE' => 0,
        'ACTIVE'   => 1,
    );
}