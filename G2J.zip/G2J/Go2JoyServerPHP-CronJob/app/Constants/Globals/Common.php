<?php

namespace App\Constants\Globals;

class Common
{
    const FILE_MESSAGE_LANGUAGE_NAME = 'messages';
    const FORMAT_NUMBER_COMMA_SEPARATED = '#,##0';
    const START_TIME_OF_DATE = '00:00:00';
    const END_TIME_OF_DATE = '23:59:59';
    const ALL_COLUMN = ['*'];
    const VERIFY_CODE = 1;
    const MIN_MEMBER_ID = 1000000;
    const COUNTRY_CODE_VN = "84";
    const MAIL_SUPPORT_GO2JOY = "support@go2joy.vn";

    const VIEW = array(
        'PROMOTION'          => 1,
        'INVITE_FRIEND'      => 2,
        'EVENT'              => 3,
        'HOTEL'              => 4,
        'NOTICE'             => 5,
        'LINK'               => 6,
        'AREA'               => 7,
        'MILEAGE_POINT'      => 8,
        'COUPON'             => 9,
        'DIRECT_DISCOUNT'    => 10,
        'PROMOTION_GROUP'    => 11,
        'AMENITY_PACK_HOTEL' => 12,
        'G2J_CERTIFIED'      => 13,
        'TET'                => 105,
        'REFERRAL_PROGRAM'   => 106,
        'LINK_IN_APP'        => 61,
        'IMAGE_ADS'          => 107
    );
    const TARGET = array(
        'PROMOTION'          => 1,
        'HOTEL'              => 2,
        'NOTICE'             => 3,
        'LINK'               => 4,
        'AREA'               => 5,
        'MILEAGE_POINT'      => 6,
        'COUPON'             => 7,
        'DIRECT_DISCOUNT'    => 8,
        'INVITE_FRIEND'      => 9,
        'PROMOTION_GROUP'    => 10,
        'AMENITY_PACK_HOTEL' => 12,
        'G2J_CERTIFIED'      => 13,
        'TET'                => 105,
        'REFERRAL_PROGRAM'   => 106,
        'LINK_IN_APP'        => 61,
        'IMAGE_ADS'          => 107

    );
    const APPLY_TARGET = array(
        'ALL'             => 1,
        'ALL_BUT_EXCLUDE' => 2,
        'JUST_APPLY'      => 3,
    );
    const APPLY_FAQ = array(
        'ALL'        => 1,
        'CONTRACTED' => 2,
        'TRIAL'      => 3,
        'APPLY'      => 4,
    );
    const LIMIT_50000 = 50000;
    const LIMIT_15000 = 15000;
    const LIMIT_5000 = 5000;
    const LIMIT_1000 = 1000;
    const LIMIT_500 = 500;
    const LIMIT_100 = 100;
    const LIMIT_50 = 50;
    const LIMIT_10 = 10;
    const LIMIT_0 = 0;
    const UNLIMITED = -1;
    const LIMIT_ALL = 25;
    const LIMIT_FS = 50;
    const DISTANCE = 0;
    const PRICE_ASC = 1;
    const PRICE_DESC = 2;
    const NUM_REVIEW = 3;
    const UNIT_KILOMET = 'K';
    const UNIT_UNIT_METER = 'M';
    const BONUS_MIDDLE = 5000000;
    const BONUS_MAX = 10000000;
    const STATUS = array(
        'STS_DELETE'         => 0,
        'STS_ACTIVE'         => 1,
        'STS_EXPIRE'         => 2,
        'STS_NOTYET'         => 3,
        'STS_DRAFT'          => 4,
        'STS_WAIT_CONFIRMED' => 5,
    );
    const LANG = array(
        'vi' => 'vi',
        'en' => 'en',
    );
    const COMMON = 'common';
    const GO2JOY = 1;
    const PARTNER = 2;
    const DISPLAY = array(
        'NO_DISPLAY' => 0,
        'DISPLAY'    => 1,
    );
    const PROMOTION_EXPORT_FIELD = array(
        Code::API_PRN_040,
        Code::API_PRN_041,
        Code::API_PRN_042,
        Code::API_PRN_047,
        Code::API_PRN_048,
        Code::API_PRN_049,
        Code::API_PRN_050,
    );
}
