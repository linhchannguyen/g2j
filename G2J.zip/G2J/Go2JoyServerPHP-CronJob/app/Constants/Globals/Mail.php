<?php

namespace App\Constants\Globals;

class Mail
{
    const SUPPORT_MAIL_ADDRESS = 'support@go2joy.vn';
    const MSG = 'mail';
    const MAIL_PAYMENT = 1;
    const MAIL_BOOKING = 2;
    const MAIL_FORGOT_PASSWORD = 3;
    const MAIL_EXPORT = 4;
    const MAIL_FAQ = 5;
    const MAIL_VERIFY = 6;

    const TITLE_NEW_BOOKING = 'titleNewBooking';
    const TITLE_UPDATE_BOOKING = 'titleUpdateBooking';
    const TITLE_CHECKIN_LOCATION = 'titleCheckinLocation';
    const TITLE_NOSHOW_LOCATION = 'titleNoshowLocation';
    const TITLE_NOSHOW_L = 'titleNoshowL';
    const TITLE_MAIL_CONFIRM_BOOKING_V2 = 'titleMailConfirmBookingV2';
    const TITLE_MAIL_CONFIRM_BOOKING = 'titleMailConfirmBooking';
    const TITLE_MAIL_CANCEL_BOOKING = 'titleMailCancelBooking';
    const TITLE_CANCEL_BOOKING_TO_HA = 'titleCancelBookingToHA';
    const TITLE_CANCEL_BOOKING_TO_PORTAL = 'titleCancelBookingToPortal';
    const TITLE_LOCK_ROOM = 'titleLockRoom';

    const TITLE_MAIL_WAITING_CHECKIN_BOOKING_FOR_HOTEL = 'titleMailWaitingCheckinBookingForHotel';
    const TITLE_MAIL_CANCEL_BOOKING_FOR_HOTEL = 'titleMailCancelBookingForHotel';
    const TITLE_MAIL_COMPLETED_BOOKING_FOR_HOTEL = 'titleMailCompletedBookingForHotel';
    //
    const TITLE_MAIL_CANCEL_BOOKING_FOR_GO2JOY_CS = 'titleMailCancelBookingForGo2JoyCS';
    const TITLE_MAIL_NO_SHOW_BOOKING_FOR_GO2JOY_CS = 'titleMailNoShowBookingForGo2JoyCS';
}
