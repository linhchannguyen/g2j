<?php

namespace App\Constants\Globals;

class FcmNotification
{
    const NOTI_TOPUP = 1;
    const NOTI_EXPIRE_COUPON = 2;
    const NOTI_ANSWER_COUNSELING = 3;
    const NOTI_USER_BOOKING = 4;
    const NOTI_DONATE_COUPON = 5;
    const NOTI_FLASHSALE = 9;
    const NOTI_NEW_COUPON_ISSUED = 10;
    const NOTI_NEW_COUNSELING = 11;
    const NOTI_STAMP = 12;
    const NOTI_EXPIRED_COUPON_ISSUED = 13;
    const NOTI_NEW_OWNER_USER_BOOKING = 14;
    const NOTI_CHECKIN_BOOKING = 15;
    const NOTI_FS_30_MINS = 50;
    const NOTI_FS_45_MINS_AT_HOTEL = 51;
    //const NOTI_FS_45_MINS_OTHER_BOOKING = 52;
    const NOTI_MILEAGE_POINT = 60;
    const NOTI_OPEN_APP = 61;
    const NOTI_DIRECT_DISCOUNT = 62;
    const NOTI_PROMOTION = 63;
    const NOTI_PROMOTION_GROUP = 630;
    const NOTI_HOTEL = 64;
    const NOTI_APP_NOTICE = 65;
    const NOTI_AGREEMENT_POLICY = 66;
    const NOTI_FAQ = 67;
    const NOTI_FAQ_ANSWER = 671;
    const NOTI_INVITE_FRIEND = 68;
    const NOTI_SIGNUP = 69;
    const NOTI_AMENITY_PACK = 101;
    const NOTI_STORE_EXPIRED = 52;
    const NOTI_G2J_CERTIFIED = 102;
    const NOTI_INSTALL_APP = 103;
    const NOTI_STAMP_REMIND = 104;
    const NOTI_TET = 105;
    const NOTI_REFERRAL_PROGRAM = 106;
    const NOTI_HOTEL_RECONCILIATION = 107;
    const NOTI_UPDATE_VERSION = 108;
    const NOT_VIEW_NOTIFICATION = [61, 62, 64, 66, 52, 101, 69, 9, 63, 65, 68, 630, 103];
    const CATEGORY_NOTIFICATION = array(
        'BOOKING'   => [4, 14, 15, 52, 104],
        'PROMOTION' => [5, 9, 10, 13, 63, 68, 630],
        'OTHER'     => [1, 3, 11, 12, 61, 64, 65, 60, 62, 101, 102, 103, 69, 105, 106],
    );
    const PREFIX_FS = 'FS';
    const TITLE_STAMP_SUSPEND = 'notification_stamp_finish';
    const TITLE_STAMP_RESTART = 'notification_stamp_open_again';
    #Your reservation has been cancelled due to hotel room unavailability
    const TITLE_REJECT_RESERVATION = 'notification_rejectReservation';
    #You have a reservation confirm
    const TITLE_ACCEPT_RESERVATION = 'notification_acceptReservation';
    #Service Agreement has just been updated.
    const TITLE_CHEKIN = 'msg_6_3_1_check_in_successful';
    #Booking is expired store
    const TITLE_EXPIRED_STORE_BOOKING = 'fs_expired_booking_other_booking';
}
