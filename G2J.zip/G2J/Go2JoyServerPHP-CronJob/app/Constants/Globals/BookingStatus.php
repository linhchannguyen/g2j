<?php

namespace App\Constants\Globals;

class BookingStatus
{
    const ALL                        = 0;
    const PENDING_PAYMENT            = 1; // BOOKING_STATUS = 5
    const AWAITING_CONFIRMATION      = 2; // BOOKING_STATUS = 6
    const AWAITING_CHECKIN           = 3; // BOOKING_STATUS = 1
    const CANCELLED                  = 4; // BOOKING_STATUS = 3
    const PAYMENT_FAILED             = 5; // BOOKING_STATUS = 0
    const NO_SHOW                    = 6; // BOOKING_STATUS = 4
    const AWAITING_GO2JOY_PROCESSING = 7; // BOOKING_STATUS = 8
    const COMPLETED                  = 8; // BOOKING_STATUS = 2
    const RECEIVED                   = 9; // BOOKING_STATUS = 9
    const AWAITING_USER_CONFIRMATION = 10; // BOOKING_STATUS = 10
}
