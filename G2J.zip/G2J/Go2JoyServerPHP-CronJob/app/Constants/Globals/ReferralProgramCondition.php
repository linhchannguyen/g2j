<?php

namespace App\Constants\Globals;

class ReferralProgramCondition
{
    const TYPE_APPLY = [
        'REFERRER' => 1,
        'REFEREE'  => 2,
    ];
    const CONDITION_KEY = [
        'CHECKIN'           => "CHECKIN",
        'MONTH'             => "MONTH",
        'CONSECUTIVE_MONTH' => "CONSECUTIVE_MONTH",
    ];
}