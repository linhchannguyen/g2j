<?php

namespace App\Constants\Globals;

class Flag
{
    const DELETE = 1;
    const ADD    = 2;
    const UPDATE = 3;
    const SKIP   = 4;
}
