<?php

namespace App\Constants\Globals;

class Message
{
    /** Validation message for request **/
    const ONLY_ADMIN_STAFF                     = 'The selected :attribute must be with values of role admin staff.';
    const ONLY_HOTEL_STAFF                     = 'The selected :attribute must be with values of role hotel staff.';
    const VERIFY_PASSWORD                      = 'The selected :attribute is not matched.';
    const INVALID_DAYS_IN_BETWEEN              = 'The selected :attribute and :other must be days in between :min - :max.';
    const INVALID_MONTHS_IN_BETWEEN            = 'The selected :attribute and :other must be months in between :min - :max.';
    const NOT_BELONGS_TO                       = 'The selected :attribute not belongs to the :other.';
    const NOT_OWNER_OF                         = 'The selected :attribute not the owner of the :other.';
    const SORTED_ON_FIELD_NOT_ALLOWED          = 'The sorted on :field is not allowed.';
    const INVALID_VALUE_IN_FIELD               = 'The selected :field is invalid.';

    /** Response message for response **/
    const SUCCESS                                               = 'All went well, and (usually) some data was returned.';
    const FAIL                                                  = 'There was a problem with the data submitted, or some pre-condition of the API call wasn\'t satisfied.';
    const ERROR                                                 = 'An error occurred in processing the request.';
    const NO_RESOURCE_WAS_FOUND                                 = 'No resource was found.';
    const UNHANDLED_ROUTES                                      = '404 not found. If the problem still persists, contact support@go2joy.vn.';
    const PERMISSION_DENIED                                     = 'Permission denied.';
    const ONE_HOTEL_ONE_ADMIN                                   = 'Every hotel just has one hotel admin.';
    const ONE_HOTEL_GROUP_ONE_ADMIN                             = 'Every hotel group just has one hotel admin.';
    const MAX_NUM_SMS                                           = 'The phone number of the receiving SMS account is over %d.';
    const DEVICE_NOT_EXISTS                                     = 'Mobile device is not exists in server.';
    const WEB_DEVICE_NOT_EXISTS                                 = 'Unknown device';
    const INVALID_EMAIL                                         = 'Email is invalid.';
    const INVALID_MOBILE                                        = 'Mobile is invalid.';
    const OVERNIGHT_PRICE_MUST_BE_GREATER_THAN_FLASH_SALE_PRICE = 'Overnight price must be greater than Flash Sale price.';
    const ALREADY_EXISTS_IN_DATABASE                            = 'Failed processing request. The resource already exists.';
    const CAN_NOT_SET_TO_CURRENT_VALUE                          = 'Failed processing request. The resource can\'t set to currently value.';
    const HAVE_TO_CONFIRM_SALE_INCENTIVE_BEFORE_CONTINUING      = 'You have to confirm sale incentive before continuing.';
    const CAN_NOT_SAVE_A_NEW_SALE_INCENTIVE_HISTORY_IN_THE_PAST = 'You can\'t save a new sale incentive history in the past.';
    const PERIOD_DEBT_TIME_INVALID                              = 'Period debt time entered invalid, please choose right date.';
    const MUST_HAVE_CREATE_HOTEL_DEBT_BEFORE                    = 'Must have create hotel debt before.';
    const INVALID_FILE_TYPE                                     = 'Wrong file type. Please select correct file type.';
    const INVALID_VALUE                                         = 'The value is invalid.';
    const INVALID_DATE_FORMAT                                   = 'The date format is invalid.';
    const ONLY_CONTRACTED_OR_TRIAL_HOTEL                        = 'Only can create staff for contracted or trial hotel.';
    const DATE_MUST_AFTER_OR_EQUAL_NOW                          = 'The date selected must be a date before or equal to now.';
    const HOTEL_MUST_BE_AT_LEAST_ONE_FIRST_DISPLAY_IMAGE        = 'Hotel must be at least one home image.';
    const UPLOAD_FILE_MUST_BE_LEAST_TWO_IMAGE                   = 'Please upload at least 2 hotel images.';
    const USER_ID_EXIST                                         = 'User is exist in system.';
    const INVALID_VERIFY_CODE                                   = 'Verify Code is invalid.';
    const INVALID_MOBILE_VERIFY                                 = 'The phone number to receive the verification code does not exist';

    const MSG_MOBILE_USER         = 'mobile/user';
    const MSG_MOBILE_USER_BOOKING = 'mobile/userBooking';
    const MSG_MOBILE_PROMOTION    = 'mobile/promotion';
    const MSG_WEB_USER            = 'webBooking/user';
    const MSG_MOBILE_REFERRAL     = 'mobile/referralProgram';
    const MSG_MOBILE_VOUCHER      = 'voucherCode';
    const MSG_WEB_HA_USER_BOOKING = 'ha/userBooking';
    const MSG_WEB_HA_ROOM_TYPE    = 'ha/roomType';
    const MSG_WEB_SA_USER_BOOKING = 'sa/userBooking';
    const MSG_WEB_SA_ROOM_TYPE    = 'sa/roomType';
    const MSG_MOBILE_REVIEW       = 'mobile/review';
    const MSG_MOBILE_SMS          = 'mobile/sms';
    const MSG_WEB_HA_SMS          = 'ha/sms';
    const MSG_COMMON              = 'common';

    const PAYMENT_FAILED               = 'Payment failed!';
    const INVALID_OTP_CODE             = 'OTP code is invalid.';
    const ACCOUNT_NOT_EXISTS           = 'Account doesn\'t exist.';
    const VERIFY_OTP_IS_REQUIRED       = 'Verify OTP is required';
    const USER_ID_OR_PASSWORD_IS_WRONG = 'User id or password is wrong.';
    const MSG_WEB_SA_SMS          = 'sa/sms';
}
