<?php

namespace App\Constants\Globals;

class Requester
{
    const WEB_APP = 'web-app';
    const MOBILE_APP = 'mobile-app';
    const WEB_SERVICE = 'web-service';
}
