<?php

namespace App\Constants;

class BannerSetting
{
    const TYPE = array(
        'APP'         => 1,
        'WEB'         => 2,
        'HOTEL_ADMIN' => 3,
    );
}
