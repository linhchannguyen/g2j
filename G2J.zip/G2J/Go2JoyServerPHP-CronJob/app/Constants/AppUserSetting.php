<?php

namespace App\Constants;

class AppUserSetting
{
    const LANG = array(
        'KO' => 1,
        'EN' => 2,
        'VI' => 3,
    );

    const TYPE_NOTIFICATION = array(
        'NONE'       => 0,
        'FLASH_SALE' => 1,
        'BOOKING'    => 2,
    );

}
