<?php

namespace App\Constants;

class HotelProduct
{
    const STATUS = array(
        'DELETED'      => 0,
        'ACTIVE'       => 1,
        'EXPIRED'      => 2,
        'TEMP'         => 3,
        'DRAFT'        => 4,
        'WAIT_CONFIRM' => 5,
    );
}
