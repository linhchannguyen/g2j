<?php

namespace App\Constants;

class BookingCancelReasonDetail
{
    const CANCEL_USER_TYPE = array(
        'STAFF' => 1,
        'USER'  => 2,
        'HOTEL' => 3
    );
}