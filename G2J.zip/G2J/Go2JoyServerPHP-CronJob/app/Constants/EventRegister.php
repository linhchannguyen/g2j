<?php


namespace App\Constants;


class EventRegister
{
    const WINNER = array(
        'NOT_WINNER' => 0,
        'WINNER' => 1,
        'ALL' => 2,
    );
}
