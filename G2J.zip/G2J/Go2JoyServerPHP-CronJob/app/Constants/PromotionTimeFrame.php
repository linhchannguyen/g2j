<?php

namespace App\Constants;

class PromotionTimeFrame
{
    const IS_APPLY = array(
        'TRUE'  => 1,
        'FALSE' => 0,
    );
}