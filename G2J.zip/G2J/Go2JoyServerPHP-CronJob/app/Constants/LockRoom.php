<?php

namespace App\Constants;

class LockRoom
{
    const LOCK = array(
        'NONE'      => 0,
        'DUPLICATE' => 1,
        'OVERLAP'   => 2,
        'INCLUDED'  => 3,
    );

    const STATUS = array(
        'DELETED' => 0,
        'CREATED'  => 1,
    );
    const STATUS_LOCK = array(
        'ABOUT_TO_LOCK' => 1,
        'LOCKING'       => 2,
    );
}