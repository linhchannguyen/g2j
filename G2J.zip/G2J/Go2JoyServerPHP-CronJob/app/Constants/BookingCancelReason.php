<?php

namespace App\Constants;

class BookingCancelReason
{
    const FILTER = [
        'GO2JOY' => 1,
        'USER'   => 2,
        'HOTEL'  => 3,
        'OTHER'  => 4,
        'SYSTEM' => 5,
    ];
}
