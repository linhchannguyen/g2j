<?php


namespace App\Constants;


class MessageQueue
{
    const SCOPE = array(
    'SCOPE_ALL_USER' =>1,
	'SCOPE_ALL_PARTNER' => 6,
	'SCOPE_GO2JOY' =>7,
	'SCOPE_BIRTHDAY' => 10,
	'SCOPE_ALL_TRIAL' => 11,
	'SCOPE_ALL_CONTRACTED' => 12,
	'SCOPE_FROM_FILE' => 13,
	'SCOPE_STAMP_PROGRAM_SUSPEND' => 15,
	'SCOPE_STAMP_PROGRAM_RESTART' => 16,
	'SCOPE_FLASH_SALE' => 18,
	'SCOPE_CRM_FILTER' => 19,
	'SCOPE_EXPIRE_COUPON' => 20,
    'SCOPE_ONE_USER' => 21,
    );

    const PRIORITY = array(
        'PRIORITY_LOW' => 1,
        'PRIORITY_HIGH' => 2,
    );

}
