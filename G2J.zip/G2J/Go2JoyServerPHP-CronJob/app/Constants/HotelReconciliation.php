<?php

namespace App\Constants;

class HotelReconciliation
{
    const STATUS = [
        'INACTIVE' => 0,
        'ACTIVE'   => 1,
    ];
}
