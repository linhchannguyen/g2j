<?php

namespace App\Constants;

class AppUser
{
    const MOBILE_DEFAULT = '0000000000';
    const EMAIL_DEFAULT = 'g2j_mail_default@go2joy.com';
    const VN_COUNTRY_CODE = '84';
    const VN_CODE = 'VN';
    const AGE_DEFAULT = 18;
    const PREFIX_SIGN_UP_APPLE = '0004';
    const PREFIX_NICK_NAME ='User';
    const VERSION_IOS_HAVE_APPLE_ID = 13;
    const VERSION_IOS_REJECT_MOBILE = '14.8.0';

    const STATUS = array(
        'DELETED' => 0,
        'ACTIVE'  => 1,
        'LOCKED'  => 2,
    );
    const GENDER_STR = array(
        0 => 'Undefined',
        1 => 'Male',
        2 => 'Female',
    );
    const GENDER = array(
        'UNDEFINED' => 0,
        'MALE'      => 1,
        'FEMALE'    => 2,
    );
    const AREA_CODE = array(
        'VN' => 84,
        'KO' => 82,
    );
    const SMS_FLAG = array(
        'ACTIVE'   => 1,
        'INACTIVE' => 0,
    );
    const REGISTER_BY = array(
        'MOBILE_DEVICE' => 1,
        'WEB_DEVICE'    => 2,
    );
    const SMS_TYPE = array(
        'SMS'   => 0,
        'VOICE' => 1,
    );
    const TYPE_INVITE = array(
        'NONE'          => 0,
        'INVITE_FRIEND' => 1,
        'HOTEL_INVITE'  => 2,
        'PGPB_INVITE'   => 3,
    );
    const PREFIX_INVITE = array(
        'HOTEL_INVITE' => 'HTL',
        'PGPB_INVITE'  => 'PBPG-',
    );
    const USER_PREFIX = array(
        //        'MANUAL'   => 1,
        'FACEBOOK' => 1,
        'GOOGLE'   => 2,
        'APPLE'    => 3,
    );
    const VIA_APP = array(
        'MANUAL'   => 1,
        'FACEBOOK' => 2,
        'GOOGLE'   => 3,
        'APPLE'    => 4,
    );
    const UPDATE_TYPE = array(
        'BOOKING' => 1,
        'CHECKIN' => 2,
    );
    const SOURCE = array(
        'UNDEFINED'             => 0,
        'ORGANIC'               => 1,
        'ADCASH'                => 2,
        'ADGATE_MEDIA'          => 3,
        'AMBIENT'               => 4,
        'APPIER'                => 5,
        'APP_SAMURAI'           => 6,
        'APPNEXT'               => 7,
        'AWING'                 => 8,
        'DABLE'                 => 9,
        'FACEBOOK'              => 10,
        'GOOGLE_ADS'            => 11,
        'GOOGLE_ORGANIC_SEARCH' => 12,
        'INSTAGRAM'             => 13,
        'MOLOCO'                => 14,
        'OFFLINE'               => 15,
        'ACCESSTRADE'           => 16,
        'SMS_MESSAGE'           => 17,
        'TIKTOK'                => 18,
        'ZALO'                  => 19,
        'ZOOMD'                 => 20,
        'NEWSPAPER'             => 21,
        'UNATTRIBUTED'          => 22,
        'UNTRUSTED_DEVICES'     => 23,
    );
    const TITLE_STR = array(
        0 => 'Undefined',
        1 => 'Mr.',
        2 => 'Ms.',
    );

    const TYPE = array(
        'SIGN_UP'   => 1,
        'SIGN_IN' => 2,
    );


    const MSG = 'appUser';
    const ERR_WRONG_CUR_PASS = 1;
    const ERR_NICK_NAME_EXIST = 2;
    const ERR_EMAIL_EXIST = 3;
    const ERR_MOBILE_EXIST = 4;
    const ERR_DISABLE_ACCOUNT = 5;
    const ERR_DEVICE_BLOCK = 'deviceBlockErr';
    const ERR_MAX_INVITE = 'maxInviteToDayErr';
    const ERR_ACCOUNT_NOT_EXIST = 6;
    const ERR_WRONG_PASS = 7;
    const ERR_SAME_PASS = 8;
    const ERR_REFRESH_TOKEN = 9;
    const ERR_WRONG_LINKED_ACCOUNT = 10;
    const SIGN_IN_APPLE_REJECT_MOBILE = 100;

    const WEB_ERR_MOBILE_REQUIRED = 1;
    const WEB_ERR_MOBILE_ALREADY = 2;
    const WEB_ERR_MOBILE_INVALID = 3;
    const WEB_ERR_EMAIL_REQUIRED = 4;
    const WEB_ERR_EMAIL_ALREADY = 5;
    const WEB_ERR_EMAIL_INVALID = 6;
    const WEB_ERR_NICKNAME_REQUIRED = 7;
    const WEB_ERR_NICKNAME_ALREADY = 8;
    const WEB_ERR_NICKNAME_INVALID = 9;
    const WEB_ERR_PASSWORD_REQUIRED = 10;
    const WEB_ERR_MOBILE_OR_EMAIL_REQUIRED = 11;
    const WEB_ERR_USER_ID_ALREADY = 12;
    const WEB_ERR_USER_ID_NOT_EXISTS = 13;
    const WEB_ERR_MOBILE_NOT_EXISTS = 14;
    const WEB_ERR_WAIT_MORE = 15;
    const WEB_ERR_PLZ_SIGN_IN = 16;
}
