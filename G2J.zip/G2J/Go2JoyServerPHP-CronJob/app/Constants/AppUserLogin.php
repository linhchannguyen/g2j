<?php

namespace App\Constants;

class AppUserLogin
{
    const STATUS = array(
        'INACTIVE' => 0,
        'ACTIVE'   => 1,
    );
}