<?php

namespace App\Constants;

class HotelDebtCreationProgressPopup
{
    const STATUS = [
        'IN_PROGRESS' => 0,
        'DONE'        => 1,
    ];
}
