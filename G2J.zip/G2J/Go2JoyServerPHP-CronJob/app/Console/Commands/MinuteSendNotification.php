<?php

namespace App\Console\Commands;

use App\Constants\AppNotification as AppNotificationConst;
use App\Constants\Coupon as CouponConst;
use App\Constants\Globals\FcmNotification as FcmNotificationConst;
use App\Constants\Globals\Pagination;
use App\Constants\Globals\QueueName;
use App\Constants\Hotel;
use App\Constants\Hotel as HotelConst;
use App\Constants\MessageQueue as MessageQueueConst;
use App\Constants\MobileDevice as MobileDeviceConst;
use App\Helpers\CommonHelper;
use App\Helpers\ConvertHelper;
use App\Helpers\LoggingHelper;
use App\Jobs\Notification\DonateCouponJob;
use App\Libraries\Maatwebsite\Excel\Imports\CrmImport;
use App\Models\AppNotification;
use App\Models\AppNotificationDetail;
use App\Models\Coupon;
use App\Models\CrmFilter;
use App\Models\MessageQueue;
use App\Models\MobileDevice;
use App\Models\Province;
use App\Models\Setting;
use App\Models\UseCondition;
use App\Repositories\Interfaces\AppNotificationDetailRepositoryInterface;
use App\Repositories\Interfaces\AppNotificationRepositoryInterface;
use App\Repositories\Interfaces\MessageLogRepositoryInterface;
use App\Repositories\MySQL\AppNotificationRepository;
use App\Repositories\MySQL\MessageQueueRepository;
use App\Repositories\MySQL\MobileDeviceRepository;
use App\Services\Common\NotificationService;
use Carbon\Carbon;
use Illuminate\Console\Command;
use Maatwebsite\Excel\Facades\Excel;
use stdClass;

class MinuteSendNotification extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'minute-send-notification';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Cron job send notification each five minute';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    public function handle(NotificationService                      $notificationService,
                           MessageQueueRepository                   $messageQueueRepository,
                           AppNotificationRepository                $appNotificationRepository,
                           MobileDeviceRepository                   $mobileDeviceRepository,
                           AppNotificationDetailRepositoryInterface $appNotificationDetailRepository,
                           MessageLogRepositoryInterface            $messageLogRepository
    ) {
        $minute = Carbon::now()->format("H:i"); // get current minute
        LoggingHelper::logCronJob("Minute cron job send notification running - $minute");
        $this->_handlePushNotification($notificationService, $messageQueueRepository, $appNotificationRepository, $mobileDeviceRepository, $appNotificationDetailRepository, $messageLogRepository);
    }

    private function _handlePushNotification(NotificationService                      $notificationService,
                                             MessageQueueRepository                   $messageQueueRepository,
                                             AppNotificationRepositoryInterface       $appNotificationRepository,
                                             MobileDeviceRepository                   $mobileDeviceRepository,
                                             AppNotificationDetailRepositoryInterface $appNotificationDetailRepository,
                                             MessageLogRepositoryInterface            $messageLogRepository
    ) {
        $messageQueueList = $this->_findMessageQueueList($messageQueueRepository);
        foreach ($messageQueueList as $messageQueue) {
            $messageQueueRepository->lockMessageQueue($messageQueue->{MessageQueue::COL_SN});
            if (!empty($messageQueue->{MessageQueue::COL_APP_NOTIFICATION_SN})) {
                $appNotificationRepository->updateAppNotificationStatus($messageQueue->{MessageQueue::COL_APP_NOTIFICATION_SN}, AppNotificationConst::STATUS['RUNNING']);
            }
            $this->_sendNotification($messageQueue, $notificationService, $appNotificationRepository, $mobileDeviceRepository, $appNotificationDetailRepository);
            LoggingHelper::logJobQueue('DONE MINUTE JOB SEND NOTIFICATION', json_encode($messageQueue));
            $messageQueueRepository->delete($messageQueue->{MessageQueue::COL_SN}, MessageQueue::COL_SN);
        }
    }

    private function _findMessageQueueList(MessageQueueRepository $messageQueueRepository)
    {
        $messageQueueList = $messageQueueRepository->findPriorityMessageQueueList(MessageQueueConst::PRIORITY['PRIORITY_HIGH']);
        if (count($messageQueueList) > 0) {
            return $messageQueueList;
        }
        $messageQueueList = $messageQueueRepository->findPriorityMessageQueueList(MessageQueueConst::PRIORITY['PRIORITY_LOW']);
        if (count($messageQueueList) > 0) {
            return $messageQueueList;
        }

        return [];
    }

    private function _sendNotification($messageQueue,
                                       $notificationService,
                                       $appNotificationRepository,
                                       $mobileDeviceRepository,
                                       $appNotificationDetailRepository
    ) {
        if (MessageQueueConst::SCOPE['SCOPE_ALL_USER'] == $messageQueue->{MessageQueue::COL_SCOPE} || MessageQueueConst::SCOPE['SCOPE_FLASH_SALE'] == $messageQueue->{MessageQueue::COL_SCOPE}) {
            $this->_sendTopicNotification($messageQueue, $notificationService, $appNotificationRepository);
        } else {
            $this->_sendNonTopicNotification($messageQueue, $notificationService, $mobileDeviceRepository, $appNotificationRepository, $appNotificationDetailRepository);
        }
    }

    private function _sendTopicNotification($messageQueue, $notificationService, $appNotificationRepository)
    {
        $finalMessageLog = new stdClass();
        $provinceSnList = [];
        $isFlashSale = false;
        $fcmNotification = ConvertHelper::toStdClass($messageQueue->{MessageQueue::COL_CONTENT});
        if (MessageQueueConst::SCOPE['SCOPE_ALL_USER'] == $messageQueue->{MessageQueue::COL_SCOPE}) {
            $appNotification = AppNotification::where(AppNotification::COL_SN, $messageQueue->{MessageQueue::COL_APP_NOTIFICATION_SN})->first();
            if (!empty($appNotification)) {
                if ($appNotification->{AppNotification::COL_SEND_TO} == AppNotificationConst::SEND_TO['ALL_USER']) {
                    if ($appNotification->{AppNotification::COL_OPEN_APP} == AppNotificationConst::LAST_TIME_OPEN_APP) {
                        if (!empty($appNotification->{AppNotification::COL_PROVINCE_SN_LIST})) {
                            $provinceSnList = ConvertHelper::toArray($appNotification->{AppNotification::COL_PROVINCE_SN_LIST});
                        }
                    }
                }
            }
        } elseif (MessageQueueConst::SCOPE['SCOPE_FLASH_SALE'] == $messageQueue->{MessageQueue::COL_SCOPE}) {
            $provinceSnList[] = $fcmNotification->provinceSn;
            $isFlashSale = true;
        }
        $condition = $this->_createTopicCondition($provinceSnList, $isFlashSale);
        $finalMessageLog->topic = $condition;
        list($topicId, $notificationId, $typeOs) = $notificationService->generateContentUserNotification(null, null,
            $finalMessageLog->topic, $fcmNotification->title, $fcmNotification->body,
            $fcmNotification->informationList ?? [], $fcmNotification->type, $fcmNotification->sn ?? null,
            $fcmNotification->hotelSn ?? null, false, $fcmNotification->appNotificationSn ?? null);
        $this->_runPushingNotification($finalMessageLog, $fcmNotification, $notificationService, null, $topicId, $notificationId);
        if (!empty($messageQueue->{MessageQueue::COL_APP_NOTIFICATION_SN})) {
            $appNotificationRepository->updateAppNotificationStatus($messageQueue->{MessageQueue::COL_APP_NOTIFICATION_SN}, AppNotificationConst::STATUS['SENT']);
        }
    }

    private function _createTopicCondition($provinceSnList, $isFlashSale)
    {
        $condition = [];
        if (count($provinceSnList) > 0) {
            foreach ($provinceSnList as $provinceSn) {
                $province = Province::where(Province::COL_SN, $provinceSn)->first();
                if (!empty($province)) {
                    $topic = getTopic($province->{Province::COL_CODE});
                    if ($isFlashSale) {
                        $topic = FcmNotificationConst::PREFIX_FS . $topic;
                    }
                    array_push($condition, $topic);
                }
            }
        } else {
            $topic = getTopic(null);
            array_push($condition, $topic);
        }

        return implode(',', $condition);
    }

    private function _runPushingNotification($finalMessageLog,
                                             $fcmNotification,
                                             NotificationService $notificationService,
                                             $os = null,
                                             $topicId = null,
                                             $notificationId = null
    ) {
        if (empty($finalMessageLog->tokenIds) && !empty($finalMessageLog->topic)) {
            $notificationService->sendNotificationToTopics($finalMessageLog->topic, $fcmNotification->title,
                $fcmNotification->body, $fcmNotification->informationList ?? [],
                $fcmNotification->otherInfoList ?? null, $fcmNotification->type, HotelConst::GO2JOY, false,
                $fcmNotification->sn ?? null, $fcmNotification->hotelSn ?? null, $fcmNotification->iconUrl ?? null,
                false, $topicId, $notificationId);
        } elseif (!empty($finalMessageLog->tokenIds) && empty($finalMessageLog->topic)) {
            $notificationService->sendNotificationToDevices(ConvertHelper::toArray($finalMessageLog->tokenIds),
                $fcmNotification->title, $fcmNotification->body, $fcmNotification->informationList ?? [],
                $fcmNotification->otherInfoList ?? null, $fcmNotification->type, HotelConst::GO2JOY,
                $fcmNotification->key, $fcmNotification->sn ?? null, $fcmNotification->hotelSn ?? null,
                $fcmNotification->iconUrl ?? null, $finalMessageLog->type, $topicId, $notificationId, $os);
        }
    }

    private function _sendNonTopicNotification($messageQueue,
                                               $notificationService,
                                               $mobileDeviceRepository,
                                               $appNotificationRepository,
                                               $appNotificationDetailRepository
    ) {
        $fcmNotification = ConvertHelper::toStdClass($messageQueue->{MessageQueue::COL_CONTENT});
        $totalIosSend = 0;
        $totalAndroidSend = 0;
        $finalMessageLog = $this->_newMessageLogForm($messageQueue);
        $appNotification = AppNotification::where(AppNotification::COL_SN, $messageQueue->{MessageQueue::COL_APP_NOTIFICATION_SN})->first();
        if (!empty($appNotification) && $appNotification->{AppNotification::COL_TYPE} == AppNotificationConst::TYPE['DONATE']) {
            $donateJob = new DonateCouponJob($appNotification, $appNotification->{AppNotification::COL_CREATE_STAFF_SN});

            dispatch($donateJob->onQueue(QueueName::DONATES));
            return;
        }
        $mobileDeviceList = $this->_findLimitMobileDeviceList($messageQueue, $fcmNotification, $mobileDeviceRepository);
        if (count($mobileDeviceList) > 0) {
            $mobileSnList = ConvertHelper::EMPTY;
            $tokens = [];
            $tokenListIos = [];
            $tokenListAndroid = [];
            foreach ($mobileDeviceList as $mobileDevice) {
                if (!empty($mobileDevice->{MobileDevice::COL_TOKEN_ID}) && $mobileDevice->{MobileDevice::COL_PUSH_NOTIFICATION} && $mobileDevice->{MobileDevice::COL_STATUS}) {
                    array_push($tokens, $mobileDevice->{MobileDevice::COL_TOKEN_ID});
                    $mobileSnList .= $mobileDevice->{MobileDevice::COL_SN} . ConvertHelper::COMMA;
                    if (!empty($mobileDevice->{MobileDevice::ALIAS_NOTI_ALL})) {
                        if ($mobileDevice->{MobileDevice::COL_OS} == MobileDeviceConst::OS['IOS']) {
                            array_push($tokenListIos, $mobileDevice->{MobileDevice::COL_TOKEN_ID});
                            $totalIosSend++;
                        } else {
                            array_push($tokenListAndroid, $mobileDevice->{MobileDevice::COL_TOKEN_ID});
                            $totalAndroidSend++;
                        }
                    } else {
                        if ($mobileDevice->{MobileDevice::COL_OS} == MobileDeviceConst::OS['IOS']) {
                            $totalIosSend++;
                        } else {
                            $totalAndroidSend++;
                        }
                    }

                }
            }
            //Because the difference in receiving notification data between ios and android is different, we separate tokens into 2 arrays to process data
            //https://firebase.google.com/docs/cloud-messaging/android/receive#kotlin+ktx
            //https://firebase.google.com/docs/cloud-messaging/concept-options#notifications_and_data_messages

            $tokens = array_unique($tokens);

            $tokenListIos = array_unique($tokenListIos);
            $tokenListAndroid = array_unique($tokenListAndroid);
            list($topicId, $notificationId, $typeOs) = $notificationService->generateContentUserNotification(null,
                $tokens, null, $fcmNotification->title, $fcmNotification->body, $fcmNotification->informationList ?? [],
                $fcmNotification->type, $fcmNotification->sn ?? null, $fcmNotification->hotelSn ?? null,
                $fcmNotification->key, $fcmNotification->appNotificationSn ?? null);
            if (count($tokenListIos) > 0) {
                foreach (array_chunk($tokenListIos, 500) as $tokens) {
                    $finalMessageLog->tokenIds = ConvertHelper::toJson($tokens);
                    $finalMessageLog->mobileDeviceSnList = $mobileSnList;
                    $this->_runPushingNotification($finalMessageLog, $fcmNotification, $notificationService, MobileDeviceConst::OS['IOS'], $topicId, $notificationId);
                }
            }

            if (count($tokenListAndroid) > 0) {
                foreach (array_chunk($tokenListAndroid, 500) as $tokens) {
                    $finalMessageLog->tokenIds = ConvertHelper::toJson($tokens);
                    $finalMessageLog->mobileDeviceSnList = $mobileSnList;
                    $this->_runPushingNotification($finalMessageLog, $fcmNotification, $notificationService, MobileDeviceConst::OS['ANDROID'], $topicId, $notificationId);
                }
            }

        }
        if (!empty($messageQueue->{MessageQueue::COL_APP_NOTIFICATION_SN})) {
            $appNotification = AppNotification::where(AppNotification::COL_SN, $messageQueue->{MessageQueue::COL_APP_NOTIFICATION_SN})->first();
            if (!empty($appNotification)) {
                $plusNotification = new AppNotification();
                $plusNotification->setAttribute(AppNotification::COL_SN, $appNotification->{AppNotification::COL_SN});
                $plusNotification->setAttribute(AppNotification::COL_TOTAL_IOS_SEND, $totalIosSend);
                $plusNotification->setAttribute(AppNotification::COL_TOTAL_ANDROID_SEND, $totalAndroidSend);
                $appNotificationRepository->plusNumAppNotification($plusNotification);
                //sẽ được sử dụng nếu mở tính năng lập lịch gửi
                //if (!empty($appNotification->{AppNotification::COL_CRM_FILTER_SN})) {
                //    $appNotificationDetail = $this->_toAppNotificationDetail($appNotification, $totalIosSend, $totalAndroidSend);
                //    $appNotificationDetailRepository->create(ConvertHelper::toArray($appNotificationDetail));
                //    $status = AppNotificationConst::STATUS['SENT'];
                //    //Function will open when create new feature in future
                //    if (AppNotificationConst::STATUS['SENT'] != $appNotification->{AppNotification::COL_STATUS}) {
                //        if ((0 == $appNotification->{AppNotification::COL_NUM_SEND})
                //            || (($appNotification->{AppNotification::COL_COUNT_NUM_SEND} + 1) < $appNotification->{AppNotification::COL_NUM_SEND})) {
                //            $mq = $this->_createMessageQueue($messageQueue,$appNotification);
                //            $messageQueueRepository->create(ConvertHelper::toArray($mq));
                //            $status = AppNotificationConst::STATUS['RUNNING'];
                //        }
                //    }
                //    $appNotificationRepository->updateAppNotificationStatus($messageQueue->{MessageQueue::COL_APP_NOTIFICATION_SN}, $status);
                //} else {
                $appNotificationRepository->updateAppNotificationStatus($messageQueue->{MessageQueue::COL_APP_NOTIFICATION_SN}, AppNotificationConst::STATUS['SENT']);
                //  }
            }
        }
    }

    private function _newMessageLogForm($messageQueue)
    {
        $finalMessageLog = new stdClass();
        $finalMessageLog->content = $messageQueue->{MessageQueue::COL_CONTENT};
        $finalMessageLog->scope = $messageQueue->{MessageQueue::COL_SCOPE};
        if (MessageQueueConst::SCOPE['SCOPE_ALL_PARTNER'] == $finalMessageLog->scope || MessageQueueConst::SCOPE['SCOPE_ALL_TRIAL'] == $finalMessageLog->scope || MessageQueueConst::SCOPE['SCOPE_ALL_CONTRACTED'] == $finalMessageLog->scope) {
            $finalMessageLog->type = true;
        } else {
            $finalMessageLog->type = false;
        }

        return $finalMessageLog;
    }

    private function _findLimitMobileDeviceList($messageQueue, $fcmNotification, $mobileDeviceRepository)
    {
        $mobileDeviceList = [];
        if (MessageQueueConst::SCOPE['SCOPE_ALL_PARTNER'] == $messageQueue->{MessageQueue::COL_SCOPE}) {
            if (FcmNotificationConst::NOTI_PROMOTION == $fcmNotification->type) {
                $coupon = Coupon::where(Coupon::COL_PROMOTION_SN, $fcmNotification->sn)->first();
                if (!empty($coupon)) {
                    $useCondition = UseCondition::where(UseCondition::COL_COUPON_SN,
                        $coupon->{Coupon::COL_SN})->first();
                    if (CouponConst::APPLY['APPLY_ALL'] != $useCondition->{UseCondition::COL_APPLY_TARGET}) {
                        return $mobileDeviceRepository->findLimitMobileDeviceViaCouponList($coupon->{Coupon::COL_SN},
                            $useCondition->{UseCondition::COL_APPLY_TARGET}, Pagination::LIMIT['NO_LIMIT']);
                    }
                }
            }
            $mobileDeviceList = $mobileDeviceRepository->findPartnerMobileDeviceList(null, HotelConst::STATUS['NO_STATUS']);
        } elseif (MessageQueueConst::SCOPE['SCOPE_ALL_TRIAL'] == $messageQueue->{MessageQueue::COL_SCOPE}) {
            $mobileDeviceList = $mobileDeviceRepository->findPartnerMobileDeviceList(null, HotelConst::STATUS['TRIAL']);
        } elseif (MessageQueueConst::SCOPE['SCOPE_ALL_CONTRACTED'] == $messageQueue->{MessageQueue::COL_SCOPE}) {
            $mobileDeviceList = $mobileDeviceRepository->findPartnerMobileDeviceList(null, HotelConst::STATUS['CONTRACTED']);
        } elseif (MessageQueueConst::SCOPE['SCOPE_GO2JOY'] == $messageQueue->{MessageQueue::COL_SCOPE}) {
            $mobileDeviceList = $mobileDeviceRepository->findLimitGroupMemberDeviceList(Pagination::LIMIT['NO_LIMIT']);
        } elseif (MessageQueueConst::SCOPE['SCOPE_BIRTHDAY'] == $messageQueue->{MessageQueue::COL_SCOPE}) {
            $now = Carbon::now();
            $timeCalculate = Carbon::now();
            if (FcmNotificationConst::NOTI_NEW_COUPON_ISSUED == $fcmNotification->type) {
                $month = ($timeCalculate->month) + 1;
                $timeCalculate = $timeCalculate->addMonths(-1);
                $timeCalculate = $timeCalculate->addYears(-1);
                $startDate = $timeCalculate->startOfMonth()->format('Y-m-d');
                $endDate = $timeCalculate->endOfMonth()->format('Y-m-d');
                $mobileDeviceList = $mobileDeviceRepository->findLimitMobileDeviceForBirthday($startDate, $endDate, $month, Pagination::LIMIT['NO_LIMIT']);
            } else {
                $setting = CommonHelper::getHotelSetting('0003', '01');
                $timeCalculate = $timeCalculate->addDays(intval($setting->{Setting::COL_NUMDATA3}));
                $startDate = $timeCalculate->format('Y-m-d');
                $endDate = $now->endOfMonth()->format('Y-m-d');
                $mobileDeviceList = $mobileDeviceRepository->findLimitMobileDeviceViaCouponIssued($startDate, $endDate, $fcmNotification->promotionSn, Pagination::LIMIT['NO_LIMIT']);
            }
        } elseif (MessageQueueConst::SCOPE['SCOPE_FROM_FILE'] == $messageQueue->{MessageQueue::COL_SCOPE}) {
            $appNotification = AppNotification::where(AppNotification::COL_SN, $messageQueue->{MessageQueue::COL_APP_NOTIFICATION_SN})->first();
            if (!empty($appNotification)) {
                $mobileDeviceList = $this->_findLimitMobileDeviceListFromExcelFile($appNotification, $mobileDeviceRepository);
            }
        } elseif (MessageQueueConst::SCOPE['SCOPE_STAMP_PROGRAM_SUSPEND'] == $messageQueue->{MessageQueue::COL_SCOPE}) {
            $mobileDeviceList = $mobileDeviceRepository->findLimitMobileDeviceHaveAtLeastOneStamp($fcmNotification->sn, Pagination::LIMIT['NO_LIMIT']);

        } elseif (MessageQueueConst::SCOPE['SCOPE_STAMP_PROGRAM_RESTART'] == $messageQueue->{MessageQueue::COL_SCOPE}) {
            $mobileDeviceList = $mobileDeviceRepository->findLimitMobileDeviceHaveAtLeastOneStamp($fcmNotification->sn, Pagination::LIMIT['NO_LIMIT']);

        } elseif (MessageQueueConst::SCOPE['SCOPE_CRM_FILTER'] == $messageQueue->{MessageQueue::COL_SCOPE}) {
            $appNotification = AppNotification::where(AppNotification::COL_SN, $messageQueue->{MessageQueue::COL_APP_NOTIFICATION_SN})->first();
            if (!empty($appNotification)) {
                $mobileDeviceList = $this->findLimitNotificationMobileDeviceListViaCrm($mobileDeviceRepository, $appNotification->{AppNotification::COL_SN}, $appNotification->{AppNotification::COL_CRM_FILTER_SN}, Pagination::LIMIT['NO_LIMIT']);
            }
        } elseif (MessageQueueConst::SCOPE['SCOPE_EXPIRE_COUPON'] == $messageQueue->{MessageQueue::COL_SCOPE}) {
            $setting = CommonHelper::getHotelSetting('0003', '02');
            $numDay = intval($setting->{Setting::COL_NUMDATA2});
            $expireDate = Carbon::now()->addDays($numDay)->format('Y-m-d');
            $mobileDeviceList = $mobileDeviceRepository->findLimitCouponExpireMobileDeviceList($expireDate, Pagination::LIMIT['NO_LIMIT']);

        } elseif (MessageQueueConst::SCOPE['SCOPE_ONE_USER'] == $messageQueue->{MessageQueue::COL_SCOPE}) {
            $appNotification = AppNotification::where(AppNotification::COL_SN, $messageQueue->{MessageQueue::COL_APP_NOTIFICATION_SN})->first();
            if (!empty($appNotification)) {
                $mobileDeviceList = $mobileDeviceRepository->findAllMobileDeviceListViaAppUser($appNotification->{AppNotification::COL_APP_USER_SN}, Pagination::LIMIT['NO_LIMIT']);
            }
        }

        return $mobileDeviceList;
    }

    private function _findLimitMobileDeviceListFromExcelFile($appNotification, $mobileDeviceRepository)
    {
        $mobileDeviceList = [];
        if (!empty($appNotification->{AppNotification::COL_FILE_PATH})) {
            $crmImport = new CrmImport();
            Excel::import($crmImport, $appNotification->{AppNotification::COL_FILE_PATH}, 's3');
            $userSnList = array_values(array_diff($crmImport->snList, [null]));
            foreach (array_chunk($userSnList, 500) as $chunkUserList) {
                $chunkMobileDeviceList = $mobileDeviceRepository->findAllMobileDeviceListViaListAppUser($chunkUserList, Pagination::LIMIT['LIMIT_500']);
                $mobileDeviceList = array_merge($mobileDeviceList, $chunkMobileDeviceList->items());
            }
        }

        return $mobileDeviceList;
    }

    /**
     * @param $mobileDeviceRepository
     * @param $appNotificationSn
     * @param $crmFilterSn
     * @param $limit
     *
     * @return array
     */
    private function findLimitNotificationMobileDeviceListViaCrm($mobileDeviceRepository,
                                                                 $appNotificationSn,
                                                                 $crmFilterSn,
                                                                 $limit
    ) {
        $mobileDeviceList = [];
        $crmFilter = CrmFilter::where(CrmFilter::COL_SN, $crmFilterSn)->first();
        if (empty($crmFilter)) {
            return $mobileDeviceList;
        }
        $userList = ConvertHelper::toArray($crmFilter->{CrmFilter::COL_USER_LIST});
        //$deviceConversionList = DeviceConversion::where(DeviceConversion::COL_APP_NOTIFICATION_SN, $appNotificationSn)->get();

        $mobileDeviceList = $mobileDeviceRepository->findLimitNotificationMobileDeviceListViaCrm($userList, null, Pagination::LIMIT['NO_LIMIT']);

        return $mobileDeviceList;
    }

    private function _toAppNotificationDetail($appNotification, $totalIosSend, $totalAndroidSend)
    {
        $appNotificationDetail = new AppNotificationDetail();
        $appNotificationDetail->setAttribute(AppNotificationDetail::COL_APP_NOTIFICATION_SN, $appNotification->{AppNotification::COL_SN});
        $appNotificationDetail->setAttribute(AppNotificationDetail::COL_SEND_DATE, Carbon::now()->format('Y-m-d'));
        $appNotificationDetail->setAttribute(AppNotificationDetail::COL_TOTAL_IOS_SEND, $totalIosSend);
        $appNotificationDetail->setAttribute(AppNotificationDetail::COL_TOTAL_ANDROID_SEND, $totalAndroidSend);
        $appNotificationDetail->setAttribute(AppNotificationDetail::COL_TOTAL_IOS_SEND, 0);
        $appNotificationDetail->setAttribute(AppNotificationDetail::COL_TOTAL_ANDROID_VIEW, 0);
        $appNotificationDetail->setAttribute(AppNotificationDetail::COL_TOTAL_IOS_CONVERSION, 0);
        $appNotificationDetail->setAttribute(AppNotificationDetail::COL_TOTAL_ANDROID_CONVERSION, 0);

        return $appNotificationDetail;
    }

    // private function _createMessageQueue($messageQueue, $appNotification)
    // {
    //     $otherInfoList = [];
    //     $addDay = (1 * $appNotification->{AppNotification::COL_INTERVAL_DAY});
    //     $scheduleTime = Carbon::now()->addDays($addDay);
    //     $messageQueue->{MessageQueue::COL_SCHEDULE_TIME} = $scheduleTime;
    //     $fcmNotification = ConvertHelper::toStdClass($messageQueue->{MessageQueue::COL_CONTENT});
    //     array_push($otherInfoList, strval($appNotification->{AppNotification::COL_CONVERSION}));
    //     array_push($otherInfoList, $scheduleTime->format('Y-m-d'));
    //     $fcmNotification->otherInfoList = $otherInfoList;
    //     $messageQueue->{MessageQueue::COL_CONTENT} = ConvertHelper::toJson($fcmNotification);
    //     $messageQueue->{MessageQueue::COL_SN} = null;
    //     $messageQueue->{MessageQueue::COL_LOCKED} = 0;
    //     $messageQueue->{MessageQueue::COL_LAST_UPDATE} = null;
    //
    //     return $messageQueue;
    // }
}
