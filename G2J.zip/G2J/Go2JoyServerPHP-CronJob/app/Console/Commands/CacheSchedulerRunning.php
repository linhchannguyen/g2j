<?php

namespace App\Console\Commands;

use App\Constants\Staff;
use App\Helpers\GenerateHelper;
use Illuminate\Console\Command;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Cache;

class CacheSchedulerRunning extends Command
{
    const CACHE_KEY = 'go2joy_scheduler_health_check';
    const MINUTES_BETWEEN_CHECKS = 5;

    /**
     * @var string
     */
    protected $signature = 'cache-scheduler-running';

    /**
     * @var string
     */
    protected $description = 'Caches the scheduler has just ran';

    public function handle()
    {
        $cacheKey = self::CACHE_KEY;
        $cacheMinutes = self::MINUTES_BETWEEN_CHECKS;
        $cacheName = GenerateHelper::cacheName(function() use ($cacheKey) {
            return sprintf('%s:%s', $cacheKey, Staff::SYSTEM);
        });
        Cache::store('redis')->put($cacheName, 'healthy', Carbon::now()->addMinutes($cacheMinutes));
    }
}
