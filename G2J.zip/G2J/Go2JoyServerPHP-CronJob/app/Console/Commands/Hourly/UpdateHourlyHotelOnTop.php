<?php

namespace App\Console\Commands\Hourly;

use App\Helpers\LoggingHelper;
use App\Services\Web\SA\HotelOnTopService;
use Carbon\Carbon;
use Exception;
use Illuminate\Console\Command;

class UpdateHourlyHotelOnTop extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'hourly:update-hourly-hotel-on-top';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Cron job for Hourly';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @param HotelOnTopService $hotelOnTopService
     */
    public function handle(HotelOnTopService $hotelOnTopService)
    {
        LoggingHelper::logFunction('START JOB: HOURLY START HOTEL ON TOP');
        $hotelOnTopService->updateHourlyHotelOnTop();
        LoggingHelper::logFunction('START JOB: HOURLY COMPLETE HOTEL ON TOP');
    }
}
