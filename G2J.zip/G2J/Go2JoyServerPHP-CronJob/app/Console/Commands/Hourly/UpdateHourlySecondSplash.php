<?php

namespace App\Console\Commands\Hourly;

use App\Helpers\LoggingHelper;
use App\Services\Web\SA\SecondSplashService;
use Carbon\Carbon;
use Exception;
use Illuminate\Console\Command;

class UpdateHourlySecondSplash extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'hourly:update-hourly-second-splash';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Cron job for Hourly';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     * @param SecondSplashService $secondSplashService
     */
    public function handle(SecondSplashService $secondSplashService)
    {
        LoggingHelper::logFunction('START JOB: HOURLY START SECOND SPLASH');
        $secondSplashService->updateHourlySecondSplash();
        LoggingHelper::logFunction('START JOB: HOURLY COMPLETE SECOND SPLASH');
    }
}
