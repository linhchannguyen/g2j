<?php

namespace App\Console\Commands\Hourly;

use App\Constants\RoomType as RoomTypeConst;
use App\Helpers\LoggingHelper;
use App\Models\RoomType;
use App\Providers\GuzzleClientServiceProvider;
use App\Repositories\Interfaces\RoomTypeRepositoryInterface;
use Exception;
use Illuminate\Console\Command;
use stdClass;

class ProcessHourlyUpdateRoomPriceOriginAgoda extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'hourly:process-hourly-update-room-price-origin-agoda';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Cron job for Every Hour Update Room Price Origin Agoda Elastic Search';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    public function handle()
    {
        $bulkRoomType = [];
        $roomTypeSnListDelete = [];
        $roomTypeRepository = app(RoomTypeRepositoryInterface::class);
        $roomTypeAgodaList = $roomTypeRepository->findAllRoomTypeAgoda();
        try {
            foreach ($roomTypeAgodaList as $roomTypeAgoda) {
                if (RoomTypeConst::STATUS['DELETED'] == $roomTypeAgoda->{RoomType::COL_STATUS}) {
                    $roomTypeSnListDelete[] = intval($roomTypeAgoda->{RoomType::COL_SN});
                } else {
                    $roomTypeSnListDelete[] = intval($roomTypeAgoda->{RoomType::COL_SN});
                    $index = ['index' => new stdClass()];
                    $pushRoomType = [
                        'hotelSn'          => intval($roomTypeAgoda->{RoomType::COL_HOTEL_SN}),
                        'roomTypeSn'       => intval($roomTypeAgoda->{RoomType::COL_SN}),
                        'status'           => RoomTypeConst::STATUS['ACTIVE'],
                        'firstHour'        => 0,
                        'additionalHour'   => 0,
                        'firstHourOrigin'  => 0,
                        'additionalOrigin' => 0,
                        'overnightOrigin'  => 0,
                        'oneDayOrigin'     => intval($roomTypeAgoda->{RoomType::COL_ONE_DAY_ORIGIN}),
                        'maxNumHour'       => 0,
                    ];
                    $index = json_encode($index);
                    $pushRoomType = json_encode($pushRoomType);
                    $bulkRoomType[] = $index;
                    $bulkRoomType[] = $pushRoomType;
                }
            }
            $this->deleteSyncMutilRoomPriceOrigin($roomTypeSnListDelete);
            $this->insertSyncMutilRoomPriceOrigin($bulkRoomType);

        } catch (Exception $exception) {
            LoggingHelper::logException($exception);
        }

    }

    private function deleteSyncMutilRoomPriceOrigin($roomTypeSnListDelete)
    {
        $headers = [
            'Content-Type'  => 'application/json',
            'Cache-Control' => 'no-cache',
            'Authorization' => 'Basic ' . config('elasticsearch.go.auth'),
        ];
        $options = [
            'base_uri' => config('elasticsearch.go.host'),
            'headers'  => $headers,
        ];

        $client = app('GuzzleClient', [
            'service' => GuzzleClientServiceProvider::SERVICE['ELASTIC_SEARCH'],
        ])($options);

        foreach (array_chunk($roomTypeSnListDelete, 10000) as $chunk) {
            $body = json_encode([
                "query" => [
                    "bool" => [
                        "must" => [
                            [
                                "terms" => [
                                    "roomTypeSn" => $chunk,
                                ],
                            ],

                        ],
                    ],
                ],
            ]);
            $client->request(
                'POST',
                'go2joy_hotel_origin_price/_delete_by_query',
                [
                    'body' => $body,
                ]
            );
        }
    }

    private function insertSyncMutilRoomPriceOrigin($bulkRoomType)
    {
        $headers = [
            'Content-Type'  => 'application/json',
            'Cache-Control' => 'no-cache',
            'Authorization' => 'Basic ' . config('elasticsearch.go.auth'),
        ];
        $options = [
            'base_uri' => config('elasticsearch.go.host'),
            'headers'  => $headers,
        ];
        $client = app('GuzzleClient', [])($options);
        foreach (array_chunk($bulkRoomType, 10000) as $chunk) {
            $bulkRoomType = join("\n", $chunk);
            $client->request(
                'POST',
                'go2joy_hotel_origin_price/_bulk?pretty',
                [
                    'body' => $bulkRoomType . "\n",
                ]
            );
        }
    }
}