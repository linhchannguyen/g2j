<?php

namespace App\Console\Commands\Hourly;

use App\Constants\RoomPriceAdjustment as RoomPriceAdjustmentConst;
use App\Helpers\LoggingHelper;
use App\Models\RoomPriceAdjustment;
use App\Models\RoomType;
use App\Repositories\Interfaces\RoomPriceAdjustmentRepositoryInterface;
use App\Services\Common\RoomTypeService;
use Exception;
use Illuminate\Console\Command;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\DB;

class ProcessHourlyRoomPriceAdjustment extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'hourly:process-hourly-room-price-adjustment';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Cron job for Every Hour When Direct Discount Has Setup Time';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    public function handle()
    {
        $roomPriceAdjustmentRepository = app(RoomPriceAdjustmentRepositoryInterface::class);
        $roomTypeService = app(RoomTypeService::class);
        $now = Carbon::now();
        try {
            $roomPriceAdjustmentList = $roomPriceAdjustmentRepository->findPriceAdjustmentHasSetupTime(RoomPriceAdjustmentConst::TYPE['DIRECT_DISCOUNT'], $now);
            foreach ($roomPriceAdjustmentList as $roomPriceAdjustment) {
                $roomPriceAdjustmentList = $roomTypeService->getRoomPriceAdjustmentApplyToday($roomPriceAdjustment->{RoomPriceAdjustment::COL_ROOM_TYPE_SN}, $now, null);
                $roomType = DB::table(RoomType::TABLE_NAME)->where(RoomType::COL_SN, '=', $roomPriceAdjustment->{RoomPriceAdjustment::COL_ROOM_TYPE_SN})->first();
                $roomTypeOrigin = clone $roomType;
                $roomTypeService->setupRoomPriceToday($roomPriceAdjustmentList, $roomType);
                if ($this->_checkRoomPriceHasChange($roomType, $roomTypeOrigin)) {
                    $roomTypeService->updatePriceRoomType($roomType, $roomTypeOrigin, $roomPriceAdjustment->{RoomPriceAdjustment::COL_ROOM_TYPE_SN});
                }

            }
        } catch (Exception $exception) {
            LoggingHelper::logException($exception);
        }

    }

    private function _checkRoomPriceHasChange($roomType, $roomTypeOrigin)
    {
        if ($roomType->{RoomType::COL_PRICE_ADDITIONAL_HOURS} != $roomTypeOrigin->{RoomType::COL_PRICE_ADDITIONAL_HOURS}) {
            return true;
        } elseif ($roomType->{RoomType::COL_PRICE_FIRST_HOURS} != $roomTypeOrigin->{RoomType::COL_PRICE_FIRST_HOURS}) {
            return true;
        } elseif ($roomType->{RoomType::COL_PRICE_ONE_DAY} != $roomTypeOrigin->{RoomType::COL_PRICE_ONE_DAY}) {
            return true;
        } elseif ($roomType->{RoomType::COL_PRICE_OVERNIGHT} != $roomTypeOrigin->{RoomType::COL_PRICE_OVERNIGHT}) {
            return true;
        }

        return false;
    }
}