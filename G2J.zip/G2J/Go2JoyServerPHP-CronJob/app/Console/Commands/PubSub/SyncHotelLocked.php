<?php

namespace App\Console\Commands\PubSub;

use App\Constants\Globals\PubSub;
use App\Helpers\LoggingHelper;
use App\Services\Common\ElasticSearchService;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Redis;

class SyncHotelLocked extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'pubsub:sync-hotel-locked';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Sync hotel locked';

    /** @var ElasticSearchService */
    protected $elasticSearchService;

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct(ElasticSearchService $elasticSearchService)
    {
        parent::__construct();

        $this->elasticSearchService = $elasticSearchService;
    }

    /**
     * Execute the console command.
     *
     * @return void
     */
    public function handle()
    {
        ini_set('default_socket_timeout', -1);
        Redis::connection('pubsub')->subscribe([PubSub::CHANNEL['SYNC_HOTEL_LOCKED']], function($message) {
            $messageArray = json_decode($message, true);
            $hotelSn = $messageArray['hotelSn'] ?? null;
            $roomTypeSn = $messageArray['roomTypeSn'] ?? null;
            $this->elasticSearchService->syncHotelLocked($hotelSn, $roomTypeSn);

            LoggingHelper::logPubSub(PubSub::CHANNEL['SYNC_HOTEL_LOCKED'], $message);
        });
    }
}
