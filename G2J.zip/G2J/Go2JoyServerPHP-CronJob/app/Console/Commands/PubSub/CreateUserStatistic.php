<?php

namespace App\Console\Commands\PubSub;

use App\Constants\AppUser as AppUserConst;
use App\Constants\Globals\PubSub;
use App\Constants\Globals\Slack;
use App\Constants\UserStatistic as UserStatisticConst;
use App\Helpers\GenerateHelper;
use App\Helpers\LoggingHelper;
use App\Models\MobileDevice;
use App\Models\UserStatistic;
use App\Repositories\Interfaces\MobileDeviceRepositoryInterface;
use App\Repositories\Interfaces\UserStatisticRepositoryInterface;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Redis;

class CreateUserStatistic extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'pubsub:create-user-statistic';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Create user statistic';

    /** @var MobileDeviceRepositoryInterface */
    protected $mobileDeviceRepository;

    /** @var UserStatisticRepositoryInterface */
    protected $userStatisticRepository;

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct(
        MobileDeviceRepositoryInterface $mobileDeviceRepository,
        UserStatisticRepositoryInterface $userStatisticRepository
    )
    {
        parent::__construct();

        $this->mobileDeviceRepository = $mobileDeviceRepository;
        $this->userStatisticRepository = $userStatisticRepository;
    }

    /**
     * Execute the console command.
     *
     * @return void
     */
    public function handle()
    {
        ini_set('default_socket_timeout', -1);
        Redis::connection('pubsub')->subscribe([PubSub::CHANNEL['CREATE_USER_STATISTIC']], function ($message) {
            $messageArr = json_decode($message, true);
            $appUserSn = $messageArr['appUserSn'];
            $firstProvinceSn = $messageArr['firstProvinceSn'];
            $registerBy = $messageArr['registerBy'];
            $registerTime = $messageArr['registerTime'];
            $status = $messageArr['status'];
            $mobile = $messageArr['mobile'];
            $nickName = $messageArr['nickName'];
            $mobileDeviceSn = $messageArr['mobileDeviceSn'];

            $this->_createUserStatistic(
                $appUserSn,
                $firstProvinceSn,
                $registerBy,
                $registerTime,
                $status,
                $mobile,
                $nickName,
                $mobileDeviceSn
            );

            $message = sprintf("App name: %s\nApp user sn: %s", config('app.name'), $appUserSn);
            //$logMessage = GenerateHelper::logMessage('info', self::class, $message);
            //LoggingHelper::toSlack(Slack::CHANNEL['DEBUGGING'], $logMessage);
            LoggingHelper::logPubSub(PubSub::CHANNEL['CREATE_USER_STATISTIC'], $message);
        });
    }

    private function _createUserStatistic(int $appUserSn, ?int $firstProvinceSn, int $registerBy, string $registerTime, int $status, string $mobile, string $nickName, ?int $mobileDeviceSn)
    {
        if ($registerBy == AppUserConst::REGISTER_BY['MOBILE_DEVICE']) {
            $mobileDevice = $this->mobileDeviceRepository->find($mobileDeviceSn, [MobileDevice::COL_OS]);
            $os = $mobileDevice->{MobileDevice::COL_OS};
        } else {
            $os = UserStatisticConst::OS['WEB_BROWSER'];
        }

        $isExists = $this->userStatisticRepository->exists($appUserSn, UserStatistic::COL_APP_USER_SN);
        if ($isExists) {
            return;
        }

        $createUserStatisticData = [
            UserStatistic::COL_APP_USER_SN       => $appUserSn,
            UserStatistic::COL_FIRST_PROVINCE_SN => $firstProvinceSn,
            UserStatistic::COL_REGISTER_BY       => $registerBy,
            UserStatistic::COL_REGISTER_TIME     => $registerTime,
            UserStatistic::COL_STATUS            => $status,
            UserStatistic::COL_MOBILE            => $mobile,
            UserStatistic::COL_OS                => $os,
            UserStatistic::COL_NICK_NAME         => $nickName,
        ];

        $this->userStatisticRepository->create($createUserStatisticData);
    }
}
