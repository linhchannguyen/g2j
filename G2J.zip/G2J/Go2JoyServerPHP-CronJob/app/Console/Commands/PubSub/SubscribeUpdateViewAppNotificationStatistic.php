<?php

namespace App\Console\Commands\PubSub;

use App\Constants\Globals\PubSub as PubSubConst;
use App\Constants\Globals\YesNo as YesNoConst;
use App\Helpers\LoggingHelper;
use App\Models\AppNotificationStatistic;
use App\Repositories\Interfaces\AppNotificationStatisticRepositoryInterface;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Redis;

class SubscribeUpdateViewAppNotificationStatistic extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'pubsub:subscribe-update-view-app-notification-statistic';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Subscribe update view app notification statistic';

    /** @var AppNotificationStatisticRepositoryInterface */
    protected $appNotificationStatisticRepository;

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct(AppNotificationStatisticRepositoryInterface $appNotificationStatisticRepository)
    {
        parent::__construct();
        $this->appNotificationStatisticRepository = $appNotificationStatisticRepository;
    }

    /**
     * Execute the console command.
     *
     * @return void
     */
    public function handle()
    {
        ini_set('default_socket_timeout', -1);
        Redis::connection('pubsub')->subscribe([PubSubConst::CHANNEL['UPDATE_VIEW_APP_NOTIFICATION_STATISTIC']], function($message) {
            $messageArr = json_decode($message, true);
            $appUserSn = $messageArr['appUserSn'] ?? null;
            $appNotificationSn = $messageArr['appNotificationSn'] ?? null;
            $this->_updateViewAppNotificationStatistic($appUserSn, $appNotificationSn);
            LoggingHelper::logPubSub(PubSubConst::CHANNEL['UPDATE_VIEW_APP_NOTIFICATION_STATISTIC'], $message);
        });
    }

    private function _updateViewAppNotificationStatistic($appUserSn, $appNotificationSn)
    {
        $this->appNotificationStatisticRepository->updateWhere([
            AppNotificationStatistic::COL_VIEW => YesNoConst::YES,
        ], [
            AppNotificationStatistic::COL_APP_USER_SN => $appUserSn,
            AppNotificationStatistic::COL_APP_NOTIFICATION_SN => $appNotificationSn,
        ]);
    }
}