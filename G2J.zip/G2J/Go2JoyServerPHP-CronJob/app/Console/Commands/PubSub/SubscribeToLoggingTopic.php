<?php

namespace App\Console\Commands\PubSub;

use App\Constants\Globals\PubSub;
use App\Constants\Globals\QueueConnection;
use App\Constants\Globals\QueueName;
use App\Jobs\Logging\SendLogJob;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Redis;

class SubscribeToLoggingTopic extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'pubsub:subscribe-to-logging';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Subscribe to logging topic';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return void
     */
    public function handle()
    {
        ini_set('default_socket_timeout', -1);
        Redis::connection('pubsub')->subscribe([PubSub::CHANNEL['LOGGING']], function ($message) {
            $messageArr = json_decode($message, true);
            $dataLog = $messageArr['dataLog'];
            $logFileChannel = $messageArr['logFileChannel'];
            $job = new SendLogJob($dataLog, $logFileChannel);
            $job->onQueue(QueueName::LOGGING);
            $job->onConnection(QueueConnection::LOGGING);
            dispatch($job);
        });
    }
}
