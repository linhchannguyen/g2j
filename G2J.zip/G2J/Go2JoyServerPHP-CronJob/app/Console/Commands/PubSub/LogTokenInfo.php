<?php

namespace App\Console\Commands\PubSub;

use App\Constants\Globals\PubSub;
use Illuminate\Console\Command;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Redis;
use MongoDB\BSON\UTCDateTime;

class LogTokenInfo extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'pubsub:log-token-info';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Log token info';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return void
     */
    public function handle()
    {
        ini_set('default_socket_timeout', -1);
        Redis::connection('pubsub')->subscribe([PubSub::CHANNEL['LOG_TOKEN_INFO']], function ($data) {
            $data = json_decode($data, true);
            $accessToken = $data['accessToken'];
            $expireAt = $data['expireAt'];
            $clientIp = $data['clientIp'];
            $platform = $data['platform'];
            $request = $data['request'];
            $appUserSn = $data['appUserSn'] ?? null;
            $staffSn = $data['staffSn'] ?? null;

            $logTokenInfo = new \App\Models\MongoDB\LogTokenInfo();
            $logTokenInfo->{\App\Models\MongoDB\LogTokenInfo::FIELD_ACCESS_TOKEN} = $accessToken;
            $logTokenInfo->{\App\Models\MongoDB\LogTokenInfo::FIELD_EXPIRE_AT} = $expireAt;
            $logTokenInfo->{\App\Models\MongoDB\LogTokenInfo::FIELD_CLIENT_IP} = $clientIp;
            $logTokenInfo->{\App\Models\MongoDB\LogTokenInfo::FIELD_PLATFORM} = $platform;
            $logTokenInfo->{\App\Models\MongoDB\LogTokenInfo::FIELD_APP_USER_SN} = $appUserSn;
            $logTokenInfo->{\App\Models\MongoDB\LogTokenInfo::FIELD_STAFF_SN} = $staffSn;
            $logTokenInfo->{\App\Models\MongoDB\LogTokenInfo::FIELD_REQUEST} = $request;
            $logTokenInfo->{\App\Models\MongoDB\LogTokenInfo::FIELD_CREATE_TIME} = new UTCDateTime(Carbon::now());
            $logTokenInfo->{\App\Models\MongoDB\LogTokenInfo::FIELD_LAST_UPDATE} = new UTCDateTime(Carbon::now());
            $logTokenInfo->save();
        });
    }
}
