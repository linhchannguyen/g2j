<?php

namespace App\Console\Commands\PubSub;

use App\Constants\Globals\PubSub;
use App\Helpers\LoggingHelper;
use App\Models\UserStatistic;
use App\Repositories\Interfaces\UserStatisticRepositoryInterface;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Redis;

class UpdateUserStatistic extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'pubsub:update-user-statistic';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Update user statistic';

    /** @var UserStatisticRepositoryInterface */
    protected $userStatisticRepository;

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct(UserStatisticRepositoryInterface $userStatisticRepository)
    {
        parent::__construct();

        $this->userStatisticRepository = $userStatisticRepository;
    }

    /**
     * Execute the console command.
     *
     * @return void
     */
    public function handle()
    {
        ini_set('default_socket_timeout', -1);
        Redis::connection('pubsub')->subscribe([PubSub::CHANNEL['UPDATE_USER_STATISTIC']], function ($message) {
            $messageArr = json_decode($message, true);
            $appUserSn = $messageArr['appUserSn'];
            $status = $messageArr['status'] ?? null;
            $nickName = $messageArr['nickName'] ?? null;
            $this->_updateUserStatistic($appUserSn, $status, $nickName);

            LoggingHelper::logPubSub(PubSub::CHANNEL['UPDATE_USER_STATISTIC'], $message);
        });
    }

    private function _updateUserStatistic(int $appUserSn, ?int $status, ?string $nickName)
    {
        $updateUserStatisticData = [
            UserStatistic::COL_NICK_NAME => $nickName,
        ];

        if (isset($status)) {
            $updateUserStatisticData[UserStatistic::COL_STATUS] = $status;
        }

        $this->userStatisticRepository->update($updateUserStatisticData, $appUserSn, UserStatistic::COL_APP_USER_SN);
    }
}
