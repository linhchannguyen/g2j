<?php

namespace App\Console\Commands\PubSub;

use App\Constants\Globals\PubSub;
use App\Constants\Globals\QueueName;
use App\Helpers\LoggingHelper;
use App\Jobs\Mobile\CheckCouponCanUseForNewAppUserJob;
use App\Services\WebBookingV4\AuthService;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Redis;

class SubscribeToNewSignUpTopic extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'pubsub:subscribe-to-new-sign-up';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Subscribe to new sign up topic';

    /** @var AuthService */
    protected $authService;

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
        $this->authService = app(AuthService::class);
    }

    /**
     * Execute the console command.
     *
     * @return void
     */
    public function handle()
    {
        ini_set('default_socket_timeout', -1);
        Redis::connection('pubsub')->subscribe([PubSub::CHANNEL['NEW_SIGN_UP']], function ($message) {
            $messageArr = json_decode($message, true);
            $appUserSn = $messageArr['appUserSn'];

            $this->_checkCouponCanUse($appUserSn);

            $this->_updateCouponForNewSignUp($appUserSn);

            LoggingHelper::logPubSub(PubSub::CHANNEL['NEW_SIGN_UP'], $message);
        });
    }

    private function _checkCouponCanUse($appUserSn)
    {
        $job = new CheckCouponCanUseForNewAppUserJob($appUserSn);
        dispatch($job->onQueue(QueueName::BACK_GROUND));
    }

    private function _updateCouponForNewSignUp($appUserSn)
    {
        $this->authService->updateCouponForSignupNew($appUserSn);
    }
}
