<?php

namespace App\Console\Commands\PubSub;

use App\Constants\Globals\PubSub;
use App\Constants\Globals\QueueName;
use App\Constants\InstantLock as InstantLockConst;
use App\Helpers\LoggingHelper;
use App\Models\InstantLock;
use App\Services\Web\SA\InstantLockService;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Redis;

class ProcessAfterInstantLockHasChanged extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'pubsub:process-after-instant-lock-has-changed';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Process after instant lock has changed';

    /** @var InstantLockService */
    protected $instantLockService;

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
        $this->instantLockService = app(InstantLockService::class);
    }

    /**
     * Execute the console command.
     *
     * @return void
     */
    public function handle()
    {
        ini_set('default_socket_timeout', -1);
        Redis::connection('pubsub')->subscribe([PubSub::CHANNEL['PROCESS_AFTER_INSTANT_LOCK_HAS_CHANGED']], function ($message) {
            $messageArr = json_decode($message, true);
            $hotelSn = $messageArr['hotelSn'];
            $roomTypeSn = $messageArr['roomTypeSn'];

            $instantLock = InstantLock::where(InstantLock::COL_HOTEL_SN, $hotelSn)
                ->where(InstantLock::COL_ROOM_TYPE_SN, $roomTypeSn)
                ->first();
            $numOfRoomLeft = $instantLock->{InstantLock::COL_NUMBER_OF_ROOM_LEFT};

            $this->instantLockService->processAfterUpdateNumOfRoomLeft($hotelSn, $roomTypeSn, $numOfRoomLeft);

            LoggingHelper::logPubSub(PubSub::CHANNEL['PROCESS_AFTER_INSTANT_LOCK_HAS_CHANGED'], $message);
        });
    }
}
