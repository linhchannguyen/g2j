<?php

namespace App\Console\Commands\PubSub;

use App\Constants\Globals\PubSub as PubSubConst;
use App\Constants\Globals\QueueName as QueueNameConst;
use App\Helpers\LoggingHelper;
use App\Jobs\Notification\PushNotificationJob;
use App\Models\UserBooking;
use App\Services\Common\UserBookingService;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Redis;

class SubscribePushNotification extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'pubsub:subscribe-push-notification';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Subscribe push notification';

    protected $userBookingService;

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
        $this->userBookingService = app(UserBookingService::class);
    }

    /**
     * Execute the console command.
     *
     * @return void
     */
    public function handle()
    {
        ini_set('default_socket_timeout', -1);
        Redis::connection('pubsub')->subscribe([PubSubConst::CHANNEL['PUSH_NOTIFICATION']], function($message) {
            $messageArr = json_decode($message, true);
            $appUserSn = $messageArr['appUserSn'] ?? null;
            $title = $messageArr['title'] ?? null;
            $tokens = $messageArr['tokens'] ?? [];
            $body = $messageArr['body'] ?? null;
            $informationList = $messageArr['informationList'] ?? [];
            $type = $messageArr['type'] ?? null;
            $author = $messageArr['author'] ?? null;
            $isUsingKey = $messageArr['isUsingKey'] ?? true;
            $topic = $messageArr['topic'] ?? [];
            $sn = $messageArr['sn'] ?? null;
            $hotelSn = $messageArr['hotelSn'] ?? null;
            $iconUrl = $messageArr['iconUrl'] ?? null;
            $typeOs = $messageArr['typeOs'] ?? null;
            $appNotificationSn = $messageArr['appNotificationSn'] ?? null;
            $isPartner = $messageArr['isPartner'] ?? false;
            if($isPartner){
                $userBooking = UserBooking::where(UserBooking::COL_SN, $sn)->first();
                $this->userBookingService->buildFcmNotificationForHA($userBooking);
            }else{
                $pushNotificationJob = new PushNotificationJob($appUserSn, $tokens, $title, $body, $informationList, $type, $author, $isUsingKey, $topic, $sn, $hotelSn, $iconUrl, $typeOs, $appNotificationSn, $isPartner);
                dispatch($pushNotificationJob->onQueue(QueueNameConst::NOTIFICATION));
            }

            LoggingHelper::logPubSub(PubSubConst::CHANNEL['PUSH_NOTIFICATION'], $message);
        });
    }
}