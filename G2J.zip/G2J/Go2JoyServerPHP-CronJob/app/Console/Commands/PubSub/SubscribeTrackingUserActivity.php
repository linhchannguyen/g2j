<?php

namespace App\Console\Commands\PubSub;

use App\Constants\Globals\PubSub;
use App\Constants\MongoDB\UserAction as UserActionConst;
use App\Helpers\LoggingHelper;
use App\Models\MongoDB\UserAction;
use Exception;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Redis;

class SubscribeTrackingUserActivity extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'pubsub:subscribe-tracking-user-activity';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Subscribe tracking user activity';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return void
     */
    public function handle()
    {
        ini_set('default_socket_timeout', -1);
        Redis::connection('pubsub')->subscribe([PubSub::CHANNEL['TRACKING_USER_ACTIVITY']], function($message) {
            $messageArr = json_decode($message, true);
            $event = $messageArr['event'];
            $project = $messageArr['project'];
            $appUserSn = $messageArr['appUserSn'] ?? null;
            $targetSn = $messageArr['targetSn'] ?? null;
            $mobileDeviceSn = $messageArr['mobileDeviceSn'] ?? null;
            $os = $messageArr['os'] ?? null;
            $staffSn = $messageArr['staffSn'] ?? null;
            $this->_trackingUserActivity($event, $appUserSn, $targetSn, $mobileDeviceSn, $os, $staffSn, $project);

            LoggingHelper::logPubSub(PubSub::CHANNEL['TRACKING_USER_ACTIVITY'], $message);
        });
    }

    private function _trackingUserActivity($event, $appUserSn, $targetSn, $mobileDeviceSn, $os, $staffSn, $project)
    {
        try {
            if (!empty($event) && !empty($targetSn)) {
                $userAction = new UserAction();
                $userAction->{UserAction::FIELD_APP_USER_SN} = $appUserSn;
                $userAction->{UserAction::FIELD_MOBILE_DEVICE_SN} = $mobileDeviceSn;
                $userAction->{UserAction::FIELD_STAFF_SN} = $staffSn;
                $userAction->{UserAction::FIELD_EVENT} = $event;
                $userAction->{UserAction::FIELD_TARGET_SN} = $targetSn;
                $userAction->{UserAction::FIELD_PROJECT} = $project;
                $userAction->{UserAction::FIELD_OS} = $os;
                $userAction->{UserAction::FIELD_IS_SNAPSHOT} = UserActionConst::IS_SNAPSHOT['FALSE'];
                $userAction->save();
            }
        } catch (Exception $exception) {
            LoggingHelper::logException($exception);

        }
    }
}