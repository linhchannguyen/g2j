<?php

namespace App\Console\Commands\PubSub;

use App\Constants\Globals\PubSub;
use App\Helpers\LoggingHelper;
use App\Services\Common\ElasticSearchService;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Redis;

class SyncHotelRanking extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'pubsub:sync-hotel-ranking';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Sync hotel ranking';

    /** @var ElasticSearchService */
    protected $elasticSearchService;

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct(ElasticSearchService $elasticSearchService)
    {
        parent::__construct();

        $this->elasticSearchService = $elasticSearchService;
    }

    /**
     * Execute the console command.
     *
     * @return void
     */
    public function handle()
    {
        ini_set('default_socket_timeout', -1);
        Redis::connection('pubsub')->subscribe([PubSub::CHANNEL['SYNC_HOTEL_RANKING']], function($message) {
            $messageArray = json_decode($message, true);
            $hotelSnList = (array)$messageArray['hotelSnList'] ?? [];
            $this->elasticSearchService->syncHotelRanking($hotelSnList);

            LoggingHelper::logPubSub(PubSub::CHANNEL['SYNC_HOTEL_RANKING'], $message);
        });
    }
}
