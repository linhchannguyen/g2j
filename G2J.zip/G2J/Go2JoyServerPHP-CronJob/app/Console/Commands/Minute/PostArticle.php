<?php

namespace App\Console\Commands\Minute;

use App\Repositories\Interfaces\ArticleRepositoryInterface;
use Illuminate\Console\Command;

class PostArticle extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'minute:post-article';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Cron job for Every Minute Post Article';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return void
     */
    public function handle()
    {
        $articleRepository = app(ArticleRepositoryInterface::class);
        $articleRepository->updateDisplayArticle();
    }
}
