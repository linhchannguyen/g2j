<?php

namespace App\Console\Commands\Minute;

use App\Actions\Reward\PushNotificationPoint;
use App\Actions\Reward\RefundPoint;
use App\Actions\Reward\WithdrawPendingRefundPoint;
use App\DTOs\Reward\PushNotificationPointInputDTO;
use App\DTOs\Reward\RefundPointInputDTO;
use App\DTOs\Reward\WithdrawPendingRefundPointInputDTO;
use App\Exceptions\ServiceException;
use App\Helpers\LoggingHelper;
use App\Models\MileagePointTransactionHistory;
use App\Repositories\Interfaces\MileagePointTransactionHistoryRepositoryInterface;
use Illuminate\Console\Command;

class HandlePendingRefundPoint extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'minute:handle-pending-refund-point';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Handle mileage point transaction history with status is pending refund';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @param MileagePointTransactionHistoryRepositoryInterface $mileagePointTransactionHistoryRepository
     *
     * @return void
     * @throws ServiceException
     */
    public function handle(MileagePointTransactionHistoryRepositoryInterface $mileagePointTransactionHistoryRepository)
    {
        $mileagePointTransactionHistoryList = $mileagePointTransactionHistoryRepository->findPendingRefundPointStatusList();

        $resultList = [];
        foreach ($mileagePointTransactionHistoryList as $mileagePointTransactionHistory) {
            $userBookingSn = $mileagePointTransactionHistory->{MileagePointTransactionHistory::COL_USER_BOOKING_SN};
            $mileagePointTransactionHistorySn = $mileagePointTransactionHistory->{MileagePointTransactionHistory::COL_SN};

            /** @var RefundPoint $refundPoint */
            $refundPoint = app(RefundPoint::class);
            $refundPointInputDTO = new RefundPointInputDTO();
            $refundPointInputDTO->setUserBookingSn($userBookingSn);
            $refundPointOutputDTO = $refundPoint->handle($refundPointInputDTO);

            /** @var WithdrawPendingRefundPoint $withdrawPendingRefundPoint */
            $withdrawPendingRefundPoint = app(WithdrawPendingRefundPoint::class);
            $withdrawPendingRefundPointInputDTO = new WithdrawPendingRefundPointInputDTO();
            $withdrawPendingRefundPointInputDTO->setUserBookingSn($userBookingSn);
            $withdrawPendingRefundPointOutputDTO = $withdrawPendingRefundPoint->handle($withdrawPendingRefundPointInputDTO);

            /** @var PushNotificationPoint $pushNotificationPoint */
            $pushNotificationPoint = app(PushNotificationPoint::class);
            $pushNotificationPointInputDTO = new PushNotificationPointInputDTO();
            $pushNotificationPointInputDTO->setMileagePointTransactionHistorySn($refundPointOutputDTO->getMileagePointTransactionHistorySn());
            $pushNotificationPoint->handle($pushNotificationPointInputDTO);

            $resultList[$mileagePointTransactionHistorySn] = [
                'refundedPoint'              => $refundPointOutputDTO->getRefundedPoint(),
                'withdrawPendingRefundPoint' => $withdrawPendingRefundPointOutputDTO->isSuccess(),
            ];
        }
        LoggingHelper::logCronJob(__CLASS__, $resultList);
    }
}
