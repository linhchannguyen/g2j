<?php

namespace App\Console\Commands\Minute;

use App\Constants\Hotel as HotelConst;
use App\Helpers\LoggingHelper;
use App\Models\Hotel;
use App\Models\UserBooking;
use App\Repositories\Interfaces\UserBookingRepositoryInterface;
use App\Services\Others\PaymentServiceV3;
use Illuminate\Console\Command;

class HandleCreatedBooking extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'minute:handle-created-booking';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Cron job for Every Minute Handle Created Booking';

    /** @var PaymentServiceV3 */
    private $paymentService;

    /** @var int */
    const LIMIT = 100;

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
        $this->paymentService = app(PaymentServiceV3::class);
    }

    /**
     * Execute the console command.
     *
     * @param UserBookingRepositoryInterface $userBookingRepository
     *
     * @return void
     */
    public function handle(UserBookingRepositoryInterface $userBookingRepository)
    {
        $userBookingList = $userBookingRepository->findCreatedBooking();

        $resultList = [];
        $numOfBookings = 0;
        foreach ($userBookingList as $userBooking) {
            if ($numOfBookings > self::LIMIT) {
                break;
            }

            $origin = Hotel::where(Hotel::COL_SN, $userBooking->{UserBooking::COL_HOTEL_SN})->first()->{Hotel::COL_ORIGIN};
            if ($origin == HotelConst::ORIGIN['AGODA']) {
                continue;
            }

            [$hasExpired, $timeRemaining] = $this->paymentService->hasPaymentExpired($userBooking->{UserBooking::COL_CREATE_TIME});
            if ($hasExpired && $timeRemaining == 0) {
                $this->paymentService->handleBookingHasCreatedPaymentRequestFailed($userBooking);

                $resultList[] = $userBooking->{UserBooking::COL_SN};

                $numOfBookings++;
            }
        }

        LoggingHelper::logCronJob(__CLASS__, $resultList);
    }
}
