<?php

namespace App\Console\Commands\Minute;

use App\Exceptions\RepositoryException;
use App\Helpers\LoggingHelper;
use App\Models\UserBooking;
use App\Repositories\Interfaces\UserBookingRepositoryInterface;
use App\Services\Others\PaymentServiceV3;
use Carbon\Carbon;
use Illuminate\Console\Command;

class HandleFailedPaymentV2 extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'minute:handle-failed-payment-v2';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Handle failed payments in case flash sale room and normal room with not processed yet';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @param PaymentServiceV3 $paymentService
     *
     * @return void
     * @throws RepositoryException
     */
    public function handle(PaymentServiceV3 $paymentService)
    {
        /**
         * Reason why: Carbon::now()->startOfDay()->subMinutes($minutes + 5)
         * Example with $minutes = 10
         * 07/03 23h55: 23h45 06/03 -> 23h45 07/03
         * 08/03 00h00: 23h45 07/03 -> 23h50 07/03
         * 08/03 00h05: 23h45 07/03 -> 23h55 07/03
         * 08/03 00h10: 23h45 07/03 -> 00h00 08/03
         */
        /**
        $minutes = 5;
        $startTime = Carbon::now()->startOfDay()->subMinutes($minutes + 5)->format('Y-m-d H:i:s');
        $endTime = Carbon::now()->subMinutes($minutes)->format('Y-m-d H:i:s');
        **/

        $startTime = Carbon::now()->subDay()->startOfDay()->format('Y-m-d H:i:s');
        $endTime = Carbon::now()->format('Y-m-d H:i:s');

        $userBookingRepository = app(UserBookingRepositoryInterface::class);
        $userBookingList = $userBookingRepository->findPaymentFailedListV2($startTime, $endTime);

        $resultList = [];
        foreach ($userBookingList as $userBooking) {
            $result = $paymentService->withdrawUserBooking($userBooking);
            $resultList[$userBooking->{UserBooking::COL_SN}] = $result;
        }

        LoggingHelper::logCronJob(__CLASS__, $resultList);
    }
}
