<?php

namespace App\Console\Commands\Minute;

use App\Constants\Globals\Payment;
use App\Constants\UserBooking as UserBookingConst;
use App\DTOs\Others\Payment\GetFinalPaymentStatusInputDTO;
use App\DTOs\Others\Payment\GetPaymentResultV2InputDTO;
use App\Exceptions\RepositoryException;
use App\Models\UserBooking;
use App\Repositories\Interfaces\UserBookingRepositoryInterface;
use App\Services\Others\PaymentServiceV2;
use Exception;
use Illuminate\Console\Command;

class HandlePendingPayment extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'minute:handle-pending-payment';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Handle pending payments in case flash sale room and normal room with not processed yet';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @param PaymentServiceV2 $paymentServiceV2
     *
     * @return void
     * @throws RepositoryException|Exception
     */
    public function handle(PaymentServiceV2 $paymentServiceV2)
    {
        $userBookingRepository = app(UserBookingRepositoryInterface::class);
        $userBookingList = $userBookingRepository->findPendingPaymentList();

        foreach ($userBookingList as $userBooking) {
            $userBookingSn = $userBooking->{UserBooking::COL_SN};
            $paymentProvider = $userBooking->{UserBooking::COL_PAYMENT_PROVIDER};
            $webDeviceSn = $userBooking->{UserBooking::COL_WEB_DEVICE_SN};
            $mobileDeviceSn = $userBooking->{UserBooking::COL_MOBILE_DEVICE_SN};

            $platform = null;
            if (!empty($webDeviceSn)) {
                $platform = Payment::PLATFORM['WEB'];
            }
            if (!empty($mobileDeviceSn)) {
                $platform = Payment::PLATFORM['APP'];
            }
            if (empty($platform)) {
                throw new Exception("User booking with sn = $userBookingSn is invalid!");
            }

            // Map to payment provider's business constant
            switch ($paymentProvider) {
                case UserBookingConst::PAYMENT_PROVIDER['MOMO']: {
                    $paymentProvider = Payment::PAYMENT_PROVIDER['MOMO'];
                    break;
                }
                case UserBookingConst::PAYMENT_PROVIDER['ZALO_PAY']: {
                    $paymentProvider = Payment::PAYMENT_PROVIDER['ZALO_PAY'];
                    break;
                }
                case UserBookingConst::PAYMENT_PROVIDER['SHOPEE_PAY']: {
                    $paymentProvider = Payment::PAYMENT_PROVIDER['SHOPEE_PAY'];
                    break;
                }
                case UserBookingConst::PAYMENT_PROVIDER['EPAY_DC']:
                case UserBookingConst::PAYMENT_PROVIDER['EPAY_IC']: {
                    $paymentProvider = Payment::PAYMENT_PROVIDER['EPAY'];
                    break;
                }
                default:
                    throw new Exception("User booking with sn = $userBookingSn invalid payment provider!");
            }

            $getFinalPaymentStatusInputDTO = new GetFinalPaymentStatusInputDTO();
            $getFinalPaymentStatusInputDTO->setUserBookingSn($userBookingSn);
            $getFinalPaymentStatusInputDTO->setPaymentProvider($paymentProvider);
            $getFinalPaymentStatusInputDTO->setPlatform($platform);
            $paymentServiceV2->getFinalPaymentStatus($getFinalPaymentStatusInputDTO);
        }
    }
}