<?php

namespace App\Console\Commands\Minute;

use App\Constants\BookingActionHistory as BookingActionHistoryConst;
use App\Constants\Hotel as HotelConst;
use App\Constants\PaymentTransaction as PaymentTransactionConst;
use App\Constants\Staff as StaffConst;
use App\Constants\UserBooking as UserBookingConst;
use App\Helpers\CommonHelper;
use App\Helpers\LoggingHelper;
use App\Models\Hotel;
use App\Models\UserBooking;
use App\Repositories\Interfaces\UserBookingRepositoryInterface;
use App\Services\Web\SA\UserBookingService;
use Exception;
use Illuminate\Console\Command;
use Illuminate\Support\Carbon;

class HandleAwaitingCheckinBookingPayInAdvance extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'minute:handle-awaiting-checkin-booking-pay-in-advance';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Cron job for Every Minute Handle Awaiting Checkin Booking Pay In Advance';

    /** @var UserBookingService */
    private $userBookingService;

    /** @var int */
    const COMPLETE_CHECKIN_BOOKING_TIMEOUT = 0; // In seconds (Default: 0 minutes)

    /** @var int */
    const COMPLETE_NO_SHOW_BOOKING_TIMEOUT = 0; // In seconds (Default: 0 minutes)

    /** @var int */
    const LIMIT = 100;

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
        $this->userBookingService = app(UserBookingService::class);
    }

    /**
     * Execute the console command.
     *
     * @param UserBookingRepositoryInterface $userBookingRepository
     *
     * @return void
     */
    public function handle(UserBookingRepositoryInterface $userBookingRepository)
    {
        $userBookingList = $userBookingRepository->findAwaitingCheckinBookingPayInAdvance();

        $resultList = [];
        $numOfBookings = 0;
        foreach ($userBookingList as $userBooking) {
            if ($numOfBookings > self::LIMIT) {
                break;
            }

            $origin = Hotel::where(Hotel::COL_SN, $userBooking->{UserBooking::COL_HOTEL_SN})->first()->{Hotel::COL_ORIGIN};
            if ($origin == HotelConst::ORIGIN['AGODA']) {
                continue;
            }
            $checkoutDateTime = CommonHelper::getBookingCheckoutDateTime($userBooking);
            $elapsedTime = Carbon::now()->timestamp - Carbon::parse($checkoutDateTime)->timestamp;
            $bookingStatus = $userBooking->{UserBooking::COL_BOOKING_STATUS};
            $paymentStatus = CommonHelper::preCheckPaymentStatus(
                $userBooking->{UserBooking::COL_SN},
                $userBooking->{UserBooking::COL_BOOKING_STATUS},
                $userBooking->{UserBooking::COL_REFUNDED},
                $userBooking->{UserBooking::COL_PAYMENT_PROVIDER}
            );
            if (PaymentTransactionConst::PAYMENT_STATUS['SUCCESSFUL'] != $paymentStatus) {
                continue;
            }

            if (
                ($bookingStatus == UserBookingConst::BOOKING_STATUS['AWAITING_CHECKIN'] && $elapsedTime >= self::COMPLETE_NO_SHOW_BOOKING_TIMEOUT)
                || ($bookingStatus == UserBookingConst::BOOKING_STATUS['RECEIVED'] && $elapsedTime >= self::COMPLETE_CHECKIN_BOOKING_TIMEOUT)
            ) {
                $userBookingSn = $userBooking->{UserBooking::COL_SN};
                $result = $this->userBookingService->completeBooking($userBookingSn, UserBookingConst::VIA_OBJECT['SYSTEM'], StaffConst::SYSTEM, BookingActionHistoryConst::ACTION_USER_TYPE['SYSTEM']);
                $resultList[$userBooking->{UserBooking::COL_SN}] = $result;

                $numOfBookings++;
            }
        }

        LoggingHelper::logCronJob(__CLASS__, $resultList);
    }
}
