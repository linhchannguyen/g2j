<?php

namespace App\Console\Commands\Minute;

use App\Constants\BookingActionHistory as BookingActionHistoryConst;
use App\Constants\PaymentTransaction as PaymentTransactionConst;
use App\Constants\Staff as StaffConst;
use App\Constants\UserBooking as UserBookingConst;
use App\Helpers\CommonHelper;
use App\Helpers\LoggingHelper;
use App\Models\NoShowHistory;
use App\Models\PaymentTransaction;
use App\Models\UserBooking;
use App\Repositories\Interfaces\BookingActionHistoryRepositoryInterface;
use App\Repositories\Interfaces\BookingStatusHistoryRepositoryInterface;
use App\Repositories\Interfaces\NoShowHistoryRepositoryInterface;
use App\Repositories\Interfaces\PaymentStatusHistoryRepositoryInterface;
use App\Repositories\Interfaces\PaymentTransactionRepositoryInterface;
use App\Repositories\Interfaces\UserBookingRepositoryInterface;
use App\Services\Others\PaymentServiceV3;
use App\Services\Web\SA\UserBookingService;
use Illuminate\Console\Command;
use Illuminate\Support\Carbon;

class HandleAwaitingUserConfirmationBooking extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'minute:handle-awaiting-user-confirmation-booking';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Cron job for Every Minute Handle Awaiting User Confirmation Booking';

    /** @var UserBookingRepositoryInterface */
    private $userBookingRepository;

    /** @var NoShowHistoryRepositoryInterface */
    private $noShowHistoryRepository;

    /** @var BookingStatusHistoryRepositoryInterface */
    private $bookingStatusHistoryRepository;

    /** @var PaymentTransactionRepositoryInterface */
    private $paymentTransactionRepository;

    /** @var BookingActionHistoryRepositoryInterface */
    private $bookingActionHistoryRepository;

    /** @var int */
    const COMPLETE_AWAITING_USER_CONFIRMATION_BOOKING_TIMEOUT = 43200; // In seconds (Default: 12 hours)

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
        $this->userBookingRepository = app(UserBookingRepositoryInterface::class);
        $this->noShowHistoryRepository = app(NoShowHistoryRepositoryInterface::class);
        $this->bookingStatusHistoryRepository = app(BookingStatusHistoryRepositoryInterface::class);
        $this->paymentTransactionRepository = app(PaymentTransactionRepositoryInterface::class);
        $this->bookingActionHistoryRepository = app(BookingActionHistoryRepositoryInterface::class);
    }

    /**
     * Execute the console command.
     *
     * @return void
     */
    public function handle()
    {
        $userBookingList = $this->userBookingRepository->findAwaitingUserConfirmationBooking();

        $resultList = [];
        foreach ($userBookingList as $userBooking) {
            $lastNoShowHistory = $this->noShowHistoryRepository->findLastNoShowHistoryByUserBookingSn($userBooking->{UserBooking::COL_SN});
            if (!empty($lastNoShowHistory)) {
                $hotelActionTime = $lastNoShowHistory->{NoShowHistory::COL_HOTEL_ACTION_TIME};
                $elapsedTime = Carbon::now()->timestamp - Carbon::parse($hotelActionTime)->timestamp;
                if ($elapsedTime >= self::COMPLETE_AWAITING_USER_CONFIRMATION_BOOKING_TIMEOUT) {
                    $userBookingSn = $userBooking->{UserBooking::COL_SN};
                    $oldBookingStatus = $userBooking->{UserBooking::COL_BOOKING_STATUS};
                    $oldViaObject = $userBooking->{UserBooking::COL_VIA_OBJECT};
                    $bookingActionHistorySn = $this->bookingActionHistoryRepository->createReceivedNoShowHistory($userBookingSn, StaffConst::SYSTEM, BookingActionHistoryConst::ACTION_USER_TYPE['SYSTEM'], $oldBookingStatus, $oldViaObject, Carbon::now());
                    $userBookingUpdate = [
                        UserBooking::COL_BOOKING_STATUS            => UserBookingConst::BOOKING_STATUS['AWAITING_GO2JOY_PROCESSING'],
                        UserBooking::COL_STAFF_SN                  => StaffConst::SYSTEM,
                        UserBooking::COL_VIA_OBJECT                => UserBookingConst::VIA_OBJECT['SYSTEM'],
                        UserBooking::COL_BOOKING_ACTION_HISTORY_SN => $bookingActionHistorySn,
                    ];
                    $this->userBookingRepository->update($userBookingUpdate, $userBookingSn);

                    if ($userBooking->{UserBooking::COL_PAYMENT_PROVIDER} == UserBookingConst::PAYMENT_PROVIDER['AT_HOTEL']) {
                        // Pay at hotel
                        $this->paymentTransactionRepository->updateWhere([
                            PaymentTransaction::COL_PAYMENT_STATUS => PaymentTransactionConst::PAYMENT_STATUS['AWAITING']
                        ], [PaymentTransaction::COL_USER_BOOKING_SN => $userBookingSn]);

                        $this->bookingStatusHistoryRepository->createAwaitingGo2JoyProcessingHistory($userBookingSn, StaffConst::SYSTEM, Carbon::now(), PaymentTransactionConst::PAYMENT_STATUS['AWAITING'], UserBookingConst::VIA_OBJECT['SYSTEM'], $oldBookingStatus, BookingActionHistoryConst::WORKING_STATUS['RECEIVED'], BookingActionHistoryConst::ACTION_TYPE['NO_SHOW']);
                    } else {
                        // Pay in advance
                        $paymentStatus = CommonHelper::preCheckPaymentStatus(
                            $userBooking->{UserBooking::COL_SN},
                            $userBooking->{UserBooking::COL_BOOKING_STATUS},
                            $userBooking->{UserBooking::COL_REFUNDED},
                            $userBooking->{UserBooking::COL_PAYMENT_PROVIDER}
                        );
                        $this->bookingStatusHistoryRepository->createAwaitingGo2JoyProcessingHistory($userBookingSn, StaffConst::SYSTEM, Carbon::now(), $paymentStatus, UserBookingConst::VIA_OBJECT['SYSTEM'], $oldBookingStatus, BookingActionHistoryConst::WORKING_STATUS['RECEIVED'], BookingActionHistoryConst::ACTION_TYPE['NO_SHOW']);
                    }

                    $resultList[] = $userBooking->{UserBooking::COL_SN};
                }
            }
        }

        LoggingHelper::logCronJob(__CLASS__, $resultList);
    }
}
