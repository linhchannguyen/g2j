<?php

namespace App\Console\Commands\Minute;

use App\Constants\BookingActionHistory as BookingActionHistoryConst;
use App\Constants\PaymentTransaction as PaymentTransactionConst;
use App\Constants\Staff as StaffConst;
use App\Constants\UserBooking as UserBookingConst;
use App\Helpers\CommonHelper;
use App\Helpers\LoggingHelper;
use App\Models\PaymentTransaction;
use App\Models\UserBooking;
use App\Repositories\Interfaces\PaymentStatusHistoryRepositoryInterface;
use App\Repositories\Interfaces\PaymentTransactionRepositoryInterface;
use App\Repositories\Interfaces\UserBookingRepositoryInterface;
use App\Services\Others\PaymentServiceV3;
use App\Services\Web\SA\UserBookingService;
use Illuminate\Console\Command;
use Illuminate\Support\Carbon;

class HandleAwaitingCheckinBookingPayAtHotel extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'minute:handle-awaiting-checkin-booking-pay-at-hotel';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Cron job for Every Minute Handle Awaiting Checkin Booking Pay At Hotel';

    /** @var UserBookingRepositoryInterface */
    private $userBookingRepository;

    /** @var UserBookingService */
    private $userBookingService;

    /** @var PaymentServiceV3 */
    private $paymentService;

    /** @var int */
    const COMPLETE_CHECKIN_BOOKING_TIMEOUT = 0; // In seconds (Default: 0 minutes)

    /** @var int */
    const COMPLETE_NO_SHOW_BOOKING_TIMEOUT = 0; // In seconds (Default: 0 minutes)

    /** @var int */
    const LIMIT = 100;

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
        $this->userBookingRepository = app(UserBookingRepositoryInterface::class);
        $this->userBookingService = app(UserBookingService::class);
        $this->paymentService = app(PaymentServiceV3::class);
    }

    /**
     * Execute the console command.
     *
     * @return void
     */
    public function handle()
    {
        $userBookingList = $this->userBookingRepository->findAwaitingCheckinBookingPayAtHotel();

        $resultList = [];
        $numOfBookings = 0;
        foreach ($userBookingList as $userBooking) {
            if ($numOfBookings > self::LIMIT) {
                break;
            }

            $checkoutDateTime = CommonHelper::getBookingCheckoutDateTime($userBooking);
            $elapsedTime = Carbon::now()->timestamp - Carbon::parse($checkoutDateTime)->timestamp;
            $bookingStatus = $userBooking->{UserBooking::COL_BOOKING_STATUS};
            if (
                ($bookingStatus == UserBookingConst::BOOKING_STATUS['AWAITING_CHECKIN'] && $elapsedTime >= self::COMPLETE_NO_SHOW_BOOKING_TIMEOUT)
                || ($bookingStatus == UserBookingConst::BOOKING_STATUS['RECEIVED'] && $elapsedTime >= self::COMPLETE_CHECKIN_BOOKING_TIMEOUT)
            ) {
                $userBookingSn = $userBooking->{UserBooking::COL_SN};
                $result = $this->userBookingService->completeBooking($userBookingSn, UserBookingConst::VIA_OBJECT['SYSTEM'], StaffConst::SYSTEM, BookingActionHistoryConst::ACTION_USER_TYPE['SYSTEM']);
                $resultList[$userBooking->{UserBooking::COL_SN}] = $result;

                if ($result) {
                    $this->paymentService->updatePaymentStatus($userBookingSn, UserBookingConst::PAYMENT_PROVIDER['AT_HOTEL'], PaymentTransactionConst::PAYMENT_STATUS['SUCCESSFUL'], $userBooking->{UserBooking::COL_AMOUNT_FROM_USER}, StaffConst::SYSTEM);
                }

                $numOfBookings++;
            }
        }

        LoggingHelper::logCronJob(__CLASS__, $resultList);
    }
}
