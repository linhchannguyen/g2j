<?php

namespace App\Console\Commands\Minute;

use App\Actions\Reward\PushNotificationPoint;
use App\Actions\Reward\RewardPointFromBooking;
use App\Actions\Reward\WithdrawPendingRewardPoint;
use App\DTOs\Reward\PushNotificationPointInputDTO;
use App\DTOs\Reward\RewardPointFromBookingInputDTO;
use App\DTOs\Reward\WithdrawPendingRewardPointInputDTO;
use App\Exceptions\ServiceException;
use App\Helpers\LoggingHelper;
use App\Models\MileagePointTransactionHistory;
use App\Repositories\Interfaces\MileagePointTransactionHistoryRepositoryInterface;
use Exception;
use Illuminate\Console\Command;
use Psr\SimpleCache\InvalidArgumentException;

class HandlePendingRewardPoint extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'minute:handle-pending-reward-point';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Handle mileage point transaction history with status is pending reward';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @param MileagePointTransactionHistoryRepositoryInterface $mileagePointTransactionHistoryRepository
     *
     * @return void
     * @throws ServiceException|InvalidArgumentException
     */
    public function handle(MileagePointTransactionHistoryRepositoryInterface $mileagePointTransactionHistoryRepository)
    {
        $mileagePointTransactionHistoryList = $mileagePointTransactionHistoryRepository->findPendingRewardPointStatusList();

        $resultList = [];
        foreach ($mileagePointTransactionHistoryList as $mileagePointTransactionHistory) {
            $userBookingSn = $mileagePointTransactionHistory->{MileagePointTransactionHistory::COL_USER_BOOKING_SN};
            $mileagePointTransactionHistorySn = $mileagePointTransactionHistory->{MileagePointTransactionHistory::COL_SN};

            try {
                /** @var RewardPointFromBooking $rewardPointFromBooking */
                $rewardPointFromBooking = app(RewardPointFromBooking::class);
                $rewardPointFromBookingInputDTO = new RewardPointFromBookingInputDTO();
                $rewardPointFromBookingInputDTO->setUserBookingSn($userBookingSn);
                $rewardPointFromBookingOutputDTO = $rewardPointFromBooking->handle($rewardPointFromBookingInputDTO);

                /** @var WithdrawPendingRewardPoint $withdrawPendingRewardPoint */
                $withdrawPendingRewardPoint = app(WithdrawPendingRewardPoint::class);
                $withdrawPendingRewardPointInputDTO = new WithdrawPendingRewardPointInputDTO();
                $withdrawPendingRewardPointInputDTO->setUserBookingSn($userBookingSn);
                $withdrawPendingRewardPointOutputDTO = $withdrawPendingRewardPoint->handle($withdrawPendingRewardPointInputDTO);

                /** @var PushNotificationPoint $pushNotificationPoint */
                $pushNotificationPoint = app(PushNotificationPoint::class);
                $pushNotificationPointInputDTO = new PushNotificationPointInputDTO();
                $pushNotificationPointInputDTO->setMileagePointTransactionHistorySn($rewardPointFromBookingOutputDTO->getMileagePointTransactionHistorySn());
                $pushNotificationPoint->handle($pushNotificationPointInputDTO);

                $resultList[$mileagePointTransactionHistorySn] = [
                    'rewardPointFromBooking' => $rewardPointFromBookingOutputDTO->getEarnedPoint(),
                    'withdrawRewardPoint'    => $withdrawPendingRewardPointOutputDTO->isSuccess(),
                ];
            } catch (Exception $exception) {
                report($exception);
                continue;
            }
        }
        LoggingHelper::logCronJob(__CLASS__, $resultList);
    }
}
