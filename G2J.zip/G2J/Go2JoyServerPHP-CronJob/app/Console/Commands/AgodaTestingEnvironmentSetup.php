<?php

namespace App\Console\Commands;

use App\Console\Commands\Integration\Agoda\FetchHotel;
use App\Console\Commands\Integration\Agoda\GroupHotel;
use App\Console\Commands\Integration\Agoda\ImportHotel;
use App\Console\Commands\Integration\Agoda\ImportHotelFacility;
use App\Console\Commands\Integration\Agoda\ImportHotelImage;
use App\Console\Commands\Integration\Agoda\ImportRoomType;
use App\Console\Commands\Integration\Agoda\ImportRoomTypeFacility;
use App\Console\Commands\Integration\Agoda\PullHotel;
use App\Console\Commands\Integration\Agoda\PullHotelFacility;
use App\Console\Commands\Integration\Agoda\PullHotelImage;
use App\Console\Commands\Integration\Agoda\PullRoomType;
use App\Console\Commands\Integration\Agoda\PullRoomTypeFacility;
use App\Console\Commands\Integration\Agoda\RefreshHotelDisplayFilter;
use App\Console\Commands\Integration\Agoda\RefreshRoomPriceToday;
use App\Console\Commands\Integration\Agoda\UpdateRoomPriceOneDay;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Artisan;

class AgodaTestingEnvironmentSetup extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'agoda-testing-environment-setup';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Agoda testing environment setup';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     */
    public function handle()
    {
        $params = [
            '--hotelId' => 2256959,
            '--cityId'  => 4064,
        ];
        Artisan::call(FetchHotel::class, $params);

        $params = [
            '--queue' => 'integration_agoda_fetch_hotel',
            '--once'  => null,
        ];
        Artisan::call('queue:work', $params);

        $params = [
            '--hotelIdList' => 2256959,
        ];
        Artisan::call(PullHotel::class, $params);

        $params = [
            '--queue' => 'integration_agoda_pull_hotel',
            '--once'  => null,
        ];
        Artisan::call('queue:work', $params);

        $params = [
            '--hotelIdList' => 2256959,
        ];
        Artisan::call(ImportHotel::class, $params);

        $params = [
            '--queue' => 'integration_agoda_import_hotel',
            '--once'  => null,
        ];
        Artisan::call('queue:work', $params);

        $params = [
            '--hotelIdList' => 2256959,
        ];
        Artisan::call(PullHotelFacility::class, $params);

        $params = [
            '--queue' => 'integration_agoda_pull_hotel_facility',
            '--once'  => null,
        ];
        Artisan::call('queue:work', $params);

        $params = [
            '--hotelIdList' => 2256959,
        ];
        Artisan::call(ImportHotelFacility::class, $params);

        $params = [
            '--queue' => 'integration_agoda_import_hotel_facility',
            '--once'  => null,
        ];
        Artisan::call('queue:work', $params);

        $params = [
            '--hotelIdList' => 2256959,
        ];
        Artisan::call(PullHotelImage::class, $params);

        $params = [
            '--queue' => 'integration_agoda_pull_hotel_image',
            '--once'  => null,
        ];
        Artisan::call('queue:work', $params);

        $params = [
            '--hotelIdList' => 2256959,
        ];
        Artisan::call(ImportHotelImage::class, $params);

        $params = [
            '--queue' => 'integration_agoda_import_hotel_image',
            '--once'  => null,
        ];
        Artisan::call('queue:work', $params);

        $params = [
            '--queue' => 'integration_agoda_transport_resource',
            '--once'  => null,
        ];
        Artisan::call('queue:work', $params);

        $params = [
            '--hotelIdList' => 2256959,
        ];
        Artisan::call(PullRoomType::class, $params);

        $params = [
            '--queue' => 'integration_agoda_pull_room_type',
            '--once'  => null,
        ];
        Artisan::call('queue:work', $params);

        $params = [
            '--hotelIdList' => 2256959,
        ];
        Artisan::call(ImportRoomType::class, $params);

        $params = [
            '--queue' => 'integration_agoda_import_room_type',
            '--once'  => null,
        ];
        Artisan::call('queue:work', $params);

        $params = [
            '--queue' => 'integration_agoda_transport_resource',
            '--once'  => null,
        ];
        Artisan::call('queue:work', $params);

        $params = [
            '--hotelIdList' => 2256959,
        ];
        Artisan::call(PullRoomTypeFacility::class, $params);

        $params = [
            '--queue' => 'integration_agoda_pull_room_type_facility',
            '--once'  => null,
        ];
        Artisan::call('queue:work', $params);

        $params = [
            '--hotelIdList' => 2256959,
        ];
        Artisan::call(ImportRoomTypeFacility::class, $params);

        $params = [
            '--queue' => 'integration_agoda_import_room_type_facility',
            '--once'  => null,
        ];
        Artisan::call('queue:work', $params);

        $params = [
            '--hotelIdList' => 2256959,
        ];
        Artisan::call(RefreshHotelDisplayFilter::class, $params);

        $params = [
            '--queue' => 'integration_agoda_refresh_hotel_display_filter',
            '--once'  => null,
        ];
        Artisan::call('queue:work', $params);

        Artisan::call(GroupHotel::class);

        $params = [
            '--hotelIdList' => 2256959,
        ];
        Artisan::call(UpdateRoomPriceOneDay::class, $params);

        $params = [
            '--queue' => 'integration_agoda_refresh_room_price_today',
            '--once'  => null,
        ];
        Artisan::call('queue:work', $params);
    }
}