<?php

namespace App\Console\Commands\Weekly;

use App\Constants\AmplitudeChangeUserBookingStatus as AmplitudeChangeUserBookingStatusConst;
use App\Helpers\LoggingHelper;
use App\Models\AmplitudeChangeUserBookingStatus;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;

class DeleteAmplitudeChangeBookingStatus extends Command
{
    protected $amplitudeProcessor;

    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'weekly:delete-amplitude-change-booking-status';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Delete tracking records when booking status changes';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    public function handle()
    {
        LoggingHelper::logFunction('START JOB: WEEKLY START DELETE AMPLITUDE CHANGE BOOKING STATUS');

        DB::connection('replica')->table(AmplitudeChangeUserBookingStatus::TABLE_NAME)
            ->where(AmplitudeChangeUserBookingStatus::COL_SEND, AmplitudeChangeUserBookingStatusConst::SEND['YES'])
            ->delete();

        LoggingHelper::logFunction('START JOB: WEEKLY COMPLETE DELETE AMPLITUDE CHANGE BOOKING STATUS');
    }
}
