<?php

namespace App\Console\Commands\Weekly;

use App\Constants\Globals\QueueName;
use App\Constants\Staff as StaffConst;
use App\Helpers\UploadHelper;
use App\Jobs\Mail\SendExportFileMailJobV2;
use App\Models\ReferralProgramInviteeBookingHistory;
use App\Models\ReferralProgramRecord;
use App\Models\UserBooking;
use App\Repositories\Interfaces\ReferralProgramInviteeBookingHistoryRepositoryInterface;
use App\Repositories\Interfaces\ReferralProgramRecordRepositoryInterface;
use App\Repositories\Interfaces\UserBookingRepositoryInterface;
use Illuminate\Console\Command;
use Illuminate\Contracts\Filesystem\FileNotFoundException;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Storage;
use PhpOffice\PhpSpreadsheet\Exception;
use PhpOffice\PhpSpreadsheet\IOFactory;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

class ReportReferralProgram extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'weekly:report-referral-program
                            {--startDate=}
                            {--endDate=}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Report referral program every week about last week recording';

    /** @var UserBookingRepositoryInterface */
    private $userBookingRepository;

    /** @var ReferralProgramRecordRepositoryInterface */
    private $referralProgramRecordRepository;

    /** @var ReferralProgramInviteeBookingHistoryRepositoryInterface */
    private $referralProgramInviteeBookingHistoryRepository;

    const BOOKING_STATUS_STR = array(
        'VI' => [
            0  => 'Đã hủy', // Payment failed
            1  => 'Chờ nhận phòng',
            2  => 'Hoàn thành',
            3  => 'Đã hủy',
            4  => 'Không nhận phòng',
            5  => 'Chờ thanh toán',
            6  => 'Chờ xác nhận phòng',
            8  => 'Chờ Go2Joy xử lý',
            9  => 'Đã nhận phòng',
            10 => 'Chờ khách xác nhận'
        ],
        'EN' => [
            0  => 'Cancelled',
            1  => 'Upcoming',
            2  => 'Completed',
            3  => 'Cancelled',
            4  => 'No-show',
            5  => 'Wait for payment',
            6  => 'Wait for confirmation',
            8  => 'Wait for Go2Joy',
            9  => 'Checked in',
            10 => 'Wait for User'
        ],
    );

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
        $this->userBookingRepository = app(UserBookingRepositoryInterface::class);
        $this->referralProgramRecordRepository = app(ReferralProgramRecordRepositoryInterface::class);
        $this->referralProgramInviteeBookingHistoryRepository = app(ReferralProgramInviteeBookingHistoryRepositoryInterface::class);
    }

    /**
     * Execute the console command.
     *
     * @return void
     * @throws Exception
     * @throws \PhpOffice\PhpSpreadsheet\Writer\Exception|FileNotFoundException
     */
    public function handle()
    {
        $startDate = Carbon::now()->startOfWeek()->subWeek();
        $endDate = Carbon::now()->endOfWeek()->subWeek();

        if (!empty($this->option('startDate')) && !empty($this->option('endDate'))) {
            $startDate = $this->option('startDate');
            $endDate = $this->option('endDate');
        }

        $referralProgramRecordList = $this->referralProgramRecordRepository->findByPeriod($startDate, $endDate);

        $referralProgramInviteeBookingHistoryList = $this->referralProgramInviteeBookingHistoryRepository->findByInviteeRegisterDateIn30Days();
        $userBookingSnList = $referralProgramInviteeBookingHistoryList->pluck(ReferralProgramInviteeBookingHistory::COL_INVITEE_USER_BOOKING_SN)->toArray();
        $userBookingList = $this->userBookingRepository->findBySnList($userBookingSnList);

        $fileTemplatePath = resource_path('views/template/excel/referral_program_report_template.xlsx');
        $spreadsheet = IOFactory::load($fileTemplatePath);
        $sheetUserList = $spreadsheet->getSheet(0);
        $startCol = 1;
        $startRow = 4;

        $colInputStartDate = 2;
        $rowInputStartDate = 1;
        $colInputEndDate = 4;
        $rowInputEndDate = 1;
        $sheetUserList->setCellValueByColumnAndRow($colInputStartDate, $rowInputStartDate, $startDate);
        $sheetUserList->setCellValueByColumnAndRow($colInputEndDate, $rowInputEndDate, $endDate);
        foreach ($referralProgramRecordList as $index => $referralProgramRecord) {
            $row = $startRow + $index;
            $col = $startCol;

            $sheetUserList->setCellValueByColumnAndRow($col, $row, $referralProgramRecord->{ReferralProgramRecord::COL_INVITEE_SN});

            $sheetUserList->setCellValueByColumnAndRow(++$col, $row, strval($referralProgramRecord->{ReferralProgramRecord::COL_INVITEE_MOBILE}));

            $sheetUserList->setCellValueByColumnAndRow(++$col, $row, $referralProgramRecord->{ReferralProgramRecord::COL_INVITEE_REGISTER_TIME});

            $sheetUserList->setCellValueByColumnAndRow(++$col, $row, $referralProgramRecord->{ReferralProgramRecord::COL_REFERRAL_CODE});

            $sheetUserList->setCellValueByColumnAndRow(++$col, $row, $referralProgramRecord->{ReferralProgramRecord::COL_REFERER_SN});

            $sheetUserList->setCellValueByColumnAndRow(++$col, $row, $referralProgramRecord->{ReferralProgramRecord::COL_REFERER_REGISTER_TIME});
        }

        $sheetBookingList = $spreadsheet->getSheet(1);
        $startRow = 2;
        foreach ($referralProgramInviteeBookingHistoryList as $index => $referralProgramInviteeBookingHistory) {
            $row = $startRow + $index;
            $col = $startCol;

            $sheetBookingList->setCellValueByColumnAndRow($col, $row, $referralProgramInviteeBookingHistory->{ReferralProgramInviteeBookingHistory::COL_INVITEE_SN});

            $sheetBookingList->setCellValueByColumnAndRow(++$col, $row, $referralProgramInviteeBookingHistory->{ReferralProgramInviteeBookingHistory::COL_INVITEE_BOOKING_DATE});

            $sheetBookingList->setCellValueByColumnAndRow(++$col, $row, $referralProgramInviteeBookingHistory->{ReferralProgramInviteeBookingHistory::COL_INVITEE_BOOKING_NO});

            $userBooking = $userBookingList->where(UserBooking::COL_SN, $referralProgramInviteeBookingHistory->{ReferralProgramInviteeBookingHistory::COL_INVITEE_USER_BOOKING_SN})->first();
            $bookingStatus = $userBooking->{UserBooking::COL_BOOKING_STATUS};
            $bookingStatusStr = self::BOOKING_STATUS_STR['EN'][$bookingStatus];
            $sheetBookingList->setCellValueByColumnAndRow(++$col, $row, $bookingStatusStr);

            $sheetBookingList->setCellValueByColumnAndRow(++$col, $row, $referralProgramInviteeBookingHistory->{ReferralProgramInviteeBookingHistory::COL_INVITEE_G2J_ACTUAL_COST});

            $sheetBookingList->setCellValueByColumnAndRow(++$col, $row, $referralProgramInviteeBookingHistory->{ReferralProgramInviteeBookingHistory::COL_INVITEE_GMV});

            $sheetBookingList->setCellValueByColumnAndRow(++$col, $row, $referralProgramInviteeBookingHistory->{ReferralProgramInviteeBookingHistory::COL_INVITEE_MILEAGE_POINT_USED});

            $sheetBookingList->setCellValueByColumnAndRow(++$col, $row, $referralProgramInviteeBookingHistory->{ReferralProgramInviteeBookingHistory::COL_REFERER_SN});
        }

        $writer = new Xlsx($spreadsheet);
        ob_start();
        $writer->save('php://output');
        $content = ob_get_contents();
        ob_end_clean();

        $from = Carbon::parse($startDate)->format('Ymd');
        $to = Carbon::parse($endDate)->format('Ymd');
        $fileName = "{$from}_{$to}.xlsx";
        $filePath = "/exports/referral-program-report/{$fileName}";
        Storage::disk('local')->put($filePath, $content);

        // Upload to S3
        $content = Storage::disk(UploadHelper::DISK_LOCAL)->get($filePath);
        UploadHelper::uploadFile($content, UploadHelper::FOLDER['UPLOAD'] . $filePath);

        // Final job
        $emailList = explode(',', config('go2joy.mkt_email_address_list'));
        $downloadUrl = config('export.file.url.sa');
        SendExportFileMailJobV2::dispatch(
            StaffConst::SYSTEM,
            $filePath,
            $fileName,
            'Referral Program Reporting',
            $emailList,
            $downloadUrl
        )->onQueue(QueueName::EMAIL);

        // Free memory
        unset($spreadsheet);
        unset($sheetUserList);
        unset($sheetBookingList);
        unset($content);

        echo 'Successful exporting' . PHP_EOL;
    }
}
