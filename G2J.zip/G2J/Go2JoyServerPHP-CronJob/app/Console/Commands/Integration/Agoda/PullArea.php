<?php

namespace App\Console\Commands\Integration\Agoda;

use App\API\External\Integration\Agoda\AgodaProcessor;
use App\Constants\Globals\Integration;
use App\Constants\Globals\Slack;
use App\Constants\Partners\Agoda as AgodaConst;
use App\DTOs\Integration\Agoda\GetAreaListInputDTO;
use App\Factories\IntegrationFactory;
use App\Helpers\GenerateHelper;
use App\Helpers\LoggingHelper;
use App\Models\MongoDB\AgodaArea;
use App\Models\MongoDB\AgodaCity;
use Exception;
use Illuminate\Console\Command;
use Illuminate\Support\Carbon;
use MongoDB\BSON\UTCDateTime;

class PullArea extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'integration:agoda:pull-area
                            {--cityIdList=}
                            {--languageId=}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Pull area info from Agoda';

    /** @var AgodaProcessor */
    public $agodaProcessor;

    /**
     * Create a new command instance.
     *
     * @return void
     * @throws Exception
     */
    public function __construct()
    {
        parent::__construct();

        $partner = Integration::PARTNER['AGODA'];
        $integrationFactory = new IntegrationFactory();
        $this->agodaProcessor = $integrationFactory->createProcessor($partner);
    }

    /**
     * Execute the console command.
     *
     * @throws Exception
     */
    public function handle()
    {
        $cityIdList = $this->option('cityIdList');
        $cityIdList = explode(',', $cityIdList);
        $cityIdList = array_filter($cityIdList);
        $cityIdList = array_map('intval', $cityIdList);

        $languageId = $this->option('languageId') ?? AgodaConst::LANGUAGE_ID['VIETNAMESE'];

        // Get all city active in MongoDB
        $allCityActive = AgodaCity::all();

        // Filter city with list of city in MongoDB
        if ($cityIdList) {
            $cityList = $allCityActive->filter(function ($item) use ($cityIdList) {
                return in_array($item->{AgodaCity::FIELD_CITY_ID}, $cityIdList);
            });
        } else {
            $cityList = $allCityActive;
        }

        foreach ($cityList as $city) {
            $getAreaListInputDTO = new GetAreaListInputDTO();
            $getAreaListInputDTO->setCityId(intval($city->{AgodaCity::FIELD_CITY_ID}));
            $getAreaListInputDTO->setLanguageId($languageId);

            // Get area list from Agoda
            $getAreaListOutputDTO = $this->agodaProcessor->getAreaList($getAreaListInputDTO);

            // Upsert to MongoDB
            $areaList = $getAreaListOutputDTO->getAreaList();
            foreach ($areaList as $area) {
                $document = [
                    AgodaArea::FIELD_CITY_ID         => $area['cityId'],
                    AgodaArea::FIELD_AREA_NAME       => $area['areaName'],
                    AgodaArea::FIELD_AREA_TRANSLATED => $area['areaTranslated'],
                    AgodaArea::FIELD_ACTIVE_HOTELS   => $area['activeHotels'],
                    AgodaArea::FIELD_LONGITUDE       => $area['longitude'],
                    AgodaArea::FIELD_LATITUDE        => $area['latitude'],
                    AgodaArea::FIELD_POLYGON         => $area['polygon'],
                    AgodaArea::FIELD_LAST_UPDATE     => new UTCDateTime(Carbon::now()),
                ];
                AgodaArea::where(AgodaArea::FIELD_AREA_ID, intval($area['areaId']))
                    ->update($document, ['upsert' => true]);
                break;
            }
        }

        $logMessage = GenerateHelper::logMessage('info', self::class, 'All done!');
        LoggingHelper::toSlack(Slack::CHANNEL['SCHEDULE_MONITOR'], $logMessage);
    }
}