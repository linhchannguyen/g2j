<?php

namespace App\Console\Commands\Integration\Agoda;

use App\Constants\Globals\QueueName;
use App\Constants\Globals\Slack;
use App\Constants\Globals\State;
use App\Constants\MongoDB\AgodaHotel as AgodaHotelConst;
use App\Helpers\GenerateHelper;
use App\Helpers\LoggingHelper;
use App\Models\MongoDB\AgodaHotel;
use App\Models\MongoDB\AgodaRoomTypeReport;
use Exception;
use Illuminate\Console\Command;

class ImportRoomType extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'integration:agoda:import-room-type
                            {--hotelIdList=}
                            {--force : Force update room price, not care about state}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Import room type from MongoDB to MySQL';

    /** @var int */
    const LIMIT = 100;

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @throws Exception
     */
    public function handle()
    {
        $hotelIdList = $this->option('hotelIdList');
        $hotelIdList = explode(',', $hotelIdList);
        $hotelIdList = array_filter($hotelIdList);
        $hotelIdList = array_map('intval', $hotelIdList);

        $force = $this->option('force');

        // Get all partner room type report in MongoDB
        $queryStatement = AgodaHotel::where(AgodaHotel::FIELD_STATUS, AgodaHotelConst::STATUS['ACTIVE'])
            ->where(AgodaHotel::FIELD_PULL_ROOM_TYPE_STATE, State::DONE)
            ->whereNotNull(AgodaHotel::FIELD_HOTEL_SN);

        if (!$force) {
            $queryStatement->where(AgodaHotel::FIELD_IMPORT_ROOM_TYPE_STATE, State::TO_DO);
        }

        // Filter hotel list with list of hotel id from input
        if ($hotelIdList) {
            $partnerHotelList = $queryStatement->whereIn(AgodaHotel::FIELD_PARTNER_HOTEL_ID, $hotelIdList)
                ->get([
                    AgodaHotel::FIELD_HOTEL_SN,
                    AgodaHotel::FIELD_PARTNER_HOTEL_ID,
                ]);
        } else {
            $partnerHotelList = $queryStatement->limit(self::LIMIT)
                ->get([
                    AgodaHotel::FIELD_HOTEL_SN,
                    AgodaHotel::FIELD_PARTNER_HOTEL_ID,
                ]);
        }

        if (!empty($partnerHotelList)) {
            $partnerHotelIdList = $partnerHotelList->pluck(AgodaHotel::FIELD_PARTNER_HOTEL_ID)->toArray();
            $partnerHotelIdList = array_map('intval', $partnerHotelIdList);
            // Update import room type stage of hotel has been pushed into queue
            AgodaHotel::whereIn(AgodaHotel::FIELD_PARTNER_HOTEL_ID, $partnerHotelIdList)
                ->update([
                    AgodaHotel::FIELD_IMPORT_ROOM_TYPE_STATE => State::DOING
                ]);
        }

        foreach ($partnerHotelList as $partnerHotel) {
            $hotelSn = $partnerHotel->{AgodaRoomTypeReport::FIELD_HOTEL_SN};
            $hotelId = $partnerHotel->{AgodaRoomTypeReport::FIELD_PARTNER_HOTEL_ID};

            $partnerRoomTypeReport = AgodaRoomTypeReport::where(AgodaRoomTypeReport::FIELD_PARTNER_HOTEL_ID, intval($hotelId))
                ->where(AgodaRoomTypeReport::FIELD_HOTEL_SN, intval($hotelSn))
                ->first([AgodaRoomTypeReport::FIELD_PARTNER_ROOM_TYPE_ID_LIST]);
            $partnerRoomTypeIdList = $partnerRoomTypeReport->{AgodaRoomTypeReport::FIELD_PARTNER_ROOM_TYPE_ID_LIST};

            // Push the import room type job into queue
            $message = json_encode([
                'hotelSn'               => $hotelSn,
                'hotelId'               => $hotelId,
                'partnerRoomTypeIdList' => $partnerRoomTypeIdList,
            ]);

            $job = new \App\Jobs\Integration\Agoda\ImportRoomTypeJob($message);
            dispatch($job->onQueue(QueueName::INTEGRATION['AGODA_REFRESH_CONTENT']['IMPORT_ROOM_TYPE']));
        }

        $numOfJobs = count($partnerHotelList);
        if ($numOfJobs != 0) {
            $logMessage = GenerateHelper::logMessage('info', self::class, "$numOfJobs import room type jobs have been pushed into queue!");
            LoggingHelper::toSlack(Slack::CHANNEL['SCHEDULE_MONITOR'], $logMessage);
        }
    }
}