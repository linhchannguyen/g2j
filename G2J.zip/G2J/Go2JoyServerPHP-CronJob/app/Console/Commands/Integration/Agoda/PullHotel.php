<?php

namespace App\Console\Commands\Integration\Agoda;

use App\API\External\Integration\Agoda\AgodaProcessor;
use App\Constants\Globals\Integration;
use App\Constants\Globals\QueueName;
use App\Constants\Globals\Slack;
use App\Constants\Globals\State;
use App\Constants\MongoDB\AgodaHotel as AgodaHotelConst;
use App\Constants\Partners\Agoda as AgodaConst;
use App\Factories\IntegrationFactory;
use App\Helpers\GenerateHelper;
use App\Helpers\LoggingHelper;
use App\Jobs\Integration\Agoda\PullHotelJob;
use App\Models\MongoDB\AgodaHotel;
use Exception;
use Illuminate\Console\Command;

class PullHotel extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'integration:agoda:pull-hotel
                            {--hotelIdList=}
                            {--languageId=}
                            {--currency=}
                            {--onlyNewHotel : Pull new hotel only}
                            {--force : Force pull data, not care about state}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Pull hotel from Agoda';

    /** @var AgodaProcessor */
    public $agodaProcessor;

    /** @var int */
    const LIMIT = 10;

    /**
     * Create a new command instance.
     *
     * @return void
     * @throws Exception
     */
    public function __construct()
    {
        parent::__construct();

        $partner = Integration::PARTNER['AGODA'];
        $integrationFactory = new IntegrationFactory();
        $this->agodaProcessor = $integrationFactory->createProcessor($partner);
    }

    /**
     * Execute the console command.
     *
     * @throws Exception
     */
    public function handle()
    {
        $hotelIdList = $this->option('hotelIdList');
        $hotelIdList = explode(',', $hotelIdList);
        $hotelIdList = array_filter($hotelIdList);
        $hotelIdList = array_map('intval', $hotelIdList);

        $languageId = $this->option('languageId') ?? AgodaConst::LANGUAGE_ID['VIETNAMESE'];
        $currency = $this->option('currency') ?? AgodaConst::CURRENCY_CODE['VIETNAMESE_DONG'];

        $onlyNewHotel = $this->option('onlyNewHotel');

        $force = $this->option('force');

        // Get all hotel active in MongoDB
        if ($onlyNewHotel) {
            $queryStatement = AgodaHotel::where(AgodaHotel::FIELD_STATUS, AgodaHotelConst::STATUS['ACTIVE'])
                ->whereNull(AgodaHotel::FIELD_HOTEL_SN);
        } else {
            $queryStatement = AgodaHotel::where(AgodaHotel::FIELD_STATUS, AgodaHotelConst::STATUS['ACTIVE']);
        }

        if (!$force) {
            $queryStatement->where(AgodaHotel::FIELD_PULL_STATE, State::TO_DO);
        }

        // Filter hotel with list of hotel id from input
        if ($hotelIdList) {
            $hotelList = $queryStatement->whereIn(AgodaHotel::FIELD_PARTNER_HOTEL_ID, $hotelIdList)
                ->get([
                    AgodaHotel::FIELD_PARTNER_HOTEL_ID
                ]);
        } else {
            $hotelList = $queryStatement->limit(self::LIMIT)
                ->get([
                    AgodaHotel::FIELD_PARTNER_HOTEL_ID
                ]);
        }

        if (!empty($hotelList)) {
            $partnerHotelIdList = $hotelList->pluck(AgodaHotel::FIELD_PARTNER_HOTEL_ID)->toArray();
            $partnerHotelIdList = array_map('intval', $partnerHotelIdList);
            // Update pull stage of hotel has been pushed into queue
            AgodaHotel::whereIn(AgodaHotel::FIELD_PARTNER_HOTEL_ID, $partnerHotelIdList)
                ->update([
                    AgodaHotel::FIELD_PULL_STATE => State::DOING
                ]);
        }

        foreach ($hotelList as $index => $hotel) {
            $hotelId = $hotel->{AgodaHotel::FIELD_PARTNER_HOTEL_ID};

            // Push the pull hotel job into queue
            $message = json_encode([
                'hotelId'    => $hotelId,
                'languageId' => $languageId,
                'currency'   => $currency,
            ]);

            $num = $index + 1;
            if ($num % 20 == 0) { // Rate limit, QPS: 20
                sleep(1);
            }

            $job = new PullHotelJob($message);
            dispatch($job->onQueue(QueueName::INTEGRATION['AGODA_REFRESH_CONTENT']['PULL_HOTEL']));
        }

        $numOfJobs = count($hotelList);
        if ($numOfJobs != 0) {
            $logMessage = GenerateHelper::logMessage('info', self::class, "$numOfJobs pull hotel jobs have been pushed into queue!");
            LoggingHelper::toSlack(Slack::CHANNEL['SCHEDULE_MONITOR'], $logMessage);
        }
    }
}
