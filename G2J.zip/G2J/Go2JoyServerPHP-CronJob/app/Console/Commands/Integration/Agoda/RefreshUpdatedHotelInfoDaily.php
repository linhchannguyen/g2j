<?php

namespace App\Console\Commands\Integration\Agoda;

use App\API\External\Integration\Agoda\AgodaProcessor;
use App\Constants\Globals\Integration;
use App\Constants\Globals\Slack;
use App\Constants\Partners\Agoda;
use App\DTOs\Integration\Agoda\GetHotelHaveInfoUpdateInputDTO;
use App\Factories\IntegrationFactory;
use App\Helpers\GenerateHelper;
use App\Helpers\LoggingHelper;
use Exception;
use Illuminate\Console\Command;
use Illuminate\Support\Carbon;

class RefreshUpdatedHotelInfoDaily extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'integration:agoda:refresh-updated-hotel-info-daily
                            {--date=}
                            {--typeIdList=}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Refresh updated hotel information daily through Feed32 API';

    /** @var AgodaProcessor */
    public $agodaProcessor;

    /**
     * Create a new command instance.
     *
     * @return void
     * @throws Exception
     */
    public function __construct()
    {
        parent::__construct();

        $partner = Integration::PARTNER['AGODA'];
        $integrationFactory = new IntegrationFactory();
        $this->agodaProcessor = $integrationFactory->createProcessor($partner);
    }

    /**
     * Execute the console command.
     *
     * @return void
     * @throws Exception
     */
    public function handle()
    {
        $date = $this->option('date') ?? Carbon::now()->subDay();
        $typeIdList = $this->option('typeIdList') ?? [Agoda::TYPE_ID['CONTENT_UPDATE'], Agoda::TYPE_ID['NEWLY_ENABLED'], Agoda::TYPE_ID['DISABLED_OR_CLOSED']];

        foreach ($typeIdList as $typeId) {
            $getHotelHaveInfoUpdateInputDTO = new GetHotelHaveInfoUpdateInputDTO();
            $getHotelHaveInfoUpdateInputDTO->setDate($date);
            $getHotelHaveInfoUpdateInputDTO->setTypeId($typeId);
            $getHotelHaveInfoUpdateOutputDTO = $this->agodaProcessor->getHotelHaveInfoUpdate($getHotelHaveInfoUpdateInputDTO);
            if (!empty($getHotelHaveInfoUpdateOutputDTO->getHotelIdList())) {
                $data = implode(',', $getHotelHaveInfoUpdateOutputDTO->getHotelIdList());
                $logMessage = GenerateHelper::logMessage('info', self::class, "RefreshUpdatedHotelInfoDaily-$typeId: $data");
                LoggingHelper::toSlack(Slack::CHANNEL['BACKEND_MONITOR'], $logMessage);
            }
        }

        $logMessage = GenerateHelper::logMessage('info', self::class, 'All done!');
        LoggingHelper::toSlack(Slack::CHANNEL['SCHEDULE_MONITOR'], $logMessage);
    }
}
