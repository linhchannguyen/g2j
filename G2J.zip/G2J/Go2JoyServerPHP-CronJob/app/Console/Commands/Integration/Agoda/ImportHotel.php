<?php

namespace App\Console\Commands\Integration\Agoda;

use App\Constants\Globals\FunctionName;
use App\Constants\Globals\QueueName;
use App\Constants\Globals\Slack;
use App\Constants\Globals\State;
use App\Constants\MongoDB\AgodaHotel as AgodaHotelConst;
use App\Helpers\GenerateHelper;
use App\Helpers\LoggingHelper;
use App\Models\MongoDB\AgodaHotel;
use Exception;
use Illuminate\Console\Command;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Cache;
use Psr\SimpleCache\InvalidArgumentException;

class ImportHotel extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'integration:agoda:import-hotel 
                            {--hotelIdList=}
                            {--force : Force update room price, not care about state}
                            {--allowOverlimitReverseGeocoding : Allow overlimit reverse geocoding}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Import hotel from MongoDB to MySQL';

    /** @var int */
    const LIMIT = 100;

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @throws Exception|InvalidArgumentException
     */
    public function handle()
    {
        $hotelIdList = $this->option('hotelIdList');
        $hotelIdList = explode(',', $hotelIdList);
        $hotelIdList = array_filter($hotelIdList);
        $hotelIdList = array_map('intval', $hotelIdList);

        $force = $this->option('force');

        $allowOverlimitReverseGeocoding = $this->option('allowOverlimitReverseGeocoding');

        // Get all hotel active in MongoDB
        $queryStatement = AgodaHotel::where(AgodaHotel::FIELD_STATUS, AgodaHotelConst::STATUS['ACTIVE'])
            ->where(AgodaHotel::FIELD_PULL_STATE, State::DONE)
            ->whereNotNull(AgodaHotel::FIELD_RAW_DATA);

        if (!$force) {
            $queryStatement->where(AgodaHotel::FIELD_IMPORT_STATE, State::TO_DO);
        }

        // Filter hotel with list of hotel id from input
        if ($hotelIdList) {
            $hotelList = $queryStatement->whereIn(AgodaHotel::FIELD_PARTNER_HOTEL_ID, $hotelIdList)
                ->get([
                    AgodaHotel::FIELD_PARTNER_HOTEL_ID,
                    AgodaHotel::FIELD_IS_USED_REVERSE_GEOCODING,
                ]);
        } else {
            $hotelList = $queryStatement->limit(self::LIMIT)
                ->get([
                    AgodaHotel::FIELD_PARTNER_HOTEL_ID,
                    AgodaHotel::FIELD_IS_USED_REVERSE_GEOCODING,
                ]);
        }

        // Get the remaining amount to use Google Map API to get Province SN and District SN
        $dailyReverseGeocodingLimit = intval(config('agoda.config.dailyReverseGeocodingLimit'));
        $numOfAllowReverseGeocoding = 0;
        $numOfUsed = 0;
        $numOfRemaining = $dailyReverseGeocodingLimit;
        $key = GenerateHelper::cacheName(function() {
            return sprintf('%s:%s', 'agoda', FunctionName::USED_DAILY_REVERSE_GEOCODING_REQUEST);
        });
        if (Cache::store('redis')->has($key)) {
            $numOfUsed = intval(Cache::store('redis')->get($key));
            $numOfRemaining = $dailyReverseGeocodingLimit - $numOfUsed;
        }

        foreach ($hotelList as $hotel) {
            $hotelId = $hotel->{AgodaHotel::FIELD_PARTNER_HOTEL_ID};
            $isUsedReverseGeocoding = boolval($hotel->{AgodaHotel::FIELD_IS_USED_REVERSE_GEOCODING});

            if ($isUsedReverseGeocoding == false && $numOfRemaining > 0) {
                $allowPushJob = true;
                $allowReverseGeocoding = true;
            } elseif ($isUsedReverseGeocoding == false && $numOfRemaining <= 0) {
                $allowPushJob = false;
                if ($allowOverlimitReverseGeocoding) {
                    $allowPushJob = true;
                }
                $allowReverseGeocoding = false;
            } else {
                $allowPushJob = true;
                $allowReverseGeocoding = false;
            }

            if ($allowPushJob) {
                // Update import stage of hotel has been pushed into queue
                AgodaHotel::where(AgodaHotel::FIELD_PARTNER_HOTEL_ID, intval($hotelId))
                    ->update([
                        AgodaHotel::FIELD_IMPORT_STATE => State::DOING
                    ]);

                // Push the import hotel job into queue
                $message = json_encode([
                    'hotelId'               => $hotelId,
                    'allowReverseGeocoding' => $allowReverseGeocoding,
                    'position'              => $numOfUsed + 1,
                ]);

                $job = new \App\Jobs\Integration\Agoda\ImportHotelJob($message);
                dispatch($job->onQueue(QueueName::INTEGRATION['AGODA_REFRESH_CONTENT']['IMPORT_HOTEL']));
            }

            if ($allowReverseGeocoding) {
                $numOfRemaining--;
                $numOfAllowReverseGeocoding++;
            }
        }

        // Store the remaining amount to use Google Map API to get Province SN and District SN
        Cache::store('redis')->forget($key);
        $expiresAt = Carbon::now()->endOfDay();
        $value = $numOfUsed + $numOfAllowReverseGeocoding;
        Cache::store('redis')->put($key, $value, $expiresAt);

        $numOfJobs = count($hotelList);
        if ($numOfJobs != 0) {
            $logMessage = GenerateHelper::logMessage('info', self::class, "$numOfJobs import hotel jobs have been pushed into queue!");
            LoggingHelper::toSlack(Slack::CHANNEL['SCHEDULE_MONITOR'], $logMessage);
        }
    }
}