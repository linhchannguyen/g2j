<?php

namespace App\Console\Commands\Integration\Agoda;

use App\Constants\Globals\Slack;
use App\Constants\Hotel as HotelConst;
use App\Helpers\GenerateHelper;
use App\Helpers\LoggingHelper;
use App\Models\Hotel;
use App\Models\HotelGroup;
use Illuminate\Console\Command;

class GroupHotel extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'integration:agoda:group-hotel
                            {--hotelGroupSn=}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Group all of Agoda hotels';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return void
     */
    public function handle()
    {
        $hotelGroupSn = $this->option('hotelGroupSn');
        $agodaHotelList = Hotel::where(Hotel::COL_ORIGIN, HotelConst::ORIGIN['AGODA'])->get([
            Hotel::COL_SN,
            Hotel::COL_HOTEL_GROUP_SN,
        ]);
        $totalHotel = $agodaHotelList->count();
        if (empty($hotelGroupSn)) {
            $name = 'Agoda';
            $hotelGroup = HotelGroup::where(HotelGroup::COL_NAME, $name)->first();
            if (empty($hotelGroup)) {
                $ownerName = 'N/A';
                $ownerTel = 'N/A';
                $ownerEmail = 'N/A';
                $hotelGroup = new HotelGroup();
                $hotelGroup->{HotelGroup::COL_NAME} = $name;
                $hotelGroup->{HotelGroup::COL_OWNER_NAME} = $ownerName;
                $hotelGroup->{HotelGroup::COL_OWNER_TEL} = $ownerTel;
                $hotelGroup->{HotelGroup::COL_OWNER_EMAIL} = $ownerEmail;
            }
            $hotelGroup->{HotelGroup::COL_TOTAL_HOTEL} = $totalHotel;
            $hotelGroup->save();
        } else {
            $hotelGroup = HotelGroup::where(HotelGroup::COL_SN, $hotelGroupSn)->first();
            if (empty($hotelGroup)) {
                $logMessage = GenerateHelper::logMessage('error', self::class, 'Hotel group not found!');
                LoggingHelper::toSlack(Slack::CHANNEL['SCHEDULE_MONITOR'], $logMessage);
                return;
            }
        }
        $hotelGroupSn = $hotelGroup->{HotelGroup::COL_SN};
        foreach ($agodaHotelList as $hotel) {
            $hotel->{Hotel::COL_HOTEL_GROUP_SN} = $hotelGroupSn;
            $hotel->save();
        }
        $logMessage = GenerateHelper::logMessage('info', self::class, 'All done!');
        LoggingHelper::toSlack(Slack::CHANNEL['SCHEDULE_MONITOR'], $logMessage);
    }
}
