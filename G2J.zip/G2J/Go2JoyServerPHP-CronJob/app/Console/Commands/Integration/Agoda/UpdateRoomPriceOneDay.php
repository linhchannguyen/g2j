<?php

namespace App\Console\Commands\Integration\Agoda;

use App\Constants\Globals\QueueName;
use App\Constants\Globals\Slack;
use App\Constants\Globals\State;
use App\Constants\MongoDB\AgodaRoomType as AgodaRoomTypeConst;
use App\Helpers\GenerateHelper;
use App\Helpers\LoggingHelper;
use App\Jobs\Integration\Agoda\UpdateRoomPriceOneDayJob;
use App\Models\MongoDB\AgodaRoomType;
use Carbon\Carbon;
use Exception;
use Illuminate\Console\Command;

class UpdateRoomPriceOneDay extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'integration:agoda:update-room-price-one-day
                            {--roomTypeIdList=}
                            {--hotelIdList=}
                            {--force : Force update room price one day, not care about state}
                            {--retry : Retry update room price one day, if exceed time execute 3hour}
                            {--doing : One of the state of update room price one day}
                            {--noDataFound : One of the state of update room price one day}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Update price one day all rooms of Agoda hotel in max 1 year from now';

    /** @var int */
    const LIMIT = 50;

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return void
     * @throws Exception
     */
    public function handle()
    {
        $hotelIdList = $this->option('hotelIdList');
        $hotelIdList = explode(',', $hotelIdList);
        $hotelIdList = array_filter($hotelIdList);
        $hotelIdList = array_map('intval', $hotelIdList);

        $roomTypeIdList = $this->option('roomTypeIdList');
        $roomTypeIdList = explode(',', $roomTypeIdList);
        $roomTypeIdList = array_filter($roomTypeIdList);
        $roomTypeIdList = array_map('intval', $roomTypeIdList);

        $force = $this->option('force');

        $retry = $this->option('retry');

        $doing = $this->option('doing');

        $noDataFound = $this->option('noDataFound');

        if (empty($hotelIdList)) {
            if (empty($roomTypeIdList)) {
                // Case: $hotelIdList = null, $roomTypeIdList = null
                $queryStatement = AgodaRoomType::where(AgodaRoomType::FIELD_STATUS, AgodaRoomTypeConst::STATUS['ACTIVE'])
                    ->whereNotNull(AgodaRoomType::FIELD_HOTEL_SN)
                    ->whereNotNull(AgodaRoomType::FIELD_ROOM_TYPE_SN);

                if (!$force) {
                    $queryStatement->where(AgodaRoomType::FIELD_UPDATE_PRICE_ONE_DAY_STATE, State::TO_DO);
                }

                if ($force && $retry) {
                    $threeHourBefore = Carbon::now()->subHours(3);
                    $stateList = [];
                    if ($doing) {
                        $stateList[] = State::DOING;
                    }
                    if ($noDataFound) {
                        $stateList[] = State::NO_DATA_FOUND;
                    }
                    if (!$doing && !$noDataFound) {
                        $stateList[] = [State::DOING, State::NO_DATA_FOUND];
                    }
                    $queryStatement->whereIn(AgodaRoomType::FIELD_UPDATE_PRICE_ONE_DAY_STATE, $stateList);
                    $queryStatement->where(AgodaRoomType::FIELD_LAST_UPDATE, '<=', $threeHourBefore);
                }

                $roomTypeList = $queryStatement->get([AgodaRoomType::FIELD_PARTNER_HOTEL_ID, AgodaRoomType::FIELD_PARTNER_ROOM_TYPE_ID]);

                $hotelList = $roomTypeList->unique(AgodaRoomType::FIELD_PARTNER_HOTEL_ID)->take(self::LIMIT);

            } else {
                #region Case: $hotelIdList = null, $roomTypeIdList != null
                $queryStatement = AgodaRoomType::where(AgodaRoomType::FIELD_STATUS, AgodaRoomTypeConst::STATUS['ACTIVE'])
                    ->whereIn(AgodaRoomType::FIELD_PARTNER_ROOM_TYPE_ID, $roomTypeIdList)
                    ->whereNotNull(AgodaRoomType::FIELD_HOTEL_SN)
                    ->whereNotNull(AgodaRoomType::FIELD_ROOM_TYPE_SN);

                if (!$force) {
                    $queryStatement->where(AgodaRoomType::FIELD_UPDATE_PRICE_ONE_DAY_STATE, State::TO_DO);
                }

                if ($force && $retry) {
                    $threeHourBefore = Carbon::now()->subHours(3);
                    $stateList = [];
                    if ($doing) {
                        $stateList[] = State::DOING;
                    }
                    if ($noDataFound) {
                        $stateList[] = State::NO_DATA_FOUND;
                    }
                    if (!$doing && !$noDataFound) {
                        $stateList[] = [State::DOING, State::NO_DATA_FOUND];
                    }
                    $queryStatement->whereIn(AgodaRoomType::FIELD_UPDATE_PRICE_ONE_DAY_STATE, $stateList);
                    $queryStatement->where(AgodaRoomType::FIELD_LAST_UPDATE, '<=', $threeHourBefore);
                }

                $roomTypeList = $queryStatement->get([AgodaRoomType::FIELD_PARTNER_HOTEL_ID, AgodaRoomType::FIELD_PARTNER_ROOM_TYPE_ID]);

                // Group all room types by hotelId
                $hotelList = $roomTypeList->groupBy(AgodaRoomType::FIELD_PARTNER_HOTEL_ID);

                $queuedHotelIdList = [];
                foreach ($hotelList as $hotelId => $roomTypeList) {
                    $roomTypeIdList = $roomTypeList->pluck(AgodaRoomType::FIELD_PARTNER_ROOM_TYPE_ID)->toArray();
                    $roomTypeIdList = array_map('intval', $roomTypeIdList);
                    $message = json_encode([
                        'hotelId'        => $hotelId,
                        'roomTypeIdList' => $roomTypeIdList,
                    ]);

                    $num = count($queuedHotelIdList);
                    if ($num > 0 && ($num % 20 == 0)) { // Rate limit, QPS: 20
                        sleep(1);
                    }

                    $job = new UpdateRoomPriceOneDayJob($message);
                    dispatch($job->onQueue(QueueName::INTEGRATION['AGODA_REFRESH_ROOM_PRICE_TODAY']));

                    $queuedHotelIdList[] = intval($hotelId);
                }
                if (!empty($queuedHotelIdList)) {
                    // Update room price one day stage of hotel has been pushed into queue
                    $queryStatement = AgodaRoomType::whereIn(AgodaRoomType::FIELD_PARTNER_HOTEL_ID, $queuedHotelIdList);

                    if ($force && $retry) {
                        $queryStatement->whereIn(AgodaRoomType::FIELD_PARTNER_ROOM_TYPE_ID, $roomTypeIdList);
                    }

                    $queryStatement->update([
                        AgodaRoomType::FIELD_UPDATE_PRICE_ONE_DAY_STATE => State::DOING
                    ]);
                }
                $numOfJobs = count($queuedHotelIdList);
                if ($numOfJobs != 0) {
                    $logMessage = GenerateHelper::logMessage('info', self::class, "$numOfJobs pull room type jobs have been pushed into queue!");
                    LoggingHelper::toSlack(Slack::CHANNEL['SCHEDULE_MONITOR'], $logMessage);
                }

                return;
                #endregion Case: $hotelIdList = null, $roomTypeIdList != null
            }
        } else {
            // Case: $hotelIdList != null, $roomTypeIdList != null
            // Case: $hotelIdList != null, $roomTypeIdList == null
            // Choose only 1 of 2 options ($hotelIdList or $roomTypeIdList)
            // => Priority: $hotelIdList
            $queryStatement = AgodaRoomType::where(AgodaRoomType::FIELD_STATUS, AgodaRoomTypeConst::STATUS['ACTIVE'])
                ->whereIn(AgodaRoomType::FIELD_PARTNER_HOTEL_ID, $hotelIdList)
                ->whereNotNull(AgodaRoomType::FIELD_HOTEL_SN)
                ->whereNotNull(AgodaRoomType::FIELD_ROOM_TYPE_SN);

            if (!$force) {
                $queryStatement->where(AgodaRoomType::FIELD_UPDATE_PRICE_ONE_DAY_STATE, State::TO_DO);
            }

            if ($force && $retry) {
                $threeHourBefore = Carbon::now()->subHours(3);
                $stateList = [];
                if ($doing) {
                    $stateList[] = State::DOING;
                }
                if ($noDataFound) {
                    $stateList[] = State::NO_DATA_FOUND;
                }
                if (!$doing && !$noDataFound) {
                    $stateList[] = [State::DOING, State::NO_DATA_FOUND];
                }
                $queryStatement->whereIn(AgodaRoomType::FIELD_UPDATE_PRICE_ONE_DAY_STATE, $stateList);
                $queryStatement->where(AgodaRoomType::FIELD_LAST_UPDATE, '<=', $threeHourBefore);
            }

            $roomTypeList = $queryStatement->get([AgodaRoomType::FIELD_PARTNER_HOTEL_ID, AgodaRoomType::FIELD_PARTNER_ROOM_TYPE_ID]);

            $hotelList = $roomTypeList->unique(AgodaRoomType::FIELD_PARTNER_HOTEL_ID);
        }

        $queuedHotelIdList = [];
        foreach ($hotelList as $hotel) {
            $hotelId = $hotel->{AgodaRoomType::FIELD_PARTNER_HOTEL_ID};
            $roomTypeIdList = $roomTypeList->where(AgodaRoomType::FIELD_PARTNER_HOTEL_ID, intval($hotelId))
                ->pluck(AgodaRoomType::FIELD_PARTNER_ROOM_TYPE_ID)
                ->toArray();
            $roomTypeIdList = array_map('intval', $roomTypeIdList);
            $message = json_encode([
                'hotelId'        => $hotelId,
                'roomTypeIdList' => $roomTypeIdList,
            ]);

            $num = count($queuedHotelIdList);
            if ($num > 0 && ($num % 20 == 0)) { // Rate limit, QPS: 20
                sleep(1);
            }

            $job = new UpdateRoomPriceOneDayJob($message);
            dispatch($job->onQueue(QueueName::INTEGRATION['AGODA_REFRESH_ROOM_PRICE_TODAY']));

            $queuedHotelIdList[] = intval($hotelId);
        }

        if (!empty($queuedHotelIdList)) {
            // Update room price one day stage of hotel has been pushed into queue
            $queryStatement = AgodaRoomType::whereIn(AgodaRoomType::FIELD_PARTNER_HOTEL_ID, $queuedHotelIdList);

            if ($force && $retry) {
                $queryStatement->whereIn(AgodaRoomType::FIELD_PARTNER_ROOM_TYPE_ID, $roomTypeIdList);
            }

            $queryStatement->update([
                AgodaRoomType::FIELD_UPDATE_PRICE_ONE_DAY_STATE => State::DOING
            ]);
        }

        $numOfJobs = count($queuedHotelIdList);
        if ($numOfJobs != 0) {
            $logMessage = GenerateHelper::logMessage('info', self::class, "$numOfJobs pull room type jobs have been pushed into queue!");
            LoggingHelper::toSlack(Slack::CHANNEL['SCHEDULE_MONITOR'], $logMessage);
        }
    }
}
