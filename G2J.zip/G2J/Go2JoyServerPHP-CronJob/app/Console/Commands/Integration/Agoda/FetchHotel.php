<?php

namespace App\Console\Commands\Integration\Agoda;

use App\API\External\Integration\Agoda\AgodaProcessor;
use App\Constants\Globals\Integration;
use App\Constants\Globals\QueueName;
use App\Constants\Globals\Slack;
use App\Constants\Partners\Agoda as AgodaConst;
use App\Factories\IntegrationFactory;
use App\Helpers\GenerateHelper;
use App\Helpers\LoggingHelper;
use App\Models\MongoDB\AgodaArea;
use App\Models\MongoDB\AgodaCity;
use Exception;
use Illuminate\Console\Command;

class FetchHotel extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'integration:agoda:fetch-hotel 
                            {--cityIdList=}
                            {--areaIdList=}
                            {--hotelId=}
                            {--cityId=}
                            {--areaId=}
                            {--languageId=}
                            {--currency=}
                            {--except : Without city id list}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Fetch hotel from Agoda';

    /** @var AgodaProcessor */
    public $agodaProcessor;

    /**
     * Create a new command instance.
     *
     * @return void
     * @throws Exception
     */
    public function __construct()
    {
        parent::__construct();

        $partner = Integration::PARTNER['AGODA'];
        $integrationFactory = new IntegrationFactory();
        $this->agodaProcessor = $integrationFactory->createProcessor($partner);
    }

    /**
     * Execute the console command.
     *
     * @throws Exception
     */
    public function handle()
    {
        $cityIdList = $this->option('cityIdList');
        $cityIdList = explode(',', $cityIdList);
        $cityIdList = array_filter($cityIdList);
        $cityIdList = array_map('intval', $cityIdList);

        $areaIdList = $this->option('areaIdList');
        $areaIdList = explode(',', $areaIdList);
        $areaIdList = array_filter($areaIdList);
        $areaIdList = array_map('intval', $areaIdList);

        $languageId = $this->option('languageId') ?? AgodaConst::LANGUAGE_ID['VIETNAMESE'];
        $currency = $this->option('currency') ?? AgodaConst::CURRENCY_CODE['VIETNAMESE_DONG'];

        $except = $this->option('except');

        // Get all city active in MongoDB
        if ($except) {
            $allCityActive = AgodaCity::whereNotIn(AgodaCity::FIELD_CITY_ID, $cityIdList)->get([AgodaCity::FIELD_CITY_ID]);
        } else {
            $allCityActive = AgodaCity::all([AgodaCity::FIELD_CITY_ID]);
        }

        // Get all area active in MongoDB
        $allAreaActive = AgodaArea::all([AgodaArea::FIELD_AREA_ID, AgodaArea::FIELD_CITY_ID]);

        // Filter area with list of area in MongoDB
        if ($areaIdList) {
            $areaList = $allAreaActive->filter(function ($item) use ($areaIdList) {
                return in_array($item->{AgodaArea::FIELD_AREA_ID}, $areaIdList);
            });
        } else {
            $areaList = AgodaConst::ALL;
        }

        // Filter city with list of city in MongoDB
        if ($cityIdList && !$except) {
            $cityList = $allCityActive->filter(function ($item) use ($cityIdList) {
                return in_array($item->{AgodaCity::FIELD_CITY_ID}, $cityIdList);
            });
        } else {
            $cityList = $allCityActive;
        }

        #region Fetch the specified hotel
        $hotelId = $this->option('hotelId') ?? AgodaConst::ALL;
        $cityId = $this->option('cityId');
        $areaId = $this->option('areaId') ?? AgodaConst::ALL;
        if ($hotelId != AgodaConst::ALL) {
            if (empty($cityId)) {
                $logMessage = GenerateHelper::logMessage('error', self::class, "Option cityId is required if fetch the specified hotel!");
                LoggingHelper::toSlack(Slack::CHANNEL['SCHEDULE_MONITOR'], $logMessage);
                return;
            }

            // Push the fetch hotel job into queue
            $message = json_encode([
                'cityId'     => $cityId,
                'areaId'     => $areaId,
                'hotelId'    => $hotelId,
                'languageId' => $languageId,
                'currency'   => $currency,
            ]);

            $job = new \App\Jobs\Integration\Agoda\FetchHotelJob($message);
            dispatch($job->onQueue(QueueName::INTEGRATION['AGODA_REFRESH_CONTENT']['FETCH_HOTEL']));

            $logMessage = GenerateHelper::logMessage('info', self::class, "$message \nFetch hotel job has been pushed into queue!");
            LoggingHelper::toSlack(Slack::CHANNEL['SCHEDULE_MONITOR'], $logMessage);

            return;
        }
        #endregion Fetch the specified hotel

        #region Fetch hotel by area
        if ($areaList != AgodaConst::ALL) {
            foreach ($areaList as $index => $area) {
                $areaId = $area->{AgodaArea::FIELD_AREA_ID};
                $cityId = $area->{AgodaArea::FIELD_CITY_ID};

                // Push fetch hotel job into queue
                $message = json_encode([
                    'cityId'     => $cityId,
                    'areaId'     => $areaId,
                    'hotelId'    => AgodaConst::ALL,
                    'languageId' => $languageId,
                    'currency'   => $currency,
                ]);

                $num = $index + 1;
                if ($num % 20 == 0) { // Rate limit, QPS: 20
                    sleep(1);
                }

                $job = new \App\Jobs\Integration\Agoda\FetchHotelJob($message);
                dispatch($job->onQueue(QueueName::INTEGRATION['AGODA_REFRESH_CONTENT']['FETCH_HOTEL']));
            }

            $numOfJobs = count($areaList);
            $logMessage = GenerateHelper::logMessage('info', self::class, "$numOfJobs fetch hotel jobs have been pushed into queue!");
            LoggingHelper::toSlack(Slack::CHANNEL['SCHEDULE_MONITOR'], $logMessage);

            return;
        }
        #endregion Fetch hotel by area

        #region Fetch hotel with all cities or the specified city
        foreach ($cityList as $index => $city) {
            $cityId = $city->{AgodaCity::FIELD_CITY_ID};

            // Push the fetch hotel job into queue
            $message = json_encode([
                'cityId'     => $cityId,
                'areaId'     => AgodaConst::ALL,
                'hotelId'    => AgodaConst::ALL,
                'languageId' => $languageId,
                'currency'   => $currency,
            ]);

            $num = $index + 1;
            if ($num % 20 == 0) { // Rate limit, QPS: 20
                sleep(1);
            }

            $job = new \App\Jobs\Integration\Agoda\FetchHotelJob($message);
            dispatch($job->onQueue(QueueName::INTEGRATION['AGODA_REFRESH_CONTENT']['FETCH_HOTEL']));
        }

        $numOfJobs = count($cityList);
        $logMessage = GenerateHelper::logMessage('info', self::class, "$numOfJobs fetch hotel jobs have been pushed into queue!");
        LoggingHelper::toSlack(Slack::CHANNEL['SCHEDULE_MONITOR'], $logMessage);
        #endregion Fetch hotel with all cities or the specified city
    }
}