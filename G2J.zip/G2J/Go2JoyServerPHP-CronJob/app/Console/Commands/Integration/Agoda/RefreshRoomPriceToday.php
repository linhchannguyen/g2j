<?php

namespace App\Console\Commands\Integration\Agoda;

use App\Constants\Globals\Slack;
use App\Constants\Globals\State;
use App\Constants\MongoDB\AgodaRoomType as AgodaRoomTypeConst;
use App\Helpers\GenerateHelper;
use App\Helpers\LoggingHelper;
use App\Models\MongoDB\AgodaHotelReport;
use App\Models\MongoDB\AgodaRoomType;
use Exception;
use Illuminate\Console\Command;
use Illuminate\Support\Carbon;
use MongoDB\BSON\UTCDateTime;

class RefreshRoomPriceToday extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'integration:agoda:refresh-room-price-today
                            {--cityIdList=}
                            {--except : Without city id list}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Refresh room price today';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return void
     * @throws Exception
     */
    public function handle()
    {
        $cityIdList = $this->option('cityIdList');
        $cityIdList = explode(',', $cityIdList);
        $cityIdList = array_filter($cityIdList);
        $cityIdList = array_map('intval', $cityIdList);

        $except = $this->option('except');

        if (!empty($cityIdList)) {
            $queryStatement = AgodaHotelReport::whereNotNull(AgodaHotelReport::FIELD_HOTEL_SN)
                ->whereNotNull(AgodaHotelReport::FIELD_PARTNER_HOTEL_ID);

            if ($except) {
                $queryStatement->whereNotIn(AgodaHotelReport::FIELD_PARTNER_CITY_ID, $cityIdList);
            } else {
                $queryStatement->wherIn(AgodaHotelReport::FIELD_PARTNER_CITY_ID, $cityIdList);
            }

            $hotelIdList = $queryStatement->get([AgodaHotelReport::FIELD_PARTNER_HOTEL_ID])
                ->pluck(AgodaHotelReport::FIELD_PARTNER_HOTEL_ID)
                ->toArray();

        } else {
            $hotelIdList = AgodaHotelReport::whereNotNull(AgodaHotelReport::FIELD_HOTEL_SN)
                ->whereNotNull(AgodaHotelReport::FIELD_PARTNER_HOTEL_ID)
                ->get([AgodaHotelReport::FIELD_PARTNER_HOTEL_ID])
                ->pluck(AgodaHotelReport::FIELD_PARTNER_HOTEL_ID)
                ->toArray();
        }

        $hotelIdList = array_map('intval', $hotelIdList);
        AgodaRoomType::where(AgodaRoomType::FIELD_STATUS, AgodaRoomTypeConst::STATUS['ACTIVE'])
            ->whereIn(AgodaRoomType::FIELD_PARTNER_HOTEL_ID, $hotelIdList)
            ->whereNotNull(AgodaRoomType::FIELD_HOTEL_SN)
            ->whereNotNull(AgodaRoomType::FIELD_ROOM_TYPE_SN)
            ->update([
                AgodaRoomType::FIELD_LAST_UPDATE                => new UTCDateTime(Carbon::now()),
                AgodaRoomType::FIELD_UPDATE_PRICE_ONE_DAY_STATE => State::TO_DO,
            ]);

        $logMessage = GenerateHelper::logMessage('info', self::class, 'All done!');
        LoggingHelper::toSlack(Slack::CHANNEL['SCHEDULE_MONITOR'], $logMessage);
    }
}
