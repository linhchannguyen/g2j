<?php

namespace App\Console\Commands\Integration\Agoda;

use App\API\External\Integration\Agoda\AgodaProcessor;
use App\Constants\Globals\Integration;
use App\Constants\Globals\Slack;
use App\Constants\Partners\Agoda as AgodaConst;
use App\DTOs\Integration\Agoda\GetCityListInputDTO;
use App\Factories\IntegrationFactory;
use App\Helpers\GenerateHelper;
use App\Helpers\LoggingHelper;
use App\Models\MongoDB\AgodaCity;
use Exception;
use Illuminate\Console\Command;
use Illuminate\Support\Carbon;
use MongoDB\BSON\UTCDateTime;

class PullCity extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'integration:agoda:pull-city 
                            {--countryId=}
                            {--languageId=}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Pull city info from Agoda';

    /** @var AgodaProcessor */
    public $agodaProcessor;

    /**
     * Create a new command instance.
     *
     * @return void
     * @throws Exception
     */
    public function __construct()
    {
        parent::__construct();

        $partner = Integration::PARTNER['AGODA'];
        $integrationFactory = new IntegrationFactory();
        $this->agodaProcessor = $integrationFactory->createProcessor($partner);
    }

    /**
     * Execute the console command.
     *
     * @throws Exception
     */
    public function handle()
    {
        $countryId = $this->option('countryId') ?? AgodaConst::COUNTRY_ID['VIETNAM'];
        $languageId = $this->option('languageId') ?? AgodaConst::LANGUAGE_ID['VIETNAMESE'];

        $getCityListInputDTO = new GetCityListInputDTO();
        $getCityListInputDTO->setCountryId($countryId);
        $getCityListInputDTO->setLanguageId($languageId);

        // Get city list from Agoda
        $getCityListOutputDTO = $this->agodaProcessor->getCityList($getCityListInputDTO);

        // Upsert to MongoDB
        $cityList = $getCityListOutputDTO->getCityList();
        foreach ($cityList as $city) {
            $document = [
                AgodaCity::FIELD_COUNTRY_ID      => $city['countryId'],
                AgodaCity::FIELD_CITY_NAME       => $city['cityName'],
                AgodaCity::FIELD_CITY_TRANSLATED => $city['cityTranslated'],
                AgodaCity::FIELD_ACTIVE_HOTELS   => $city['activeHotels'],
                AgodaCity::FIELD_LONGITUDE       => $city['longitude'],
                AgodaCity::FIELD_LATITUDE        => $city['latitude'],
                AgodaCity::FIELD_NO_AREA         => $city['noArea'],
                AgodaCity::FIELD_LAST_UPDATE     => new UTCDateTime(Carbon::now()),
            ];
            AgodaCity::where(AgodaCity::FIELD_CITY_ID, intval($city['cityId']))
                ->update($document, ['upsert' => true]);
            break;
        }

        $logMessage = GenerateHelper::logMessage('info', self::class, 'All done!');
        LoggingHelper::toSlack(Slack::CHANNEL['SCHEDULE_MONITOR'], $logMessage);
    }
}