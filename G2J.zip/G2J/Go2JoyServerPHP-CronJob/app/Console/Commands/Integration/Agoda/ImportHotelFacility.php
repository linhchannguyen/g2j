<?php

namespace App\Console\Commands\Integration\Agoda;

use App\Constants\Globals\Integration;
use App\Constants\Globals\QueueName;
use App\Constants\Globals\Slack;
use App\Constants\Globals\State;
use App\Constants\MongoDB\AgodaHotel as AgodaHotelConst;
use App\Helpers\GenerateHelper;
use App\Helpers\LoggingHelper;
use App\Models\MongoDB\AgodaHotel;
use App\Models\MongoDB\AgodaHotelFacilityReport;
use Exception;
use Illuminate\Console\Command;

class ImportHotelFacility extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'integration:agoda:import-hotel-facility
                            {--hotelIdList=}
                            {--force : Force update room price, not care about state}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Import hotel facility from MongoDB to MySQL';

    /** @var int */
    const LIMIT = 100;

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @throws Exception
     */
    public function handle()
    {
        $hotelIdList = $this->option('hotelIdList');
        $hotelIdList = explode(',', $hotelIdList);
        $hotelIdList = array_filter($hotelIdList);
        $hotelIdList = array_map('intval', $hotelIdList);

        $force = $this->option('force');

        // Get all hotel active in MongoDB and already imported to MySQL
        $queryStatement = AgodaHotel::where(AgodaHotel::FIELD_STATUS, AgodaHotelConst::STATUS['ACTIVE'])
            ->where(AgodaHotel::FIELD_PULL_FACILITY_STATE, State::DONE)
            ->whereNotNull(AgodaHotel::FIELD_HOTEL_SN);

        if (!$force) {
            $queryStatement->where(AgodaHotel::FIELD_IMPORT_FACILITY_STATE, State::TO_DO);
        }

        // Filter hotel list with list of hotel id from input
        if ($hotelIdList) {
            $partnerHotelList = $queryStatement->whereIn(AgodaHotel::FIELD_PARTNER_HOTEL_ID, $hotelIdList)
                ->get([
                    AgodaHotel::FIELD_HOTEL_SN,
                    AgodaHotelFacilityReport::FIELD_PARTNER_HOTEL_ID,
                ]);
        } else {
            $partnerHotelList = $queryStatement->limit(self::LIMIT)
                ->get([
                    AgodaHotel::FIELD_HOTEL_SN,
                    AgodaHotelFacilityReport::FIELD_PARTNER_HOTEL_ID,
                ]);
        }

        if (!empty($partnerHotelList)) {
            $partnerHotelIdList = $partnerHotelList->pluck(AgodaHotel::FIELD_PARTNER_HOTEL_ID)->toArray();
            $partnerHotelIdList = array_map('intval', $partnerHotelIdList);
            // Update import facility stage of hotel has been pushed into queue
            AgodaHotel::whereIn(AgodaHotel::FIELD_PARTNER_HOTEL_ID, $partnerHotelIdList)
                ->update([
                    AgodaHotel::FIELD_IMPORT_FACILITY_STATE => State::DOING
                ]);
        }

        foreach ($partnerHotelList as $partnerHotel) {
            $hotelSn = $partnerHotel->{AgodaHotel::FIELD_HOTEL_SN};
            $hotelId = $partnerHotel->{AgodaHotel::FIELD_PARTNER_HOTEL_ID};

            $partnerHotelFacilityReport = AgodaHotelFacilityReport::where(AgodaHotelFacilityReport::FIELD_PARTNER, Integration::PARTNER['AGODA'])
                ->where(AgodaHotelFacilityReport::FIELD_PARTNER_HOTEL_ID, intval($hotelId))
                ->where(AgodaHotelFacilityReport::FIELD_HOTEL_SN, intval($hotelSn))
                ->first([AgodaHotelFacilityReport::FIELD_PARTNER_FACILITY_ID_LIST]);
            $partnerFacilityIdList = $partnerHotelFacilityReport->{AgodaHotelFacilityReport::FIELD_PARTNER_FACILITY_ID_LIST};

            // Push the import hotel facility job into queue
            $message = json_encode([
                'hotelSn'               => $hotelSn,
                'hotelId'               => $hotelId,
                'partnerFacilityIdList' => $partnerFacilityIdList,
            ]);

            $job = new \App\Jobs\Integration\Agoda\ImportHotelFacilityJob($message);
            dispatch($job->onQueue(QueueName::INTEGRATION['AGODA_REFRESH_CONTENT']['IMPORT_HOTEL_FACILITY']));
        }

        $numOfJobs = count($partnerHotelList);
        if ($numOfJobs != 0) {
            $logMessage = GenerateHelper::logMessage('info', self::class, "$numOfJobs import hotel facility jobs have been pushed into queue!");
            LoggingHelper::toSlack(Slack::CHANNEL['SCHEDULE_MONITOR'], $logMessage);
        }
    }
}