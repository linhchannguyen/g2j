<?php

namespace App\Console\Commands\Integration\Agoda;

use App\Constants\Globals\QueueName;
use App\Constants\Globals\Slack;
use App\Constants\Globals\State;
use App\Constants\MongoDB\AgodaHotel as AgodaHotelConst;
use App\Helpers\GenerateHelper;
use App\Helpers\LoggingHelper;
use App\Jobs\Background\RefreshHotelDisplayFilterJob;
use App\Models\Hotel;
use App\Models\MongoDB\AgodaRoomType;
use App\Models\MongoDB\AgodaRoomTypeReport;
use Carbon\Carbon;
use Exception;
use Illuminate\Console\Command;

class RefreshHotelDisplayFilter extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'integration:agoda:refresh-hotel-display-filter
                            {--hotelIdList=}
                            {--force : Force refresh hotel display filter, not care about state}
                            {--retry : Retry refresh hotel display filter, if exceed time execute 1hour}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Refresh hotel display filter';

    /** @var int */
    const LIMIT = 100;

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @throws Exception
     */
    public function handle()
    {
        $hotelIdList = $this->option('hotelIdList');
        $hotelIdList = explode(',', $hotelIdList);
        $hotelIdList = array_filter($hotelIdList);
        $hotelIdList = array_map('intval', $hotelIdList);

        $force = $this->option('force');

        $retry = $this->option('retry');

        // Refresh hotel display filter based on facilities, views, bed type of room
        // so only get all rooms already imported full information to MySQL
        $queryStatement = AgodaRoomType::where(AgodaRoomType::FIELD_STATUS, AgodaHotelConst::STATUS['ACTIVE'])
            ->whereNotNull(AgodaRoomType::FIELD_ROOM_TYPE_SN)
            ->whereNotNull(AgodaRoomType::FIELD_HOTEL_SN);

        if (!$force) {
            $queryStatement->where(AgodaRoomType::FIELD_REFRESH_FILTER_STATE, State::TO_DO);
        }

        if ($force && $retry) {
            $oneHourBefore = Carbon::now()->subHour();
            $queryStatement->where(AgodaRoomType::FIELD_REFRESH_FILTER_STATE, State::DOING);
            $queryStatement->where(AgodaRoomType::FIELD_LAST_UPDATE, '<=', $oneHourBefore);
        }

        // Filter hotel list with list of hotel id from input
        if ($hotelIdList) {
            $roomTypeList = $queryStatement->whereIn(AgodaRoomType::FIELD_PARTNER_HOTEL_ID, $hotelIdList)
                ->get([
                    AgodaRoomType::FIELD_HOTEL_SN
                ]);
        } else {
            $roomTypeList = $queryStatement->limit(self::LIMIT)
                ->get([
                    AgodaRoomType::FIELD_HOTEL_SN
                ]);
        }

        $refreshHotelSnList = [];
        $roomTypeList = $roomTypeList->groupBy(AgodaRoomType::FIELD_HOTEL_SN);
        foreach ($roomTypeList as $hotelSn => $refreshRoomTypeList) {
            $numOfRefreshRoomTypes = count($refreshRoomTypeList);
            $partnerRoomTypeReport = AgodaRoomTypeReport::where(AgodaRoomTypeReport::FIELD_HOTEL_SN, intval($hotelSn))->first([AgodaRoomTypeReport::FIELD_NUM_OF_ROOM_TYPE]);

            // Only hotel have the same num of refresh room types
            if ($numOfRefreshRoomTypes == $partnerRoomTypeReport->{AgodaRoomTypeReport::FIELD_NUM_OF_ROOM_TYPE}) {
                array_push($refreshHotelSnList, intval($hotelSn));
            }
        }

        $hotelChunks = [];
        if (!empty($refreshHotelSnList)) {
            $hotelList = Hotel::whereIn(Hotel::COL_SN, $refreshHotelSnList)->get();
            $hotelChunks = $hotelList->chunk(50);
            foreach ($hotelChunks as $hotelList) {
                $job = new RefreshHotelDisplayFilterJob($hotelList);
                dispatch($job->onQueue(QueueName::INTEGRATION['AGODA_REFRESH_CONTENT']['REFRESH_HOTEL_DISPLAY_FILTER']));
            }

            // Update pull stage of room type has been pushed into queue
            AgodaRoomType::whereIn(AgodaRoomType::FIELD_HOTEL_SN, $refreshHotelSnList)
                ->update([
                    AgodaRoomType::FIELD_REFRESH_FILTER_STATE => State::DOING
                ]);
        }

        $numOfJobs = count($hotelChunks);
        if ($numOfJobs != 0) {
            $logMessage = GenerateHelper::logMessage('info', self::class, "$numOfJobs refresh hotel display filter jobs have been pushed into queue!");
            LoggingHelper::toSlack(Slack::CHANNEL['SCHEDULE_MONITOR'], $logMessage);
        }
    }
}