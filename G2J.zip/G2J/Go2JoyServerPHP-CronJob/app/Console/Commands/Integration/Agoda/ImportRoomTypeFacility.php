<?php

namespace App\Console\Commands\Integration\Agoda;

use App\Constants\Globals\QueueName;
use App\Constants\Globals\Slack;
use App\Constants\Globals\State;
use App\Constants\MongoDB\AgodaRoomType as AgodaRoomTypeConst;
use App\Helpers\GenerateHelper;
use App\Helpers\LoggingHelper;
use App\Models\MongoDB\AgodaRoomType;
use App\Models\MongoDB\AgodaRoomTypeFacilityReport;
use Exception;
use Illuminate\Console\Command;

class ImportRoomTypeFacility extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'integration:agoda:import-room-type-facility 
                            {--hotelIdList=}
                            {--force : Force update room price, not care about state}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Import room type facility from MongoDB to MySQL';

    /** @var int */
    const LIMIT = 100;

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @throws Exception
     */
    public function handle()
    {
        $hotelIdList = $this->option('hotelIdList');
        $hotelIdList = explode(',', $hotelIdList);
        $hotelIdList = array_filter($hotelIdList);
        $hotelIdList = array_map('intval', $hotelIdList);

        $force = $this->option('force');

        // Get all partner room type facility report in MongoDB
        $queryStatement = AgodaRoomType::where(AgodaRoomType::FIELD_STATUS, AgodaRoomTypeConst::STATUS['ACTIVE'])
            ->where(AgodaRoomType::FIELD_PULL_FACILITY_STATE, State::DONE)
            ->whereNotNull(AgodaRoomType::FIELD_ROOM_TYPE_SN)
            ->whereNotNull(AgodaRoomType::FIELD_HOTEL_SN);

        if (!$force) {
            $queryStatement->where(AgodaRoomType::FIELD_IMPORT_FACILITY_STATE, State::TO_DO);
        }

        // Filter hotel list with list of hotel id from input
        if ($hotelIdList) {
            $partnerRoomTypeList = $queryStatement->whereIn(AgodaRoomType::FIELD_PARTNER_HOTEL_ID, $hotelIdList)
                ->get([
                    AgodaRoomType::FIELD_HOTEL_SN,
                    AgodaRoomType::FIELD_PARTNER_HOTEL_ID,
                    AgodaRoomType::FIELD_ROOM_TYPE_SN,
                    AgodaRoomType::FIELD_PARTNER_ROOM_TYPE_ID,
                ]);
        } else {
            $partnerRoomTypeList = $queryStatement->limit(self::LIMIT)
                ->get([
                    AgodaRoomType::FIELD_HOTEL_SN,
                    AgodaRoomType::FIELD_PARTNER_HOTEL_ID,
                    AgodaRoomType::FIELD_ROOM_TYPE_SN,
                    AgodaRoomType::FIELD_PARTNER_ROOM_TYPE_ID,
                ]);
        }

        foreach ($partnerRoomTypeList as $partnerRoomType) {
            $hotelSn = $partnerRoomType->{AgodaRoomType::FIELD_HOTEL_SN};
            $hotelId = $partnerRoomType->{AgodaRoomType::FIELD_PARTNER_HOTEL_ID};
            $roomTypeSn = $partnerRoomType->{AgodaRoomType::FIELD_ROOM_TYPE_SN};
            $roomTypeId = $partnerRoomType->{AgodaRoomType::FIELD_PARTNER_ROOM_TYPE_ID};

            $partnerRoomTypeFacilityReport = AgodaRoomTypeFacilityReport::where(AgodaRoomTypeFacilityReport::FIELD_PARTNER_HOTEL_ID, intval($hotelId))
                ->where(AgodaRoomTypeFacilityReport::FIELD_HOTEL_SN, intval($hotelSn))
                ->where(AgodaRoomTypeFacilityReport::FIELD_PARTNER_ROOM_TYPE_ID, intval($roomTypeId))
                ->where(AgodaRoomTypeFacilityReport::FIELD_ROOM_TYPE_SN, intval($roomTypeSn))
                ->first([AgodaRoomTypeFacilityReport::FIELD_PARTNER_FACILITY_ID_LIST]);
            $partnerFacilityIdList = $partnerRoomTypeFacilityReport->{AgodaRoomTypeFacilityReport::FIELD_PARTNER_FACILITY_ID_LIST};

            // Update import facility stage of room type has been pushed into queue
            AgodaRoomType::where(AgodaRoomType::FIELD_PARTNER_ROOM_TYPE_ID, intval($roomTypeId))
                ->update([
                    AgodaRoomType::FIELD_IMPORT_FACILITY_STATE => State::DOING
                ]);

            // Push the import hotel facility job into queue
            $message = json_encode([
                'hotelSn'               => $hotelSn,
                'hotelId'               => $hotelId,
                'roomTypeSn'            => $roomTypeSn,
                'roomTypeId'            => $roomTypeId,
                'partnerFacilityIdList' => $partnerFacilityIdList,
            ]);

            $job = new \App\Jobs\Integration\Agoda\ImportRoomTypeFacilityJob($message);
            dispatch($job->onQueue(QueueName::INTEGRATION['AGODA_REFRESH_CONTENT']['IMPORT_ROOM_TYPE_FACILITY']));
        }

        $numOfJobs = count($partnerRoomTypeList);
        if ($numOfJobs != 0) {
            $logMessage = GenerateHelper::logMessage('info', self::class, "$numOfJobs import room type facility jobs have been pushed into queue!");
            LoggingHelper::toSlack(Slack::CHANNEL['SCHEDULE_MONITOR'], $logMessage);
        }
    }
}