<?php

namespace App\Console\Commands\SearchingEngine;

use App\Constants\Globals\Slack;
use App\Constants\LogSyncSearchingEngine as LogSyncSearchingEngineConst;
use App\Helpers\ConvertHelper;
use App\Helpers\GenerateHelper;
use App\Helpers\LoggingHelper;
use App\Models\LogSyncSearchingEngine;
use App\Models\LogSyncSearchingEngineDetail;
use Exception;
use Illuminate\Console\Command;
use Illuminate\Support\Arr;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\DB;

class RetrySyncData extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'searching-engine:retry-sync-data';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Retry synchronize data between Go2Joy and Searching Engine';

    /** @var int */
    const LIMIT = 500;

    /** @var int */
    const NUM_OF_RETRY = 3;

    /** @var array */
    const TABLE_HAS_LARGE_VOLUME = array(
        'HOTEL',
        'HOTEL_DISPLAY_RULE',
        'ROOM_TYPE',
    );

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return void
     */
    public function handle()
    {
        $logSyncSearchingEngineList = DB::table(LogSyncSearchingEngine::TABLE_NAME)
            ->where(LogSyncSearchingEngine::COL_STATUS, LogSyncSearchingEngineConst::STATUS['ERROR_SYNC'])
            ->where(LogSyncSearchingEngine::COL_NUM_OF_RETRY, '<', self::NUM_OF_RETRY)
            ->whereNotIn(LogSyncSearchingEngine::COL_TABLE_NAME, self::TABLE_HAS_LARGE_VOLUME)
            ->limit(self::LIMIT)
            ->orderBy(LogSyncSearchingEngine::COL_UPDATE_TIME)
            ->get([
                LogSyncSearchingEngine::COL_SN,
                LogSyncSearchingEngine::COL_TABLE_NAME,
                LogSyncSearchingEngine::COL_TABLE_SN,
                LogSyncSearchingEngine::COL_ACTION_TYPE,
                LogSyncSearchingEngine::COL_NUM_OF_RETRY,
            ]);

        $logSyncSearchingEngineTableSnList = [];
        $logSyncSearchingEngineSnList = [];
        $numOfRetryList = [];
        foreach ($logSyncSearchingEngineList as $logSyncSearchingEngine) {
            $numOfRetry = $logSyncSearchingEngine->{LogSyncSearchingEngine::COL_NUM_OF_RETRY};
            $actionType = $logSyncSearchingEngine->{LogSyncSearchingEngine::COL_ACTION_TYPE};
            $logSyncSearchingEngineSn = $logSyncSearchingEngine->{LogSyncSearchingEngine::COL_SN};
            $logSyncSearchingEngineTableSn = $logSyncSearchingEngine->{LogSyncSearchingEngine::COL_TABLE_SN};
            $numOfLogSyncSearchingEngineDetail = DB::table(LogSyncSearchingEngineDetail::TABLE_NAME)
                ->where(LogSyncSearchingEngineDetail::COL_TABLE_SN, $logSyncSearchingEngineTableSn)
                ->count();
            if ($numOfLogSyncSearchingEngineDetail > 0) {
                $logSyncSearchingEngineTableSnList[$logSyncSearchingEngineTableSn] = $actionType;
                $logSyncSearchingEngineSnList[$logSyncSearchingEngineTableSn] = $logSyncSearchingEngineSn;
                $numOfRetryList[$logSyncSearchingEngineTableSn] = $numOfRetry;
                continue;
            }
            $tableName = $logSyncSearchingEngine->{LogSyncSearchingEngine::COL_TABLE_NAME};
            $tableSn = $logSyncSearchingEngine->{LogSyncSearchingEngine::COL_TABLE_SN};
            $numOfRetry = $logSyncSearchingEngine->{LogSyncSearchingEngine::COL_NUM_OF_RETRY};
            switch ($actionType) {
                case LogSyncSearchingEngineConst::ACTION_TYPE['INSERT']: {
                    $this->_retrySyncInsertAction($logSyncSearchingEngineSn, $tableName, $tableSn, $numOfRetry);
                    break;
                }
                case LogSyncSearchingEngineConst::ACTION_TYPE['UPDATE']: {
                    $this->_retrySyncUpdateAction($logSyncSearchingEngineSn, $tableName, $tableSn, $numOfRetry);
                    break;
                }
                case LogSyncSearchingEngineConst::ACTION_TYPE['DELETE']: {
                    $this->_retrySyncDeleteAction($logSyncSearchingEngineSn, $tableName, $tableSn, $numOfRetry);
                    break;
                }
            }
        }

        $logSyncSearchingEngineDetailList = DB::table(LogSyncSearchingEngineDetail::TABLE_NAME)
            ->whereIn(LogSyncSearchingEngineDetail::COL_TABLE_SN, array_keys($logSyncSearchingEngineTableSnList))
            ->get([
                LogSyncSearchingEngineDetail::COL_SN,
                LogSyncSearchingEngineDetail::COL_TABLE_SN,
                LogSyncSearchingEngineDetail::COL_TABLE_NAME,
                LogSyncSearchingEngineDetail::COL_COLUMN_NAME,
                LogSyncSearchingEngineDetail::COL_COLUMN_VALUE,
            ]);

        // Get group by composite primary key
        $groupByList = [];
        foreach($logSyncSearchingEngineDetailList as $logSyncSearchingEngineDetail) {
            $logSyncSearchingEngineDetailTableSn = $logSyncSearchingEngineDetail->{LogSyncSearchingEngineDetail::COL_TABLE_SN};
            $tableName = $logSyncSearchingEngineDetail->{LogSyncSearchingEngineDetail::COL_TABLE_NAME};
            $groupByList[$logSyncSearchingEngineDetailTableSn][$tableName][] = $logSyncSearchingEngineDetail;
        }

        foreach ($groupByList as $logSyncSearchingEngineTableSn => $value) {
            $tableName = current(array_keys($value));
            $logSyncSearchingEngineDetailList = Arr::flatten($value);
            $actionType = $logSyncSearchingEngineTableSnList[$logSyncSearchingEngineTableSn];
            $numOfRetry = $numOfRetryList[$logSyncSearchingEngineTableSn];
            $logSyncSearchingEngineSn = $logSyncSearchingEngineSnList[$logSyncSearchingEngineTableSn];
            switch ($actionType) {
                case LogSyncSearchingEngineConst::ACTION_TYPE['INSERT']: {
                    $this->_retrySyncDetailInsertAction($logSyncSearchingEngineSn, $tableName, $logSyncSearchingEngineDetailList, $numOfRetry);
                    break;
                }
                case LogSyncSearchingEngineConst::ACTION_TYPE['UPDATE']: {
                    $this->_retrySyncDetailUpdateAction($logSyncSearchingEngineSn, $tableName, $logSyncSearchingEngineDetailList, $numOfRetry);
                    break;
                }
                case LogSyncSearchingEngineConst::ACTION_TYPE['DELETE']: {
                    $this->_retrySyncDetailDeleteAction($logSyncSearchingEngineSn, $tableName, $logSyncSearchingEngineDetailList, $numOfRetry);
                    break;
                }
            }
        }
    }

    private function _markRecord($logSyncSearchingEngineSn, $status, $errorLog, $syncedTime, $contentSync, $numOfRetry)
    {
        DB::table(LogSyncSearchingEngine::TABLE_NAME)
            ->where(LogSyncSearchingEngine::COL_SN, $logSyncSearchingEngineSn)
            ->update([
                LogSyncSearchingEngine::COL_STATUS       => $status,
                LogSyncSearchingEngine::COL_ERROR_LOG    => $errorLog,
                LogSyncSearchingEngine::COL_SYNCED_TIME  => $syncedTime,
                LogSyncSearchingEngine::COL_CONTENT_SYNC => $contentSync,
                LogSyncSearchingEngine::COL_NUM_OF_RETRY => $numOfRetry,
                LogSyncSearchingEngine::COL_UPDATE_TIME  => Carbon::now(),
            ]);

        if ($numOfRetry == self::NUM_OF_RETRY) {
            $message = sprintf("Message: Exceed num of retry\nLOG_SYNC_SEARCHING_ENGINE_SN: %s\nERROR_LOG: %s\nSYNCED_TIME: %s", $logSyncSearchingEngineSn, $errorLog, $syncedTime);
            $logMessage = GenerateHelper::logMessage('info', self::class, $message);
            LoggingHelper::toSlack(Slack::CHANNEL['SYNCING_MONITOR'], $logMessage);
        }
    }

    private function _retrySyncInsertAction($logSyncSearchingEngineSn, $tableName, $tableSn, $numOfRetry)
    {
        $status = LogSyncSearchingEngineConst::STATUS['SYNCED'];
        $errorLog = null;
        $syncedTime = Carbon::now()->toDateTimeString();
        $contentSync = null;

        try {
            $record = DB::table($tableName)->where('SN', $tableSn)->first();
            if (empty($record)) {
                throw new Exception('Record not found');
            }
            $contentSync = ConvertHelper::stdClassToArray($record);
            DB::connection('searching_engine')->table($tableName)->insert($contentSync);
        } catch (Exception $exception) {
            $numOfRetry++;
            $status = LogSyncSearchingEngineConst::STATUS['ERROR_SYNC'];
            $errorLog = $exception->getMessage();
        }

        $this->_markRecord($logSyncSearchingEngineSn, $status, $errorLog, $syncedTime, $contentSync, $numOfRetry);

        return $status;
    }

    private function _retrySyncUpdateAction($logSyncSearchingEngineSn, $tableName, $tableSn, $numOfRetry)
    {
        $status = LogSyncSearchingEngineConst::STATUS['SYNCED'];
        $errorLog = null;
        $syncedTime = Carbon::now()->toDateTimeString();
        $contentSync = null;

        try {
            $record = DB::table($tableName)->where('SN', $tableSn)->first();
            if (empty($record)) {
                throw new Exception('Record not found');
            }

            $contentSync = ConvertHelper::stdClassToArray($record);

            DB::connection('searching_engine')->table($tableName)->updateOrInsert(
                ['SN' => $tableSn],
                $contentSync
            );
        } catch (Exception $exception) {
            $numOfRetry++;
            $status = LogSyncSearchingEngineConst::STATUS['ERROR_SYNC'];
            $errorLog = $exception->getMessage();
        }

        $this->_markRecord($logSyncSearchingEngineSn, $status, $errorLog, $syncedTime, $contentSync, $numOfRetry);

        return $status;
    }

    private function _serializeDataUpdate($tableName, &$contentSync)
    {
        //
    }

    private function _retrySyncDeleteAction($logSyncSearchingEngineSn, $tableName, $tableSn, $numOfRetry)
    {
        $status = LogSyncSearchingEngineConst::STATUS['SYNCED'];
        $errorLog = null;
        $syncedTime = Carbon::now()->toDateTimeString();
        $contentSync = null;

        try {
            DB::connection('searching_engine')->table($tableName)->where('SN', $tableSn)->delete();
        } catch (Exception $exception) {
            $numOfRetry++;
            $status = LogSyncSearchingEngineConst::STATUS['ERROR_SYNC'];
            $errorLog = $exception->getMessage();
        }

        $this->_markRecord($logSyncSearchingEngineSn, $status, $errorLog, $syncedTime, $contentSync, $numOfRetry);

        return $status;
    }

    private function _retrySyncDetailInsertAction($logSyncSearchingEngineSn, $tableName, $logSyncSearchingEngineDetailList, $numOfRetry)
    {
        $status = LogSyncSearchingEngineConst::STATUS['SYNCED'];
        $errorLog = null;
        $syncedTime = Carbon::now()->toDateTimeString();
        $contentSync = null;

        $record = DB::table($tableName);

        foreach ($logSyncSearchingEngineDetailList as $logSyncSearchingEngineDetail) {
            $columnName = $logSyncSearchingEngineDetail->{LogSyncSearchingEngineDetail::COL_COLUMN_NAME};
            $columnValue = $logSyncSearchingEngineDetail->{LogSyncSearchingEngineDetail::COL_COLUMN_VALUE};

            $record->where($columnName, $columnValue);
        }

        try {
            $record = $record->first();
            if (empty($record)) {
                throw new Exception('Record not found');
            }
            $contentSync = ConvertHelper::stdClassToArray($record);

            DB::connection('searching_engine')->table($tableName)->insert($contentSync);
        } catch (Exception $exception) {
            $numOfRetry++;
            $status = LogSyncSearchingEngineConst::STATUS['ERROR_SYNC'];
            $errorLog = $exception->getMessage();
        }

        $this->_markRecord($logSyncSearchingEngineSn, $status, $errorLog, $syncedTime, $contentSync, $numOfRetry);
    }

    private function _retrySyncDetailUpdateAction($logSyncSearchingEngineSn, $tableName, $logSyncSearchingEngineDetailList, $numOfRetry)
    {
        $status = LogSyncSearchingEngineConst::STATUS['SYNCED'];
        $errorLog = null;
        $syncedTime = Carbon::now()->toDateTimeString();
        $contentSync = null;

        $table = DB::connection('searching_engine')->table($tableName);
        $record = DB::table($tableName);

        $whereCondition = [];
        foreach ($logSyncSearchingEngineDetailList as $logSyncSearchingEngineDetail) {
            $columnName = $logSyncSearchingEngineDetail->{LogSyncSearchingEngineDetail::COL_COLUMN_NAME};
            $columnValue = $logSyncSearchingEngineDetail->{LogSyncSearchingEngineDetail::COL_COLUMN_VALUE};
            $whereCondition[$columnName] = $columnValue;

            $record->where($columnName, $columnValue);
        }

        try {
            $record = $record->first();
            if (empty($record)) {
                throw new Exception('Record not found');
            }

            $contentSync = ConvertHelper::stdClassToArray($record);

            $table->updateOrInsert(
                $whereCondition,
                $contentSync
            );
        } catch (Exception $exception) {
            $numOfRetry++;
            $status = LogSyncSearchingEngineConst::STATUS['ERROR_SYNC'];
            $errorLog = $exception->getMessage();
        }

        $this->_markRecord($logSyncSearchingEngineSn, $status, $errorLog, $syncedTime, $contentSync, $numOfRetry);
    }

    private function _retrySyncDetailDeleteAction($logSyncSearchingEngineSn, $tableName, $logSyncSearchingEngineDetailList, $numOfRetry)
    {
        $status = LogSyncSearchingEngineConst::STATUS['SYNCED'];
        $errorLog = null;
        $syncedTime = Carbon::now()->toDateTimeString();
        $contentSync = null;

        $table = DB::connection('searching_engine')->table($tableName);
        foreach ($logSyncSearchingEngineDetailList as $logSyncSearchingEngineDetail) {
            $columnName = $logSyncSearchingEngineDetail->{LogSyncSearchingEngineDetail::COL_COLUMN_NAME};
            $columnValue = $logSyncSearchingEngineDetail->{LogSyncSearchingEngineDetail::COL_COLUMN_VALUE};
            $table->where($columnName, $columnValue);
        }

        try {
            $table->delete();
        } catch (Exception $exception) {
            $numOfRetry++;
            $status = LogSyncSearchingEngineConst::STATUS['ERROR_SYNC'];
            $errorLog = $exception->getMessage();
        }

        $this->_markRecord($logSyncSearchingEngineSn, $status, $errorLog, $syncedTime, $contentSync, $numOfRetry);
    }
}
