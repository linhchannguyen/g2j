<?php

namespace App\Console\Commands\SearchingEngine;

use App\Constants\LogSyncSearchingEngine as LogSyncSearchingEngineConst;
use App\Helpers\ConvertHelper;
use App\Models\LogSyncSearchingEngine;
use App\Models\LogSyncSearchingEngineDetail;
use Exception;
use Illuminate\Console\Command;
use Illuminate\Support\Arr;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\DB;

class SyncHotelData extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'searching-engine:sync-hotel-data';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Synchronize hotel data between Go2Joy and Searching Engine';

    /** @var int */
    const LIMIT = 1000;

    /** @var string */
    const TABLE_NAME = 'HOTEL';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return void
     */
    public function handle()
    {
        $this->_syncInsertAction();

        $this->_syncUpdateAction();

        $this->_syncDeleteAction();
    }

    private function _markRecord($logSyncSearchingEngineSn, $status, $errorLog, $syncedTime, $contentSync)
    {
        DB::table(LogSyncSearchingEngine::TABLE_NAME)
            ->where(LogSyncSearchingEngine::COL_SN, $logSyncSearchingEngineSn)
            ->update([
                LogSyncSearchingEngine::COL_STATUS       => $status,
                LogSyncSearchingEngine::COL_ERROR_LOG    => $errorLog,
                LogSyncSearchingEngine::COL_SYNCED_TIME  => $syncedTime,
                LogSyncSearchingEngine::COL_CONTENT_SYNC => $contentSync,
            ]);
    }

    private function _syncInsertAction()
    {
        $logSyncSearchingEngineList = DB::table(LogSyncSearchingEngine::TABLE_NAME)
            ->where(LogSyncSearchingEngine::COL_STATUS, LogSyncSearchingEngineConst::STATUS['NOT_YET_SYNC'])
            ->where(LogSyncSearchingEngine::COL_TABLE_NAME, self::TABLE_NAME)
            ->where(LogSyncSearchingEngine::COL_ACTION_TYPE, LogSyncSearchingEngineConst::ACTION_TYPE['INSERT'])
            ->orderBy(LogSyncSearchingEngine::COL_SN)
            ->get([
                LogSyncSearchingEngine::COL_SN,
                LogSyncSearchingEngine::COL_TABLE_NAME,
                LogSyncSearchingEngine::COL_TABLE_SN,
            ]);

        foreach ($logSyncSearchingEngineList as $logSyncSearchingEngine) {
            $logSyncSearchingEngineSn = $logSyncSearchingEngine->{LogSyncSearchingEngine::COL_SN};
            $tableName = $logSyncSearchingEngine->{LogSyncSearchingEngine::COL_TABLE_NAME};
            $tableSn = $logSyncSearchingEngine->{LogSyncSearchingEngine::COL_TABLE_SN};

            $status = LogSyncSearchingEngineConst::STATUS['SYNCED'];
            $errorLog = null;
            $syncedTime = Carbon::now()->toDateTimeString();
            $contentSync = null;

            try {
                $record = DB::table($tableName)->where('SN', $tableSn)->first();
                if (empty($record)) {
                    throw new Exception('Record not found');
                }
                $contentSync = ConvertHelper::stdClassToArray($record);
                DB::connection('searching_engine')->table($tableName)->insert($contentSync);
            } catch (Exception $exception) {
                $status = LogSyncSearchingEngineConst::STATUS['ERROR_SYNC'];
                $errorLog = $exception->getMessage();
            }

            $this->_markRecord($logSyncSearchingEngineSn, $status, $errorLog, $syncedTime, $contentSync);
        }
    }

    private function _syncUpdateAction()
    {
        $newestLogSyncSearchingEngineSn = DB::table(LogSyncSearchingEngine::TABLE_NAME)
            ->where(LogSyncSearchingEngine::COL_STATUS, LogSyncSearchingEngineConst::STATUS['NOT_YET_SYNC'])
            ->where(LogSyncSearchingEngine::COL_TABLE_NAME, self::TABLE_NAME)
            ->where(LogSyncSearchingEngine::COL_ACTION_TYPE, LogSyncSearchingEngineConst::ACTION_TYPE['UPDATE'])
            ->max(LogSyncSearchingEngine::COL_SN);

        if (!empty($newestLogSyncSearchingEngineSn)) {
            $logSyncSearchingEngineList = DB::table(LogSyncSearchingEngine::TABLE_NAME)
                ->where(LogSyncSearchingEngine::COL_STATUS, LogSyncSearchingEngineConst::STATUS['NOT_YET_SYNC'])
                ->where(LogSyncSearchingEngine::COL_TABLE_NAME, self::TABLE_NAME)
                ->where(LogSyncSearchingEngine::COL_ACTION_TYPE, LogSyncSearchingEngineConst::ACTION_TYPE['UPDATE'])
                ->where(LogSyncSearchingEngine::COL_SN, '<=', $newestLogSyncSearchingEngineSn)
                ->distinct(LogSyncSearchingEngine::COL_TABLE_SN)
                ->limit(self::LIMIT)
                ->get([
                    LogSyncSearchingEngine::COL_SN,
                    LogSyncSearchingEngine::COL_TABLE_NAME,
                    LogSyncSearchingEngine::COL_TABLE_SN,
                ]);

            $logSyncSearchingEngineList = $logSyncSearchingEngineList->unique(LogSyncSearchingEngine::COL_TABLE_SN);

            foreach ($logSyncSearchingEngineList as $logSyncSearchingEngine) {
                $tableName = $logSyncSearchingEngine->{LogSyncSearchingEngine::COL_TABLE_NAME};
                $tableSn = $logSyncSearchingEngine->{LogSyncSearchingEngine::COL_TABLE_SN};

                $status = LogSyncSearchingEngineConst::STATUS['SYNCED'];
                $errorLog = null;
                $syncedTime = Carbon::now()->toDateTimeString();
                $contentSync = null;

                try {
                    $record = DB::table($tableName)->where('SN', $tableSn)->first();
                    if (empty($record)) {
                        throw new Exception('Record not found');
                    }

                    $contentSync = ConvertHelper::stdClassToArray($record);

                    DB::connection('searching_engine')->table($tableName)->updateOrInsert(
                        ['SN' => $tableSn],
                        $contentSync
                    );

                } catch (Exception $exception) {
                    $status = LogSyncSearchingEngineConst::STATUS['ERROR_SYNC'];
                    $errorLog = $exception->getMessage();
                }

                $this->_markBatchRecord($newestLogSyncSearchingEngineSn, $tableSn, $status, $errorLog, $syncedTime, $contentSync);
            }
        }
    }

    private function _markBatchRecord($newestLogSyncSearchingEngineSn, $tableSn, $status, $errorLog, $syncedTime, $contentSync)
    {
        DB::table(LogSyncSearchingEngine::TABLE_NAME)
            ->where(LogSyncSearchingEngine::COL_STATUS, LogSyncSearchingEngineConst::STATUS['NOT_YET_SYNC'])
            ->where(LogSyncSearchingEngine::COL_TABLE_NAME, self::TABLE_NAME)
            ->where(LogSyncSearchingEngine::COL_ACTION_TYPE, LogSyncSearchingEngineConst::ACTION_TYPE['UPDATE'])
            ->where(LogSyncSearchingEngine::COL_SN, '<=', $newestLogSyncSearchingEngineSn)
            ->where(LogSyncSearchingEngine::COL_TABLE_SN, $tableSn)
            ->update([
                LogSyncSearchingEngine::COL_STATUS       => $status,
                LogSyncSearchingEngine::COL_ERROR_LOG    => $errorLog,
                LogSyncSearchingEngine::COL_SYNCED_TIME  => $syncedTime,
                LogSyncSearchingEngine::COL_CONTENT_SYNC => $contentSync,
            ]);
    }

    private function _serializeDataUpdate(&$contentSync)
    {
        //
    }

    private function _syncDeleteAction()
    {
        $logSyncSearchingEngineList = DB::table(LogSyncSearchingEngine::TABLE_NAME)
            ->where(LogSyncSearchingEngine::COL_STATUS, LogSyncSearchingEngineConst::STATUS['NOT_YET_SYNC'])
            ->where(LogSyncSearchingEngine::COL_TABLE_NAME, self::TABLE_NAME)
            ->where(LogSyncSearchingEngine::COL_ACTION_TYPE, LogSyncSearchingEngineConst::ACTION_TYPE['DELETE'])
            ->orderBy(LogSyncSearchingEngine::COL_SN)
            ->get([
                LogSyncSearchingEngine::COL_SN,
                LogSyncSearchingEngine::COL_TABLE_NAME,
                LogSyncSearchingEngine::COL_TABLE_SN,
            ]);

        foreach ($logSyncSearchingEngineList as $logSyncSearchingEngine) {
            $logSyncSearchingEngineSn = $logSyncSearchingEngine->{LogSyncSearchingEngine::COL_SN};
            $tableName = $logSyncSearchingEngine->{LogSyncSearchingEngine::COL_TABLE_NAME};
            $tableSn = $logSyncSearchingEngine->{LogSyncSearchingEngine::COL_TABLE_SN};

            $status = LogSyncSearchingEngineConst::STATUS['SYNCED'];
            $errorLog = null;
            $syncedTime = Carbon::now()->toDateTimeString();
            $contentSync = null;

            try {
                DB::connection('searching_engine')->table($tableName)->where('SN', $tableSn)->delete();
            } catch (Exception $exception) {
                $status = LogSyncSearchingEngineConst::STATUS['ERROR_SYNC'];
                $errorLog = $exception->getMessage();
            }

            $this->_markRecord($logSyncSearchingEngineSn, $status, $errorLog, $syncedTime, $contentSync);
        }
    }
}
