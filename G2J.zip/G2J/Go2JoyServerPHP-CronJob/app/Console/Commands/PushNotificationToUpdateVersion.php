<?php

namespace App\Console\Commands;

use App\Constants\Globals\Common as CommonConst;
use App\Constants\Globals\FcmNotification as FcmNotificationConst;
use App\Constants\Globals\QueueName as QueueNameConst;
use App\Constants\Globals\YesNo as YesNoConst;
use App\Constants\MobileDevice as MobileDeviceConst;
use App\Jobs\Notification\PushNotificationJob;
use App\Models\StaffNotification;
use Illuminate\Console\Command;
use Illuminate\Support\Carbon;

class PushNotificationToUpdateVersion extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'push-notification-to-update-version {--staffSnList=} {--os=}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Cron job for push notification to update version';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     */
    public function handle()
    {
        $staffSnList = $this->option('staffSnList');
        $staffSnList = explode(',', $staffSnList);
        $staffSnList = array_filter($staffSnList);
        $staffSnList = array_map('intval', $staffSnList);
        $os = $this->option('os');

        $title = 'Thông báo cập nhật phiên bản';
        $content = 'Ứng dụng đang có 1 phiên bản mới vừa được phát hành. Vui lòng cập nhật phiên bản mới.';

        foreach ($staffSnList as $staffSn) {
            if ($os) {
                $staffNotificationList = StaffNotification::where(StaffNotification::COL_STAFF_SN, $staffSn)
                    ->where(StaffNotification::COL_OS, $os)
                    ->get();
            } else {
                $staffNotificationList = StaffNotification::where(StaffNotification::COL_STAFF_SN, $staffSn)->get();
            }
            $_tokenIdIosList = [];
            $_tokenIdNotIosList = [];
            foreach ($staffNotificationList as $staffNotification) {
                if ($staffNotification->{StaffNotification::COL_OS} == MobileDeviceConst::OS['IOS']) {
                    $_tokenIdIosList[] = $staffNotification->{StaffNotification::COL_TOKEN_ID};
                } else {
                    $_tokenIdNotIosList[] = $staffNotification->{StaffNotification::COL_TOKEN_ID};
                }
            }
            $body = [
                'staffSn'    => $staffSn,
                'read'       => YesNoConst::NO,
                'createTime' => Carbon::now(),
                'type'       => FcmNotificationConst::NOTI_HOTEL_RECONCILIATION,
                'content'    => $content,
                'hotelName'  => $content,//bùa để bắn noti theo format FE
            ];
            if ($_tokenIdIosList) {
                PushNotificationJob::dispatch(
                    null,
                    $_tokenIdIosList,
                    $title,
                    $body,
                    [],
                    FcmNotificationConst::NOTI_UPDATE_VERSION,
                    CommonConst::GO2JOY,
                    false,
                    null,
                    $staffSn,
                    null,
                    null,
                    MobileDeviceConst::OS['IOS'],
                    null,
                    true)->onQueue(QueueNameConst::NOTIFICATION);
            }

            if ($_tokenIdNotIosList) {
                PushNotificationJob::dispatch(
                    null,
                    $_tokenIdNotIosList,
                    $title,
                    $body,
                    [],
                    FcmNotificationConst::NOTI_UPDATE_VERSION,
                    CommonConst::GO2JOY,
                    false,
                    null,
                    $staffSn,
                    null,
                    null,
                    null,
                    null,
                    true)->onQueue(QueueNameConst::NOTIFICATION);
            }
        }
    }
}
