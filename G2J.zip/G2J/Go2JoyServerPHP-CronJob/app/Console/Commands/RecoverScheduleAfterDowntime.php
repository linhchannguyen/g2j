<?php

namespace App\Console\Commands;

use App\Console\Commands\Daily\RunAt0Hour\UpdateDailyAvailableBooking;
use App\Console\Commands\Daily\RunAt0Hour\UpdateDailyCouponIssuedExperied;
use App\Console\Commands\Daily\RunAt0Hour\UpdateDailyLuckWheel;
use App\Console\Commands\Daily\RunAt0Hour\UpdateDailyPromotion;
use App\Console\Commands\Daily\RunAt0Hour\UpdateDailyPromotionGroup;
use App\Console\Commands\Daily\RunAt0Hour\UpdateDailyRoomPriceAdjustment;
use App\Console\Commands\Daily\RunAt0Hour\UpdateDailyShowPopupHistory;
use App\Console\Commands\Daily\RunAt0Hour\UpdateStatusReferralProgram;
use App\Console\Commands\Daily\RunAt0Hour\UpdateViewsForElasticSearch;
use App\Console\Commands\Daily\RunAt2Hour\UpdateDailyRegisterStampSuspendOrEnd;
use App\Console\Commands\Daily\RunAt2Hour\UpdateDailyStampIssuedToExpired;
use App\Console\Commands\Daily\RunAt2Hour\UpdateDailyStatusForMileagePoint;
use App\Console\Commands\Daily\RunAt2Hour\UpdateDailyTempToNotYetCoupon;
use App\Console\Commands\Daily\RunAt3Hour\UpdateDailyHotelStatus;
use App\Console\Commands\Daily\RunAt3Hour\UpdateDailyNumOfNewReviewForHotel;
use App\Console\Commands\Daily\RunAt3Hour\UpdateDailyRoomTypeHasPromotionExpired;
use App\Console\Commands\Daily\RunAt6Hour\UpdateDailyBannerExpired;
use App\Console\Commands\Daily\RunAt6Hour\UpdateDailyLockRoomSetting;
use App\Console\Commands\Daily\RunAt6Hour\UpdateDailyNotifyCouponExpired;
use App\Console\Commands\Daily\RunAt6Hour\UpdateDailyPopupExpired;
use App\Console\Commands\Daily\RunAt6Hour\UpdateDailyRefreshInstantLock;
use App\Console\Commands\Daily\RunAt6Hour\UpdateDailyRefreshNotiFS;
use App\Console\Commands\Daily\RunAt6Hour\UpdateDailyRefreshSoldOutToday;
use App\Console\Commands\Daily\RunAt8Hour\UpdateUninstallDevice;
use App\Console\Commands\Daily\RunAt9Hour\NotifyExpiredStamp;
use App\Console\Commands\Daily\RunAt9Hour\NotifyForBirthdayCoupon;
use App\Console\Commands\Daily\RunAt9Hour\NotifyForSuspendStamp;
use App\Console\Commands\Daily\RunAt9Hour\NotifyPrepareExpireStampOneDate;
use App\Console\Commands\Daily\RunAt9Hour\NotifyPrepareExpireStampTwoWeek;
use App\Console\Commands\Daily\RunAt9Hour\UpdateBudgetHistory;
use App\Console\Commands\Daily\RunAt9Hour\UpdateInviteFriendStatus;
use App\Constants\Globals\Environment;
use Illuminate\Console\Command;
use Illuminate\Console\Scheduling\Schedule;
use Illuminate\Support\Facades\Artisan;

class RecoverScheduleAfterDowntime extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'recover-schedule-after-downtime';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Recover running schedule after downtime';

    /**
     * The environments
     *
     * @var array
     */
    protected $environments = [
        Environment::PRODUCTION,
    ];

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @param Schedule $schedule
     *
     * @return void
     */
    public function handle(Schedule $schedule)
    {
        if ($this->confirm('Do you wish to continue?')) {
            Artisan::call(UpdateDailyCouponIssuedExperied::class);
            Artisan::call(UpdateDailyPromotion::class);
            Artisan::call(UpdateDailyPromotionGroup::class);
            Artisan::call(UpdateDailyLuckWheel::class);
            Artisan::call(UpdateDailyRoomPriceAdjustment::class);
            Artisan::call(UpdateDailyShowPopupHistory::class);
            Artisan::call(UpdateStatusReferralProgram::class);
            Artisan::call(UpdateViewsForElasticSearch::class);
            Artisan::call(UpdateDailyAvailableBooking::class);

            //=== 2h
            Artisan::call(UpdateDailyRegisterStampSuspendOrEnd::class);
            Artisan::call(UpdateDailyStampIssuedToExpired::class);
            Artisan::call(UpdateDailyStatusForMileagePoint::class);
            Artisan::call(UpdateDailyTempToNotYetCoupon::class);

            //=== 3h
            Artisan::call(UpdateDailyHotelStatus::class);
            Artisan::call(UpdateDailyNumOfNewReviewForHotel::class);
            Artisan::call(UpdateDailyRoomTypeHasPromotionExpired::class);

            //=== 6h
            Artisan::call(UpdateDailyBannerExpired::class);
            Artisan::call(UpdateDailyLockRoomSetting::class);
            Artisan::call(UpdateDailyNotifyCouponExpired::class);
            Artisan::call(UpdateDailyPopupExpired::class);
            Artisan::call(UpdateDailyRefreshNotiFS::class);

            //=== 8h
            Artisan::call(UpdateUninstallDevice::class);

            //=== 9h
            Artisan::call(UpdateInviteFriendStatus::class);
            Artisan::call(UpdateBudgetHistory::class);
            Artisan::call(NotifyForBirthdayCoupon::class);
            Artisan::call(NotifyExpiredStamp::class);
            Artisan::call(NotifyPrepareExpireStampOneDate::class);
            Artisan::call(NotifyPrepareExpireStampTwoWeek::class);
            Artisan::call(NotifyForSuspendStamp::class);

            Artisan::output();

            $this->info('Please run command by manual after see this message: adhoc:recover-update-daily-refresh-instant-lock, adhoc:recover-update-daily-refresh-sold-out-today');
        }
    }
}