<?php

namespace App\Console\Commands;

use App\Constants\Globals\QueueName;
use App\Constants\Hotel as HotelConst;
use App\Jobs\ElasticSearch\SyncHotelLockedJob;
use App\Models\Hotel;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;

class SyncMultipleHotelLockedToElasticSearch extends Command
{
    const SECONDS_DELAY_301 = 301;
    const CHUNK_135 = 135;

    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'sync-multiple-hotel-locked-elastic-search {--hotelSn=} {--roomTypeSn=}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Cron job for sync multiple hotel locked to elastic search';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     */
    public function handle()
    {
        $hotelSn = $this->option('hotelSn');
        $roomTypeSn = $this->option('roomTypeSn');
        if ($hotelSn) {
            $syncHotelLockedJob = new SyncHotelLockedJob(json_encode([
                'hotelSn'    => $hotelSn,
                'roomTypeSn' => $roomTypeSn,
            ]));
            dispatch($syncHotelLockedJob)->onQueue(QueueName::HOTEL_LOCKED_SYNCING);

            return;
        }
        $hotelSnList = DB::table(Hotel::TABLE_NAME)
            ->where(Hotel::COL_DISPLAY, '=', HotelConst::DISPLAY['DISPLAY'])
            ->where(Hotel::COL_ROOM_AVAILABLE, '>', HotelConst::ROOM_AVAILABLE['NOT_AVAILABLE'])
            ->where(Hotel::COL_SN, '!=', HotelConst::TESTING_HOTEL)
            ->whereIn(Hotel::COL_HOTEL_STATUS, [HotelConst::STATUS['CONTRACTED'], HotelConst::STATUS['TRIAL']])
            ->orderBy(Hotel::COL_SN)
            ->get([Hotel::COL_SN])
            ->toArray();

        $chunk135HotelSnList = array_chunk($hotelSnList, self::CHUNK_135);
        foreach ($chunk135HotelSnList as $index => $chunkHotelSnList) {
            $secondsDelay = self::SECONDS_DELAY_301 * $index;
            foreach ($chunkHotelSnList as $hotelSnList) {
                $syncHotelLockedJob = new SyncHotelLockedJob(json_encode([
                    'hotelSn' => $hotelSnList->{Hotel::COL_SN},
                ]));
                dispatch($syncHotelLockedJob)->onQueue(QueueName::HOTEL_LOCKED_SYNCING)->delay(now()->addSeconds($secondsDelay));
            }
        }
    }
}
