<?php


namespace App\Console\Commands;

use App\Services\Common\ElasticSearchService;
use Illuminate\Console\Command;

class InsertMultipleHotelRankingToElasticSearch extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'insert-multiple-hotel-ranking-elastic-search';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Cron job for insert multiple hotel ranking to elastic search';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @param ElasticSearchService $elasticSearchService
     */
    public function handle(ElasticSearchService $elasticSearchService)
    {
        $elasticSearchService->insertMultipleHotelRanking();
    }
}
