<?php

namespace App\Console\Commands;

use App\Helpers\ConvertHelper;
use App\Models\MongoDB\LogCronJob;
use App\Models\MongoDB\LogDatabase;
use App\Models\MongoDB\LogException;
use App\Models\MongoDB\LogExternalCallback;
use App\Models\MongoDB\LogExternalPaymentAPI;
use App\Models\MongoDB\LogFunction;
use App\Models\MongoDB\LogHandlerAddress;
use App\Models\MongoDB\LogInternalAPI;
use App\Models\MongoDB\LogJobQueue;
use App\Models\MongoDB\LogMobileAPI;
use App\Models\MongoDB\LogPaymentAPI;
use App\Models\MongoDB\LogQueueUserAccess;
use App\Models\MongoDB\LogSoap;
use App\Models\MongoDB\LogUserFlow;
use App\Models\MongoDB\LogUserFlowBookingInsight;
use App\Models\MongoDB\LogUserOpenApp;
use App\Models\MongoDB\LogUserSignUp;
use App\Models\MongoDB\LogWebBookingAPI;
use App\Models\MongoDB\UserNotificationDetail;
use App\Models\UserFlow;
use Illuminate\Console\Command;

class GarbageCollection extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'garbage-collection';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Garbage collection of data';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     */
    public function handle()
    {
        $this->_groupRemoveDocumentsLast7Days();
        $this->_groupRemoveDocumentsLast14Days();
        $this->_groupRemoveDocumentsLast30Days();
        $this->_groupRemoveUserFlowLast60Days();
    }

    private function _groupRemoveDocumentsLast7Days()
    {
        $time = strtotime(date('Y-m-d H:i:s', strtotime('-7 days')));

        LogException::where(
            '_id', '<=', ConvertHelper::timestampToObjectId($time)
        )->delete();

        LogCronJob::where(
            '_id', '<=', ConvertHelper::timestampToObjectId($time)
        )->delete();

        LogDatabase::where(
            '_id', '<=', ConvertHelper::timestampToObjectId($time)
        )->delete();

        LogFunction::where(
            '_id', '<=', ConvertHelper::timestampToObjectId($time)
        )->delete();

        LogJobQueue::where(
            '_id', '<=', ConvertHelper::timestampToObjectId($time)
        )->delete();
    }

    private function _groupRemoveDocumentsLast14Days()
    {
        $time = strtotime(date('Y-m-d H:i:s', strtotime('-14 days')));

        LogUserOpenApp::where(
            '_id', '<=', ConvertHelper::timestampToObjectId($time)
        )->delete();

        LogUserSignUp::where(
            '_id', '<=', ConvertHelper::timestampToObjectId($time)
        )->delete();

        LogUserFlow::where(
            '_id', '<=', ConvertHelper::timestampToObjectId($time)
        )->delete();

        LogUserFlowBookingInsight::where(
            '_id', '<=', ConvertHelper::timestampToObjectId($time)
        )->delete();

        LogQueueUserAccess::where('_id', '<=', ConvertHelper::timestampToObjectId($time))
            ->where('is_snapshot', '=', 1)
            ->delete();

        LogHandlerAddress::where('_id', '<=', ConvertHelper::timestampToObjectId($time))
            ->where('info_address_parse.canNotGeocoding', '=', false)
            ->delete();

        LogInternalAPI::where(
            '_id', '<=', ConvertHelper::timestampToObjectId($time)
        )->delete();

        LogExternalCallback::where(
            '_id', '<=', ConvertHelper::timestampToObjectId($time)
        )->delete();

        LogExternalPaymentAPI::where(
            '_id', '<=', ConvertHelper::timestampToObjectId($time)
        )->delete();

        LogPaymentAPI::where(
            '_id', '<=', ConvertHelper::timestampToObjectId($time)
        )->delete();

        LogMobileAPI::where(
            '_id', '<=', ConvertHelper::timestampToObjectId($time)
        )->delete();

        LogSoap::where(
            '_id', '<=', ConvertHelper::timestampToObjectId($time)
        )->delete();

        LogWebBookingAPI::where(
            '_id', '<=', ConvertHelper::timestampToObjectId($time)
        )->delete();
    }

    private function _groupRemoveDocumentsLast30Days()
    {
        $time = strtotime(date('Y-m-d H:i:s', strtotime('-30 days')));

        UserNotificationDetail::where(
            '_id', '<=', ConvertHelper::timestampToObjectId($time)
        )->delete();
    }

    private function _groupRemoveUserFlowLast60Days()
    {
        $datetime = date('Y-m-d H:i:s', strtotime('-60 days'));

        UserFlow::where(
            UserFlow::COL_LAST_UPDATE, '<=', $datetime
        )->where(UserFlow::COL_SN,'>',0)
        ->delete();
    }
}
