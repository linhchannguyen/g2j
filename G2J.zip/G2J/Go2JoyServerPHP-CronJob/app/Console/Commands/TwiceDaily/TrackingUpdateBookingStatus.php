<?php

namespace App\Console\Commands\TwiceDaily;

use App\Actions\Tracking\Amplitude\TrackingUpdateBookingStatusEvent;
use App\API\External\Tracking\Amplitude\AmplitudeProcessor;
use App\Constants\AmplitudeChangeUserBookingStatus as AmplitudeChangeUserBookingStatusConst;
use App\Helpers\LoggingHelper;
use App\Models\AmplitudeChangeUserBookingStatus;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;

class TrackingUpdateBookingStatus extends Command
{
    protected $amplitudeProcessor;

    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'twiceDaily:tracking-update-booking-status-event';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Cron job for twice Daily';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
        $this->amplitudeProcessor = app(AmplitudeProcessor::class);
    }

    public function handle(TrackingUpdateBookingStatusEvent $trackingUpdateBookingStatusEvent)
    {
        LoggingHelper::logFunction('START JOB: TWICE DAILY START TRACKING BOOKING UPDATE STATUS EVENT');

        $amplitudeChangeUserBookingStatusList = DB::connection('replica')
            ->table(AmplitudeChangeUserBookingStatus::TABLE_NAME)
            ->where(AmplitudeChangeUserBookingStatus::COL_SEND, AmplitudeChangeUserBookingStatusConst::SEND['NO'])
            ->get();
        foreach ($amplitudeChangeUserBookingStatusList as $values) {
            $trackingUpdateBookingStatusEventOutPut = $trackingUpdateBookingStatusEvent->handle($values);
            $this->amplitudeProcessor->trackingUpdateBookingStatus($trackingUpdateBookingStatusEventOutPut->getEvents());
            DB::connection('replica')->table(AmplitudeChangeUserBookingStatus::TABLE_NAME)
                ->where(AmplitudeChangeUserBookingStatus::COL_SN, $values->{AmplitudeChangeUserBookingStatus::COL_SN})
                ->update([
                    AmplitudeChangeUserBookingStatus::COL_SEND => AmplitudeChangeUserBookingStatusConst::SEND['YES']
                ]);
        }

        LoggingHelper::logFunction('START JOB: TWICE DAILY COMPLETE TRACKING BOOKING UPDATE STATUS EVENT');
    }
}
