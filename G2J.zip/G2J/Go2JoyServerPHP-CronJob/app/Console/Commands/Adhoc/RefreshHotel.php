<?php

namespace App\Console\Commands\Adhoc;

use App\Services\Mobile\HotelDisplayRuleService;
use Illuminate\Console\Command;

class RefreshHotel extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'adhoc:refresh-hotel
                            {--hotelSn=}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Refresh hotel include: 1.display rule, 2.sold out today, 3.display filter, 4.available';

    /**
     * @var HotelDisplayRuleService
     */
    protected $hotelDisplayRuleService;

    /**
     * RefreshHotelAvailable constructor.
     */
    public function __construct(HotelDisplayRuleService $hotelDisplayRuleService)
    {
        parent::__construct();
        $this->hotelDisplayRuleService = $hotelDisplayRuleService;
    }

    /**
     * Execute the console command.
     *
     * @return void
     */
    public function handle()
    {
        $hotelSn = $this->option('hotelSn');
        $this->hotelDisplayRuleService->refreshHotelDisplayRuleJob($hotelSn);
        $this->hotelDisplayRuleService->refreshHotelSoldOutTodayJob($hotelSn);
        $this->hotelDisplayRuleService->refreshHotelDisplayFilterJob($hotelSn);
        $this->hotelDisplayRuleService->refreshHotelAvailableJob($hotelSn);
    }
}
