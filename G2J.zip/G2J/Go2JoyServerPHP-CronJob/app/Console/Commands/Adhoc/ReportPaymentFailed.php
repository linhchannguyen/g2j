<?php

namespace App\Console\Commands\Adhoc;

use App\Constants\Globals\Code;
use App\Constants\Globals\Payment;
use App\Constants\Globals\Payment as PaymentConst;
use App\Constants\Globals\QueueName;
use App\Constants\UserBooking as UserBookingConst;
use App\Factories\PaymentFactory;
use App\Helpers\ConvertHelper;
use App\Helpers\UploadHelper;
use App\Jobs\Mail\SendExportFileMailJob;
use App\Models\MongoDB\LogExternalCallback;
use App\Models\PaymentTransaction;
use App\Models\UserBooking;
use Box\Spout\Writer\Style\StyleBuilder;
use Carbon\Carbon;
use Exception;
use Generator;
use Illuminate\Console\Command;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Storage;
use Rap2hpoutre\FastExcel\FastExcel;
use Rap2hpoutre\FastExcel\SheetCollection;
use stdClass;

class ReportPaymentFailed extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'adhoc:report-payment-failed
                            {--startDate=}
                            {--endDate=}
                            {--userBookingSnList=}
                            {--staffSn=}
                            {--table : Print report as table view to console. Default: export to Excel file and send via email}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Report some reason failed payment of user booking';

    /** @var PaymentFactory */
    private $paymentFactory;

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
        $this->paymentFactory = new PaymentFactory();
    }

    /**
     * Execute the console command.
     *
     * @return void
     * @throws Exception
     */
    public function handle()
    {
        $table = $this->option('table');

        $staffSn = $this->option('staffSn');
        if (!$table && empty($staffSn)) {
            $this->error('Command option `staffSn` is required!');
            return;
        }

        $startDate = $this->option('startDate') ?? Carbon::now()->startOfDay();
        $endDate = $this->option('endDate') ?? Carbon::now()->endOfDay();

        $userBookingSnList = $this->option('userBookingSnList');
        $userBookingSnList = explode(',', $userBookingSnList);
        $userBookingSnList = array_filter($userBookingSnList);
        $userBookingSnList = array_map('intval', $userBookingSnList);

        $queryStatement = UserBooking::where(UserBooking::COL_BOOKING_STATUS, UserBookingConst::BOOKING_STATUS['PAYMENT_FAILED'])
            ->whereNotIn(UserBooking::COL_PAYMENT_PROVIDER, [UserBookingConst::PAYMENT_PROVIDER['AT_HOTEL'], UserBookingConst::PAYMENT_PROVIDER['PAYOO_STORE']])
            ->where(UserBooking::COL_PREPAY_AMOUNT, 0);

        if (!empty($userBookingSnList)) {
            $queryStatement->whereIn(UserBooking::COL_SN, $userBookingSnList);
        } else {
            $queryStatement->whereBetween(UserBooking::COL_CHECK_IN_DATE_PLAN, [$startDate, $endDate]);
        }

        $data = [];
        $userBookingPaymentFailedList = $queryStatement->get([UserBooking::COL_SN, UserBooking::COL_BOOKING_NO, UserBooking::COL_PAYMENT_PROVIDER, UserBooking::COL_DEVICE_TYPE, UserBooking::COL_CREATE_TIME]);
        $index = 0;
        foreach ($userBookingPaymentFailedList as $userBookingPaymentFailed) {
            $createTime = $userBookingPaymentFailed->{UserBooking::COL_CREATE_TIME};
            $userBookingSn = $userBookingPaymentFailed->{UserBooking::COL_SN};
            $bookingNo = $userBookingPaymentFailed->{UserBooking::COL_BOOKING_NO};
            $paymentProvider = $userBookingPaymentFailed->{UserBooking::COL_PAYMENT_PROVIDER};
            $deviceType = $userBookingPaymentFailed->{UserBooking::COL_DEVICE_TYPE};
            $platform = ($deviceType == UserBookingConst::DEVICE_TYPE['MOBILE']) ? PaymentConst::PLATFORM['APP'] : PaymentConst::PLATFORM['WEB'];
            $result = $this->_tracingReason($createTime, $userBookingSn, $bookingNo, $paymentProvider, $platform);
            if (!empty($result)) {
                $index++;
                array_unshift($result, $index);
                $data[] = $result;
            }
        }

        if ($table) {
            // Set the table headers.
            $headers = ['#', 'USER_BOOKING_SN', 'Payment Provider', 'User', 'Go2Joy', 'PSP'];

            // Render the table to the output
            $this->table($headers, $data);
        } else {
            // Export Excel file and push send mail job
            $headerStyle = (new StyleBuilder())->setFontBold()->build();
            $sheetOne = 'FAILED PAYMENT REPORT';
            $sheets = new SheetCollection([
                $sheetOne => $this->_reportsGenerator($data),
            ]);

            $createdAt = Carbon::now()->timestamp;
            $author = $staffSn;
            $filePath = "/exports/failed-payment-report/{$author}_{$createdAt}.xlsx";
            $fullPath = Storage::disk('local')->path($filePath);
            // Check folder already exists or not, create if not exists
            $folder = storage_path('app/exports/failed-payment-report/');
            if (!File::exists($folder)) {
                File::makeDirectory($folder, 0755, true, true);
            }
            (new FastExcel($sheets))
                ->headerStyle($headerStyle)
                ->export($fullPath);

            // Upload to S3
            $content = Storage::disk(UploadHelper::DISK_LOCAL)->get($filePath);
            UploadHelper::uploadFile($content, UploadHelper::FOLDER['UPLOAD'] . $filePath);

            // Finally, push job to send mail
            if (empty($userBookingSnList)) {
                $fileName = sprintf("FAILED_PAYMENT_REPORT_%s-%s_%s.%s-%s.xlsx", Carbon::parse($startDate)->format('dmYHis'), Carbon::parse($endDate)->format('dmYHis'), now()->hour, now()->minute, now()->format('dmY'));
            } else {
                $fileName = 'FAILED_PAYMENT_REPORT.xlsx';
            }
            SendExportFileMailJob::dispatch($author, $filePath, $fileName)->allOnConnection('redis')->allOnQueue(QueueName::EMAIL);
        }
    }

    /**
     * @throws Exception
     */
    private function _tracingReason($createTime, $userBookingSn, $bookingNo, $paymentProvider, $platform)
    {
        $paymentProviderStr = UserBookingConst::PAYMENT_PROVIDER_STR[$paymentProvider];
        switch ($paymentProvider) {
            case UserBookingConst::PAYMENT_PROVIDER['MOMO']: {
                $provider = PaymentConst::PAYMENT_PROVIDER['MOMO'];
                $logExternalCallback = LogExternalCallback::raw(function($collection) use ($provider, $bookingNo) {
                    return $collection->find(
                        [
                            'provider'             => $provider,
                            'request.body.orderId' => strval($bookingNo),
                            'request.method'       => 'POST',
                        ]
                    );
                })->sortBy('request_at');
                break;
            }
            case UserBookingConst::PAYMENT_PROVIDER['ZALO_PAY']: {
                $logExternalCallback = [];
                $provider = PaymentConst::PAYMENT_PROVIDER['ZALO_PAY'];
                $createTime = Carbon::parse($createTime)->toDateTimeString();
                $paymentTransaction = PaymentTransaction::where(PaymentTransaction::COL_USER_BOOKING_SN, $userBookingSn)->first();
                $transactionId = $paymentTransaction->{PaymentTransaction::COL_TRANSACTION_ID};
                $logExternalCallbackList = LogExternalCallback::raw(function($collection) use ($provider, $createTime) {
                    return $collection->find(
                        [
                            '_id'            => ['$gte' => ConvertHelper::timestampToObjectId($createTime),],
                            'provider'       => $provider,
                            'request.method' => 'POST',
                        ]
                    );
                });
                foreach ($logExternalCallbackList as $log) {
                    $dataJson = json_decode($log->request->body->data);
                    $embedData = json_decode($dataJson->embed_data);
                    if ($transactionId == $embedData->transactionId) {
                        $logExternalCallback = $log;
                        break;
                    }
                }
                break;
            }
            case UserBookingConst::PAYMENT_PROVIDER['EPAY_IC']:
            case UserBookingConst::PAYMENT_PROVIDER['EPAY_DC']: {
                $provider = PaymentConst::PAYMENT_PROVIDER['EPAY'];
                $logExternalCallback = LogExternalCallback::raw(function($collection) use ($provider, $bookingNo) {
                    return $collection->find(
                        [
                            'provider'               => $provider,
                            'request.method'         => 'POST',
                            'request.body.invoiceNo' => strval($bookingNo),
                        ]
                    );
                })->sortBy('request_at');
                break;
            }
            default: return [];
        }

        if (count($logExternalCallback) > 0) {
            if ($paymentProvider == userBookingConst::PAYMENT_PROVIDER['MOMO']) {
                // By User: transaction denied by user
                if ($logExternalCallback->first()->request->body->resultCode == Payment::MOMO_AIOV2_ERROR_CODE['TRANSACTION_DENIED_BY_USER']) {
                    return [$userBookingSn, $paymentProviderStr, '+', '-', '-'];
                }
            }

            // By Go2Joy: not process or process failed with IPN
            return [$userBookingSn, $paymentProviderStr, '-', '+', '-'];
        } else {
            $paymentTransaction = PaymentTransaction::where(PaymentTransaction::COL_USER_BOOKING_SN, $userBookingSn)->first();
            if (!empty($paymentTransaction)) {
                $transactionId = $paymentTransaction->{PaymentTransaction::COL_TRANSACTION_ID};
                $pspTransactionId = $paymentTransaction->{PaymentTransaction::COL_PSP_TRANSACTION_ID};

                // Get user booking info
                $userBooking = UserBooking::where(UserBooking::COL_SN, $userBookingSn)->first();
                if (empty($userBooking)) {
                    throw new Exception("User booking with sn = $userBookingSn not found!");
                }
                $inputs['platform'] = $platform;
                $inputs['userBooking'] = $userBooking;
                $inputs['paymentProvider'] = $provider;
                $inputs['transactionId'] = $transactionId;
                $inputs['pspTransactionId'] = $pspTransactionId;
                $paymentProcessor = $this->paymentFactory->createProcessor($platform, $provider);
                try {
                    $paymentResult = $paymentProcessor->getPaymentResult($inputs);

                    // Build result form
                    $resultForm = $this->paymentFactory->buildResultForm($paymentResult, $platform, $provider);

                    if ($resultForm->getCode() == Code::SUCCESS) {
                        return [$userBookingSn, $paymentProviderStr, '-', '-', '+'];
                    } else {
                        return [$userBookingSn, $paymentProviderStr, '+', '-', '-'];
                    }
                } catch (Exception $exception) {
                    if ($paymentProvider == userBookingConst::PAYMENT_PROVIDER['MOMO'] && $exception->getCode() == 402) {
                        return [$userBookingSn, $paymentProviderStr, '+', '-', '-'];
                    }
                    return [$userBookingSn, $paymentProviderStr, '-', '-', '+'];
                }
            } else {
                return [$userBookingSn, $paymentProviderStr, '-', '+', '-'];
            }
        }
    }

    /**
     * @param array|collection $data
     * @return Generator
     */
    private function _reportsGenerator($data)
    {
        foreach ($data as $key => $value) {
            yield $this->_sheetOneFormatting($key, $value);
        }
    }

    /**
     * @param int $index
     * @param stdClass $item
     * @return stdClass
     */
    private function _sheetOneFormatting($index, $item)
    {
        $object = new stdClass();
        $object->{'#'} = $item[0];
        $object->{'USER_BOOKING_SN'} = $item[1];
        $object->{'Payment Provider'} = $item[2];
        $object->{'User'} = $item[3] === '+' ? 1 : 0;
        $object->{'Go2Joy'} = $item[4] === '+' ? 1 : 0;
        $object->{'PSP'} = $item[5] === '+' ? 1 : 0;

        return $object;
    }
}
