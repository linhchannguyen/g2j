<?php

namespace App\Console\Commands\Adhoc;

use App\Constants\HotelDebt as HotelDebtConst;
use App\Models\HotelDebt;
use App\Services\Web\SA\HotelDebtService;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;

class RemoveFinalHotelDebt extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'adhoc:remove-final-hotel-debt
                            {--startDate=}
                            {--endDate=}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Remove all of final hotel debts';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        $startDate = $this->option('startDate');
        $endDate = $this->option('endDate');

        $hotelDebtService = app(HotelDebtService::class);
        $query = DB::table(HotelDebt::TABLE_NAME)
            ->where(HotelDebt::COL_FINAL_RECORD, HotelDebtConst::FINAL_RECORD['TRUE']);

        if (!empty($startDate) && !empty($endDate)) {
            $query->whereDate(HotelDebt::COL_START_DATE, '=', $startDate)
                ->whereDate(HotelDebt::COL_END_DATE, '=', $endDate);
        }

        $allFinalHotelDebt = $query->pluck(HotelDebt::COL_SN)->all();

        $hotelDebtSnList = array_unique($allFinalHotelDebt);

        foreach ($hotelDebtSnList as $hotelDebtSn) {
            $result = $hotelDebtService->destroy($hotelDebtSn);
            if ($result) {
                $this->info("$hotelDebtSn");
            } else {
                $this->error("Failed: $hotelDebtSn");
                break;
            }
        }
    }
}
