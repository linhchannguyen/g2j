<?php

namespace App\Console\Commands\Adhoc;

use App\Constants\Globals\Code;
use App\Constants\Globals\Payment as PaymentConst;
use App\Constants\Staff as StaffConst;
use App\Constants\UserBooking as UserBookingConst;
use App\Factories\PaymentFactory;
use App\Models\CancellationPolicy;
use App\Models\PaymentTransaction;
use App\Models\RefundingHistory;
use App\Models\UserBooking;
use App\Repositories\Interfaces\RefundingHistoryRepositoryInterface;
use App\Services\Others\PaymentServiceV2;
use Illuminate\Console\Command;

class RefundPayment extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'adhoc:refund-payment
                            {--userBookingSnList=}';

    protected $paymentService;

    protected $refundingHistoryRepository;

    protected $paymentFactory;

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Refund payment for user booking only - NOT UPDATE STATE OF USER BOOKING';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
        $this->paymentService = app(PaymentServiceV2::class);
        $this->refundingHistoryRepository = app(RefundingHistoryRepositoryInterface::class);
        $this->paymentFactory = app(PaymentFactory::class);
    }

    /**
     * Execute the console command.
     *
     * @return void
     */
    public function handle()
    {
        $userBookingSnList = $this->option('userBookingSnList');
        $userBookingSnList = explode(',', $userBookingSnList);
        $userBookingSnList = array_filter($userBookingSnList);
        $userBookingSnList = array_map('intval', $userBookingSnList);

        foreach ($userBookingSnList as $userBookingSn) {
            $userBooking = UserBooking::where(UserBooking::COL_SN, $userBookingSn)->first();
            $paymentTransaction = PaymentTransaction::where(PaymentTransaction::COL_USER_BOOKING_SN, $userBookingSn)->first();

            $cancellationPolicy = CancellationPolicy::where(CancellationPolicy::COL_USER_BOOKING_SN, $userBookingSn)->first();
            if (!empty($cancellationPolicy)) {
                $userBooking->{UserBooking::COL_PREPAY_AMOUNT} = $cancellationPolicy->{CancellationPolicy::COL_REFUNDING_AMOUNT};
            }

            $refunded = true;
            $errorMessage = null;
            if (!empty($userBooking) && !empty($paymentTransaction)) {
                // Generate refund transaction id (format: RF - {TRANSACTION_ID})
                $inputs['transactionId'] = 'RF-' . $paymentTransaction->{PaymentTransaction::COL_TRANSACTION_ID};
                // Get refund transaction id (can be null if not refunded yet)
                $inputs['rfTransactionId'] = $paymentTransaction->{PaymentTransaction::COL_RF_TRANSACTION_ID};
                $pspTransactionId = $paymentTransaction->{PaymentTransaction::COL_PSP_TRANSACTION_ID};
                $inputs['pspTransactionId'] = $pspTransactionId;
                $inputs['userBooking'] = $userBooking;

                switch ($userBooking->{UserBooking::COL_PAYMENT_PROVIDER}) {
                    case UserBookingConst::PAYMENT_PROVIDER['MOMO']:
                        $deviceType = $userBooking->{UserBooking::COL_DEVICE_TYPE};
                        if ($deviceType == UserBookingConst::DEVICE_TYPE['MOBILE']) {
                            $inputs['platform'] = PaymentConst::PLATFORM['APP'];
                        } else {
                            $inputs['platform'] = PaymentConst::PLATFORM['WEB'];
                        }
                        $inputs['paymentProvider'] = PaymentConst::PAYMENT_PROVIDER['MOMO'];
                        $inputs['userBookingSn'] = $userBooking->{UserBooking::COL_SN};
                        [$refunded, $errorMessage] = $this->_refund($inputs);
                        break;
                    case UserBookingConst::PAYMENT_PROVIDER['ZALO_PAY']:
                        $deviceType = $userBooking->{UserBooking::COL_DEVICE_TYPE};
                        if ($deviceType == UserBookingConst::DEVICE_TYPE['MOBILE']) {
                            $inputs['platform'] = PaymentConst::PLATFORM['APP'];
                        } else {
                            $inputs['platform'] = PaymentConst::PLATFORM['WEB'];
                        }
                        $inputs['paymentProvider'] = PaymentConst::PAYMENT_PROVIDER['ZALO_PAY'];
                        $inputs['userBookingSn'] = $userBooking->{UserBooking::COL_SN};
                        [$refunded, $errorMessage] = $this->_refund($inputs);
                        break;
                    case UserBookingConst::PAYMENT_PROVIDER['EPAY_DC']:
                    case UserBookingConst::PAYMENT_PROVIDER['EPAY_IC']:
                        $deviceType = $userBooking->{UserBooking::COL_DEVICE_TYPE};
                        if ($deviceType == UserBookingConst::DEVICE_TYPE['MOBILE']) {
                            $inputs['platform'] = PaymentConst::PLATFORM['APP'];
                        } else {
                            $inputs['platform'] = PaymentConst::PLATFORM['WEB'];
                        }
                        $inputs['paymentProvider'] = PaymentConst::PAYMENT_PROVIDER['EPAY'];
                        $inputs['refTransactionId'] = $userBooking->{UserBooking::COL_TRANSACTION_ID};
                        $inputs['refundAmount'] = $userBooking->{UserBooking::COL_PREPAY_AMOUNT};
                        $inputs['userBookingSn'] = $userBooking->{UserBooking::COL_SN};
                        $inputs['payType'] = $userBooking->{UserBooking::COL_PAYMENT_PROVIDER};
                        [$refunded, $errorMessage] = $this->_refund($inputs);
                        break;
                    case UserBookingConst::PAYMENT_PROVIDER['SHOPEE_WALLET']:
                        $deviceType = $userBooking->{UserBooking::COL_DEVICE_TYPE};
                        if ($deviceType == UserBookingConst::DEVICE_TYPE['MOBILE']) {
                            $inputs['platform'] = PaymentConst::PLATFORM['APP'];
                        } else {
                            $inputs['platform'] = PaymentConst::PLATFORM['WEB'];
                        }
                        $inputs['paymentProvider'] = PaymentConst::PAYMENT_PROVIDER['SHOPEE_PAY'];
                        $inputs['userBookingSn'] = $userBooking->{UserBooking::COL_SN};
                        $inputs['refundAmount'] = $userBooking->{UserBooking::COL_PREPAY_AMOUNT};
                        [$refunded, $errorMessage] = $this->_refund($inputs);
                        break;
                }

                $refundingHistory = new RefundingHistory();
                $refundingHistory->setAttribute(RefundingHistory::COL_USER_BOOKING_SN, $userBooking->{UserBooking::COL_SN});
                $refundingHistory->setAttribute(RefundingHistory::COL_STAFF_SN, StaffConst::SYSTEM);
                $this->refundingHistoryRepository->create($refundingHistory->toArray());
            } else {
                $refunded = false;
                $errorMessage = 'Something went wrong!';
            }

            // Set the table headers.
            $headers = ['Refunded', 'Error message'];

            // Render the table to the output
            $data[] = [$refunded, $errorMessage];
            $this->table($headers, $data);
        }
    }

    private function _refund($inputs)
    {
        $paymentProcessor = $this->paymentFactory->createProcessor($inputs['platform'], $inputs['paymentProvider']);
        $refundResult = $paymentProcessor->refund($inputs);

        // Build result form
        $resultForm = $this->paymentFactory->buildResultForm($refundResult, $inputs['platform'], $inputs['paymentProvider']);

        // Save RF_TRANSACTION_ID
        $rfTransactionId = $resultForm->getData()['transactionId'];
        PaymentTransaction::where(PaymentTransaction::COL_USER_BOOKING_SN, $inputs['userBookingSn'])->update([
            PaymentTransaction::COL_RF_TRANSACTION_ID => $rfTransactionId
        ]);

        if ($resultForm->getCode() == Code::SUCCESS) {
            return [true, 'Successful'];
        } else {
            $errorMessage = $resultForm->getError()[0]['message'] ?? null;

            return [false, $errorMessage];
        }
    }
}
