<?php

namespace App\Console\Commands\Adhoc;

use App\Constants\Epay as EpayConst;
use App\Constants\Globals\Payment;
use App\Constants\Globals\Payment as PaymentConst;
use App\Constants\Globals\QueueName;
use App\Constants\UserBooking as UserBookingConst;
use App\Factories\PaymentFactory;
use App\Helpers\UploadHelper;
use App\Jobs\Mail\SendExportFileMailJob;
use App\Models\PaymentTransaction;
use App\Models\UserBooking;
use Box\Spout\Writer\Style\StyleBuilder;
use Carbon\Carbon;
use Exception;
use Generator;
use Illuminate\Console\Command;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Storage;
use Rap2hpoutre\FastExcel\FastExcel;
use Rap2hpoutre\FastExcel\SheetCollection;
use stdClass;

class ReportPaymentStatus extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'adhoc:report-payment-status
                            {--startDate=}
                            {--endDate=}
                            {--userBookingSnList=}
                            {--staffSn=}
                            {--tempBooking : Option to find out temporary booking}
                            {--table : Print report as table view to console. Default: export to Excel file and send via email}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Report status (paid yet or not) of user booking';

    /** @var PaymentFactory */
    private $paymentFactory;

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
        $this->paymentFactory = new PaymentFactory();
    }

    /**
     * Execute the console command.
     *
     * @return void
     * @throws Exception
     */
    public function handle()
    {
        $table = $this->option('table');

        $tempBooking = $this->option('tempBooking');

        $staffSn = $this->option('staffSn');
        if (!$table && empty($staffSn)) {
            $this->error('Command option `staffSn` is required!');
            return;
        }

        $startDate = $this->option('startDate') ?? Carbon::now()->startOfDay();
        $endDate = $this->option('endDate') ?? Carbon::now()->endOfDay();

        $userBookingSnList = $this->option('userBookingSnList');
        $userBookingSnList = explode(',', $userBookingSnList);
        $userBookingSnList = array_filter($userBookingSnList);
        $userBookingSnList = array_map('intval', $userBookingSnList);
        if ($tempBooking) {
            $queryStatement = UserBooking::whereIn(UserBooking::COL_BOOKING_STATUS, [UserBookingConst::BOOKING_STATUS['TEMP']])
                ->where(UserBooking::COL_PREPAY_AMOUNT, '=', 0)
                ->whereIn(UserBooking::COL_PAYMENT_PROVIDER, [UserBookingConst::PAYMENT_PROVIDER['EPAY_DC'], UserBookingConst::PAYMENT_PROVIDER['EPAY_IC']]);

        } else {
            $queryStatement = UserBooking::whereIn(UserBooking::COL_BOOKING_STATUS, [UserBookingConst::BOOKING_STATUS['CANCELLED'], UserBookingConst::BOOKING_STATUS['NO_SHOW']])
                ->where(UserBooking::COL_PREPAY_AMOUNT, '>', 0)
                ->whereIn(UserBooking::COL_PAYMENT_PROVIDER, [UserBookingConst::PAYMENT_PROVIDER['ZALO_PAY']]);
        }

        if (!empty($userBookingSnList)) {
            $queryStatement->whereIn(UserBooking::COL_SN, $userBookingSnList);
        } else {
            $queryStatement->whereBetween(UserBooking::COL_CREATE_TIME, [$startDate, $endDate]);
        }
        $data = [];
        $userBookingList = $queryStatement->get([
            UserBooking::COL_SN,
            UserBooking::COL_BOOKING_NO,
            UserBooking::COL_PAYMENT_PROVIDER,
            UserBooking::COL_PREPAY_AMOUNT,
            UserBooking::COL_CREATE_TIME,
            UserBooking::COL_DEVICE_TYPE,
        ]);
        $index = 0;
        foreach ($userBookingList as $userBooking) {
            $userBookingSn = $userBooking->{UserBooking::COL_SN};
            $bookingNo = $userBooking->{UserBooking::COL_BOOKING_NO};
            $paymentProvider = $userBooking->{UserBooking::COL_PAYMENT_PROVIDER};
            $prepayAmount = $userBooking->{UserBooking::COL_PREPAY_AMOUNT};
            $deviceType = $userBooking->{UserBooking::COL_DEVICE_TYPE};
            $platform = ($deviceType == UserBookingConst::DEVICE_TYPE['MOBILE']) ? PaymentConst::PLATFORM['APP'] : PaymentConst::PLATFORM['WEB'];
            $result = $this->_checkingStatus($userBookingSn, $paymentProvider, $platform);
            if (!empty($result)) {
                $index++;
                array_unshift($result, $index);
                $data[] = $result;
            }
        }
        if ($table) {
            // Set the table headers.
            $headers = ['#', 'USER_BOOKING_SN', 'Payment Provider', 'Paid', 'Not Paid'];

            // Render the table to the output
            $this->table($headers, $data);
        } else {
            // Export Excel file and push send mail job
            $headerStyle = (new StyleBuilder())->setFontBold()->build();
            $sheetOne = 'STATUS PAYMENT REPORT';
            $sheets = new SheetCollection([
                $sheetOne => $this->_reportsGenerator($data),
            ]);

            $createdAt = Carbon::now()->timestamp;
            $author = $staffSn;
            $filePath = "/exports/status-payment-report/{$author}_{$createdAt}.xlsx";
            $fullPath = Storage::disk('local')->path($filePath);
            // Check folder already exists or not, create if not exists
            $folder = storage_path('app/exports/status-payment-report/');
            if (!File::exists($folder)) {
                File::makeDirectory($folder, 0755, true, true);
            }
            (new FastExcel($sheets))
                ->headerStyle($headerStyle)
                ->export($fullPath);

            // Upload to S3
            $content = Storage::disk(UploadHelper::DISK_LOCAL)->get($filePath);
            UploadHelper::uploadFile($content, UploadHelper::FOLDER['UPLOAD'] . $filePath);

            // Finally, push job to send mail
            if (empty($userBookingSnList)) {
                $fileName = sprintf("STATUS_PAYMENT_REPORT_%s-%s_%s.%s-%s.xlsx", Carbon::parse($startDate)->format('dmYHis'), Carbon::parse($endDate)->format('dmYHis'), now()->hour, now()->minute, now()->format('dmY'));
            } else {
                $fileName = 'STATUS_PAYMENT_REPORT.xlsx';
            }
            SendExportFileMailJob::dispatch($author, $filePath, $fileName)->allOnConnection('redis')->allOnQueue(QueueName::EMAIL);
        }
    }

    private function _checkingStatus($userBookingSn, $paymentProvider, $platform)
    {
        $paymentProviderStr = UserBookingConst::PAYMENT_PROVIDER_STR[$paymentProvider];
        switch ($paymentProvider) {
            case UserBookingConst::PAYMENT_PROVIDER['ZALO_PAY']: {
                $provider = PaymentConst::PAYMENT_PROVIDER['ZALO_PAY'];
                break;
            }
            case UserBookingConst::PAYMENT_PROVIDER['EPAY_IC']:
            case UserBookingConst::PAYMENT_PROVIDER['EPAY_DC']: {
                $provider = PaymentConst::PAYMENT_PROVIDER['EPAY'];
                break;
            }
            default:
                return [];
        }
        $paymentTransaction = PaymentTransaction::where(PaymentTransaction::COL_USER_BOOKING_SN, $userBookingSn)->first();
        if (!empty($paymentTransaction)) {
            $transactionId = $paymentTransaction->{PaymentTransaction::COL_TRANSACTION_ID};
            $pspTransactionId = $paymentTransaction->{PaymentTransaction::COL_PSP_TRANSACTION_ID};

            // Get user booking info
            $userBooking = UserBooking::where(UserBooking::COL_SN, $userBookingSn)->first();
            if (empty($userBooking)) {
                throw new Exception("User booking with sn = $userBookingSn not found!");
            }
            $inputs['platform'] = $platform;
            $inputs['userBooking'] = $userBooking;
            $inputs['paymentProvider'] = $provider;
            $inputs['transactionId'] = $transactionId;
            $inputs['pspTransactionId'] = $pspTransactionId;
            $paymentProcessor = $this->paymentFactory->createProcessor($platform, $provider);
            try {
                $paymentResult = $paymentProcessor->getPaymentResult($inputs);
                switch ($provider) {
                    case  PaymentConst::PAYMENT_PROVIDER['ZALO_PAY']: {
                        if ($paymentResult['return_code'] == Payment::ZALO_PAY_RETURN_CODE['SUCCESS'] && $paymentResult['sub_return_code'] == Payment::ZALO_PAY_SUB_RETURN_CODE['SUCCESSFUL']) {
                            return [$userBookingSn, $paymentProviderStr, '+', '-'];
                        } elseif ($paymentResult['return_code'] == Payment::ZALO_PAY_RETURN_CODE['PROCESSING'] && $paymentResult['sub_return_code'] == Payment::ZALO_PAY_SUB_RETURN_CODE['EXCEPTION']) {
                            return [$userBookingSn, $paymentProviderStr, '-', '+'];
                        }
                    }
                    case PaymentConst::PAYMENT_PROVIDER['EPAY']: {
                            if ($paymentResult->resultCd == EpayConst::RETURN_CODE['SUCCESS']) {
                                if ($paymentResult->data->resultCd == EpayConst::RETURN_CODE['SUCCESS'] && in_array($paymentResult->data->status,
                                        [EpayConst::STATUS['SUCCESS'], EpayConst::STATUS['REFUNDED']])) {
                                    return [$userBookingSn, $paymentProviderStr, '+', '-'];
                                } else {
                                    return [$userBookingSn, $paymentProviderStr, '-', '+'];
                                }
                            }
                        }
                        break;
                }

            } catch (Exception $exception) {
            }
        }

    }

    /**
     * @param array|collection $data
     *
     * @return Generator
     */
    private function _reportsGenerator($data)
    {
        foreach ($data as $key => $value) {
            yield $this->_sheetOneFormatting($key, $value);
        }
    }

    /**
     * @param int $index
     * @param stdClass $item
     *
     * @return stdClass
     */
    private function _sheetOneFormatting($index, $item)
    {
        $object = new stdClass();
        $object->{'#'} = $item[0];
        $object->{'USER_BOOKING_SN'} = $item[1];
        $object->{'Payment Provider'} = $item[2];
        $object->{'Paid'} = $item[3] === '+' ? 1 : 0;
        $object->{'Not Paid'} = $item[4] === '+' ? 1 : 0;

        return $object;
    }
}