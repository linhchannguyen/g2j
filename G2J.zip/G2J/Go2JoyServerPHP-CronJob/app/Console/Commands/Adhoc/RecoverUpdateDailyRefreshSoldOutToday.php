<?php

namespace App\Console\Commands\Adhoc;

use App\Constants\Globals\QueueName as QueueNameConst;
use App\Helpers\LoggingHelper;
use App\Jobs\Background\RefreshHotelSoldOutTodayJob;
use App\Models\Hotel;
use App\Models\RoomSetting;
use App\Models\RoomType;
use App\Repositories\Interfaces\HotelRepositoryInterface;
use App\Repositories\Interfaces\RoomSettingRepositoryInterface;
use App\Repositories\Interfaces\RoomTypeRepositoryInterface;
use Exception;
use Illuminate\Console\Command;
use Illuminate\Support\Carbon;

class RecoverUpdateDailyRefreshSoldOutToday extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'adhoc:recover-update-daily-refresh-sold-out-today
                            {dateTime}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Recover update daily refresh sold out today';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @param RoomTypeRepositoryInterface $roomTypeRepository
     * @param RoomSettingRepositoryInterface $roomSettingRepository
     * @param HotelRepositoryInterface $hotelRepository
     */
    public function handle(
        RoomTypeRepositoryInterface $roomTypeRepository,
        RoomSettingRepositoryInterface $roomSettingRepository,
        HotelRepositoryInterface $hotelRepository
    ) {
        $dateTime = Carbon::parse($this->argument('dateTime'));
        LoggingHelper::logFunction('START JOB: RECOVER UPDATE DAILY REFRESH SOLD OUT TODAY');
        try {
            $roomSettingList = $roomSettingRepository->findWhere([
                [RoomSetting::COL_SOLD_OUT_TIME, '<', $dateTime]
            ], [RoomSetting::COL_ROOM_TYPE_SN]);

            if (!$roomSettingList->isEmpty()) {
                $roomTypeSnList = $roomSettingList->pluck(RoomSetting::COL_ROOM_TYPE_SN)->toArray();

                LoggingHelper::logFunction('START--recoverUpdateDailyRefreshSoldOutToday');
                $roomTypeRepository->recoverUpdateDailyRefreshSoldOutToday($roomTypeSnList);
                LoggingHelper::logFunction('END--recoverUpdateDailyRefreshSoldOutToday');

                LoggingHelper::logFunction('START--recoverRefreshHotelSoldOutTodayJob');
                LoggingHelper::logFunction('START--refreshHotelSoldOutTodayJob');

                $roomTypeList = $roomTypeRepository->findWhereIn(RoomType::COL_SN, $roomTypeSnList, [RoomType::COL_HOTEL_SN]);
                $hotelSnList = $roomTypeList->pluck(RoomType::COL_HOTEL_SN)->toArray();

                $hotelList = $hotelRepository->findWhereIn(Hotel::COL_SN, $hotelSnList, [Hotel::COL_SN, Hotel::COL_ORIGIN]);
                $hotelChunks = $hotelList->chunk(50);
                foreach ($hotelChunks as $hotelList) {
                    LoggingHelper::logFunction('refreshHotelSoldOutTodayJob - size', count($hotelList));
                    dispatch(new RefreshHotelSoldOutTodayJob($hotelList))->onQueue(QueueNameConst::BACK_GROUND);
                }

                LoggingHelper::logFunction('END--refreshHotelSoldOutTodayJob');
                LoggingHelper::logFunction('END--recoverRefreshHotelSoldOutTodayJob');
            }
        } catch (Exception $e) {
            LoggingHelper::logFunction('ERROR JOB: RECOVER UPDATE DAILY REFRESH SOLD OUT TODAY - ' . $e->getMessage());
        }
        LoggingHelper::logFunction( 'END JOB: RECOVER UPDATE DAILY DAILY REFRESH SOLD OUT TODAY');
    }
}