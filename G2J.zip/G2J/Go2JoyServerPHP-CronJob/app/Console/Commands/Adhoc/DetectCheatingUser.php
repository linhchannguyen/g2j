<?php

namespace App\Console\Commands\Adhoc;

use App\Constants\Globals\QueueName;
use App\Constants\UserBooking as UserBookingConst;
use App\Helpers\UploadHelper;
use App\Jobs\Mail\SendExportFileMailJob;
use App\Models\AppUser;
use App\Models\UserBooking;
use Box\Spout\Common\Exception\InvalidArgumentException;
use Box\Spout\Common\Exception\IOException;
use Box\Spout\Common\Exception\UnsupportedTypeException;
use Box\Spout\Writer\Exception\WriterNotOpenedException;
use Box\Spout\Writer\Style\StyleBuilder;
use Generator;
use Illuminate\Console\Command;
use Illuminate\Contracts\Filesystem\FileNotFoundException;
use Illuminate\Support\Carbon;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Storage;
use Rap2hpoutre\FastExcel\FastExcel;
use Rap2hpoutre\FastExcel\SheetCollection;
use stdClass;

class DetectCheatingUser extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'adhoc:detect-cheating-user
                            {--staffSnList=}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Detect cheating users';

    const NUM_OF_NEWEST_BOOKINGS = 3;
    const AVG_BOOKING_AMOUNT = 500000;
    const DEFAULT_STAFF_SN_RECEIVING_MAIL = 3662;

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return void
     * @throws IOException
     * @throws InvalidArgumentException
     * @throws UnsupportedTypeException
     * @throws WriterNotOpenedException
     * @throws FileNotFoundException
     */
    public function handle()
    {
        $staffSnList = $this->option('staffSnList') ? explode(',', $this->option('staffSnList')) : [];
        $staffSnList[] = self::DEFAULT_STAFF_SN_RECEIVING_MAIL;
        $startDate = Carbon::now()->subMonth()->toDateString();
        $appUserList = DB::table('USER_BOOKING')
            ->where('PAYMENT_PROVIDER', UserBookingConst::PAYMENT_PROVIDER['AT_HOTEL'])
            ->whereNotNull('APP_USER_SN')
            ->whereNotIn('BOOKING_STATUS', [UserBookingConst::BOOKING_STATUS['COMPLETED'], UserBookingConst::BOOKING_STATUS['RECEIVED']])
            ->whereDate('CHECK_IN_DATE_PLAN', '>=', $startDate)
            ->groupBy('APP_USER_SN')
            ->havingRaw('COUNT(SN) >= ' . self::NUM_OF_NEWEST_BOOKINGS)
            ->get('APP_USER_SN');

        $data = [];
        foreach ($appUserList as $appUser) {
            $appUserSn = $appUser->{UserBooking::COL_APP_USER_SN};
            $userBookingList = DB::table('USER_BOOKING as userBooking')
                ->join('APP_USER as appUser', function($join) {
                    $join->on('appUser.SN', '=', 'userBooking.APP_USER_SN');
                })
                ->where('userBooking.PAYMENT_PROVIDER', UserBookingConst::PAYMENT_PROVIDER['AT_HOTEL'])
                ->whereNotIn('userBooking.BOOKING_STATUS', [UserBookingConst::BOOKING_STATUS['COMPLETED'], UserBookingConst::BOOKING_STATUS['RECEIVED']])
                ->where('userBooking.APP_USER_SN', $appUserSn)
                ->orderByDesc('userBooking.SN')
                ->limit(self::NUM_OF_NEWEST_BOOKINGS)
                ->get([
                    'appUser.NICK_NAME',
                    'appUser.MOBILE',
                    'userBooking.APP_USER_SN',
                    'userBooking.BOOKING_NO',
                    'userBooking.AMOUNT_FROM_USER',
                    'userBooking.CHECK_IN_DATE_PLAN',
                ]);
            $avgBookingAmount = intval($userBookingList->avg('AMOUNT_FROM_USER'));
            if ($avgBookingAmount >= self::AVG_BOOKING_AMOUNT) {
                $_appUserSn = $userBookingList[0]->{UserBooking::COL_APP_USER_SN};
                $nickName = $userBookingList[0]->{AppUser::COL_NICK_NAME};
                $mobile = $userBookingList[0]->{AppUser::COL_MOBILE};
                $data[] = [
                    $_appUserSn,
                    $nickName,
                    $mobile,
                    $userBookingList[0]->{UserBooking::COL_BOOKING_NO},
                    $userBookingList[0]->{UserBooking::COL_AMOUNT_FROM_USER},
                    $userBookingList[0]->{UserBooking::COL_CHECK_IN_DATE_PLAN},
                    $userBookingList[1]->{UserBooking::COL_BOOKING_NO},
                    $userBookingList[1]->{UserBooking::COL_AMOUNT_FROM_USER},
                    $userBookingList[1]->{UserBooking::COL_CHECK_IN_DATE_PLAN},
                    $userBookingList[2]->{UserBooking::COL_BOOKING_NO},
                    $userBookingList[2]->{UserBooking::COL_AMOUNT_FROM_USER},
                    $userBookingList[2]->{UserBooking::COL_CHECK_IN_DATE_PLAN},
                    $avgBookingAmount,
                ];
            }
        }

        // Export Excel file and push send mail job
        $headerStyle = (new StyleBuilder())->setFontBold()->build();
        $sheetOne = 'DETECT CHEATING USER';
        $sheets = new SheetCollection([
            $sheetOne => $this->_reportsGenerator($data),
        ]);

        $createdAt = Carbon::now()->timestamp;
        $filePath = "/exports/detect-cheating-user/{$createdAt}.xlsx";
        $fullPath = Storage::disk('local')->path($filePath);
        // Check folder already exists or not, create if not exists
        $folder = storage_path('app/exports/detect-cheating-user/');
        if (!File::exists($folder)) {
            File::makeDirectory($folder, 0755, true, true);
        }
        (new FastExcel($sheets))
            ->headerStyle($headerStyle)
            ->export($fullPath);

        // Upload to S3
        $content = Storage::disk(UploadHelper::DISK_LOCAL)->get($filePath);
        UploadHelper::uploadFile($content, UploadHelper::FOLDER['UPLOAD'] . $filePath);

        // Finally, push job to send mail
        if (empty($userBookingSnList)) {
            $fileName = sprintf("DETECT_CHEATING_USER_%s.xlsx", now()->format('dmY'));
        } else {
            $fileName = 'DETECT_CHEATING_USER_REPORT.xlsx';
        }

        foreach ($staffSnList as $staffSn) {
            SendExportFileMailJob::dispatch($staffSn, $filePath, $fileName)->allOnConnection('redis')->allOnQueue(QueueName::EMAIL);
        }
    }

    /**
     * @param array|collection $data
     * @return Generator
     */
    private function _reportsGenerator($data)
    {
        foreach ($data as $key => $value) {
            yield $this->_sheetOneFormatting($key, $value);
        }
    }

    /**
     * @param int $index
     * @param stdClass $item
     * @return stdClass
     */
    private function _sheetOneFormatting($index, $item)
    {
        $object = new stdClass();
        $object->{'#'} = $index + 1;
        $object->{'APP USER SN'} = $item[0];
        $object->{'NICKNAME'} = $item[1];
        $object->{'PHONE NUMBER'} = $item[2];
        $object->{'BOOKING NO #1'} = $item[3];
        $object->{'BOOKING AMOUNT #1'} = $item[4];
        $object->{'CHECK IN DATE PLAN #1'} = $item[5];
        $object->{'BOOKING NO #2'} = $item[6];
        $object->{'BOOKING AMOUNT #2'} = $item[7];
        $object->{'CHECK IN DATE PLAN #2'} = $item[8];
        $object->{'BOOKING NO #3'} = $item[9];
        $object->{'BOOKING AMOUNT #3'} = $item[10];
        $object->{'CHECK IN DATE PLAN #3'} = $item[11];
        $object->{'AVERAGE BOOKING AMOUNT'} = $item[12];
        return $object;
    }
}
