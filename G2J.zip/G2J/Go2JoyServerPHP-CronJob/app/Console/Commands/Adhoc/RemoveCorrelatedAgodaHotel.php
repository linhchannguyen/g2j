<?php

namespace App\Console\Commands\Adhoc;

use App\Constants\Hotel as HotelConst;
use App\Constants\MongoDB\AgodaHotel as AgodaHotelConst;
use App\Models\CorrelatedHotel;
use App\Models\Hotel;
use App\Models\MongoDB\AgodaHotel;
use Illuminate\Console\Command;

class RemoveCorrelatedAgodaHotel extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'adhoc:remove-correlated-agoda-hotel
                            {--agodaHotelSn=}
                            {--go2joyHotelSn=}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Remove Agoda hotel correlated with Go2Joy hotel';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return void
     */
    public function handle(): void
    {
        $agodaHotelSn = $this->option('agodaHotelSn');
        $go2joyHotelSn = $this->option('go2joyHotelSn');
        if (empty($agodaHotelSn) || empty($go2joyHotelSn)) {
            $this->error('Some input value missing');
            return;
        }

        $numOfRecords = Hotel::where(Hotel::COL_SN, $agodaHotelSn)
            ->where(Hotel::COL_ORIGIN, HotelConst::ORIGIN['AGODA'])->first();
        if (empty($numOfRecords)) {
            $this->error('Input `agodaHotelSn` is invalid');
            return;
        }

        Hotel::where(Hotel::COL_SN, $agodaHotelSn)
        ->where(Hotel::COL_ORIGIN, HotelConst::ORIGIN['AGODA'])
        ->update([
            Hotel::COL_HOTEL_STATUS => HotelConst::STATUS['NO_STATUS'],
            Hotel::COL_DISPLAY      => HotelConst::DISPLAY['HIDE']
        ]);

        $agodaHotel = Hotel::where(Hotel::COL_SN, $agodaHotelSn)->first([
            Hotel::COL_PARTNER_HOTEL_ID
        ]);

        $partnerHotelId = intval($agodaHotel->{Hotel::COL_PARTNER_HOTEL_ID});
        $numOfRecords = AgodaHotel::where(AgodaHotel::FIELD_PARTNER_HOTEL_ID, $partnerHotelId)
            ->update([
                AgodaHotel::FIELD_STATUS => AgodaHotelConst::STATUS['INACTIVE']
            ]);
        if ($numOfRecords == 0) {
            $this->error('Input `agodaHotelSn` is invalid');
            return;
        }

        $hotel = new CorrelatedHotel();
        $hotel->{CorrelatedHotel::COL_HOTEL_SN} = $go2joyHotelSn;
        $hotel->{CorrelatedHotel::COL_AGODA_HOTEL_ID} = $partnerHotelId;
        $hotel->save();
    }
}
