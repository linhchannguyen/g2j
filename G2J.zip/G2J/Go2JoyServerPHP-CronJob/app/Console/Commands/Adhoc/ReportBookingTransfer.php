<?php

namespace App\Console\Commands\Adhoc;

use App\Constants\Globals\QueueName;
use App\Constants\Province as ProvinceConst;
use App\Constants\UserBooking as UserBookingConst;
use App\Constants\UserBookingTransfer as UserBookingTransferConst;
use App\Helpers\CommonHelper;
use App\Helpers\UploadHelper;
use App\Jobs\Mail\SendExportFileMailJob;
use App\Models\Hotel;
use App\Models\Province;
use App\Models\UserBooking;
use App\Models\UserBookingTransfer;
use Box\Spout\Common\Exception\InvalidArgumentException;
use Box\Spout\Common\Exception\IOException;
use Box\Spout\Common\Exception\UnsupportedTypeException;
use Box\Spout\Writer\Exception\WriterNotOpenedException;
use Box\Spout\Writer\Style\StyleBuilder;
use Generator;
use Illuminate\Console\Command;
use Illuminate\Contracts\Filesystem\FileNotFoundException;
use Illuminate\Support\Carbon;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Storage;
use Rap2hpoutre\FastExcel\FastExcel;
use Rap2hpoutre\FastExcel\SheetCollection;
use stdClass;

class ReportBookingTransfer extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'adhoc:report-booking-transfer
                            {--startDate=}
                            {--endDate=}
                            {--staffSnList=}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Report booking transfer';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return void
     * @throws IOException
     * @throws InvalidArgumentException
     * @throws UnsupportedTypeException
     * @throws WriterNotOpenedException
     * @throws FileNotFoundException
     */
    public function handle()
    {
        $staffSnList = $this->option('staffSnList') ? explode(',', $this->option('staffSnList')) : [];
        $startDate = $this->option('startDate');
        $endDate = $this->option('endDate');
        $userBookingList = DB::table('USER_BOOKING as userBooking')
            ->join('USER_BOOKING_TRANSFER as userBookingTransfer', 'userBooking.SN', '=', 'userBookingTransfer.USER_BOOKING_SN')
            ->join('HOTEL as hotel', 'hotel.SN', '=', 'userBooking.HOTEL_SN')
            ->join('PROVINCE as province', 'province.SN', '=', 'hotel.PROVINCE_SN')
            ->where('userBookingTransfer.STATUS', UserBookingTransferConst::STATUS['CONFIRM'])
            ->whereBetween('userBooking.CHECK_IN_DATE_PLAN', [$startDate, $endDate])
            ->get([
                'userBooking.BOOKING_NO',
                'hotel.NAME as HOTEL_NAME',
                'hotel.CODE as HOTEL_CODE',
                'province.REGIONS',
                'userBooking.CHECK_IN_DATE_PLAN',
                'userBooking.CHECK_IN_TIME',
                'userBooking.TYPE',
                'userBooking.START_TIME',
                'userBooking.END_TIME',
                'userBooking.END_DATE',
                'userBooking.HOTEL_SN',
                'userBookingTransfer.LAST_UPDATE',
            ]);

        $data = [];
        foreach ($userBookingList as $userBooking) {
            $bookingNo = $userBooking->{UserBooking::COL_BOOKING_NO};
            $hotelName = $userBooking->{Hotel::AS_NAME};
            $hotelCode = $userBooking->{Hotel::AS_CODE};
            $regionName = ProvinceConst::REGION_STR[$userBooking->{Province::COL_REGIONS}];
            $checkIn = CommonHelper::getBookingCheckinDateTime($userBooking);
            $checkOut = CommonHelper::getBookingCheckoutDateTime($userBooking);

            if (!Carbon::parse($checkOut)->between($checkIn, $checkOut)) {
                continue;
            }

            $transferTime = $userBooking->{UserBookingTransfer::COL_LAST_UPDATE};
            $data[] = [
                $bookingNo,
                $hotelName,
                $hotelCode,
                $regionName,
                $checkIn,
                $checkOut,
                $transferTime,
            ];
        }

        // Export Excel file and push send mail job
        $headerStyle = (new StyleBuilder())->setFontBold()->build();
        $sheetOne = 'REPORT BOOKING TRANSFER';
        $sheets = new SheetCollection([
            $sheetOne => $this->_reportsGenerator($data),
        ]);

        $createdAt = Carbon::now()->timestamp;
        $filePath = "/exports/report-booking-transfer/{$createdAt}.xlsx";
        $fullPath = Storage::disk('local')->path($filePath);
        // Check folder already exists or not, create if not exists
        $folder = storage_path('app/exports/report-booking-transfer/');
        if (!File::exists($folder)) {
            File::makeDirectory($folder, 0755, true, true);
        }
        (new FastExcel($sheets))
            ->headerStyle($headerStyle)
            ->export($fullPath);

        // Upload to S3
        $content = Storage::disk(UploadHelper::DISK_LOCAL)->get($filePath);
        UploadHelper::uploadFile($content, UploadHelper::FOLDER['UPLOAD'] . $filePath);

        // Finally, push job to send mail
        if (empty($userBookingSnList)) {
            $fileName = sprintf("REPORT_BOOKING_TRANSFER_%s.xlsx", now()->format('dmY'));
        } else {
            $fileName = 'REPORT_BOOKING_TRANSFER.xlsx';
        }

        foreach ($staffSnList as $staffSn) {
            SendExportFileMailJob::dispatch($staffSn, $filePath, $fileName)->allOnConnection('redis')->allOnQueue(QueueName::EMAIL);
        }
    }

    /**
     * @param array|collection $data
     * @return Generator
     */
    private function _reportsGenerator($data)
    {
        foreach ($data as $key => $value) {
            yield $this->_sheetOneFormatting($key, $value);
        }
    }

    /**
     * @param int $index
     * @param stdClass $item
     * @return stdClass
     */
    private function _sheetOneFormatting($index, $item)
    {
        $object = new stdClass();
        $object->{'#'} = $index + 1;
        $object->{'Booking No'} = $item[0];
        $object->{'Hotel Name'} = $item[1];
        $object->{'Hotel Code'} = $item[2];
        $object->{'Region'} = $item[3];
        $object->{'Check-in'} = $item[4];
        $object->{'Check-out'} = $item[5];
        $object->{'Transfer time'} = Carbon::parse($item[6])->toDateString();
        return $object;
    }
}
