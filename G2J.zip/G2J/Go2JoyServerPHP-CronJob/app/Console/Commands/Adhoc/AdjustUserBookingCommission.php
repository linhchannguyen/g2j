<?php

namespace App\Console\Commands\Adhoc;

use App\Constants\UserBooking as UserBookingConst;
use App\DTOs\Web\SA\UserBookingTransaction\GenerateUserBookingTransactionInputDTO;
use App\Helpers\ConvertHelper;
use App\Http\Resources\Web\SA\UserBookingResource;
use App\Jobs\Background\GenerateUserBookingTransactionJob;
use App\Models\UserBooking;
use App\Models\UserBookingTransaction;
use Box\Spout\Common\Exception\InvalidArgumentException;
use Box\Spout\Common\Exception\IOException;
use Box\Spout\Common\Exception\UnsupportedTypeException;
use Box\Spout\Writer\Exception\WriterNotOpenedException;
use Box\Spout\Writer\Style\StyleBuilder;
use Carbon\Carbon;
use Generator;
use Illuminate\Console\Command;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Rap2hpoutre\FastExcel\FastExcel;
use Rap2hpoutre\FastExcel\SheetCollection;
use stdClass;

class AdjustUserBookingCommission extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'adhoc:adjust-user-booking-commission
                            {--userBookingSnList=}
                            {--hotelSnList=}
                            {--staffSn=}
                            {--fromDate= : Based on CHECK_IN_TIME without time. If not exists, take all}
                            {--newCommission= : New Commission for User Booking}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Adjust Commission of User Booking (Recalculate HOTEL_REFUND and COMMISSION_AMOUNT)';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return void
     * @throws IOException
     * @throws InvalidArgumentException
     * @throws UnsupportedTypeException
     * @throws WriterNotOpenedException
     */
    public function handle()
    {
        $userBookingSnList = $this->option('userBookingSnList');
        $userBookingSnList = explode(',', $userBookingSnList);
        $userBookingSnList = array_filter($userBookingSnList);
        $userBookingSnList = array_map('intval', $userBookingSnList);

        $staffSn = $this->option('staffSn');
        if (empty($staffSn)) {
            $this->error('Command option `staffSn` is required!');
        }

        $newCommission = $this->option('newCommission');
        if (empty($newCommission)) {
            $this->error('Command option `newCommission` is required!');
        }
        $coefficientCommission = intval($newCommission) / 100;

        $hotelSnList = $this->option('hotelSnList');
        $hotelSnList = explode(',', $hotelSnList);
        $hotelSnList = array_filter($hotelSnList);
        $hotelSnList = array_map('intval', $hotelSnList);

        $fromDate = $this->option('fromDate');

        if (empty($hotelSnList)) {
            if (!empty($userBookingSnList)) {
                $queryStatement = DB::table(UserBooking::TABLE_NAME)
                    ->whereIn(UserBooking::COL_SN, $userBookingSnList)
                    ->where(UserBooking::COL_BOOKING_STATUS, UserBookingConst::BOOKING_STATUS['CHECK-IN']);

                if (!empty($fromDate)) {
                    $queryStatement->whereDate(UserBooking::COL_CHECK_IN_TIME, '>=', $fromDate);
                }

                $queryStatement->havingRaw('COMMISSION_AMOUNT != NEW_COMMISSION_AMOUNT');
                $queryStatement->select([
                    'SN',
                    'CHECK_IN_TIME',
                    'TOTAL_AMOUNT',
                    'FS_HOTEL_DISCOUNT',
                    'REDEEM_VALUE',
                    'DIRECT_DISCOUNT',
                    'HOTEL_DISCOUNT',
                    'COMMISSION_AMOUNT',
                    'COMMISSION_PRODUCT_AMOUNT',
                    DB::raw("CAST((TOTAL_AMOUNT - FS_HOTEL_DISCOUNT - REDEEM_VALUE - DIRECT_DISCOUNT - HOTEL_DISCOUNT) * $coefficientCommission AS UNSIGNED) as NEW_COMMISSION_AMOUNT"),
                    'HOTEL_REFUND',
                    DB::raw("CAST(
                        (
                            ((TOTAL_AMOUNT - FS_HOTEL_DISCOUNT - REDEEM_VALUE - DIRECT_DISCOUNT - HOTEL_DISCOUNT) * 0.15) + COMMISSION_PRODUCT_AMOUNT
                        ) 
                        -
                        (PREPAY_AMOUNT + GO2JOY_DISCOUNT + SPONSOR_DISCOUNT + MILEAGE_POINT)
                    AS SIGNED) as NEW_HOTEL_REFUND")
                ]);

                $_userBookingList = $queryStatement->get();

                $this->_recordHistoryValue($_userBookingList);

                foreach ($_userBookingList as $_userBooking) {
                    $sn = $_userBooking->{UserBooking::COL_SN};
                    $oldData = UserBooking::where(UserBooking::COL_SN, $sn)->first();
                    $newCommissionAmount = $_userBooking->{'NEW_COMMISSION_AMOUNT'};
                    $newHotelRefund = $_userBooking->{'NEW_HOTEL_REFUND'};
                    UserBooking::where(UserBooking::COL_SN, $sn)
                        ->update([
                            UserBooking::COL_COMMISSION_AMOUNT => $newCommissionAmount,
                            UserBooking::COL_HOTEL_REFUND => $newHotelRefund,
                        ]);

                    $userBookingTransaction = UserBookingTransaction::where(UserBookingTransaction::COL_USER_BOOKING_SN, $sn)->first();
                    if (!empty($userBookingTransaction)) {
                        $newData = UserBooking::where(UserBooking::COL_SN, $sn)->first();
                        $transferTime = Carbon::now()->toDateTimeString();
                        $oldData = ConvertHelper::toJson(UserBookingResource::toForm($oldData));
                        $newData = ConvertHelper::toJson(UserBookingResource::toForm($newData));
                        $generateUserBookingTransactionInputDTO = GenerateUserBookingTransactionInputDTO::setProperty($sn, $oldData, $newData, $staffSn, $transferTime);
                        GenerateUserBookingTransactionJob::dispatchNow($generateUserBookingTransactionInputDTO)->onConnection('sync');
                    } else {
                        // Don't have transaction yet but exceed 15 days (from 01 to 16 and from 16 to 30 or 31) already calculate revenue,
                        // so we're need create the transaction too
                        $_fromDate = Carbon::parse($fromDate);
                        $now = Carbon::now();
                        if ($_fromDate->diffInDays($now) > 15) {
                            $newData = UserBooking::where(UserBooking::COL_SN, $sn)->first();
                            $transferTime = Carbon::now()->toDateTimeString();
                            $oldData = ConvertHelper::toJson(UserBookingResource::toForm($oldData));
                            $newData = ConvertHelper::toJson(UserBookingResource::toForm($newData));
                            $generateUserBookingTransactionInputDTO = GenerateUserBookingTransactionInputDTO::setProperty($sn, $oldData, $newData, $staffSn, $transferTime);
                            GenerateUserBookingTransactionJob::dispatchNow($generateUserBookingTransactionInputDTO)->onConnection('sync');
                        }
                    }
                }
            }
        } else {
            foreach ($hotelSnList as $hotelSn) {
                $queryStatement = DB::table(UserBooking::TABLE_NAME)
                    ->where(UserBooking::COL_HOTEL_SN, $hotelSn)
                    ->where(UserBooking::COL_BOOKING_STATUS, UserBookingConst::BOOKING_STATUS['CHECK-IN']);

                if (!empty($fromDate)) {
                    $queryStatement->whereDate(UserBooking::COL_CHECK_IN_TIME, '>=', $fromDate);
                }

                $queryStatement->havingRaw('COMMISSION_AMOUNT != NEW_COMMISSION_AMOUNT');
                $queryStatement->select([
                    'SN',
                    'CHECK_IN_TIME',
                    'TOTAL_AMOUNT',
                    'FS_HOTEL_DISCOUNT',
                    'REDEEM_VALUE',
                    'DIRECT_DISCOUNT',
                    'HOTEL_DISCOUNT',
                    'COMMISSION_AMOUNT',
                    'COMMISSION_PRODUCT_AMOUNT',
                    DB::raw("CAST((TOTAL_AMOUNT - FS_HOTEL_DISCOUNT - REDEEM_VALUE - DIRECT_DISCOUNT - HOTEL_DISCOUNT) * $coefficientCommission AS UNSIGNED) as NEW_COMMISSION_AMOUNT"),
                    'HOTEL_REFUND',
                    DB::raw("CAST(
                        (
                            ((TOTAL_AMOUNT - FS_HOTEL_DISCOUNT - REDEEM_VALUE - DIRECT_DISCOUNT - HOTEL_DISCOUNT) * 0.15) + COMMISSION_PRODUCT_AMOUNT
                        ) 
                        -
                        (PREPAY_AMOUNT + GO2JOY_DISCOUNT + SPONSOR_DISCOUNT + MILEAGE_POINT)
                    AS SIGNED) as NEW_HOTEL_REFUND")
                ]);

                $userBookingList = $queryStatement->get();

                $this->_recordHistoryValue($userBookingList);

                foreach ($userBookingList as $userBooking) {
                    $sn = $userBooking->{UserBooking::COL_SN};
                    $oldData = UserBooking::where(UserBooking::COL_SN, $sn)->first();
                    $newCommissionAmount = $userBooking->{'NEW_COMMISSION_AMOUNT'};
                    $newHotelRefund = $userBooking->{'NEW_HOTEL_REFUND'};
                    UserBooking::where(UserBooking::COL_SN, $sn)
                        ->update([
                            UserBooking::COL_COMMISSION_AMOUNT => $newCommissionAmount,
                            UserBooking::COL_HOTEL_REFUND => $newHotelRefund,
                        ]);

                    $userBookingTransaction = UserBookingTransaction::where(UserBookingTransaction::COL_USER_BOOKING_SN, $sn)->first();
                    if (!empty($userBookingTransaction)) {
                        $newData = UserBooking::where(UserBooking::COL_SN, $sn)->first();
                        $transferTime = Carbon::now()->toDateTimeString();
                        $oldData = ConvertHelper::toJson(UserBookingResource::toForm($oldData));
                        $newData = ConvertHelper::toJson(UserBookingResource::toForm($newData));
                        $generateUserBookingTransactionInputDTO = GenerateUserBookingTransactionInputDTO::setProperty($sn, $oldData, $newData, $staffSn, $transferTime);
                        GenerateUserBookingTransactionJob::dispatchNow($generateUserBookingTransactionInputDTO);
                    } else {
                        // Don't have transaction yet but exceed 15 days (from 01 to 16 and from 16 to 30 or 31) already calculate revenue,
                        // so we're need create the transaction too
                        $_fromDate = Carbon::parse($fromDate);
                        $now = Carbon::now();
                        if ($_fromDate->diffInDays($now) > 15) {
                            $newData = UserBooking::where(UserBooking::COL_SN, $sn)->first();
                            $transferTime = Carbon::now()->toDateTimeString();
                            $oldData = ConvertHelper::toJson(UserBookingResource::toForm($oldData));
                            $newData = ConvertHelper::toJson(UserBookingResource::toForm($newData));
                            $generateUserBookingTransactionInputDTO = GenerateUserBookingTransactionInputDTO::setProperty($sn, $oldData, $newData, $staffSn, $transferTime);
                            GenerateUserBookingTransactionJob::dispatchNow($generateUserBookingTransactionInputDTO);
                        }
                    }
                }
            }
        }
        $this->info("Done.");
    }

    /**
     * Record history value before update of user booking for logging
     *
     * @param array|Collection $userBookingList
     *
     * @return void
     * @throws IOException
     * @throws InvalidArgumentException
     * @throws UnsupportedTypeException
     * @throws WriterNotOpenedException
     */
    private function _recordHistoryValue($userBookingList)
    {
        // check folder is exists before exporting the file
        $folderPath = 'exports/adhoc/';
        $isExists = Storage::exists($folderPath);
        if (!$isExists) {
            Storage::disk('local')->makeDirectory('exports/adhoc/');
        }

        $filePath = sprintf("exports/adhoc/AdjustUserBookingCommission_%s.%s-%s.xlsx", now()->hour, now()->minute, now()->format('dmY'));
        $fullPath = Storage::disk('local')->path($filePath);
        $headerStyle = (new StyleBuilder())->setFontBold()->build();

        $sheet = new SheetCollection([$this->_userBookingsGenerator($userBookingList)]);

        (new FastExcel($sheet))->headerStyle($headerStyle)->export($fullPath);
    }

    /**
     * @param array|collection $data
     *
     * @return Generator
     */
    private function _userBookingsGenerator($data)
    {
        foreach ($data as $key => $value) {
            yield $this->_sheetOneFormatting($key, $value);
        }
    }

    /**
     * @param int $index
     * @param stdClass $item
     * @return stdClass
     */
    private function _sheetOneFormatting($index, $item)
    {
        $object = new stdClass();
        $object->{'#'} = $index + 1;
        $object->{'SN'} = $item->{UserBooking::COL_SN};
        $object->{'CHECK_IN_TIME'} = $item->{UserBooking::COL_CHECK_IN_TIME};
        $object->{'TOTAL_AMOUNT'} = $item->{UserBooking::COL_TOTAL_AMOUNT};
        $object->{'FS_HOTEL_DISCOUNT'} = $item->{UserBooking::COL_FS_HOTEL_DISCOUNT};
        $object->{'REDEEM_VALUE'} = $item->{UserBooking::COL_REDEEM_VALUE};
        $object->{'DIRECT_DISCOUNT'} = $item->{UserBooking::COL_DIRECT_DISCOUNT};
        $object->{'HOTEL_DISCOUNT'} = $item->{UserBooking::COL_HOTEL_DISCOUNT};
        $object->{'COMMISSION_AMOUNT'} = $item->{UserBooking::COL_COMMISSION_AMOUNT};
        $object->{'COMMISSION_PRODUCT_AMOUNT'} = $item->{UserBooking::COL_COMMISSION_PRODUCT_AMOUNT};
        $object->{'NEW_COMMISSION_AMOUNT'} = $item->{'NEW_COMMISSION_AMOUNT'};
        $object->{'HOTEL_REFUND'} = $item->{UserBooking::COL_HOTEL_REFUND};
        $object->{'NEW_HOTEL_REFUND'} = $item->{'NEW_HOTEL_REFUND'};

        return $object;
    }

}
