<?php

namespace App\Console\Commands\Adhoc;

use App\Constants\MileageHistory as MileageHistoryConst;
use App\Constants\StampIssued as StampIssuedConst;
use App\Constants\UserBooking as UserBookingConst;
use App\Exceptions\ServiceException;
use App\Models\MileageHistory;
use App\Models\StampIssued;
use App\Models\UserBooking;
use App\Repositories\Interfaces\ReferralProgramHistoryRepositoryInterface;
use App\Services\Web\SA\UserBookingService;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Artisan;

class AmendBooking extends Command
{
    const ACTION_LIST = [
        'NO_SHOW' => 1,
    ];

    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'adhoc:amend-booking
                            {--bookingNo=}
                            {--action= : 1: NoShow}
                            {--reason=}
                            {--staffSn=}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Amend booking';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return void
     * @throws ServiceException
     */
    public function handle(ReferralProgramHistoryRepositoryInterface $referralProgramHistoryRepository)
    {
        $bookingNo = $this->option('bookingNo');
        $action = $this->option('action');
        $reason = $this->option('reason');
        $staffSn = $this->option('staffSn');
        if (empty($bookingNo) || empty($action) || empty($reason) || empty($staffSn)) {
            $this->error('Some input value missing');
            return;
        }

        $userBooking = UserBooking::where(UserBooking::COL_BOOKING_NO, $bookingNo)->first();
        if (empty($userBooking)) {
            $this->error('Invalid booking!');
            return;
        }
        $userBookingSn = $userBooking->{UserBooking::COL_SN};
        $bookingStatus = $userBooking->{UserBooking::COL_BOOKING_STATUS};
        $viaObject = $userBooking->{UserBooking::COL_VIA_OBJECT};
        $checkInTime = $userBooking->{UserBooking::COL_CHECK_IN_TIME};
        $report = $userBooking->{UserBooking::COL_REPORT};
        $bookingActionHistorySn = $userBooking->{UserBooking::COL_BOOKING_ACTION_HISTORY_SN};

        $isExists = StampIssued::where(StampIssued::COL_USER_BOOKING_SN, $userBooking->{UserBooking::COL_SN})
            ->where(StampIssued::COL_STATUS, StampIssuedConst::STATUS['ACTIVE'])
            ->exists();
        if ($isExists) {
            $this->error('Can\'t action on booking had received stamp!');
            return;
        }
        if ($userBooking->{UserBooking::COL_REDEEM_VALUE} > 0) {
            $this->error('Can\'t action on booking have redeem value!');
            return;
        }
        if (!empty($userBooking->{UserBooking::COL_APP_USER_SN})) {
            $referralProgramHistory = $referralProgramHistoryRepository->findByRefereeUserSnAndUserBookingSn($userBooking->{UserBooking::COL_APP_USER_SN}, $userBookingSn);
            if (!empty($referralProgramHistory)) {
                $this->error('Can\'t action on booking have referral program!');
                return;
            }
        }

        $isExists = MileageHistory::where(MileageHistory::COL_USER_BOOKING_SN, $userBooking->{UserBooking::COL_SN})
            ->where(MileageHistory::COL_TYPE, '!=', MileageHistoryConst::TYPE['GET'])
            ->exists();
        $paymentProvider = $userBooking->{UserBooking::COL_PAYMENT_PROVIDER};
        if ($isExists && $paymentProvider != UserBookingConst::PAYMENT_PROVIDER['AT_HOTEL']) {
            $this->error('Can\'t action on booking had received and used mileage point with pay in advance!');
            return;
        }
        if (!empty($userBooking->{UserBooking::COL_FLASH_SALE_HISTORY_SN})) {
            $this->error('Can\'t action on FlashSale booking!');
            return;
        }

        switch($action) {
            case self::ACTION_LIST['NO_SHOW']: {
                /** @var UserBookingService $userBookingService */
                $userBookingService = app(UserBookingService::class);
                $userBookingService->updateNoShowBooking($userBookingSn, $staffSn, $reason, null, true);
            }
        }

        $command = GenerateAdjustedBookingTransactions::class;
        $params = [
            '--staffSn'                => $staffSn,
            '--bookingNo'              => $bookingNo,
            '--bookingStatus'          => $bookingStatus,
            '--viaObject'              => $viaObject,
            '--checkInTime'            => $checkInTime,
            '--report'                 => $report,
            '--bookingActionHistorySn' => $bookingActionHistorySn,
        ];
        Artisan::call($command, $params);
        Artisan::output();
    }
}
