<?php

namespace App\Console\Commands\Adhoc;

use App\Constants\BookingActionHistory as BookingActionHistoryConst;
use App\Constants\Globals\QueueName;
use App\Constants\Staff as StaffConst;
use App\Constants\UserBooking as UserBookingConst;
use App\Helpers\UploadHelper;
use App\Jobs\Mail\SendExportFileMailJob;
use App\Models\AppUser;
use App\Models\BookingActionHistory;
use App\Models\BookingStatusHistory;
use App\Models\Hotel;
use App\Models\UserBooking;
use Box\Spout\Common\Exception\InvalidArgumentException;
use Box\Spout\Common\Exception\IOException;
use Box\Spout\Common\Exception\UnsupportedTypeException;
use Box\Spout\Writer\Exception\WriterNotOpenedException;
use Box\Spout\Writer\Style\StyleBuilder;
use Generator;
use Illuminate\Console\Command;
use Illuminate\Contracts\Filesystem\FileNotFoundException;
use Illuminate\Support\Carbon;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Storage;
use Rap2hpoutre\FastExcel\FastExcel;
use Rap2hpoutre\FastExcel\SheetCollection;
use stdClass;

class ReportBookingAutocomplete extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'adhoc:report-booking-autocomplete
                            {--startDate=}
                            {--endDate=}
                            {--hotelSnList=12650,817}
                            {--staffSnList=3662,8675}
                            {--phase=}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Report booking autocomplete';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return void
     * @throws IOException
     * @throws InvalidArgumentException
     * @throws UnsupportedTypeException
     * @throws WriterNotOpenedException
     * @throws FileNotFoundException
     */
    public function handle()
    {
        $phase = $this->option('phase');
        if (empty($phase)) {
            $this->error('The "--phase" option is required!');
            return;
        }
        switch ($phase) {
            case 1: {
                $startDate = Carbon::now()->firstOfMonth()->toDateTimeString();
                $endDate = Carbon::parse($startDate)->format('Y-m-14 23:59:59');
                break;
            }
            case 2: {
                $startDate = Carbon::now()->format('Y-m-15 00:00:00');
                $endDate = Carbon::now()->lastOfMonth()->format('Y-m-d 23:59:59');
                break;
            }
            default: $this->error('The "--phase" option value is invalid!'); return;
        }
        $staffSnList = $this->option('staffSnList') ? explode(',', $this->option('staffSnList')) : [];
        $hotelSnList = $this->option('hotelSnList') ? explode(',', $this->option('hotelSnList')) : [];
        $table = DB::table('USER_BOOKING as userBooking')
            ->join('HOTEL as hotel', 'hotel.SN', '=', 'userBooking.HOTEL_SN')
            ->join('PROVINCE as province', 'province.SN', '=', 'hotel.PROVINCE_SN')
            ->join('APP_USER as appUser', 'appUser.SN', '=', 'userBooking.APP_USER_SN')
            ->where('userBooking.BOOKING_STATUS', UserBookingConst::BOOKING_STATUS['COMPLETED'])
            ->where('userBooking.VIA_OBJECT', UserBookingConst::VIA_OBJECT['SYSTEM'])
            ->whereBetween('userBooking.CHECK_IN_DATE_PLAN', [$startDate, $endDate])
            ->select([
                'userBooking.SN',
                'userBooking.BOOKING_NO',
                'hotel.NAME as HOTEL_NAME',
                'hotel.CODE as HOTEL_CODE',
                'userBooking.CREATE_TIME',
                'userBooking.CHECK_IN_DATE_PLAN',
                'appUser.MOBILE',
                'appUser.USER_ID',
            ]);

        if (!empty($hotelSnList)) {
            $table->whereIn('userBooking.HOTEL_SN', $hotelSnList);
        }

        $userBookingList = $table->get();

        $data = [];
        foreach ($userBookingList as $userBooking) {
            $isExistsActionFromGo2JoyStaff = BookingActionHistory::where(BookingActionHistory::COL_USER_BOOKING_SN, $userBooking->{UserBooking::COL_SN})
                ->whereIn(BookingActionHistory::COL_ACTION_USER_TYPE, [
                    BookingActionHistoryConst::ACTION_USER_TYPE['GO2JOY_STAFF'],
                    BookingActionHistoryConst::ACTION_USER_TYPE['HOTEL_STAFF']
                ])
                ->exists();

            $isExistsActionFromHotelStaff = BookingStatusHistory::where(BookingStatusHistory::COL_USER_BOOKING_SN, $userBooking->{UserBooking::COL_SN})
                ->where(BookingStatusHistory::COL_ACTION_BY, '!=', StaffConst::SYSTEM)
                ->exists();

            if ($isExistsActionFromGo2JoyStaff || $isExistsActionFromHotelStaff) {
                continue;
            }

            $bookingNo = $userBooking->{UserBooking::COL_BOOKING_NO};
            $hotelName = $userBooking->{Hotel::AS_NAME};
            $hotelCode = $userBooking->{Hotel::AS_CODE};
            $createTime = $userBooking->{UserBooking::COL_CREATE_TIME};
            $checkInDatePlan = $userBooking->{UserBooking::COL_CHECK_IN_DATE_PLAN};
            $userId = $userBooking->{AppUser::COL_USER_ID};
            $mobile = $userBooking->{AppUser::COL_MOBILE};

            $data[] = [
                $bookingNo,
                $hotelName,
                $hotelCode,
                $createTime,
                $checkInDatePlan,
                $userId,
                $mobile,
            ];
        }

        // Export Excel file and push send mail job
        $headerStyle = (new StyleBuilder())->setFontBold()->build();
        $sheetOne = 'REPORT BOOKING AUTOCOMPLETE';
        $sheets = new SheetCollection([
            $sheetOne => $this->_reportsGenerator($data),
        ]);

        $createdAt = Carbon::now()->timestamp;
        $filePath = "/exports/report-booking-autocomplete/{$createdAt}.xlsx";
        $fullPath = Storage::disk('local')->path($filePath);
        // Check folder already exists or not, create if not exists
        $folder = storage_path('app/exports/report-booking-autocomplete/');
        if (!File::exists($folder)) {
            File::makeDirectory($folder, 0755, true, true);
        }
        (new FastExcel($sheets))
            ->headerStyle($headerStyle)
            ->export($fullPath);

        // Upload to S3
        $content = Storage::disk(UploadHelper::DISK_LOCAL)->get($filePath);
        UploadHelper::uploadFile($content, UploadHelper::FOLDER['UPLOAD'] . $filePath);

        // Finally, push job to send mail
        if (empty($userBookingSnList)) {
            $fileName = sprintf("REPORT_BOOKING_AUTOCOMPLETE_%s.xlsx", now()->format('dmY'));
        } else {
            $fileName = 'REPORT_BOOKING_AUTOCOMPLETE_.xlsx';
        }

        foreach ($staffSnList as $staffSn) {
            SendExportFileMailJob::dispatch($staffSn, $filePath, $fileName)->allOnConnection('redis')->allOnQueue(QueueName::EMAIL);
        }
    }

    /**
     * @param array|collection $data
     *
     * @return Generator
     */
    private function _reportsGenerator($data)
    {
        foreach ($data as $key => $value) {
            yield $this->_sheetOneFormatting($key, $value);
        }
    }

    /**
     * @param int $index
     * @param stdClass $item
     *
     * @return stdClass
     */
    private function _sheetOneFormatting($index, $item)
    {
        $object = new stdClass();
        $object->{'#'} = $index + 1;
        $object->{'Booking No'} = $item[0];
        $object->{'Hotel Name'} = $item[1];
        $object->{'Hotel Code'} = $item[2];
        $object->{'Booking Time'} = $item[3];
        $object->{'Check In Date Plan'} = Carbon::parse($item[4])->toDateString();
        $object->{'User ID'} = $item[5];
        $object->{'Phone Number'} = $item[6];

        return $object;
    }
}
