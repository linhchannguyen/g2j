<?php

namespace App\Console\Commands\Adhoc;

use App\Constants\Hotel as HotelConst;
use App\Constants\MileageHistory as MileageHistoryConst;
use App\Constants\StampIssued as StampIssuedConst;
use App\Constants\UserBooking as UserBookingConst;
use App\Exceptions\ServiceException;
use App\Models\Hotel;
use App\Models\MileageHistory;
use App\Models\StampIssued;
use App\Models\UserBooking;
use App\Repositories\Interfaces\ReferralProgramHistoryRepositoryInterface;
use App\Services\Web\SA\UserBookingService;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Artisan;

class CancelAgodaBooking extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'adhoc:cancel-agoda-booking
                            {--bookingNo=}
                            {--reason=}
                            {--staffSn=}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Cancel Agoda Booking';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return void
     * @throws ServiceException
     */
    public function handle(ReferralProgramHistoryRepositoryInterface $referralProgramHistoryRepository)
    {
        $bookingNo = $this->option('bookingNo');
        $reason = $this->option('reason');
        $staffSn = $this->option('staffSn');
        if (empty($bookingNo) || empty($reason) || empty($staffSn)) {
            $this->error('Some input value missing');
            return;
        }

        $userBooking = UserBooking::where(UserBooking::COL_BOOKING_NO, $bookingNo)
            ->first([
                UserBooking::COL_SN,
                UserBooking::COL_HOTEL_SN,
            ]);

        $hotelSn = $userBooking->{UserBooking::COL_HOTEL_SN};
        $hotel = Hotel::where(Hotel::COL_SN, $hotelSn)->first([Hotel::COL_ORIGIN]);
        $origin = $hotel->{Hotel::COL_ORIGIN};

        if (empty($userBooking) || $origin != HotelConst::ORIGIN['AGODA']) {
            $this->error('Invalid booking!');
            return;
        }

        /** @var UserBookingService $userBookingService */
        $userBookingService = app(UserBookingService::class);
        $userBookingSn = $userBooking->{UserBooking::COL_SN};
        $reasonCancelSn = config('go2joy.booking_cancel_reason_sn_other_reason_by_go2joy');
        $userBookingService->cancelBooking($userBookingSn, $staffSn, false, $reasonCancelSn, $reason);
        $this->error('Done.');
    }
}
