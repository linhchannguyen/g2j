<?php

namespace App\Console\Commands\Adhoc;

use App\Constants\Hotel as HotelConst;
use App\Constants\Role as RoleConst;
use App\Models\HotelGroup;
use App\Models\Staff;
use Box\Spout\Common\Exception\InvalidArgumentException;
use Box\Spout\Common\Exception\IOException;
use Box\Spout\Common\Exception\UnsupportedTypeException;
use Box\Spout\Writer\Exception\WriterNotOpenedException;
use Box\Spout\Writer\Style\StyleBuilder;
use Generator;
use Illuminate\Console\Command;
use Illuminate\Contracts\Filesystem\FileNotFoundException;
use Illuminate\Support\Carbon;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Storage;
use Rap2hpoutre\FastExcel\FastExcel;
use Rap2hpoutre\FastExcel\SheetCollection;
use stdClass;

class GetAdminStaffOfHotelGroup extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'adhoc:get-admin-staff-of-hotel-group';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Get Admin staff of Hotel Group';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return void
     * @throws IOException
     * @throws InvalidArgumentException
     * @throws UnsupportedTypeException
     * @throws WriterNotOpenedException
     * @throws FileNotFoundException
     */
    public function handle()
    {
        $staffList = DB::table('STAFF as staff')
            ->join('HOTEL as hotel', 'hotel.SN', '=', 'staff.HOTEL_SN')
            ->leftJoin('HOTEL_GROUP as hotelGroup', 'hotelGroup.SN', '=', 'hotel.HOTEL_GROUP_SN')
            ->where('hotel.HOTEL_STATUS', [HotelConst::STATUS['CONTRACTED']])
            ->whereNotNull('hotel.HOTEL_GROUP_SN')
            ->where('staff.HOTEL_SN', '!=', HotelConst::GO2JOY)
            ->whereNotExists(function ($query) {
                $query->select(DB::raw(1))
                    ->from('STAFF as _staff')
                    ->whereRaw('_staff.HOTEL_SN = staff.HOTEL_SN')
                    ->where('_staff.HOTEL_SN', '!=', HotelConst::GO2JOY)
                    ->where('_staff.ROLE_SN', '=', RoleConst::HOTEL_ADMIN);
            })
            ->groupBy('staff.HOTEL_SN')
            ->get([
                'staff.HOTEL_SN',
                'hotelGroup.SN as HOTEL_GROUP_SN',
                'hotelGroup.NAME as HOTEL_GROUP_NAME'
            ]);

        $data = [];
        $hotelGroupSnList = [];
        foreach ($staffList as $staff) {
            $hotelSn = $staff->{Staff::COL_HOTEL_SN};
            $hotelGroupSn = $staff->{HotelGroup::AS_HOTEL_GROUP_SN};

            if (in_array($hotelGroupSn, $hotelGroupSnList)) {
                continue;
            }

            $hotelGroupName = $staff->{HotelGroup::AS_HOTEL_GROUP_NAME};
            $adminStaff = DB::table('STAFF as staff')
                ->join('HOTEL as hotel', 'hotel.SN', '=', 'staff.HOTEL_SN')
                ->join('HOTEL_GROUP as hotelGroup', 'hotelGroup.SN', '=', 'hotel.HOTEL_GROUP_SN')
                ->where('hotelGroup.SN', $hotelGroupSn)
                ->where('staff.ROLE_SN', RoleConst::HOTEL_ADMIN)
                ->select([
                    'staff.FULL_NAME',
                    'staff.EMAIL',
                    'staff.MOBILE',
                ])
                ->first();

            if (!empty($adminStaff)) {
                $data[] = [
                    $adminStaff->{Staff::COL_FULL_NAME},
                    $adminStaff->{Staff::COL_EMAIL},
                    $adminStaff->{Staff::COL_MOBILE},
                    $hotelGroupName,
                ];

                $hotelGroupSnList[] = $hotelGroupSn;
            }
        }

        // Export Excel file and push send mail job
        $headerStyle = (new StyleBuilder())->setFontBold()->build();
        $sheetOne = 'ADMIN STAFF OF HOTEL GROUP';
        $sheets = new SheetCollection([
            $sheetOne => $this->_reportsGenerator($data),
        ]);

        $createdAt = Carbon::now()->timestamp;
        $filePath = "/exports/ad-hoc/{$createdAt}.xlsx";
        $fullPath = Storage::disk('local')->path($filePath);
        // Check folder already exists or not, create if not exists
        $folder = storage_path('app/exports/ad-hoc/');
        if (!File::exists($folder)) {
            File::makeDirectory($folder, 0755, true, true);
        }
        (new FastExcel($sheets))
            ->headerStyle($headerStyle)
            ->export($fullPath);
    }

    /**
     * @param array|collection $data
     * @return Generator
     */
    private function _reportsGenerator($data)
    {
        foreach ($data as $key => $value) {
            yield $this->_sheetOneFormatting($key, $value);
        }
    }

    /**
     * @param int $index
     * @param stdClass $item
     * @return stdClass
     */
    private function _sheetOneFormatting($index, $item)
    {
        $object = new stdClass();
        $object->{'#'} = $index + 1;
        $object->{'Họ tên'} = $item[0];
        $object->{'Email'} = $item[1];
        $object->{'Di động'} = $item[2];
        $object->{'Tên chuỗi khách sạn'} = $item[3];
        return $object;
    }
}
