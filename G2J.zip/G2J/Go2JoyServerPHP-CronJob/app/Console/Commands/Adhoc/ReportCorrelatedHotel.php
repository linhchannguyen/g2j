<?php

namespace App\Console\Commands\Adhoc;

use App\Constants\Hotel as HotelConst;
use App\Helpers\CommonHelper;
use App\Models\CorrelatedHotel;
use App\Models\Hotel;
use Exception;
use Illuminate\Console\Command;
use Illuminate\Support\Arr;
use Illuminate\Support\Facades\DB;

class ReportCorrelatedHotel extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'adhoc:report-correlated-hotel';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Report correlated hotel from multiple source';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return void
     * @throws Exception
     */
    public function handle()
    {
        $agodaHotelList = DB::table('HOTEL as hotel')
            ->where('hotel.ORIGIN', HotelConst::ORIGIN['AGODA'])
            ->where('hotel.DISPLAY', HotelConst::DISPLAY['HIDE'])
            ->where('hotel.HOTEL_STATUS', HotelConst::STATUS['NO_STATUS'])
            ->whereNotExists(function ($query) {
                $query->select(DB::raw(1))
                    ->from('CORRELATED_HOTEL as correlatedHotel')
                    ->whereRaw('hotel.PARTNER_HOTEL_ID = correlatedHotel.AGODA_HOTEL_ID');
            })
            ->get([
                'hotel.SN',
                'hotel.PARTNER_HOTEL_ID',
                'hotel.ADDRESS',
                'hotel.NAME',
                'hotel.PROVINCE_SN',
                'hotel.DISTRICT_SN',
                'hotel.LATITUDE',
                'hotel.LONGITUDE',
            ]);

        foreach ($agodaHotelList as $agodaHotel) {
            $sn = $agodaHotel->{Hotel::COL_SN};
            $address = $agodaHotel->{Hotel::COL_ADDRESS};
            $name = $agodaHotel->{Hotel::COL_NAME};
            $partnerHotelId = $agodaHotel->{Hotel::COL_PARTNER_HOTEL_ID};
            $provinceSn = $agodaHotel->{Hotel::COL_PROVINCE_SN};
            $districtSn = $agodaHotel->{Hotel::COL_DISTRICT_SN};
            $latitude = $agodaHotel->{Hotel::COL_LATITUDE};
            $longitude = $agodaHotel->{Hotel::COL_LONGITUDE};

            $symbolCharList = [',', '-', '@', '(', ')', ',(', '),', '(,', ',)'];

            $func = function ($value) {
                if (is_numeric($value)) {
                    return sprintf('%s%s', '+', str_replace([',', '-', '@', '(', ')', ',(', '),', '(,', ',)'], '', $value));
                }
                return sprintf('%s%s', '>', str_replace([',', '-', '@', '(', ')', ',(', '),', '(,', ',)'], '', $value));
            };

            $filtered = array_filter(explode(' ', $address));
            $filtered = Arr::where($filtered, function ($value, $key) use ($symbolCharList) {
                return !in_array($value, $symbolCharList);
            });

            $haveFirstLeadingZero = false;
            $filteredRemoveFirstLeadingZero = array_map(function ($value) use (&$haveFirstLeadingZero) {
                if (is_numeric($value)) {
                    $removeFirstLeadingZero = CommonHelper::removeFirstLeadingZero($value);
                    $haveFirstLeadingZero = !($removeFirstLeadingZero === $value);
                    return $removeFirstLeadingZero;
                }
                return $value;
            }, $filtered);

            $filteredList = [$filtered, $filteredRemoveFirstLeadingZero];

            foreach ($filteredList as $filtered) {
                $_filtered = [];
                foreach ($filtered as $item) {
                    $exploded = explode('-', $item);
                    $_filtered[] = array_filter($exploded);
                }
                $filtered = Arr::flatten($_filtered);
                $mapped = array_map($func, $filtered);
                $keyword = implode(' ', $mapped);
                $result1 = DB::select(/** @lang text */ '
                    SELECT
                        SN,
                        PARTNER_HOTEL_ID,
                        ADDRESS,
                        NAME,
                        PROVINCE_SN,
                        DISTRICT_SN,
                        LATITUDE,
                        LONGITUDE
                    FROM HOTEL
                    WHERE SN != :sn
                       AND ORIGIN = :origin
                       AND HOTEL_STATUS = :hotelStatus
                       AND MATCH(ADDRESS) AGAINST(:keyword IN BOOLEAN MODE);
                    ', [
                        ':sn'          => $sn,
                        ':origin'      => HotelConst::ORIGIN['GO2JOY'],
                        ':hotelStatus' => HotelConst::STATUS['CONTRACTED'],
                        ':keyword'     => $keyword,
                    ]
                );

                $found = false;
                $maxRanking = 3;
                for ($position = 0; $position < $maxRanking; $position++) {
                    $confidence = 0;

                    $candidate = $result1[$position] ?? null;
                    if (empty($candidate)) {
                        continue;
                    }

                    $candidateHotelSn = $candidate->{Hotel::COL_SN};
                    $candidateProvinceSn = $candidate->{Hotel::COL_PROVINCE_SN};
                    $candidateDistrictSn = $candidate->{Hotel::COL_DISTRICT_SN};
                    $candidateLatitude = $candidate->{Hotel::COL_LATITUDE};
                    $candidateLongitude = $candidate->{Hotel::COL_LONGITUDE};

                    $confidence++;

                    $filtered = array_filter(explode(' ', $name));
                    $filtered = Arr::where($filtered, function($value, $key) use ($symbolCharList) {
                        return !in_array($value, $symbolCharList);
                    });
                    $mapped = array_map($func, $filtered);
                    $keyword = implode(' ', $mapped);

                    $result2 = DB::select(/** @lang text */ '
                        SELECT
                            SN,
                            ADDRESS,
                            NAME
                        FROM HOTEL
                        WHERE SN != :sn
                           AND ORIGIN = :origin
                           AND HOTEL_STATUS = :hotelStatus
                           AND MATCH(NAME) AGAINST(:keyword IN BOOLEAN MODE);
                        ', [
                            ':origin'      => HotelConst::ORIGIN['GO2JOY'],
                            ':sn'          => $sn,
                            ':hotelStatus' => HotelConst::STATUS['CONTRACTED'],
                            ':keyword'     => $keyword,
                        ]
                    );

                    $result2 = collect($result2)->pluck(Hotel::COL_SN)->toArray();
                    if (in_array($candidateHotelSn, $result2)) {
                        $confidence++;
                    }

                    if ($candidateProvinceSn == $provinceSn && $candidateDistrictSn == $districtSn) {
                        $confidence++;
                    }

                    $distance = CommonHelper::harversineDistance($latitude, $longitude, $candidateLatitude, $candidateLongitude);
                    if (intval($distance) <= 500) {
                        $confidence++;
                    }

                    $expectedConfidence = 4;
                    if ($confidence == $expectedConfidence) {
                        $correlatedHotel = CorrelatedHotel::where('HOTEL_SN', $candidateHotelSn)->first();
                        if (empty($correlatedHotel)) {
                            // Insert new record
                            $hotel = new CorrelatedHotel();
                            $hotel->{CorrelatedHotel::COL_HOTEL_SN} = $candidateHotelSn;
                            $hotel->{CorrelatedHotel::COL_AGODA_HOTEL_ID} = $partnerHotelId;
                            $hotel->save();
                        } else {
                            // Update record existed
                            $correlatedHotel->{CorrelatedHotel::COL_AGODA_HOTEL_ID} = $partnerHotelId;
                            $correlatedHotel->save();
                        }
                        $found = true;
                        break;
                    }
                }

                if ($found || !$haveFirstLeadingZero) {
                    break;
                }
            }

        }
    }
}
