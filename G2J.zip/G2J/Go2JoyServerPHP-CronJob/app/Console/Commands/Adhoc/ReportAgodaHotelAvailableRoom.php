<?php

namespace App\Console\Commands\Adhoc;

use App\API\External\Integration\Agoda\AgodaProcessor;
use App\Constants\Hotel as HotelConst;
use App\Constants\MongoDB\AgodaHotel as AgodaHotelConst;
use App\Constants\Partners\Agoda as AgodaConst;
use App\DTOs\Integration\Agoda\FetchHotelInputDTO;
use App\DTOs\Integration\Agoda\GetHotelDetailInputDTO;
use App\Models\Hotel;
use App\Models\MongoDB\AgodaHotel;
use Exception;
use Illuminate\Console\Command;
use Illuminate\Support\Carbon;

class ReportAgodaHotelAvailableRoom extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'adhoc:report-agoda-hotel-available-room
                            {--checkIn=}
                            {--checkOut=}
                            {--numOfRoom=}
                            {--numOfAdults=}
                            {--numOfChildren=}
                            {--hotelIdList=}
                            {--cityIdList=}
                            {--provinceSnList=}
                            {--districtSnList=}
                            {--languageId=}
                            {--currency=}
                            {--withDuplicate}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Report available room of Agoda hotel';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return void
     * @throws Exception
     */
    public function handle()
    {
        $agodaProcessor = new AgodaProcessor(config('agoda.config'));

        $checkIn = $this->option('checkIn');
        $checkIn = $checkIn ? Carbon::parse($checkIn)->format('Y-m-d') : null;

        $checkOut = $this->option('checkOut');
        $checkOut = $checkOut ? Carbon::parse($checkOut)->format('Y-m-d') : null;

        $hotelIdList = $this->option('hotelIdList');
        $hotelIdList = explode(',', $hotelIdList);
        $hotelIdList = array_filter($hotelIdList);
        $hotelIdList = array_map('intval', $hotelIdList);

        $cityIdList = $this->option('cityIdList');
        $cityIdList = explode(',', $cityIdList);
        $cityIdList = array_filter($cityIdList);
        $cityIdList = array_map('intval', $cityIdList);

        $provinceSnList = $this->option('provinceSnList');
        $provinceSnList = explode(',', $provinceSnList);
        $provinceSnList = array_filter($provinceSnList);
        $provinceSnList = array_map('intval', $provinceSnList);

        $districtSnList = $this->option('districtSnList');
        $districtSnList = explode(',', $districtSnList);
        $districtSnList = array_filter($districtSnList);
        $districtSnList = array_map('intval', $districtSnList);

        $withDuplicate = $this->option('withDuplicate');

        $languageId = $this->option('languageId') ?? AgodaConst::LANGUAGE_ID['VIETNAMESE'];
        $currency = $this->option('currency') ?? AgodaConst::CURRENCY_CODE['VIETNAMESE_DONG'];

        $numOfRoom = $this->option('numOfRoom') ?? null;
        $numOfAdults = $this->option('numOfAdults') ?? null;
        $numOfChildren = $this->option('numOfChildren') ?? null;

        // Filter hotel list with list of hotel sn from input
        $partnerHotelIdList = [];
        if (!empty($cityIdList)) {
            foreach ($cityIdList as $cityId) {
                $fetchHotelInputDTO = new FetchHotelInputDTO();
                $fetchHotelInputDTO->setCityId($cityId);
                $fetchHotelInputDTO->setAreaId(AgodaConst::ALL);
                $fetchHotelInputDTO->setHotelId(AgodaConst::ALL);
                $fetchHotelInputDTO->setLanguageId($languageId);
                $fetchHotelInputDTO->setCurrency($currency);

                // Get hotel list from Agoda
                $fetchHotelOutputDTO = $agodaProcessor->fetchHotel($fetchHotelInputDTO);
                $hotelList = $fetchHotelOutputDTO->getHotelList();

                foreach ($hotelList as $hotel) {
                    $partnerHotelId = intval($hotel['hotelId']);
                    $partnerHotelIdList[] = $partnerHotelId;
                }
            }
        } elseif (!empty($hotelIdList)) {
            $partnerHotelIdList = AgodaHotel::where(AgodaHotel::FIELD_STATUS, AgodaHotelConst::STATUS['ACTIVE'])
                ->whereNotNull(AgodaHotel::FIELD_HOTEL_SN)
                ->whereIn(AgodaHotel::FIELD_PARTNER_HOTEL_ID, $hotelIdList)
                ->get([AgodaHotel::FIELD_PARTNER_HOTEL_ID])
                ->pluck(AgodaHotel::FIELD_PARTNER_HOTEL_ID)
                ->toArray();
        } elseif (!empty($provinceSnList)) {
            $queryStatement = Hotel::where(Hotel::COL_ORIGIN, HotelConst::ORIGIN['AGODA'])
                ->whereIn(Hotel::COL_PROVINCE_SN, $provinceSnList);
            if (!$withDuplicate) {
                $queryStatement->where(Hotel::COL_HOTEL_STATUS, HotelConst::STATUS['CONTRACTED'])
                    ->where(Hotel::COL_DISPLAY, HotelConst::DISPLAY['DISPLAY']);
            }

            $partnerHotelIdList = $queryStatement->get([Hotel::COL_PARTNER_HOTEL_ID])
                ->pluck(Hotel::COL_PARTNER_HOTEL_ID)
                ->toArray();
        } elseif (!empty($districtSnList)) {
            $queryStatement = Hotel::where(Hotel::COL_ORIGIN, HotelConst::ORIGIN['AGODA'])
                ->whereIn(Hotel::COL_DISTRICT_SN, $districtSnList);
            if (!$withDuplicate) {
                $queryStatement->where(Hotel::COL_HOTEL_STATUS, HotelConst::STATUS['CONTRACTED'])
                    ->where(Hotel::COL_DISPLAY, HotelConst::DISPLAY['DISPLAY']);
            }

            $partnerHotelIdList = $queryStatement->get([Hotel::COL_PARTNER_HOTEL_ID])
                ->pluck(Hotel::COL_PARTNER_HOTEL_ID)
                ->toArray();
        }

        $numOfAvailableRoom = 0;
        foreach ($partnerHotelIdList as $partnerHotelId) {
            $partnerHotelId = intval($partnerHotelId);

            $getHotelDetailInputDTO = new GetHotelDetailInputDTO();
            $getHotelDetailInputDTO->setHotelIdList([$partnerHotelId]);

            if (!empty($numOfRoom)) {
                $getHotelDetailInputDTO->setNumOfRoom($numOfRoom);
            }
            if (!empty($numOfAdults)) {
                $getHotelDetailInputDTO->setNumOfAdults($numOfAdults);
            }
            if (!empty($numOfChildren)) {
                $getHotelDetailInputDTO->setNumOfChildren($numOfChildren);
            }

            if (!empty($checkIn) && !empty($checkOut)) {
                $getHotelDetailInputDTO->setCheckIn($checkIn);
                $getHotelDetailInputDTO->setCheckOut($checkOut);
            } else {
                $getHotelDetailInputDTO->setCheckIn(Carbon::now()->setTimezone(config('app.timezone'))->format('Y-m-d'));
                $getHotelDetailInputDTO->setCheckOut(Carbon::now()->setTimezone(config('app.timezone'))->addDay()->format('Y-m-d'));
            }

            $getHotelDetailOutputDTO = $agodaProcessor->getHotelDetail($getHotelDetailInputDTO);
            $searchResponse = $getHotelDetailOutputDTO->getSearchResponse();
            if (empty($searchResponse->getErrorMessage())) {
                $numOfAvailableRoom++;
            }
        }

        $numOfAgodaHotel = count($partnerHotelIdList);
        $this->info("Total Agoda hotel: $numOfAgodaHotel, Total available room: $numOfAvailableRoom");
    }
}
