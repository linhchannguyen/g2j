<?php

namespace App\Console\Commands\Adhoc;

use App\Constants\MileagePointExpiration as MileagePointExpirationConst;
use App\Constants\MileagePointHistory as MileagePointHistoryConst;
use App\Constants\MileagePointTransactionHistory as MileagePointTransactionHistoryConst;
use App\Constants\Setting as SettingConst;
use App\Helpers\CommonHelper;
use App\Models\AppUser;
use App\Models\MileagePointExpiration;
use App\Models\MileagePointHistory;
use App\Models\MileagePointTransactionHistory;
use App\Models\Setting;
use Exception;
use Illuminate\Console\Command;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\DB;

class DonatePoint extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'adhoc:donate-point
                            {--appUserSn=}
                            {--numOfPoint=}
                            {--typeProgram= : 1: Donate; 2: Referral Program}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Donate point to specified user';

    const TYPE_PROGRAM = [
        'DONATE'           => 1,
        'REFERRAL_PROGRAM' => 2,
    ];

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return void
     */
    public function handle(): void
    {
        $appUserSn = $this->option('appUserSn');
        $numOfPoint = $this->option('numOfPoint');
        $typeProgram = $this->option('typeProgram');
        if (empty($appUserSn)) {
            $this->error('Please input appUserSn value!');
        }
        if (empty($numOfPoint)) {
            $this->error('Please input numOfPoint value!');
        }
        if (empty($typeProgram)) {
            $this->error('Please input typeProgram value!');
        }

        if (!in_array($typeProgram, self::TYPE_PROGRAM)) {
            $this->error('Please input typeProgram value!');
        }

        switch ($typeProgram) {
            case self::TYPE_PROGRAM['REFERRAL_PROGRAM']: {
                $typeProgramMileagePointTransactionHistory = MileagePointTransactionHistoryConst::TYPE_PROGRAM['REFERRAL'];
                $typeProgramMileagePointHistory = MileagePointHistoryConst::TYPE_PROGRAM['REFERRAL'];
                break;
            }
            default: {
                $typeProgramMileagePointTransactionHistory = MileagePointTransactionHistoryConst::TYPE_PROGRAM['DONATE'];
                $typeProgramMileagePointHistory = MileagePointHistoryConst::TYPE_PROGRAM['DONATE'];
            }
        }

        DB::connection('mysql')->beginTransaction();
        try {
            $appUser = AppUser::lockForUpdate()
                ->where(AppUser::COL_SN, $appUserSn)
                ->first([
                    AppUser::COL_MILEAGE_AMOUNT,
                    AppUser::COL_MILEAGE_EARNED,
                    AppUser::COL_MILEAGE_FIRST_TIME,
                ]);

            $mileageAmount = $appUser->{AppUser::COL_MILEAGE_AMOUNT};
            $mileageEarned = $appUser->{AppUser::COL_MILEAGE_EARNED};
            $mileageFirstTime = $appUser->{AppUser::COL_MILEAGE_FIRST_TIME};

            $totalActivePoint = $mileageAmount + $numOfPoint;
            $mileagePointTransactionHistorySn = DB::table(MileagePointTransactionHistory::TABLE_NAME)
                ->insertGetId([
                    MileagePointTransactionHistory::COL_APP_USER_SN        => $appUserSn,
                    MileagePointTransactionHistory::COL_TYPE_PROGRAM       => $typeProgramMileagePointTransactionHistory,
                    MileagePointTransactionHistory::COL_TOTAL_ACTIVE_POINT => $totalActivePoint,
                    MileagePointTransactionHistory::COL_ACTUAL_POINT       => $numOfPoint,
                    MileagePointTransactionHistory::COL_EXPECTED_POINT     => $numOfPoint,
                    MileagePointTransactionHistory::COL_STATUS             => MileagePointTransactionHistoryConst::STATUS['ACTIVE'],
                ]);

            $setting = CommonHelper::getHotelSetting(SettingConst::COMMON_TYPE['MILEAGE_POINT'], SettingConst::CLASS_NO['01']);
            $numOfMonth = (int)$setting->{Setting::COL_NUMDATA2};
            $expiredDate = Carbon::now()->addMonths($numOfMonth);

            DB::table(MileagePointHistory::TABLE_NAME)
                ->insert([
                    MileagePointHistory::COL_APP_USER_SN                            => $appUserSn,
                    MileagePointHistory::COL_TYPE_PROGRAM                           => $typeProgramMileagePointHistory,
                    MileagePointHistory::COL_PROGRAM_NAME                           => 'Go2Joy',
                    MileagePointHistory::COL_STATUS                                 => MileagePointHistoryConst::STATUS['ACTIVE'],
                    MileagePointHistory::COL_TOTAL_ACTIVE_POINT                     => $totalActivePoint,
                    MileagePointHistory::COL_ACTUAL_POINT                           => $numOfPoint,
                    MileagePointHistory::COL_EXPECTED_POINT                         => $numOfPoint,
                    MileagePointHistory::COL_USER_PAID                              => 0,
                    MileagePointHistory::COL_ACTIVE_TIME_FROM                       => Carbon::now()->toDateTimeString(),
                    MileagePointHistory::COL_ACTIVE_TIME_TO                         => $expiredDate->toDateTimeString(),
                    MileagePointHistory::COL_MILEAGE_POINT_TRANSACTION_HISTORY_LIST => json_encode([$mileagePointTransactionHistorySn]),
                ]);

            MileagePointExpiration::create([
                MileagePointExpiration::COL_MILEAGE_POINT_TRANSACTION_HISTORY_SN => $mileagePointTransactionHistorySn,
                MileagePointExpiration::COL_APP_USER_SN                          => $appUserSn,
                MileagePointExpiration::COL_NUM_OF_POINT                         => $numOfPoint,
                MileagePointExpiration::COL_REMAINING_POINT                      => $numOfPoint,
                MileagePointExpiration::COL_DAY                                  => $expiredDate->day,
                MileagePointExpiration::COL_MONTH                                => $expiredDate->month,
                MileagePointExpiration::COL_YEAR                                 => $expiredDate->year,
                MileagePointExpiration::COL_PROCESSED                            => MileagePointExpirationConst::PROCESSED['NOT_YET'],
            ]);

            $mileageAmount = $mileageAmount + $numOfPoint;
            $mileageEarned = $mileageEarned + $numOfPoint;

            $updateAppUserData = [
                AppUser::COL_MILEAGE_AMOUNT     => $mileageAmount,
                AppUser::COL_MILEAGE_EARNED     => $mileageEarned,
                AppUser::COL_MILEAGE_FIRST_TIME => $mileageFirstTime,
            ];
            if (empty($mileageFirstTime)) {
                $updateAppUserData[AppUser::COL_MILEAGE_FIRST_TIME] = Carbon::now();
            }

            AppUser::where(AppUser::COL_SN, $appUserSn)->update($updateAppUserData);

            DB::connection('mysql')->commit();

            $this->info('Done: APP_USER_SN: ' . $appUserSn . ' POINT: ' . $numOfPoint);

        } catch (Exception $exception) {
            DB::connection('mysql')->rollBack();
            $this->error($exception->getMessage());
        }
    }
}