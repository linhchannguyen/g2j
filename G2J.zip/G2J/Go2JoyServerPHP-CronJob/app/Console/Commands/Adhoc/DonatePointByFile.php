<?php

namespace App\Console\Commands\Adhoc;

use App\Helpers\LoggingHelper;
use App\Libraries\Maatwebsite\Excel\Imports\DonatePointImport;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Artisan;
use Maatwebsite\Excel\Facades\Excel;

class DonatePointByFile extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'adhoc:donate-point-by-file
                            {--typeProgram= : 1: Donate; 2: Referral Program}
                            {--linkExcel=}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Donate point to user by file';

    const TYPE_PROGRAM = [
        'DONATE'           => 1,
        'REFERRAL_PROGRAM' => 2,
    ];

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return void
     */
    public function handle(): void
    {
        $linkExcel = $this->option('linkExcel');
        $typeProgram = $this->option('typeProgram');
        if (!in_array($typeProgram, self::TYPE_PROGRAM)) {
            $this->error('Please input typeProgram value!');
            return;
        }

        LoggingHelper::logFunction("START_FUNCTION_DONATE", ['typeProgram' => $typeProgram, 'linkExcel' => $linkExcel]);
        if (!empty($linkExcel)) {
            $import = new DonatePointImport;
            Excel::import($import, $linkExcel, 's3');
            $importFile = $import->getArray();
            $donatePointListChunk = array_chunk($importFile, 500);
            foreach ($donatePointListChunk as $donatePointChunk) {
                foreach ($donatePointChunk as $donatePoint) {
                    $params = [
                        '--appUserSn'   => $donatePoint['sn'],
                        '--numOfPoint'  => $donatePoint['numOfPoint'],
                        '--typeProgram' => $typeProgram,
                    ];
                    Artisan::call(DonatePoint::class, $params);
                    $this->info(Artisan::output());
                }
            }
        }
        LoggingHelper::logFunction("END_FUNCTION_DONATE", ['typeProgram' => $typeProgram, 'linkExcel' => $linkExcel]);
    }
}