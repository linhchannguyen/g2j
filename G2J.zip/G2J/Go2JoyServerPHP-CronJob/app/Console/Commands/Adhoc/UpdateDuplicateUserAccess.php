<?php

namespace App\Console\Commands\Adhoc;

use App\Helpers\LoggingHelper;
use App\Libraries\Spatie\Async\Tasks\UserAccessDuplicatedChunkTask;
use App\Libraries\Spatie\Async\Tasks\UserAccessDuplicatedParentChunkTask;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;
use Spatie\Async\Pool;

class UpdateDuplicateUserAccess extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'adhoc:update-duplicate-user-access{--year=}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Update duplicate user access';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    public function handle()
    {
        $year = $this->option('year');
        if (empty($year)) {
            $year = '2019';
        }
        $userAccessByCreateTimeList = DB::table('USER_ACCESS_' . $year)
            ->where('DUPLICATED', '=', 0)
            ->groupBy('MOBILE_DEVICE_SN', 'CREATE_TIME')
            ->havingRaw('TOTAL_CREATE_TIME > 1')
            ->orderBy('MOBILE_DEVICE_SN', 'ASC')
            ->selectRaw('MOBILE_DEVICE_SN, CREATE_TIME, MAX(SN) AS USER_ACCESS_SN, COUNT(SN) as TOTAL_CREATE_TIME')
            ->skip(0)
            ->take(100000)
            ->get();

        // $table = 'USER_ACCESS_' . $year;
        // $userAccessByCreateTimeList = DB::table($table)
        //     ->where('DUPLICATED', '=', 0)
        //     ->whereRaw("MOBILE_DEVICE_SN IN (
        //         select MOBILE_DEVICE_SN
        //         from {$table}
        //         where DUPLICATED = 0
        //         group by MOBILE_DEVICE_SN
        //         HAVING COUNT(SN) > 1)")
        //     ->groupBy('CREATE_TIME')
        //     ->havingRaw('TOTAL_MOBILE_DEVICE > 1')
        //     ->selectRaw('CREATE_TIME, MOBILE_DEVICE_SN, COUNT(SN) as TOTAL_MOBILE_DEVICE')->get();

        LoggingHelper::logFunction("Total: " . count($userAccessByCreateTimeList));
        $pool = Pool::create()
            // The maximum amount of processes which can run simultaneously.
            //->concurrency(config('async.concurrency'))
            ->concurrency(20)
            // The maximum amount of time a process may take to finish in seconds
            // (decimal places are supported for more granular timeouts).
            ->timeout(config('async.timeout'))
            // Configure which autoloader sub processes should use.
            ->autoload(__DIR__ . '/../../../../vendor/autoload.php')
            // Configure how long the loop should sleep before re-checking the process statuses in microseconds.
            ->sleepTime(config('async.sleepTime'));

        $chunks = $userAccessByCreateTimeList->chunk(50)->toArray();
        foreach ($chunks as $index => $chunk) {
            $task = new UserAccessDuplicatedParentChunkTask($year, $chunk, $index);
            $pool->add($task)->then(function() {
                // On success, `$output` is returned by the process or callable you passed to the queue.
            })->catch(function($exception) {
                // When an exception is thrown from within a process, it's caught and passed here.
                LoggingHelper::logFunction("logException: " . $exception);
            })
            ->timeout(function() {
                // A process took too long to finish.
            });
        }
        $pool->wait();

        // ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

        //$year = $this->option('year');
        //if (empty($year)) {
        //    $year = '2018';
        //}
        //$userAccessByCreateTimeList = DB::table('USER_ACCESS_' . $year)
        //    ->where('DUPLICATED', '=', 0)
        //    ->groupBy('CREATE_TIME')
        //    ->havingRaw('TOTAL_CREATE_TIME > 1')
        //    ->selectRaw('CREATE_TIME, COUNT(MOBILE_DEVICE_SN) as TOTAL_CREATE_TIME')->get();
        //
        //LoggingHelper::logFunction("Total: " . count($userAccessByCreateTimeList));
        //foreach ($userAccessByCreateTimeList as $index => $userAccessByCreateTime) {
        //    $userAccessByMobileDeviceList = DB::table('USER_ACCESS_' . $year)
        //        ->where('DUPLICATED', '=', 0)
        //        ->where('CREATE_TIME', '=', $userAccessByCreateTime->CREATE_TIME)
        //        ->groupBy('MOBILE_DEVICE_SN')
        //        ->havingRaw('TOTAL_MOBILE_DEVICE > 1')
        //        ->selectRaw('MOBILE_DEVICE_SN, COUNT(SN) as TOTAL_MOBILE_DEVICE')->get();
        //
        //    if (count($userAccessByMobileDeviceList) > 0) {
        //        LoggingHelper::logFunction("Index ------- : " . $index);
        //
        //        $pool = Pool::create()
        //            // The maximum amount of processes which can run simultaneously.
        //            ->concurrency(config('async.concurrency'))
        //            // The maximum amount of time a process may take to finish in seconds
        //            // (decimal places are supported for more granular timeouts).
        //            ->timeout(config('async.timeout'))
        //            // Configure which autoloader sub processes should use.
        //            ->autoload(__DIR__ . '/../../../../vendor/autoload.php')
        //            // Configure how long the loop should sleep before re-checking the process statuses in microseconds.
        //            ->sleepTime(config('async.sleepTime'));
        //
        //        $chunks = $userAccessByMobileDeviceList->chunk(30)->toArray();
        //        foreach ($chunks as $index => $chunk) {
        //            $task = new UserAccessDuplicatedChunkTask($index, $index, $year, $chunk, $userAccessByCreateTime->CREATE_TIME);
        //            $pool->add($task)->then(function() {
        //                // On success, `$output` is returned by the process or callable you passed to the queue.
        //            })->catch(function($exception) {
        //                // When an exception is thrown from within a process, it's caught and passed here.
        //                LoggingHelper::logFunction("logException: " . $exception);
        //            })
        //            ->timeout(function() {
        //                // A process took too long to finish.
        //            });
        //        }
        //        $pool->wait();
        //    } else {
        //        LoggingHelper::logFunction("Updated Index ------- : " . $index);
        //    }
        //}
    }
}