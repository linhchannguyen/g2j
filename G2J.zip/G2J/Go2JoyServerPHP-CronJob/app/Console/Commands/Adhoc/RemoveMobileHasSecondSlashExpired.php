<?php

namespace App\Console\Commands\Adhoc;

use App\Helpers\ConvertHelper;
use App\Models\MobileDeviceHasSecondSplash;
use App\Repositories\Interfaces\MobileDeviceHasSecondSplashRepositoryInterface;
use App\Repositories\Interfaces\SecondSplashRepositoryInterface;
use Illuminate\Console\Command;

class RemoveMobileHasSecondSlashExpired extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'adhoc:remove-mobile-has-second-slash-expired
                            {--secondSplashSnList=}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Remove Mobile Has Second Slash Expired';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        $secondSplashSnList = $this->option('secondSplashSnList');
        $secondSplashSnList = explode(',', $secondSplashSnList);
        $secondSplashSnList = array_filter($secondSplashSnList);
        $secondSplashSnArray = array_map('intval', $secondSplashSnList);

        $secondSplashRepository = app(SecondSplashRepositoryInterface::class);
        $mobileDeviceHasSecondSplashRepository = app(MobileDeviceHasSecondSplashRepositoryInterface::class);
        if (empty($secondSplashSnArray)) {
            $secondSplashList = $secondSplashRepository->findSecondSplashExpiredList();
            $secondSplashSnArray = $secondSplashList->pluck('SN')->toArray();
        }
        if (empty($secondSplashSnArray)) {
            return true;
        }
        $mobileDeviceHasSecondSplashList = $mobileDeviceHasSecondSplashRepository->findAllMobileDeviceHasSecondSplashList();

        foreach ($mobileDeviceHasSecondSplashList as $mobileDeviceHasSecondSplash) {
            $secondSplashList = $mobileDeviceHasSecondSplash->{MobileDeviceHasSecondSplash::COL_SECOND_SPLASH_LIST} ?? [];
            $secondSplashList = ConvertHelper::toArray($secondSplashList);
            $mobileHasSecondSlashArray = array_diff($secondSplashList, $secondSplashSnArray);
            $mobileDeviceHasSecondSplashRepository->update(
                [MobileDeviceHasSecondSplash::COL_SECOND_SPLASH_LIST => ConvertHelper::toJson($mobileHasSecondSlashArray)],
                $mobileDeviceHasSecondSplash->{MobileDeviceHasSecondSplash::COL_SN}
            );

        }

    }
}
