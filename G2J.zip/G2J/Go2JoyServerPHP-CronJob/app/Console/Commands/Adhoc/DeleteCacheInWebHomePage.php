<?php

namespace App\Console\Commands\Adhoc;

use App\API\External\Integration\Agoda\AgodaProcessor;
use App\Constants\MongoDB\AgodaHotel as AgodaHotelConst;
use App\Constants\Partners\Agoda as AgodaConst;
use App\DTOs\Integration\Agoda\FetchHotelInputDTO;
use App\DTOs\Integration\Agoda\GetHotelDetailInputDTO;
use App\Models\Hotel;
use App\Models\MongoDB\AgodaHotel;
use App\Models\Province;
use App\Models\WebDevice;
use Exception;
use Illuminate\Console\Command;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Cache;
use Psr\SimpleCache\InvalidArgumentException;

class DeleteCacheInWebHomePage extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'adhoc:delete-cache-in-web-home-page {--collectionSn=}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Delete cache in Web Home Page';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return void
     * @throws InvalidArgumentException
     */
    public function handle()
    {
        $collectionSn = $this->option('collectionSn');
        $provinceSnList = array_column(Province::all([Hotel::COL_SN])->toArray(), Hotel::COL_SN);
        $appUserSnList = array_column(WebDevice::whereNotNull(WebDevice::COL_APP_USER_SN)->distinct()->get(WebDevice::COL_APP_USER_SN)->toArray(), WebDevice::COL_APP_USER_SN);
        $keyHotelOfCollection = [];
        $keyCollectionByProvinceSn = [];
        $keyCollectionByProvinceSnAndAppUserSn = [];
        foreach ($provinceSnList as $provinceSn) {
            if ($collectionSn) {
                $keyHotelOfCollection[] = 'HC_' . $collectionSn . '_' . $provinceSn;
            }
            $keyCollectionByProvinceSn[] = 'collection:web:' . $provinceSn;
            foreach ($appUserSnList as $appUserSn) {
                $keyCollectionByProvinceSnAndAppUserSn[] = 'collection:web:' . $provinceSn . '_' . $appUserSn;
            }
        }
        Cache::store('redis')->deleteMultiple($keyHotelOfCollection);
        Cache::store('redis')->deleteMultiple($keyCollectionByProvinceSn);
        Cache::store('redis')->deleteMultiple($keyCollectionByProvinceSnAndAppUserSn);
        echo 'DONE' . PHP_EOL;
    }
}
