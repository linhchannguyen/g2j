<?php

namespace App\Console\Commands\Adhoc;

use App\Constants\AppUser as AppUserConst;
use App\Constants\CouponIssued as CouponIssuedConst;
use App\Constants\Setting as SettingConst;
use App\Constants\StampIssued as StampIssuedConst;
use App\Helpers\CommonHelper;
use App\Models\AppUser;
use App\Models\Coupon;
use App\Models\CouponIssued;
use App\Models\Promotion;
use App\Models\RegisterStamp;
use App\Models\Setting;
use App\Models\StampIssued;
use App\Models\UserBooking;
use App\Models\UserStamp;
use App\Repositories\Interfaces\RegisterStampRepositoryInterface;
use App\Repositories\Interfaces\UserBookingRepositoryInterface;
use App\Repositories\Interfaces\UserStampRepositoryInterface;
use Illuminate\Console\Command;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\DB;

class RecallCoupon extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'adhoc:recall-coupon
                            {--couponSn=}
                            {--appUserSnList=}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Recall coupon not use yet of user';

    const LIMIT = 500;

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return void
     */
    public function handle()
    {
        $couponSn = $this->option('couponSn');
        if (empty($couponSn)) {
            $this->error('The "--couponSn" option is required!');
            return;
        }
        $coupon = DB::table(Coupon::TABLE_NAME)
            ->where(Coupon::COL_SN, $couponSn)
            ->first([
                Coupon::COL_PROMOTION_SN
            ]);
        if (empty($coupon)) {
            $this->error('Coupon is invalid!');
            return;
        }

        $promotionSn = $coupon->{Coupon::COL_PROMOTION_SN};

        $appUserSnList = $this->option('appUserSnList');
        $appUserSnList = explode(',', $appUserSnList);
        $appUserSnList = array_filter($appUserSnList);
        $appUserSnList = array_map('intval', $appUserSnList);

        $query1 = DB::table('COUPON_ISSUED as couponIssued')
            ->leftJoin('USER_BOOKING as userBooking', 'userBooking.COUPON_ISSUED_SN', '=', 'couponIssued.SN')
            ->whereIn('couponIssued.USED', [CouponIssuedConst::USED['NOT_YET'], CouponIssuedConst::USED['TEMP']])
            ->where('couponIssued.COUPON_SN', $couponSn)
            ->whereNull('userBooking.SN');

        if (!empty($appUserSnList)) {
            $query1->whereIn('couponIssued.APP_USER_SN', $appUserSnList);
        }

        $chunks = array_chunk($query1->get(['couponIssued.SN'])->pluck('SN')->toArray(), self::LIMIT);

        $numOfRecord = 0;
        foreach ($chunks as $chunk) {
            $couponIssuedSnList = $chunk;
            $numOfRecord += DB::table(CouponIssued::TABLE_NAME)->whereIn(CouponIssued::COL_SN, $couponIssuedSnList)->delete();
        }

        $totalCoupon = DB::table(CouponIssued::TABLE_NAME)
            ->where(CouponIssued::COL_COUPON_SN, $couponSn)
            ->count();

        $totalConsumed = DB::table(CouponIssued::TABLE_NAME)
            ->where(CouponIssued::COL_COUPON_SN, $couponSn)
            ->where(CouponIssued::COL_USED, CouponIssuedConst::USED['USED'])
            ->count();

        DB::table(Promotion::TABLE_NAME)
            ->where(Promotion::COL_SN, $promotionSn)
            ->update([
                Promotion::COL_TOTAL_COUPON => $totalCoupon,
                Promotion::COL_TOTAL_CONSUMED => $totalConsumed,
            ]);

        $this->info("Num of record had been deleted: $numOfRecord, Total coupon: $totalCoupon, Total consumed: $totalConsumed");
    }
}
