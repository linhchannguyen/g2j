<?php

namespace App\Console\Commands\Adhoc;

use App\Helpers\LoggingHelper;
use App\Repositories\Interfaces\InstantLockRepositoryInterface;
use Exception;
use Illuminate\Console\Command;
use Illuminate\Support\Carbon;

class RecoverUpdateDailyRefreshInstantLock extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'adhoc:recover-update-daily-refresh-instant-lock
                            {dateTime}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Recover update daily refresh instant lock after downtime';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @param InstantLockRepositoryInterface $instantLockRepository
     */
    public function handle(InstantLockRepositoryInterface $instantLockRepository)
    {
        $now = Carbon::now();
        $dateTime = Carbon::parse($this->argument('dateTime'));
        LoggingHelper::logFunction('START JOB: RECOVER UPDATE DAILY REFRESH INSTANT LOCK');
        try {
            $instantLockRepository->recoverUpdateDailyRefreshInstantLock($dateTime->toDateTimeString());
        } catch (Exception $e) {
            LoggingHelper::logFunction("$now->hour Hour", 'ERROR JOB: RECOVER UPDATE DAILY REFRESH INSTANT LOCK - ' . $e->getMessage());
        }
        LoggingHelper::logFunction("$now->hour Hour", 'END JOB: RECOVER UPDATE DAILY DAILY REFRESH INSTANT LOCK');
    }
}