<?php

namespace App\Console\Commands\Adhoc;

use App\Models\Coupon;
use App\Models\CouponIssued;
use App\Models\Promotion;
use App\Models\UserBooking;
use Illuminate\Console\Command;

class RefundCoupon extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'adhoc:refund-coupon
                            {--userBookingSnList=}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Refund coupon for user booking';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return void
     */
    public function handle()
    {
        $userBookingSnList = $this->option('userBookingSnList');
        $userBookingSnList = explode(',', $userBookingSnList);
        $userBookingSnList = array_filter($userBookingSnList);
        $userBookingSnList = array_map('intval', $userBookingSnList);

        foreach ($userBookingSnList as $userBookingSn) {
            $userBooking = UserBooking::where(UserBooking::COL_SN, $userBookingSn)->first();
            $prepayAmount = $userBooking->{UserBooking::COL_PREPAY_AMOUNT};
            $couponIssuedSn = $userBooking->{UserBooking::COL_COUPON_ISSUED_SN};
            if ($prepayAmount > 0) {
                // Remove coupon issued sn value in USER_BOOKING table
                UserBooking::where(UserBooking::COL_SN, $userBookingSn)->update([UserBooking::COL_COUPON_ISSUED_SN => null]);

                // Recalculate booking amount

                // Revert info in COUPON_ISSUED table
                CouponIssued::where(CouponIssued::COL_SN, $couponIssuedSn)
                    ->update([
                        CouponIssued::COL_USED      => 0,
                        CouponIssued::COL_USED_TIME => null,
                        CouponIssued::COL_HOTEL_SN  => null,
                    ]);

                // Revert info in PROMOTION table
                $couponIssued = CouponIssued::where(CouponIssued::COL_SN, $couponIssuedSn)->first();
                $couponSn = $couponIssued->{CouponIssued::COL_COUPON_SN};
                $coupon = Coupon::where(Coupon::COL_SN, $couponSn)->first();
                $promotionSn = $coupon->{Coupon::COL_PROMOTION_SN};
                Promotion::where(Promotion::COL_SN, $promotionSn)->decrement(Promotion::COL_TOTAL_CONSUMED);
            }
            $this->error("This booking with SN = $userBookingSn is paid in advance. Please contact to Go2Joy's CS to process this booking!!!");
        }
    }
}
