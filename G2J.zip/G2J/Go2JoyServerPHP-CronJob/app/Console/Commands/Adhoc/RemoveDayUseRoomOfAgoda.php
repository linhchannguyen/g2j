<?php

namespace App\Console\Commands\Adhoc;

use App\Constants\MongoDB\AgodaRoomType as AgodaRoomTypeConst;
use App\Constants\RoomType as RoomTypeConst;
use App\Models\MongoDB\AgodaRoomType;
use App\Models\RoomType;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;

class RemoveDayUseRoomOfAgoda extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'adhoc:remove-day-use-room-of-agoda';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Remove day use (ở theo ngày) room of Agoda';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return void
     */
    public function handle(): void
    {
        $roomTypeList = DB::table(RoomType::TABLE_NAME)
            ->whereNotNull(RoomType::COL_PARTNER_ROOM_TYPE_ID)
            ->whereRaw(RoomType::COL_NAME . " REGEXP 'day use|ở trong ngày'")
            ->where(RoomType::COL_STATUS, RoomTypeConst::STATUS['ACTIVE'])
            ->get([
                RoomType::COL_SN,
                RoomType::COL_PARTNER_ROOM_TYPE_ID,
            ]);

        foreach ($roomTypeList as $roomType) {
            $roomTypeSn = $roomType->{RoomType::COL_SN};
            $partnerRoomTypeId = $roomType->{RoomType::COL_PARTNER_ROOM_TYPE_ID};
            RoomType::where(RoomType::COL_SN, $roomTypeSn)
                ->where(RoomType::COL_PARTNER_ROOM_TYPE_ID, strval($partnerRoomTypeId))
                ->update([
                    RoomType::COL_STATUS => RoomTypeConst::STATUS['DELETED']
                ]);

            AgodaRoomType::where(AgodaRoomType::FIELD_ROOM_TYPE_SN, $roomTypeSn)
                ->where(AgodaRoomType::FIELD_PARTNER_ROOM_TYPE_ID, intval($partnerRoomTypeId))
                ->update([
                    AgodaRoomType::FIELD_STATUS => AgodaRoomTypeConst::STATUS['INACTIVE']
                ]);
        }
    }
}
