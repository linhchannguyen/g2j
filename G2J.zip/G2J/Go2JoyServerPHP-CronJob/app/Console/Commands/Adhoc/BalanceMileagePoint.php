<?php

namespace App\Console\Commands\Adhoc;

use App\Constants\AppUser as AppUserConst;
use App\Constants\Setting as SettingConst;
use App\Constants\StampIssued as StampIssuedConst;
use App\Constants\UserBooking as UserBookingConst;
use App\Helpers\CommonHelper;
use App\Models\AppUser;
use App\Models\RegisterStamp;
use App\Models\Setting;
use App\Models\StampIssued;
use App\Models\UserBooking;
use App\Models\UserStamp;
use App\Repositories\Interfaces\AppUserRepositoryInterface;
use Carbon\Carbon;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;

class BalanceMileagePoint extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'adhoc:balance-mileage-point
                            {--appUserSnList=}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Balance mileage point for user';

    /** @var int */
    const LIMIT = 500;

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        $appUserSnList = $this->option('appUserSnList');
        $appUserSnList = explode(',', $appUserSnList);
        $appUserSnList = array_filter($appUserSnList);
        $appUserSnList = array_map('intval', $appUserSnList);

        if (empty($appUserSnList)) {
            $appUserSnList = AppUser::where(AppUser::COL_STATUS, AppUserConst::STATUS['ACTIVE'])->limit(self::LIMIT)->get([AppUser::COL_SN]);
            $appUserSnList = $appUserSnList->pluck(AppUser::COL_SN)->toArray();
        }

        foreach ($appUserSnList as $appUserSn) {
            $this->_balanceMileagePoint($appUserSn);
        }
    }

    /**
     * @param string|int $appUserSn
     */
    private function _balanceMileagePoint($appUserSn)
    {
        $appUserRepository = app(AppUserRepositoryInterface::class);
        $appUserMissMileagePointList = $appUserRepository->findMissingMileagePoint($appUserSn);
        foreach ($appUserMissMileagePointList as $appUserMissMileagePoint) {
            $appUserSn = $appUserMissMileagePoint->{AppUser::COL_SN};
            $amountPointDeficiency = abs($appUserMissMileagePoint->{AppUser::VAR_AMOUNT_POINT_DEFICIENCY});

            // Update mileage point earned of app user
            $appUser = AppUser::where(AppUser::COL_SN, $appUserSn)->first();
            $mileageEarned = intval($appUser->{AppUser::COL_MILEAGE_EARNED});
            $mileageAmount = intval($appUser->{AppUser::COL_MILEAGE_AMOUNT});
            $appUser->{AppUser::COL_MILEAGE_EARNED} = $mileageEarned + $amountPointDeficiency;
            $appUser->{AppUser::COL_MILEAGE_AMOUNT} = $mileageAmount + $amountPointDeficiency;
            $appUser->save();
        }
    }
}
