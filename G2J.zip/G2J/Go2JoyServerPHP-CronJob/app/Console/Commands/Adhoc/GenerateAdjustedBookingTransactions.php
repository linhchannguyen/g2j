<?php

namespace App\Console\Commands\Adhoc;

use App\DTOs\Web\SA\UserBookingTransaction\GenerateUserBookingTransactionInputDTO;
use App\Helpers\ConvertHelper;
use App\Models\UserBooking;
use App\Services\Web\SA\UserBookingTransactionService;
use Illuminate\Console\Command;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\DB;

class GenerateAdjustedBookingTransactions extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'adhoc:generate-adjusted-booking-transactions
                            {--staffSn=681}
                            {--bookingNo=}
                            {--transferTime=}
                            {--bookingStatus=}
                            {--commissionAmount=}
                            {--commissionProductAmount=}
                            {--hotelRefund=}
                            {--roomTypeSn=}
                            {--totalAmount=}
                            {--amountFromUser=}
                            {--roomTypeHistorySn=}
                            {--directDiscount=}
                            {--hotelSn=}
                            {--checkInTime=}
                            {--checkInDatePlan=}
                            {--endDate=}
                            {--prepayAmount=}
                            {--go2joyDiscount=}
                            {--hotelDiscount=}
                            {--endTime=}
                            {--viaObject=}
                            {--paymentProvider=}
                            {--refunded=}
                            {--report=}
                            {--bookingActionHistorySn=}
                           ';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Generate transactions for booking have already adjusted';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        $transferTime = $this->option('transferTime');
        $bookingNo = $this->option('bookingNo');
        $userBookingTransaction = DB::table('USER_BOOKING_TRANSACTION as UBT')
            ->join('USER_BOOKING as UB', function($join) {
                $join->on('UBT.USER_BOOKING_SN', '=', 'UB.SN');
            })
            ->where('UB.BOOKING_NO', '=', $bookingNo)
            ->first();
        if (!$userBookingTransaction) {
            $bookingStatus = $this->option('bookingStatus');
            $commissionAmount = $this->option('commissionAmount');
            $commissionProductAmount = $this->option('commissionProductAmount');
            $hotelRefund = $this->option('hotelRefund');
            $roomTypeSn = $this->option('roomTypeSn');
            $totalAmount = $this->option('totalAmount');
            $amountFromUser = $this->option('amountFromUser');
            $roomTypeHistorySn = $this->option('roomTypeHistorySn');
            $directDiscount = $this->option('directDiscount');
            $hotelSn = $this->option('hotelSn');
            $checkInTime = $this->option('checkInTime');
            $checkInDatePlan = $this->option('checkInDatePlan');
            $endDate = $this->option('endDate');
            $prepayAmount = $this->option('prepayAmount');
            $go2joyDiscount = $this->option('go2joyDiscount');
            $hotelDiscount = $this->option('hotelDiscount');
            $endTime = $this->option('endTime');
            $viaObject = $this->option('viaObject');
            $paymentProvider = $this->option('paymentProvider');
            $refunded = $this->option('refunded');
            $report = $this->option('report');
            $bookingActionHistorySn = $this->option('bookingActionHistorySn');

            $userBooking = DB::table('USER_BOOKING as UB')->where('UB.BOOKING_NO', '=', $bookingNo)->first();

            $newData = ConvertHelper::toJson($userBooking, function($items) {
                return ConvertHelper::toArrayCamelCase($items);
            });

            $oldData = $userBooking;
            $oldData->{UserBooking::COL_BOOKING_STATUS} = isset($bookingStatus) ? $bookingStatus : $oldData->{UserBooking::COL_BOOKING_STATUS};
            $oldData->{UserBooking::COL_COMMISSION_AMOUNT} = $commissionAmount ? intval($commissionAmount) : $oldData->{UserBooking::COL_COMMISSION_AMOUNT};
            $oldData->{UserBooking::COL_COMMISSION_PRODUCT_AMOUNT} = $commissionProductAmount ? intval($commissionProductAmount) : $oldData->{UserBooking::COL_COMMISSION_PRODUCT_AMOUNT};
            $oldData->{UserBooking::COL_HOTEL_REFUND} = $hotelRefund ? intval($hotelRefund) : $oldData->{UserBooking::COL_HOTEL_REFUND};
            $oldData->{UserBooking::COL_ROOM_TYPE_SN} = $roomTypeSn ? intval($roomTypeSn) : $oldData->{UserBooking::COL_ROOM_TYPE_SN};
            $oldData->{UserBooking::COL_TOTAL_AMOUNT} = $totalAmount ? intval($totalAmount) : $oldData->{UserBooking::COL_TOTAL_AMOUNT};
            $oldData->{UserBooking::COL_AMOUNT_FROM_USER} = $amountFromUser ? intval($amountFromUser) : $oldData->{UserBooking::COL_AMOUNT_FROM_USER};
            $oldData->{UserBooking::COL_ROOM_TYPE_HISTORY_SN} = $roomTypeHistorySn ? intval($roomTypeHistorySn) : $oldData->{UserBooking::COL_ROOM_TYPE_HISTORY_SN};
            $oldData->{UserBooking::COL_DIRECT_DISCOUNT} = $directDiscount ? intval($directDiscount) : $oldData->{UserBooking::COL_DIRECT_DISCOUNT};
            $oldData->{UserBooking::COL_CHECK_IN_TIME} = $checkInTime ?: $oldData->{UserBooking::COL_CHECK_IN_TIME};
            $oldData->{UserBooking::COL_HOTEL_SN} = $hotelSn ?: $oldData->{UserBooking::COL_HOTEL_SN};
            $oldData->{UserBooking::COL_CHECK_IN_DATE_PLAN} = $checkInDatePlan ?: $oldData->{UserBooking::COL_CHECK_IN_DATE_PLAN};
            $oldData->{UserBooking::COL_END_DATE} = $endDate ?: $oldData->{UserBooking::COL_END_DATE};
            $oldData->{UserBooking::COL_PREPAY_AMOUNT} = $prepayAmount ?: $oldData->{UserBooking::COL_PREPAY_AMOUNT};
            $oldData->{UserBooking::COL_GO2JOY_DISCOUNT} = $go2joyDiscount ?: $oldData->{UserBooking::COL_GO2JOY_DISCOUNT};
            $oldData->{UserBooking::COL_HOTEL_DISCOUNT} = $hotelDiscount ?: $oldData->{UserBooking::COL_HOTEL_DISCOUNT};
            $oldData->{UserBooking::COL_END_TIME} = $endTime ?: $oldData->{UserBooking::COL_END_TIME};
            $oldData->{UserBooking::COL_VIA_OBJECT} = $viaObject ?: $oldData->{UserBooking::COL_VIA_OBJECT};
            $oldData->{UserBooking::COL_PAYMENT_PROVIDER} = isset($paymentProvider) ? $paymentProvider : $oldData->{UserBooking::COL_PAYMENT_PROVIDER};
            $oldData->{UserBooking::COL_REFUNDED} = $refunded ?: $oldData->{UserBooking::COL_REFUNDED};
            $oldData->{UserBooking::COL_REPORT} = $report ?: $oldData->{UserBooking::COL_REPORT};
            $oldData->{UserBooking::COL_BOOKING_ACTION_HISTORY_SN} = $bookingActionHistorySn ? intval($bookingActionHistorySn) : $oldData->{UserBooking::COL_BOOKING_ACTION_HISTORY_SN};
            $oldData = ConvertHelper::toJson($oldData, function($items) {
                return ConvertHelper::toArrayCamelCase($items);
            });

            #region Generate transactions
            $userBookingTransactionService = app(UserBookingTransactionService::class);
            $userBookingSn = $userBooking->{UserBooking::COL_SN};
            $staffSn = $this->option('staffSn');
            $transferTime = $transferTime ?? Carbon::now()->toDateTimeString();
            $generateUserBookingTransactionInputDTO = new GenerateUserBookingTransactionInputDTO([
                'userBookingSn' => $userBookingSn,
                'oldData'       => $oldData,
                'newData'       => $newData,
                'staffSn'       => $staffSn,
                'transferTime'  => $transferTime,
            ]);
            $isInserted = $userBookingTransactionService->store($generateUserBookingTransactionInputDTO);
            if ($isInserted) {
                $this->line("Done.");
            }
            #endregion
        } else {
            $this->line("This booking already have transactions!");
        }

        return 0;
    }
}
