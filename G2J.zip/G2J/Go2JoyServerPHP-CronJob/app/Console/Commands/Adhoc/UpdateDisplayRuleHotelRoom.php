<?php


namespace App\Console\Commands\Adhoc;


use App\Constants\Hotel as HotelConst;
use App\Models\Hotel;
use App\Services\Common\RoomTypeService;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;

class UpdateDisplayRuleHotelRoom extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'adhoc:update-display-rule-hotel-room';


    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Update price for room and hotel available';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    public function handle()
    {
        $roomTypeService = app(RoomTypeService::class);
        $query = DB::table(Hotel::TABLE_NAME)
            ->where(Hotel::COL_ORIGIN, HotelConst::ORIGIN['GO2JOY']);

        $hotelSnList = $query->pluck(Hotel::COL_SN)->all();
        foreach ($hotelSnList as $hotelSn) {
            $roomTypeService->_updateGiftBonusHourForHotel($hotelSn);
            $roomTypeService->updateLowestPriceForHotel($hotelSn);
        }
    }
}