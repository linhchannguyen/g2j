<?php

namespace App\Console\Commands\Adhoc;

use App\Constants\Globals\Slack;
use App\Constants\MileageHistory as MileageHistoryConst;
use App\Constants\MileageReward as MileageRewardConst;
use App\Constants\Setting as SettingConst;
use App\Constants\UserBooking as UserBookingConst;
use App\Helpers\CommonHelper;
use App\Helpers\GenerateHelper;
use App\Helpers\LoggingHelper;
use App\Models\AppUser;
use App\Models\MileageHistory;
use App\Models\MileageReward;
use App\Models\MileageTarget;
use App\Models\Setting;
use App\Models\UserBooking;
use Carbon\Carbon;
use Illuminate\Console\Command;

class AdjustMileagePointDeficiency extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'adhoc:adjust-mileage-point-deficiency
                            {--userBookingSnList=}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Adjust Mileage Point deficiency by booking (Missing x3% when pay in advance)';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        $userBookingSnList = $this->option('userBookingSnList');
        $userBookingSnList = explode(',', $userBookingSnList);
        $userBookingSnList = array_filter($userBookingSnList);
        $userBookingSnList = array_map('intval', $userBookingSnList);

        foreach ($userBookingSnList as $userBookingSn) {
            $mileageHistory = MileageHistory::where(MileageHistory::COL_USER_BOOKING_SN, $userBookingSn)->first();
            if (!empty($mileageHistory)) {
                $userBooking = UserBooking::where(UserBooking::COL_SN, $userBookingSn)->first();
                $mileageRewardSn = $mileageHistory->{MileageHistory::COL_MILEAGE_REWARD_SN};
                if (empty($mileageRewardSn)) {
                    # region Recalculate num of point
                    $numPoint = 10;
                    $amountFromUser = $userBooking->{UserBooking::COL_AMOUNT_FROM_USER};
                    $newNumOfPoint = ($amountFromUser / MileageRewardConst::MONEY_UNIT_DEFAULT) * $numPoint;
                    $prepayAmount = $userBooking->{UserBooking::COL_PREPAY_AMOUNT};
                    if ($prepayAmount > 0) {
                        $newNumOfPoint = (int)($newNumOfPoint * MileageRewardConst::COEFFICIENT_PAY_IN_ADVANCE);
                    }
                    # endregion Recalculate num of point

                    $currNumOfPoint = $mileageHistory->{MileageHistory::COL_NUM_OF_POINT};

                    #region Process mismatch num of point
                    if ($currNumOfPoint != $newNumOfPoint) {
                        $amountPointDeficiency = $newNumOfPoint - $currNumOfPoint;

                        // Update app user mileage point
                        $appUserSn = $userBooking->{UserBooking::COL_APP_USER_SN};
                        $appUser = AppUser::where(AppUser::COL_SN, $appUserSn)->first();
                        $mileageEarned = $appUser->{AppUser::COL_MILEAGE_EARNED};
                        $appUser->{AppUser::COL_MILEAGE_EARNED} = $mileageEarned + $amountPointDeficiency;
                        $appUser->save();

                        // Update mileage history
                        $mileageHistory->{MileageHistory::COL_NUM_OF_POINT} = $newNumOfPoint;
                        $mileageHistory->save();

                        // Logging
                        $message = sprintf("APP_USER:\n `SN = %s`\n `MILEAGE_EARNED [OLD] = %s`\n `MILEAGE_EARNED [NEW] = %s`\n MILEAGE_HISTORY:\n `SN = %s`\n `NUM_OF_POINT [OLD] = %s\n `NUM_OF_POINT [NEW] = %s\n", $appUserSn, $mileageEarned, $mileageEarned + $amountPointDeficiency, $mileageHistory->{MileageHistory::COL_SN}, $currNumOfPoint, $newNumOfPoint);
                        $logMessage = GenerateHelper::logMessage('info', self::class, $message);
                        LoggingHelper::toSlack(Slack::CHANNEL['ADHOC_MONITOR'], $logMessage);
                    }
                    #endregion Process mismatch num of point
                } else {
                    $mileageReward = MileageReward::where(MileageReward::COL_SN, $mileageRewardSn)->first();
                    if (!empty($mileageReward)) {
                        # region Recalculate num of point
                        $numPoint = intval($mileageReward->{MileageReward::COL_NUM_POINT});
                        $amountFromUser = $userBooking->{UserBooking::COL_AMOUNT_FROM_USER};
                        $newNumOfPoint = ($amountFromUser / MileageRewardConst::MONEY_UNIT_DEFAULT) * $numPoint;
                        $prepayAmount = $userBooking->{UserBooking::COL_PREPAY_AMOUNT};
                        if ($prepayAmount > 0) {
                            $newNumOfPoint = (int)($newNumOfPoint * MileageRewardConst::COEFFICIENT_PAY_IN_ADVANCE);
                        }
                        # endregion Recalculate num of point

                        $currNumOfPoint = $mileageHistory->{MileageHistory::COL_NUM_OF_POINT};

                        #region Process mismatch num of point
                        if ($currNumOfPoint != $newNumOfPoint) {
                            $amountPointDeficiency = $newNumOfPoint - $currNumOfPoint;

                            // Update app user mileage point
                            $appUserSn = $userBooking->{UserBooking::COL_APP_USER_SN};
                            $appUser = AppUser::where(AppUser::COL_SN, $appUserSn)->first();
                            $mileageEarned = $appUser->{AppUser::COL_MILEAGE_EARNED};
                            $appUser->{AppUser::COL_MILEAGE_EARNED} = $mileageEarned + $amountPointDeficiency;
                            $appUser->save();

                            // Update mileage history
                            $mileageHistory->{MileageHistory::COL_NUM_OF_POINT} = $newNumOfPoint;
                            $mileageHistory->save();

                            // Logging
                            $message = sprintf("APP_USER:\n `SN = %s`\n `MILEAGE_EARNED [OLD] = %s`\n `MILEAGE_EARNED [NEW] = %s`\n MILEAGE_HISTORY:\n `SN = %s`\n `NUM_OF_POINT [OLD] = %s\n `NUM_OF_POINT [NEW] = %s\n", $appUserSn, $mileageEarned, $mileageEarned + $amountPointDeficiency, $mileageHistory->{MileageHistory::COL_SN}, $currNumOfPoint, $newNumOfPoint);
                            $logMessage = GenerateHelper::logMessage('info', self::class, $message);
                            LoggingHelper::toSlack(Slack::CHANNEL['ADHOC_MONITOR'], $logMessage);
                        }
                        #endregion Process mismatch num of point
                    }
                }
            }
        }
    }
}
