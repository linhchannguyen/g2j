<?php

namespace App\Console\Commands\Adhoc;

use App\Constants\AppUser as AppUserConst;
use App\Constants\Setting as SettingConst;
use App\Constants\StampIssued as StampIssuedConst;
use App\Helpers\CommonHelper;
use App\Models\AppUser;
use App\Models\RegisterStamp;
use App\Models\Setting;
use App\Models\StampIssued;
use App\Models\UserBooking;
use App\Models\UserStamp;
use App\Repositories\Interfaces\RegisterStampRepositoryInterface;
use App\Repositories\Interfaces\UserBookingRepositoryInterface;
use App\Repositories\Interfaces\UserStampRepositoryInterface;
use Illuminate\Console\Command;
use Illuminate\Support\Carbon;

class BalanceStamp extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'adhoc:balance-stamp
                            {--appUserSnList=}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Balance stamp for user. Case: not received after check-in booking';

    /** @var int */
    const LIMIT = 500;

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        $appUserSnList = $this->option('appUserSnList');
        $appUserSnList = explode(',', $appUserSnList);
        $appUserSnList = array_filter($appUserSnList);
        $appUserSnList = array_map('intval', $appUserSnList);

        if (empty($appUserSnList)) {
            $appUserSnList = AppUser::where(AppUser::COL_STATUS, AppUserConst::STATUS['ACTIVE'])->limit(self::LIMIT)->get([AppUser::COL_SN]);
            $appUserSnList = $appUserSnList->pluck(AppUser::COL_SN)->toArray();
        }

        foreach ($appUserSnList as $appUserSn) {
            $this->_balanceStamp($appUserSn);
        }
    }

    /**
     * @param string|int $appUserSn
     */
    private function _balanceStamp($appUserSn)
    {
        $userBookingRepository = app(UserBookingRepositoryInterface::class);
        $registerStampRepository = app(RegisterStampRepositoryInterface::class);
        $userStampRepository = app(UserStampRepositoryInterface::class);
        $userBookingNotReceivedStampList = $userBookingRepository->findNotReceivedStamp($appUserSn);
        foreach ($userBookingNotReceivedStampList as $userBookingNotReceivedStamp) {
            $userBookingSn = $userBookingNotReceivedStamp->{UserBooking::COL_SN};
            $hotelSn = $userBookingNotReceivedStamp->{UserBooking::COL_HOTEL_SN};
            $registerStamp = $registerStampRepository->findRegisterStampViaHotelSn($hotelSn, true);
            $registerStampSn = $registerStamp->{RegisterStamp::COL_SN};
            $numStampActive = $registerStamp->{RegisterStamp::COL_NUM_STAMP_ACTIVE};

            $setting = CommonHelper::getHotelSetting(SettingConst::COMMON_TYPE['STAMP'], SettingConst::CLASS_NO['01']);
            $numberOfExpireMonths = intval($setting->{Setting::COL_NUMDATA1});
            $expireDate = Carbon::now()->addMonths($numberOfExpireMonths)->startOfDay()->format('Y-m-d');

            // Add stamp issued had been missed
            $stampIssued = new StampIssued();
            $stampIssued->{StampIssued::COL_HOTEL_SN} = $hotelSn;
            $stampIssued->{StampIssued::COL_APP_USER_SN} = $appUserSn;
            $stampIssued->{StampIssued::COL_USER_BOOKING_SN} = $userBookingSn;
            $stampIssued->{StampIssued::COL_STATUS} = StampIssuedConst::STATUS['ACTIVE'];
            $stampIssued->{StampIssued::COL_REGISTER_STAMP_SN} = $registerStampSn;
            $stampIssued->{StampIssued::COL_EXPIRE_DATE} = $expireDate;
            $stampIssued->save();

            // Update num of stamp active in USER_STAMP table
            $userStamp = $userStampRepository->findUserStamp($hotelSn, $appUserSn);
            $userStampSn = $userStamp->{UserStamp::COL_SN};
            $numOfStampActive = $userStamp->{UserStamp::COL_NUM_STAMP_ACTIVE};
            $userStampRepository->updateWhere([
                UserStamp::COL_NUM_STAMP_ACTIVE => $numOfStampActive + 1
            ], [UserStamp::COL_SN => $userStampSn]);

            // Update num of stamp active in REGISTER_STAMP table
            $registerStampRepository->updateWhere([
                RegisterStamp::COL_NUM_STAMP_ACTIVE => $numStampActive + 1
            ], [RegisterStamp::COL_SN => $registerStampSn]);
        }
    }
}
