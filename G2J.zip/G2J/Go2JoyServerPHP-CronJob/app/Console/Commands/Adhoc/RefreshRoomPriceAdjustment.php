<?php

namespace App\Console\Commands\Adhoc;

use App\Services\Web\SA\RoomTypeService;
use Illuminate\Console\Command;

class RefreshRoomPriceAdjustment extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'adhoc:refresh-room-price-adjustment
                            {--roomTypeSnList=}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Refresh room price adjustment';

    protected $roomTypeService;

    /**
     * RefreshInstantLockMissedOut constructor.
     */
    public function __construct(RoomTypeService $roomTypeService)
    {
        parent::__construct();
        $this->roomTypeService = $roomTypeService;
    }

    /**
     * Execute the console command.
     *
     * @return void
     */
    public function handle()
    {
        $roomTypeSnList = $this->option('roomTypeSnList');
        $roomTypeSnList = explode(',', $roomTypeSnList);
        $roomTypeSnList = array_filter($roomTypeSnList);
        $roomTypeSnList = array_map('intval', $roomTypeSnList);
        foreach ($roomTypeSnList as $roomTypeSn) {
            $this->roomTypeService->refreshRoomPriceToday($roomTypeSn);
        }
    }
}