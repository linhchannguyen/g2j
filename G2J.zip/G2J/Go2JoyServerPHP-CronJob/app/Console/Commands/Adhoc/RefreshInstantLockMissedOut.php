<?php

namespace App\Console\Commands\Adhoc;

use App\Constants\Globals\QueueName;
use App\Constants\InstantLock as InstantLockConst;
use App\Constants\RoomType as RoomTypeConst;
use App\Jobs\ElasticSearch\SyncHotelLockedJob;
use App\Models\InstantLock;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;

class RefreshInstantLockMissedOut extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'adhoc:refresh-instant-lock-missed-out
                            {--hotelSn=}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Refresh instant lock have been missed out';

    /**
     * RefreshInstantLockMissedOut constructor.
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return void
     */
    public function handle()
    {
        $hotelSn = $this->option('hotelSn');

        $query = DB::table("INSTANT_LOCK")
            ->where('STATUS', '=', InstantLockConst::STATUS['LOCK']);

        if (!empty($hotelSn)) {
            $query->where("HOTEL_SN", $hotelSn);
        }

        $instantLockList = $query->get([
            "SN",
            "HOTEL_SN",
            "ROOM_TYPE_SN",
        ]);

        foreach ($instantLockList as $instantLock) {
            DB::table("INSTANT_LOCK")->where("SN", $instantLock->SN)->update([
                "STATUS"                 => InstantLockConst::STATUS['UNLOCK'],
                "NUMBER_OF_ROOM_LEFT"    => null,
                "NUMBER_OF_ROOM_INITIAL" => null,
                "CREATED_BY"             => null,
                "UPDATED_BY"             => null,
                "CREATE_TIME"            => null,
                "LAST_UPDATE"            => null,
            ]);

            DB::table("INSTANT_LOCK_HISTORY")->insert([
                'INSTANT_LOCK_SN'     => $instantLock->SN,
                'STATUS'              => InstantLockConst::STATUS['UNLOCK'],
                'NUMBER_OF_ROOM_LEFT' => null,
                'CREATED_BY'          => null,
            ]);

            DB::table("ROOM_TYPE")->where("SN", $instantLock->ROOM_TYPE_SN)
                ->where('STATUS', '!=', RoomTypeConst::STATUS['DELETED'])
                ->update([
                    "STATUS" => RoomTypeConst::STATUS['ACTIVE'],
                ]);

            $syncHotelLockedJob = new SyncHotelLockedJob(json_encode([
                'hotelSn'    => $instantLock->{InstantLock::COL_HOTEL_SN},
                'roomTypeSn' => $instantLock->{InstantLock::COL_ROOM_TYPE_SN},
            ]));
            dispatch($syncHotelLockedJob)->onQueue(QueueName::HOTEL_LOCKED_SYNCING);
        }
    }
}
