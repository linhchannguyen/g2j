<?php

namespace App\Console\Commands\Adhoc;

use App\Constants\Globals\QueueName;
use App\Constants\Globals\Slack;
use App\Constants\Setting as SettingConst;
use App\Helpers\CommonHelper;
use App\Helpers\GenerateHelper;
use App\Helpers\LoggingHelper;
use App\Jobs\Integration\Agoda\UpdateBookingStatusCheckInAgodaJobV2;
use App\Models\Setting;
use App\Models\UserBooking;
use Carbon\Carbon;
use Exception;
use Illuminate\Console\Command;

class RecoverAutoCheckInAgodaBookingJob extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'adhoc:recover-auto-check-in-agoda-booking-job {--userBookingSnList=}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Recover auto checkin Agoda booking';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return void
     * @throws Exception
     */
    public function handle()
    {
        $userBookingSnList = $this->option('userBookingSnList');
        $userBookingSnList = explode(',', $userBookingSnList);
        $userBookingSnList = array_filter($userBookingSnList);
        $userBookingSnList = array_map('intval', $userBookingSnList);

        foreach ($userBookingSnList as $userBookingSn) {
            $userBooking = UserBooking::where(UserBooking::COL_SN, $userBookingSn)->first();
            $setting = CommonHelper::getHotelSetting(SettingConst::COMMON_TYPE['INTEGRATION'], SettingConst::CLASS_NO['01'], $userBooking->{UserBooking::COL_HOTEL_SN});
            $checkInDatePlan = Carbon::parse($userBooking->{UserBooking::COL_CHECK_IN_DATE_PLAN})->timestamp;
            $now = Carbon::now()->timestamp;
            $checkInTime = Carbon::parse($userBooking->{UserBooking::COL_CHECK_IN_DATE_PLAN} . ' ' . $setting->{Setting::COL_CHARDATA1});
            if ($checkInDatePlan < $now) {
                $jobCheckIn = new UpdateBookingStatusCheckInAgodaJobV2($userBookingSn, $checkInTime->toDateTimeString());
                dispatch($jobCheckIn->onQueue(QueueName::BACK_GROUND));
            } else {
                $checkInTimeInMinutes = 1; // 1 Minute
                if ($checkInTime->isAfter(Carbon::now())) {
                    $checkInTimeInMinutes = $checkInTime->diffInMinutes(Carbon::now());
                }
                $jobCheckIn = new UpdateBookingStatusCheckInAgodaJobV2($userBooking->{UserBooking::COL_SN});
                dispatch($jobCheckIn->onQueue(QueueName::BACK_GROUND)->delay(Carbon::now()->addMinutes($checkInTimeInMinutes)));
            }

            LoggingHelper::logFunction("Log userBookingSn auto check-in Agoda: $userBookingSn");
        }
        $logMessage = GenerateHelper::logMessage('info', self::class, 'All done!');
        LoggingHelper::toSlack(Slack::CHANNEL['SCHEDULE_MONITOR'], $logMessage);
    }
}
