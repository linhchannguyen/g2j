<?php

namespace App\Console\Commands\Adhoc;

use App\API\External\Integration\Agoda\AgodaProcessor;
use App\Constants\MongoDB\AgodaHotel as AgodaHotelConst;
use App\Constants\Partners\Agoda as AgodaConst;
use App\DTOs\Integration\Agoda\FetchHotelInputDTO;
use App\DTOs\Integration\Agoda\GetHotelDetailInputDTO;
use App\Models\MongoDB\AgodaHotel;
use Exception;
use Illuminate\Console\Command;
use Illuminate\Support\Carbon;

class GetAgodaHotelHaveRoomToday extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'adhoc:get-agoda-hotel-have-room-today
                            {--checkIn=}
                            {--checkOut=}
                            {--numOfRoom=}
                            {--numOfAdults=}
                            {--numOfChildren=}
                            {--hotelIdList=}
                            {--cityIdList=}
                            {--languageId=}
                            {--currency=}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Get Agoda hotel have room today';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return void
     * @throws Exception
     */
    public function handle()
    {
        $agodaProcessor = new AgodaProcessor(config('agoda.config'));

        $checkIn = $this->option('checkIn');
        $checkIn = $checkIn ? Carbon::parse($checkIn)->format('Y-m-d') : null;

        $checkOut = $this->option('checkOut');
        $checkOut = $checkOut ? Carbon::parse($checkOut)->format('Y-m-d') : null;

        $hotelIdList = $this->option('hotelIdList');
        $hotelIdList = explode(',', $hotelIdList);
        $hotelIdList = array_filter($hotelIdList);
        $hotelIdList = array_map('intval', $hotelIdList);

        $cityIdList = $this->option('cityIdList');
        $cityIdList = explode(',', $cityIdList);
        $cityIdList = array_filter($cityIdList);
        $cityIdList = array_map('intval', $cityIdList);

        $languageId = $this->option('languageId') ?? AgodaConst::LANGUAGE_ID['VIETNAMESE'];
        $currency = $this->option('currency') ?? AgodaConst::CURRENCY_CODE['VIETNAMESE_DONG'];

        $numOfRoom = $this->option('numOfRoom') ?? null;
        $numOfAdults = $this->option('numOfAdults') ?? null;
        $numOfChildren = $this->option('numOfChildren') ?? null;

        // Filter hotel list with list of hotel sn from input
        $partnerHotelIdList = [];
        if (!empty($cityIdList)) {
            foreach ($cityIdList as $cityId) {
                $fetchHotelInputDTO = new FetchHotelInputDTO();
                $fetchHotelInputDTO->setCityId($cityId);
                $fetchHotelInputDTO->setAreaId(AgodaConst::ALL);
                $fetchHotelInputDTO->setHotelId(AgodaConst::ALL);
                $fetchHotelInputDTO->setLanguageId($languageId);
                $fetchHotelInputDTO->setCurrency($currency);

                // Get hotel list from Agoda
                $fetchHotelOutputDTO = $agodaProcessor->fetchHotel($fetchHotelInputDTO);
                $hotelList = $fetchHotelOutputDTO->getHotelList();

                foreach ($hotelList as $hotel) {
                    $partnerHotelId = intval($hotel['hotelId']);
                    $partnerHotelIdList[] = $partnerHotelId;
                }
            }
        } else {
            if (!empty($hotelIdList)) {
                $partnerHotelIdList = AgodaHotel::where(AgodaHotel::FIELD_STATUS, AgodaHotelConst::STATUS['ACTIVE'])
                    ->whereNotNull(AgodaHotel::FIELD_HOTEL_SN)
                    ->whereIn(AgodaHotel::FIELD_PARTNER_HOTEL_ID, $hotelIdList)
                    ->get([AgodaHotel::FIELD_PARTNER_HOTEL_ID])
                    ->pluck(AgodaHotel::FIELD_PARTNER_HOTEL_ID)
                    ->toArray();
            }
        }

        $result = [];
        foreach ($partnerHotelIdList as $partnerHotelId) {
            $partnerHotelId = intval($partnerHotelId);
            $rangeTime = strtotime('+1 day');
            $currentTime = Carbon::now()->timestamp;
            while ($currentTime < $rangeTime) {
                $getHotelDetailInputDTO = new GetHotelDetailInputDTO();
                $getHotelDetailInputDTO->setHotelIdList([$partnerHotelId]);

                if (!empty($numOfRoom)) {
                    $getHotelDetailInputDTO->setNumOfRoom($numOfRoom);
                }
                if (!empty($numOfAdults)) {
                    $getHotelDetailInputDTO->setNumOfAdults($numOfAdults);
                }
                if (!empty($numOfChildren)) {
                    $getHotelDetailInputDTO->setNumOfChildren($numOfChildren);
                }

                if (!empty($checkIn) && !empty($checkOut)) {
                    $getHotelDetailInputDTO->setCheckIn($checkIn);
                    $getHotelDetailInputDTO->setCheckOut($checkOut);
                } else {
                    $getHotelDetailInputDTO->setCheckIn(Carbon::parse($currentTime)->setTimezone(config('app.timezone'))->format('Y-m-d'));
                    $getHotelDetailInputDTO->setCheckOut(Carbon::parse($currentTime)->setTimezone(config('app.timezone'))->addDay()->format('Y-m-d'));
                }
                $getHotelDetailOutputDTO = $agodaProcessor->getHotelDetail($getHotelDetailInputDTO);
                $searchResponse = $getHotelDetailOutputDTO->getSearchResponse();
                if (empty($searchResponse->getErrorMessage())) {
                    $result[] = json_decode(json_encode($searchResponse->getRawData()), true);
                }

                $currentTime = strtotime('+1 day', $currentTime);
            }
        }
        print_r(json_encode($result));
    }
}
