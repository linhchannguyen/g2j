<?php

namespace App\Console\Commands\Adhoc;

use App\Constants\StampIssued as StampIssuedConst;
use App\Constants\UserBooking as UserBookingConst;
use App\Models\RegisterStamp;
use App\Models\StampIssued;
use App\Models\UserBooking;
use App\Models\UserStamp;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;

class RefundStamp extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'adhoc:refund-stamp
                            {--userBookingSnList=}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Refund stamp for user booking no stamp earned';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        $userBookingSnList = $this->option('userBookingSnList');
        $userBookingSnList = explode(',', $userBookingSnList);
        $userBookingSnList = array_filter($userBookingSnList);
        $userBookingSnList = array_map('intval', $userBookingSnList);

        foreach ($userBookingSnList as $userBookingSn) {
            $userBooking = UserBooking::where(UserBooking::COL_SN, $userBookingSn)
                ->where(UserBooking::COL_BOOKING_STATUS, UserBookingConst::BOOKING_STATUS['CANCELLED'])
                ->whereIn(UserBooking::COL_VIA_OBJECT, [UserBookingConst::VIA_OBJECT['USER'], UserBookingConst::VIA_OBJECT['HOTEL'], UserBookingConst::VIA_OBJECT['GO2JOY']])
                ->first();
            $redeemValue = $userBooking->{UserBooking::COL_REDEEM_VALUE} ?? 0;
            if ($redeemValue > 0) {
                $hotelSn = $userBooking->{UserBooking::COL_HOTEL_SN};
                $appUserSn = $userBooking->{UserBooking::COL_APP_USER_SN};
                $stampIssuedList = StampIssued::where(StampIssued::COL_USE_FOR_BOOKING_SN, $userBookingSn)
                    ->groupBy(StampIssued::COL_REGISTER_STAMP_SN)
                    ->get([StampIssued::COL_REGISTER_STAMP_SN]);
                $numOfRegisterStampSn = count($stampIssuedList);
                if ($numOfRegisterStampSn == 1) {
                    $registerStampSn = $stampIssuedList->first()->{StampIssued::COL_REGISTER_STAMP_SN};
                    $registerStamp = RegisterStamp::where(RegisterStamp::COL_SN, $registerStampSn)->first();
                    $numToRedeem = $registerStamp->{RegisterStamp::COL_NUM_TO_REDEEM};
                    $stampIssuedNeedRefundList = StampIssued::where(StampIssued::COL_USE_FOR_BOOKING_SN, $userBookingSn)
                        ->orderByDesc(StampIssued::COL_LAST_UPDATE)
                        ->limit($numToRedeem)
                        ->get();
                    $stampIssuedSnNeedRefundList = $stampIssuedNeedRefundList->pluck(StampIssued::COL_SN)->toArray();

                    // Refund stamp issued
                    StampIssued::whereIn(StampIssued::COL_SN, $stampIssuedSnNeedRefundList)
                        ->update([
                            StampIssued::COL_STATUS             => StampIssuedConst::STATUS['ACTIVE'],
                            StampIssued::COL_USE_FOR_BOOKING_SN => null,
                        ]);

                    // Recover user stamp values
                    UserStamp::where(UserStamp::COL_HOTEL_SN, $hotelSn)
                        ->where(UserStamp::COL_APP_USER_SN, $appUserSn)
                        ->update([
                            UserStamp::COL_NUM_STAMP_ACTIVE => DB::raw(UserStamp::COL_NUM_STAMP_ACTIVE . ' + ' . $numToRedeem),
                            UserStamp::COL_NUM_STAMP_USED   => DB::raw(UserStamp::COL_NUM_STAMP_USED . ' - ' . $numToRedeem),
                            UserStamp::COL_TOTAL_REDEEM     => DB::raw(UserStamp::COL_TOTAL_REDEEM . ' - ' . 1),
                        ]);
                }
                $this->error("This booking with SN = $userBookingSn had redeemed stamp exceed 1 stamp program!");
            }
        }
    }
}
