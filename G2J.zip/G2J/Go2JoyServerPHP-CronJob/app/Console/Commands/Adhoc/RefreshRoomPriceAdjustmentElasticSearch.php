<?php

namespace App\Console\Commands\Adhoc;

use App\Providers\GuzzleClientServiceProvider;
use App\Repositories\Interfaces\RoomPriceAdjustmentRepositoryInterface;
use App\Services\Web\SA\RoomTypeService;
use Illuminate\Console\Command;

class RefreshRoomPriceAdjustmentElasticSearch extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'adhoc:refresh-room-price-adjustment-elastic-search';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Refresh Room Price Adjustment ElasticSearch';

    protected $roomPriceAdjustmentRepository;

    /**
     * RefreshInstantLockMissedOut constructor.
     */
    public function __construct(RoomPriceAdjustmentRepositoryInterface $roomPriceAdjustmentRepository)
    {
        parent::__construct();
        $this->roomPriceAdjustmentRepository = $roomPriceAdjustmentRepository;
    }

    /**
     * Execute the console command.
     *
     * @return void
     */
    public function handle()
    {
        $roomTypeList = $this->roomPriceAdjustmentRepository->findAllRoomPriceAdjustmentMigration();
        $roomTypeSnList = $roomTypeList->pluck('SN')->toArray();
        $headers = [
            'Content-Type'  => 'application/json',
            'Cache-Control' => 'no-cache',
            'Authorization' => 'Basic ' . config('elasticsearch.go.auth'),
        ];
        $options = [
            'base_uri' => config('elasticsearch.go.host'),
            'headers'  => $headers,
        ];

        $client = app('GuzzleClient', [
            'service' => GuzzleClientServiceProvider::SERVICE['ELASTIC_SEARCH'],
        ])($options);
        $body = json_encode([
            "query" => [
                "bool" => [
                    "must_not" => [
                        [
                            "terms" => [
                                "roomTypeSn" => $roomTypeSnList,
                            ],
                        ],

                    ],
                ],

            ],
        ]);
        $client->request(
            'POST',
            'go2joy_hotel_all_days_price/_delete_by_query?refresh',
            [
                'body' => $body,
            ]
        );
    }
}