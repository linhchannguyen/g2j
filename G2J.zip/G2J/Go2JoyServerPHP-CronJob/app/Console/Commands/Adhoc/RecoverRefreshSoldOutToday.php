<?php

namespace App\Console\Commands\Adhoc;

use App\Constants\RoomType as RoomTypeConst;
use App\Models\HotelDisplayRule;
use App\Models\RoomType;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;

class RecoverRefreshSoldOutToday extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'adhoc:recover-refresh-sold-out-today';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Recover refresh sold out today';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        $roomTypeList = DB::table(RoomType::TABLE_NAME)
            ->where(RoomType::COL_STATUS, RoomTypeConst::STATUS['ACTIVE'])
            ->where(RoomType::COL_MODE, RoomTypeConst::MODE['NORMAL'])
            ->groupBy(RoomType::COL_HOTEL_SN)
            ->select([
                RoomType::COL_SN,
                RoomType::COL_HOTEL_SN,
                RoomType::COL_STATUS,
                DB::raw('IF(FIRST_HOURS > 0, 0, 1) AS HOURLY'),
                DB::raw('IF(PRICE_OVERNIGHT > 0, 0, 1) AS OVERNIGHT'),
                DB::raw('IF(PRICE_ONE_DAY > 0, 0, 1) AS DAILY'),
            ])
            ->get();

        foreach ($roomTypeList as $roomType) {
            $hotelSn = $roomType->{RoomType::COL_HOTEL_SN};
            $hourly = $roomType->HOURLY;
            $overnight = $roomType->OVERNIGHT;
            $daily = $roomType->DAILY;
            $hotelDisplayRule = DB::table(HotelDisplayRule::TABLE_NAME)
                ->where(HotelDisplayRule::COL_HOTEL_SN, $hotelSn)
                ->orWhere(HotelDisplayRule::SOLD_OUT_TODAY_HOURLY, '!=', $hourly)
                ->orWhere(HotelDisplayRule::SOLD_OUT_TODAY_DAILY, '!=', $daily)
                ->orWhere(HotelDisplayRule::SOLD_OUT_TODAY_OVERNIGHT, '!=', $overnight)
                ->first();
            if (!empty($hotelDisplayRule)) {
                DB::table(HotelDisplayRule::TABLE_NAME)
                    ->where(HotelDisplayRule::COL_HOTEL_SN, $hotelSn)
                    ->update([
                        HotelDisplayRule::SOLD_OUT_TODAY_HOURLY => $hourly,
                        HotelDisplayRule::SOLD_OUT_TODAY_DAILY => $daily,
                        HotelDisplayRule::SOLD_OUT_TODAY_OVERNIGHT => $overnight,
                    ]);
            }
        }
    }
}
