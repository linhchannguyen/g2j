<?php

namespace App\Console\Commands\Adhoc;

use App\Services\Mobile\HotelDisplayRuleService;
use Illuminate\Console\Command;

class RefreshHotelAvailable extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'adhoc:refresh-hotel-available
                            {--hotelSn=}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Refresh Hotel Available';

    /**
     * @var HotelDisplayRuleService
     */
    protected $hotelDisplayRuleService;

    /**
     * RefreshHotelAvailable constructor.
     *
     * @param HotelDisplayRuleService $hotelDisplayRuleService
     */
    public function __construct(HotelDisplayRuleService $hotelDisplayRuleService)
    {
        parent::__construct();
        $this->hotelDisplayRuleService = $hotelDisplayRuleService;
    }

    /**
     * Execute the console command.
     *
     * @return void
     */
    public function handle()
    {
        $hotelSn = $this->option('hotelSn');
        $this->hotelDisplayRuleService->refreshHotelAvailableJob($hotelSn);
    }
}
