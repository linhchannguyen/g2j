<?php

namespace App\Console\Commands\Adhoc;

use App\Helpers\ConvertHelper;
use App\Helpers\LoggingHelper;
use App\Providers\GuzzleClientServiceProvider;
use Exception;
use Illuminate\Console\Command;

class RestoreUserLocationElasticSearch extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'restore-user-location-elastic-search';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Cron job for insert multiple to elastic search';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    public function handle()
    {
        $addressCanNotGeocoding = $this->getUserLocationCanNotGeocoding();
        foreach ($addressCanNotGeocoding as $addressCannot) {
            $location = $addressCannot['_source']['location'];
            $addressResult = ConvertHelper::handleAddress("", $location['lat'], $location['lon'], null, true, false);
            $this->updateUserLocationCanNotGeocoding($addressCannot['_id'], $addressResult, $location['lat'], $location['lon']);
        }

    }

    public function getUserLocationCanNotGeocoding()
    {
        $addressCanNotGeocoding = [];
        try {
            $headers = [
                'Content-Type'  => 'application/json',
                'Cache-Control' => 'no-cache',
                'Authorization' => 'Basic ' . config('elasticsearch.auth'),
            ];
            $options = [
                'base_uri' => config('elasticsearch.host'),
                'headers'  => $headers,
                'timeout'  => 1,
            ];

            $client = app('GuzzleClient', [
                'service' => GuzzleClientServiceProvider::SERVICE['ELASTIC_SEARCH'],
            ])($options);

            $dataJson = json_encode([
                "query" => [
                    "bool" => [
                        "must" => [
                            [
                                "match" => [
                                    "canNotGeocoding" => true,

                                ],
                            ], [
                                "match" => [
                                    "internalLocation" => true,
                                ],
                            ],

                        ],
                    ],
                ],
                "size"  => 5000,
            ]);

            $responseUserLocation = $client->request(
                'GET',
                'go2joy_user_location/_search',
                [
                    'body' => $dataJson . "\n",
                ]
            );
            $resultUserLocation = (string)$responseUserLocation->getBody() ? json_decode((string)$responseUserLocation->getBody(), true) : [];
            if (isset($resultUserLocation['hits']['hits'])) {
                $addressCanNotGeocoding = $resultUserLocation['hits']['hits'];
            }
        } catch (Exception $exception) {
            LoggingHelper::logException($exception);
        }

        return $addressCanNotGeocoding;
    }

    public function updateUserLocationCanNotGeocoding($id, $addressResult, $latitude, $longitude)
    {
        try {
            $headers = [
                'Content-Type'  => 'application/json',
                'Cache-Control' => 'no-cache',
                'Authorization' => 'Basic ' . config('elasticsearch.auth'),
            ];
            $options = [
                'base_uri' => config('elasticsearch.host'),
                'headers'  => $headers,
            ];

            $client = app('GuzzleClient', [
                'service' => GuzzleClientServiceProvider::SERVICE['ELASTIC_SEARCH'],
            ])($options);
            $dataJson = json_encode([
                'doc' => [
                    'address'          => $addressResult['fullAddress'],
                    'districtSn'       => $addressResult['districtSn'],
                    'districtName'     => $addressResult['districtName'],
                    'provinceName'     => $addressResult['provinceName'],
                    'provinceSn'       => $addressResult['provinceSn'],
                    'canNotGeocoding'  => $addressResult['canNotGeocoding'],
                    'internalLocation' => $addressResult['internalLocation'],
                    'location'         => [
                        'lat' => $latitude,
                        'lon' => $longitude,
                    ],
                ],
            ]);

            $client->request(
                'POST',
                'go2joy_user_location/_update/' . $id,
                [
                    'body' => $dataJson . "\n",
                ]
            );

        } catch (Exception $exception) {
            LoggingHelper::logException($exception);
        }
    }
}