<?php

namespace App\Console\Commands\Adhoc;

use App\API\External\Integration\Agoda\AgodaProcessor;
use App\Constants\Partners\Agoda as AgodaConst;
use App\DTOs\Integration\Agoda\GetHotelDetailInputDTO;
use App\Services\Others\AgodaService;
use Exception;
use Illuminate\Console\Command;

class GetAgodaCancellationPolicy extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'adhoc:get-agoda-cancellation-policy
                           {--hotelId=}
                           {--roomTypeId=}
                           {--checkIn=}
                           {--checkOut=}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Get Agoda cancellation policy';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return void
     * @throws Exception
     */
    public function handle()
    {
        $hotelId = intval($this->option('hotelId'));
        $roomTypeId = $this->option('roomTypeId');
        $checkIn = $this->option('checkIn');
        $checkOut = $this->option('checkOut');

        $agodaProcessor = new AgodaProcessor(config('agoda.config'));
        $getHotelDetailInputDTO = new GetHotelDetailInputDTO();
        $getHotelDetailInputDTO->setHotelIdList([$hotelId]);
        $getHotelDetailInputDTO->setCheckIn($checkIn);
        $getHotelDetailInputDTO->setCheckOut($checkOut);
        $getHotelDetailOutputDTO = $agodaProcessor->getHotelDetail($getHotelDetailInputDTO);
        $searchResponse = $getHotelDetailOutputDTO->getSearchResponse();
        $hotel = current($searchResponse->getHotels());
        $roomList = !empty($hotel) ? $hotel->getMinPriceEachRoomType() : [];
        foreach ($roomList as $room) {
            if ($room->getId() == $roomTypeId) {
                $agodaService= app(AgodaService::class);
                $cancelDescription = $agodaService->getCancelDescriptionAgoda($room, $checkIn);
                print_r($cancelDescription);
                break;
            }
        }
    }
}
