<?php

namespace App\Console\Commands;

use App\Models\MobileDevice;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;

class ReviewIosUUID extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'adhoc:reviewIosUUID';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Review device IOS in database';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        $appVersionList = ['14.14.0','14.14.1','14.14.2','14.14.3','14.14.4','14.14.5','14.14.6','14.14.7','14.14.8','14.14.9',
                            '14.15.0','14.15.1','14.15.2','14.15.3','14.15.4','14.15.5','14.15.6','14.15.7','14.15.8','14.15.9'];
        //$hotelDebtService = app(HotelDebtService::class);
        $deviceList = DB::table(MobileDevice::TABLE_NAME)
            ->where(MobileDevice::COL_OS, 1)
            ->whereIn(MobileDevice::COL_APP_VERSION, $appVersionList)
            ->get();

        foreach ($deviceList as $device) {
            $mktCode2 = $device->MKT_CODE2;

            $resultList = DB::table(MobileDevice::TABLE_NAME)
            ->where(MobileDevice::COL_MKT_CODE2, $mktCode2)
            ->get();

            if (count($resultList) == 2) {
                foreach ($resultList as $result) {
                    $registerTime = $result;
                }
            }
        }
    }
}