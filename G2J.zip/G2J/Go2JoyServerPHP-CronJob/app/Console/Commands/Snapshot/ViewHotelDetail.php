<?php

namespace App\Console\Commands\Snapshot;

use App\Constants\MongoDB\UserAction as UserActionConst;
use App\Helpers\LoggingHelper;
use App\Models\MongoDB\UserAction;
use App\Models\ViewHotelDetailStatistic;
use App\Services\Common\UserActionService;
use Exception;
use Illuminate\Console\Command;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\DB;
use Psr\SimpleCache\InvalidArgumentException;

class ViewHotelDetail extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'snapshot:view-hotel-detail';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Snapshot for view hotel detail';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @throws Exception|InvalidArgumentException
     */
    public function handle()
    {
        $currentTimestamp = Carbon::now()->timestamp;
        $userActionService = app(UserActionService::class);
        $viewHotelDetails = $userActionService->findByEvent(UserActionConst::EVENT['VIEW_HOTEL_DETAIL'], $currentTimestamp);
        $oidFailedList = [];
        foreach ($viewHotelDetails as $viewHotelDetail) {
            $_id = $viewHotelDetail->_id;
            $oid = $_id->{UserAction::FIELD_OBJECT_ID};
            $appUserSn = $_id->{UserAction::FIELD_APP_USER_SN};
            $hotelSn = $_id->{UserAction::FIELD_TARGET_SN};
            $count = $viewHotelDetail->{UserAction::VAR_COUNT};

            $maxAttempts = 3;
            $attempts = 0;
            while ($attempts < $maxAttempts) {
                DB::connection('mysql')->beginTransaction();
                try {
                    $viewHotelDetailStatistic = ViewHotelDetailStatistic::where(ViewHotelDetailStatistic::COL_APP_USER_SN, $appUserSn)
                        ->where(ViewHotelDetailStatistic::COL_HOTEL_SN, $hotelSn)
                        ->first();
                    if (empty($viewHotelDetailStatistic)) {
                        // If not exists, create a new record
                        $viewHotelDetailStatistic = new ViewHotelDetailStatistic();
                        $viewHotelDetailStatistic->{ViewHotelDetailStatistic::COL_APP_USER_SN} = $appUserSn;
                        $viewHotelDetailStatistic->{ViewHotelDetailStatistic::COL_HOTEL_SN} = $hotelSn;
                        $viewHotelDetailStatistic->{ViewHotelDetailStatistic::COL_COUNT} = $count;
                    } else {
                        // Update the count of this record
                        $sn = $viewHotelDetailStatistic->{ViewHotelDetailStatistic::COL_SN};
                        $_count = $viewHotelDetailStatistic->{ViewHotelDetailStatistic::COL_COUNT};
                        $viewHotelDetailStatistic = ViewHotelDetailStatistic::find($sn);
                        $viewHotelDetailStatistic->{ViewHotelDetailStatistic::COL_COUNT} = $_count + $count;
                        $viewHotelDetailStatistic->{ViewHotelDetailStatistic::COL_LAST_UPDATE} = Carbon::now();
                    }
                    $viewHotelDetailStatistic->save();

                    DB::connection('mysql')->commit();

                    // Break the loop if the transaction is successful
                    break;
                } catch (Exception $exception) {
                    // Handle the specific exception, e.g., log the error
                    LoggingHelper::logException($exception);

                    // Rollback the transaction
                    DB::connection('mysql')->rollBack();

                    // Increment the attempts counter
                    $attempts++;

                    // Delay before retrying (if needed)
                    usleep(100000); // 100 milliseconds
                }
            }

            if ($attempts >= $maxAttempts) {
                $oidFailedList[] = $oid;
            }
        }

        if (!$viewHotelDetails->isEmpty()) {
            // Mark records in MongoDB are already snapshot
            $numberOfRecords = $userActionService->turnToSnapshotByEvent(UserActionConst::EVENT['VIEW_HOTEL_DETAIL'], $currentTimestamp);
            if ($numberOfRecords <= 0) {
                $message = "User action turn to snapshot by event ViewHotelDetail failed with timestamp: $currentTimestamp";
                throw new Exception($message);
            }
        }

        if (!empty($oidFailedList)) {
            // Turn off IS_SNAPSHOT which document failed update
            UserAction::whereIn(UserAction::FIELD_OBJECT_ID, $oidFailedList)->update([UserAction::FIELD_IS_SNAPSHOT => UserActionConst::IS_SNAPSHOT['FALSE']]);
        }
    }
}
