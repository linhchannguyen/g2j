<?php

namespace App\Console\Commands\Snapshot;

use App\Constants\MobileDevice as MobileDeviceConst;
use App\Helpers\LoggingHelper;
use App\Models\MongoDB\LogQueueUserAccess;
use App\Models\UserAccess;
use App\Repositories\Interfaces\UserAccessRepositoryInterface;
use App\Services\Common\UserAccessService;
use Carbon\Carbon;
use DateTime;
use Exception;
use Illuminate\Console\Command;
use MongoDB\BSON\UTCDateTime;

class UpdateUserAccess extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'snapshot:update-user-access';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Snapshot for update user access';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @param UserAccessRepositoryInterface $userAccessRepository
     *
     * @throws Exception
     */
    public function handle(UserAccessRepositoryInterface $userAccessRepository)
    {
        $currentTimestamp = Carbon::now()->timestamp;
        $userAccessService = app(UserAccessService::class);
        $userAccessList = $userAccessService->findByCurrentTimestamp($currentTimestamp);
        LoggingHelper::logFunction("UPDATE USER ACCESS", count($userAccessList));
        foreach ($userAccessList as $userAccessDetail) {
            $userAccess[UserAccess::COL_APP_USER_SN] = $userAccessDetail->{LogQueueUserAccess::FIELD_APP_USER_SN};
            $userAccess[UserAccess::COL_MOBILE_DEVICE_SN] = $userAccessDetail->{LogQueueUserAccess::FIELD_MOBILE_DEVICE_SN};
            $userAccess[UserAccess::COL_OS] = $userAccessDetail->{LogQueueUserAccess::FIELD_OS};
            $userAccess[UserAccess::COL_ADDRESS] = $userAccessDetail->{LogQueueUserAccess::FIELD_ADDRESS};
            $userAccess[UserAccess::COL_LATITUDE] = $userAccessDetail->{LogQueueUserAccess::FIELD_LATITUDE};
            $userAccess[UserAccess::COL_LONGITUDE] = $userAccessDetail->{LogQueueUserAccess::FIELD_LONGITUDE};
            $userAccess[UserAccess::COL_PROVINCE_SN] = $userAccessDetail->{LogQueueUserAccess::FIELD_PROVINCE_SN};
            $userAccess[UserAccess::COL_PROVINCE_NAME] = $userAccessDetail->{LogQueueUserAccess::FIELD_PROVINCE_NAME};
            $userAccess[UserAccess::COL_DISTRICT_SN] = $userAccessDetail->{LogQueueUserAccess::FIELD_DISTRICT_SN};
            $userAccess[UserAccess::COL_DISTRICT_NAME] = $userAccessDetail->{LogQueueUserAccess::FIELD_DISTRICT_NAME};
            $userAccess[UserAccess::COL_TYPE] = $userAccessDetail->{LogQueueUserAccess::FIELD_TYPE} ?? MobileDeviceConst::USER_ACCESS['SPLASH_SCREEN'];
            $userAccess[UserAccess::COL_CREATE_TIME] = $userAccessDetail->{LogQueueUserAccess::FIELD_CREATE_TIME};
            $year = Carbon::parse($userAccessDetail->{LogQueueUserAccess::FIELD_CREATE_TIME})->format('Y');
            $userAccessRepository->createUserAccessHistoryByYear($userAccess, $year);
        }

        if (!$userAccessList->isEmpty()) {
            // Mark records in MongoDB are already snapshot
            $numberOfRecords = $userAccessService->turnToSnapshotByCurrentTimestamp($currentTimestamp);
            if ($numberOfRecords <= 0) {
                $message = "User access turn to snapshot by current timestamp failed with timestamp: $currentTimestamp";
                throw new Exception($message);
            }
        }
    }
}