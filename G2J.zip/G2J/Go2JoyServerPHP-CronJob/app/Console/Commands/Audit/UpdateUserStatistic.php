<?php

namespace App\Console\Commands\Audit;

use App\Constants\AppUser as AppUserConst;
use App\Constants\UserStatistic as UserStatisticConst;
use App\Models\AppUser;
use App\Models\MobileDevice;
use App\Models\UserStatistic;
use App\Repositories\Interfaces\AppUserRepositoryInterface;
use App\Repositories\Interfaces\MobileDeviceRepositoryInterface;
use App\Repositories\Interfaces\UserStatisticRepositoryInterface;
use Illuminate\Console\Command;

class UpdateUserStatistic extends Command
{
    const LIMIT = 100;

    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'audit:update-user-statistic';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Update user statistic if mismatch with app user table.';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     */
    public function handle(
        AppUserRepositoryInterface $appUserRepository,
        MobileDeviceRepositoryInterface $mobileDeviceRepository,
        UserStatisticRepositoryInterface $userStatisticRepository
    )
    {
        $appUserListHasNotBeenCounted = $appUserRepository->findAppUserListHasNotBeenCounted();

        $userStatisticList = null;
        foreach ($appUserListHasNotBeenCounted as $appUser) {
            $appUserSn = $appUser->{AppUser::COL_SN};
            $firstProvinceSn = $appUser->{AppUser::COL_FIRST_PROVINCE_SN};
            $registerBy = $appUser->{AppUser::COL_REGISTER_BY};
            $registerTime = $appUser->{AppUser::COL_REGISTER_TIME};
            $status = $appUser->{AppUser::COL_STATUS};
            $mobile = $appUser->{AppUser::COL_MOBILE};
            $nickName = $appUser->{AppUser::COL_NICK_NAME};
            if ($registerBy == AppUserConst::REGISTER_BY['MOBILE_DEVICE']) {
                $mobileDeviceSn = $appUser->{AppUser::COL_MOBILE_DEVICE_SN};
                $mobileDevice = $mobileDeviceRepository->find($mobileDeviceSn, [MobileDevice::COL_OS]);
                $os = $mobileDevice->{MobileDevice::COL_OS};
            } else {
                $os = UserStatisticConst::OS['WEB_BROWSER'];
            }

            $userStatisticList[] = [
                UserStatistic::COL_APP_USER_SN       => $appUserSn,
                UserStatistic::COL_FIRST_PROVINCE_SN => $firstProvinceSn,
                UserStatistic::COL_REGISTER_BY       => $registerBy,
                UserStatistic::COL_REGISTER_TIME     => $registerTime,
                UserStatistic::COL_STATUS            => $status,
                UserStatistic::COL_MOBILE            => $mobile,
                UserStatistic::COL_OS                => $os,
                UserStatistic::COL_NICK_NAME         => $nickName,
            ];

            if (count($userStatisticList) == self::LIMIT) {
                $userStatisticRepository->batchInsert($userStatisticList);
                $userStatisticList = null;
            }
        }

        if (!empty($userStatisticList)) {
            $userStatisticRepository->batchInsert($userStatisticList);
        }
    }
}
