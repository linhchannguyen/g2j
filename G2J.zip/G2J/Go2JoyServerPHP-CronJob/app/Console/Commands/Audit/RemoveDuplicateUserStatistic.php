<?php

namespace App\Console\Commands\Audit;

use App\Models\UserStatistic;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;

class RemoveDuplicateUserStatistic extends Command
{
    const LIMIT = 100;

    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'audit:remove-duplicate-user-statistic';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Remove duplicate user statistic.';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     */
    public function handle()
    {
        $userStatisticDuplicationList = DB::table(UserStatistic::TABLE_NAME)
            ->groupBy(UserStatistic::COL_APP_USER_SN)
            ->havingRaw(DB::raw('COUNT('. UserStatistic::COL_APP_USER_SN .') > 1'))
            ->select([
                UserStatistic::COL_SN,
                UserStatistic::COL_APP_USER_SN,
                UserStatistic::COL_OS,
            ])
            ->cursor();

        $this->output->progressStart($userStatisticDuplicationList->count());
        foreach ($userStatisticDuplicationList as $userStatisticDuplication) {
            $sn = $userStatisticDuplication->{UserStatistic::COL_SN};
            $appUserSn = $userStatisticDuplication->{UserStatistic::COL_APP_USER_SN};
            $os = $userStatisticDuplication->{UserStatistic::COL_OS};
            DB::table(UserStatistic::TABLE_NAME)
                ->where(UserStatistic::COL_SN, '!=', $sn)
                ->where(UserStatistic::COL_APP_USER_SN, $appUserSn)
                ->where(UserStatistic::COL_OS, $os)
                ->delete();
            $this->output->progressAdvance();
        }

        $this->output->progressFinish();
    }
}
