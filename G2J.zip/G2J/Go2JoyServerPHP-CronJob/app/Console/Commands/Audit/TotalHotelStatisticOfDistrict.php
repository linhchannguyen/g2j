<?php

namespace App\Console\Commands\Audit;

use App\Models\District;
use App\Services\Web\SA\DistrictService;
use Illuminate\Console\Command;

class TotalHotelStatisticOfDistrict extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'audit:total-hotel-statistic-of-district';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Adjust total hotel and total contracted of district.';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     */
    public function handle(DistrictService $districtService)
    {
        // Get districts not matching total hotel
        $notMatchingTotalHotelDistricts = $districtService->getNotMatchingTotalHotel();

        // Adjust total hotel of districts
        foreach ($notMatchingTotalHotelDistricts as $district) {
            $districtSn = $district->{District::COL_SN};
            $numOfTotalHotel = $district->{District::VAR_NUM_OF_TOTAL_HOTEL};
            District::where(District::COL_SN, $districtSn)
                ->update([
                    District::COL_TOTAL_HOTEL => $numOfTotalHotel
                ]);
        }

        // Get districts not matching total contracted
        $notMatchingTotalContractedDistricts = $districtService->getNotMatchingTotalContracted();

        // Adjust total contracted of districts
        foreach ($notMatchingTotalContractedDistricts as $district) {
            $districtSn = $district->{District::COL_SN};
            $numOfTotalContracted = $district->{District::VAR_NUM_OF_TOTAL_CONTRACTED};
            District::where(District::COL_SN, $districtSn)
                ->update([
                    District::COL_TOTAL_CONTRACTED => $numOfTotalContracted
                ]);
        }
    }
}
