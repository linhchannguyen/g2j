<?php

namespace App\Console\Commands\Migration;

use App\Constants\Coupon as CouponConst;
use App\Constants\Promotion as PromotionConst;
use App\Models\Coupon;
use App\Models\Promotion;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;

class MigrateTitlePromotion extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'migration:migrate-title-promotion';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Migrate value column TITLE_EN for PROMOTION table.';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return void
     */
    public function handle()
    {
        $promotionList = DB::table('PROMOTION as promotion')
            ->where('promotion.CREATE_TIME', '<', config('go2joy.promotion_phase2_released_time'))
            ->orWhereNull('promotion.CREATE_TIME')
            ->get([
                'promotion.SN',
                'promotion.TITLE',
                'promotion.TITLE_EN',
            ]);
        foreach ($promotionList as $promotion) {
            Promotion::where(Promotion::COL_SN, $promotion->{Promotion::COL_SN})
                ->update([
                    Promotion::COL_TITLE_EN => $promotion->{Promotion::COL_TITLE}
                ]);
        }
    }
}
