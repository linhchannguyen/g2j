<?php

namespace App\Console\Commands\Migration;

use App\Constants\RoomType as RoomTypeConst;
use App\Models\RoomType;
use App\Providers\GuzzleClientServiceProvider;
use App\Repositories\Interfaces\RoomTypeRepositoryInterface;
use Illuminate\Console\Command;
use stdClass;

class TransferBookingTypeAvailableHotelLocked extends Command
{
    const RETRY_ON_CONFLICT = 3;

    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'migration:transfer-booking-type-available-hotel-blocked';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Transfer Booking Type Available Hotel Locked.';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     */
    public function handle(RoomTypeRepositoryInterface $roomTypeRepository)
    {
        $roomTypeList = $roomTypeRepository->findAllRoomPriceOriginMigration();
        foreach ($roomTypeList as $roomType) {
            $roomTypeSn = $roomType->{RoomType::COL_SN};
            $hotelSn = $roomType->{RoomType::COL_HOTEL_SN};
            $hourlyAvailable = $roomType->{RoomType::COL_FIRST_HOURS_ORIGIN} > 0;
            $overnightAvailable = $roomType->{RoomType::COL_OVERNIGHT_ORIGIN} > 0;
            $dailyAvailable = $roomType->{RoomType::COL_ONE_DAY_ORIGIN} > 0;
            $maxNumHour = $roomType->{RoomType::COL_MAX_NUM_HOUR};
            if (is_null($maxNumHour)) {
                if (intval($roomType->{RoomType::COL_ADDITIONAL_ORIGIN}) > 0) {
                    $maxNumHour = 0;
                } else {
                    $maxNumHour = intval($roomType->{RoomType::COL_FIRST_HOURS});
                }
            }
            $this->updateBookingTypeAvailableHotelLocked($hotelSn, $roomTypeSn, json_encode($hourlyAvailable), json_encode($overnightAvailable), json_encode($dailyAvailable), $maxNumHour);
        }
    }

    private function updateBookingTypeAvailableHotelLocked($hotelSn, $roomTypeSn, $hourlyAvailable, $overnightAvailable, $dailyAvailable, $maxNumHour)
    {
        $headers = [
            'Content-Type'  => 'application/json',
            'Cache-Control' => 'no-cache',
            'Authorization' => 'Basic ' . config('elasticsearch.go.auth'),
        ];
        $options = [
            'base_uri' => config('elasticsearch.go.host'),
            'headers'  => $headers,
        ];
        $client = app('GuzzleClient', [])($options);
        $source = " ctx._source.hourlyAvailable = $hourlyAvailable; ctx._source.overnightAvailable = $overnightAvailable; ctx._source.dailyAvailable = $dailyAvailable; ctx._source.maxNumHour = $maxNumHour";

        $client->request(
            'POST',
            'go2joy_hotel_locked/_update_by_query',
            [
                'body'              => json_encode([
                    "script" => [
                        "source" => $source,
                        "lang"   => "painless",
                    ],
                    "query"  => [
                        "bool" => [
                            "must" => [
                                [
                                    "match" => [
                                        "hotelSn" => $hotelSn,
                                    ],
                                ],
                                [
                                    "match" => [
                                        "roomTypeSn" => $roomTypeSn,
                                    ],
                                ],
                            ],
                        ],
                    ],
                ]),
                'retry_on_conflict' => self::RETRY_ON_CONFLICT,
            ]
        );
    }
}

