<?php

namespace App\Console\Commands\Migration;

use App\Constants\Coupon as CouponConst;
use App\Constants\Globals\QueueName;
use App\Jobs\ElasticSearch\SyncHotelCouponJob;
use App\Models\Coupon;
use App\Models\Promotion;
use App\Repositories\Interfaces\PromotionRepositoryInterface;
use Illuminate\Console\Command;

class TransferForHotelCoupon extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'migration:transfer-for-hotel-coupon';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Transfer Coupon For Hotel Coupon.';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     */
    public function handle(PromotionRepositoryInterface $promotionRepository)
    {
        $promotionList = $promotionRepository->findAllPromotionMigration();
        foreach ($promotionList as $promotion) {
            $syncHotelCouponJob = new SyncHotelCouponJob(json_encode([
                'promotionSn'      => $promotion->{Promotion::COL_SN},
                'couponSn'         => $promotion->{Coupon::COL_COUPON_SN},
                'needHotelConfirm' => CouponConst::NEED_HOTEL_CONFIRM['NO'],
            ]));
            dispatch($syncHotelCouponJob)->onQueue(QueueName::HOTEL_COUPON_SYNCING);
        }

    }
}

