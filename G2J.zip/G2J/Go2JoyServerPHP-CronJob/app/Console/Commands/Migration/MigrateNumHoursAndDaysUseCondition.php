<?php

namespace App\Console\Commands\Migration;

use App\Constants\UseCondition as UseConditionConst;
use App\Models\UseCondition;
use Carbon\Carbon;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;

class MigrateNumHoursAndDaysUseCondition extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'migration:migrate-num-hours-and-days-use-condition';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Migrate data from old Coupon to new phase.';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return void
     */
    public function handle()
    {
        $useConditions = DB::table('USE_CONDITION as useCondition')
            ->select(
                'useCondition.SN',
                'useCondition.HOURLY',
                'useCondition.DAILY',
                'useCondition.NUM_HOURS_CONDITION',
                'useCondition.NUM_HOURS',
                'useCondition.NUM_DAYS_CONDITION',
                'useCondition.NUM_DAYS'
            )
            ->get();
        foreach ($useConditions as $value) {
            $updateUseCondition = [];
            if ($value->{UseCondition::COL_HOURLY} == 1 && $value->{UseCondition::COL_NUM_HOURS} > 0) {
                $updateUseCondition['NUM_HOURS_CONDITION'] = UseConditionConst::NUM_HOURS_AND_DAYS_CONDITION['EQUAL'];
            } else {
                $updateUseCondition['NUM_HOURS_CONDITION'] = UseConditionConst::NUM_HOURS_AND_DAYS_CONDITION['DEFAULT'];
                $updateUseCondition['NUM_HOURS'] = UseConditionConst::NUM_HOURS_AND_DAYS_CONDITION['DEFAULT'];
            }
            if ($value->{UseCondition::COL_DAILY} == 1 && $value->{UseCondition::COL_NUM_DAYS} > 0) {
                $updateUseCondition['NUM_DAYS_CONDITION'] = UseConditionConst::NUM_HOURS_AND_DAYS_CONDITION['EQUAL'];
            } else {
                $updateUseCondition['NUM_DAYS_CONDITION'] = UseConditionConst::NUM_HOURS_AND_DAYS_CONDITION['DEFAULT'];
                $updateUseCondition['NUM_DAYS'] = UseConditionConst::NUM_HOURS_AND_DAYS_CONDITION['DEFAULT'];
            }
            UseCondition::where(UseCondition::COL_SN, $value->{UseCondition::COL_SN})->update($updateUseCondition);
        }
    }
}
