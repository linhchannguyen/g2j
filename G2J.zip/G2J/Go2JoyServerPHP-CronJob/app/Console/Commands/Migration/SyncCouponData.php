<?php

namespace App\Console\Commands\Migration;

use App\Constants\CouponForHotel as CouponForHotelConst;
use App\Constants\Promotion as PromotionConst;
use App\Constants\RoomType as RoomTypeConst;
use App\Constants\UseCondition as UseConditionConst;
use App\Helpers\ConvertHelper;
use App\Models\CouponForHotel;
use App\Models\RoomType;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;

class SyncCouponData extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'migration:sync-coupon-data {--status=}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Migrate data from old Coupon to new phase.';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return void
     */
    public function handle()
    {
        $status = (int)$this->option('status');
        $statusList = [
            PromotionConst::STATUS['ACTIVE'],
            PromotionConst::STATUS['EXPIRED'],
            PromotionConst::STATUS['NOT_YET'],
            PromotionConst::STATUS['REJECTED'],
            PromotionConst::STATUS['AWAITING_CONFIRMATION']
        ];
        if (in_array($status, $statusList)) {
            $coupons = DB::table('PROMOTION as promotion')
                ->join('COUPON as coupon', 'coupon.PROMOTION_SN', '=', 'promotion.SN')
                ->join('USE_CONDITION as useCondition', 'useCondition.COUPON_SN', '=', 'coupon.SN')
                ->where('promotion.STATUS', $status)
                ->where('useCondition.APPLY_TARGET', UseConditionConst::APPLY_TARGET['JUST_APPLY'])
                ->select(
                    'promotion.SN as promotionSn',
                    'coupon.ROOM_APPLY_INFO as roomApplyInfo',
                    'coupon.SN as couponSn'
                )
                ->groupBy('couponSn')
                ->get();
            foreach ($coupons as $value) {
                $couponSn = $value->couponSn;
                $couponForHotelList = CouponForHotel::where(CouponForHotel::COL_COUPON_SN, $couponSn)
                    ->where(CouponForHotel::COL_TYPE, CouponForHotelConst::TYPE['USE'])
                    ->get([
                        CouponForHotel::COL_SN,
                        CouponForHotel::COL_HOTEL_SN,
                        CouponForHotel::COL_ROOM_TYPE_SN_LIST
                    ])
                    ->toArray();
                $isUpdate = false;
                $roomTypeSnList = "";
                if (count($couponForHotelList) == 1) {
                    if ($couponForHotelList[0]['ROOM_TYPE_SN_LIST'] != "[]") {
                        continue;
                    }
                    $room = json_decode($value->roomApplyInfo);
                    if (!empty($room) && isset($room->roomTypeSnList) && !empty($room->roomTypeSnList)) {
                        $isUpdate = true;
                        $roomTypeSnList = ConvertHelper::toJson($room->roomTypeSnList);
                    } else {
                        $hotelSn = $couponForHotelList[0]['HOTEL_SN'] ?? 0;
                        $roomType = RoomType::where(RoomType::COL_HOTEL_SN, $hotelSn)
                            ->whereNotIn(RoomType::COL_STATUS, [RoomTypeConst::STATUS['DELETED']])
                            ->pluck(RoomType::COL_SN)
                            ->toArray();
                        if (count($roomType) > 0) {
                            $isUpdate = true;
                            $roomTypeSnList = ConvertHelper::toJson($roomType);
                        }
                    }
                    if ($isUpdate) {
                        CouponForHotel::where(CouponForHotel::COL_SN, $couponForHotelList[0]['SN'])
                            ->update([
                                CouponForHotel::COL_ROOM_TYPE_SN_LIST => $roomTypeSnList
                            ]);
                    }
                } else if (count($couponForHotelList) > 1) {
                    foreach ($couponForHotelList as $couponForHotel) {
                        if ($couponForHotel['ROOM_TYPE_SN_LIST'] != "[]") {
                            continue;
                        }
                        $hotelSn = $couponForHotel['HOTEL_SN'] ?? 0;
                        $roomType = RoomType::where(RoomType::COL_HOTEL_SN, $hotelSn)
                            ->whereNotIn(RoomType::COL_STATUS, [RoomTypeConst::STATUS['DELETED']])
                            ->pluck(RoomType::COL_SN)
                            ->toArray();
                        if (count($roomType) > 0) {
                            $roomTypeSnList = ConvertHelper::toJson($roomType);
                            CouponForHotel::where(CouponForHotel::COL_SN, $couponForHotel['SN'])
                                ->update([
                                    CouponForHotel::COL_ROOM_TYPE_SN_LIST => $roomTypeSnList
                                ]);
                        }
                    }
                }
            }
        }
    }
}
