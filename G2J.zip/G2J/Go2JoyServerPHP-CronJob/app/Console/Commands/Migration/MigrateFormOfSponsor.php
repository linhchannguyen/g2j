<?php

namespace App\Console\Commands\Migration;

use App\Constants\Coupon as CouponConst;
use App\Constants\Promotion as PromotionConst;
use App\Models\Coupon;
use App\Models\Promotion;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;

class MigrateFormOfSponsor extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'migration:migrate-form-of-sponsor';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Migrate value column FORM_OF_SPONSOR for PROMOTION table.';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return void
     */
    public function handle()
    {
        $couponList = DB::table('PROMOTION as promotion')
            ->join('COUPON as coupon', 'coupon.PROMOTION_SN', '=', 'promotion.SN')
            ->where('promotion.FORM_OF_SPONSOR', -1)
            ->get([
               'coupon.DISCOUNT_TYPE',
               'coupon.PROMOTION_SN',
               'promotion.GO2JOY_DISCOUNT',
               'promotion.HOTEL_DISCOUNT',
            ]);

        foreach ($couponList as $coupon) {
            $promotionSn = $coupon->{Coupon::COL_PROMOTION_SN};
            switch ($coupon->{Coupon::COL_DISCOUNT_TYPE}) {
                case CouponConst::DISCOUNT_TYPE['MONEY']:
                case CouponConst::DISCOUNT_TYPE['PERCENT']:
                case CouponConst::DISCOUNT_TYPE['SAME_PRICE']: {
                    switch (true) {
                        case $coupon->{Promotion::COL_GO2JOY_DISCOUNT} != 0 && $coupon->{Promotion::COL_HOTEL_DISCOUNT} != 0: {
                            Promotion::where(Promotion::COL_SN, $promotionSn)
                                ->update([
                                    Promotion::COL_FORM_OF_SPONSOR => PromotionConst::FORM_OF_SPONSOR['G2J_HOTEL']
                                ]);
                            break;
                        }
                        case $coupon->{Promotion::COL_GO2JOY_DISCOUNT} != 0 && $coupon->{Promotion::COL_HOTEL_DISCOUNT} == 0: {
                            Promotion::where(Promotion::COL_SN, $promotionSn)
                                ->update([
                                    Promotion::COL_FORM_OF_SPONSOR => PromotionConst::FORM_OF_SPONSOR['G2J']
                                ]);
                            break;
                        }
                        case $coupon->{Promotion::COL_GO2JOY_DISCOUNT} == 0 && $coupon->{Promotion::COL_HOTEL_DISCOUNT} != 0: {
                            Promotion::where(Promotion::COL_SN, $promotionSn)
                                ->update([
                                    Promotion::COL_FORM_OF_SPONSOR => PromotionConst::FORM_OF_SPONSOR['HOTEL']
                                ]);
                            break;
                        }
                    }

                    break;
                }
                case CouponConst::DISCOUNT_TYPE['GIFT']:
                case CouponConst::DISCOUNT_TYPE['HOURS']: {
                    Promotion::where(Promotion::COL_SN, $promotionSn)
                        ->update([
                            Promotion::COL_FORM_OF_SPONSOR => PromotionConst::FORM_OF_SPONSOR['HOTEL']
                        ]);
                    break;
                }
            }
        }
    }
}
