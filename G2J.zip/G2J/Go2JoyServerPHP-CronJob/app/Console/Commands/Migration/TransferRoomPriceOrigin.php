<?php

namespace App\Console\Commands\Migration;

use App\Constants\RoomType as RoomTypeConst;
use App\Models\RoomType;
use App\Providers\GuzzleClientServiceProvider;
use App\Repositories\Interfaces\RoomTypeRepositoryInterface;
use Illuminate\Console\Command;
use stdClass;

class TransferRoomPriceOrigin extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'migration:transfer-room-price-origin';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Transfer Room Price Origin.';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     */
    public function handle(RoomTypeRepositoryInterface $roomTypeRepository)
    {
        $bulkRoomType = [];
        $roomTypeList = $roomTypeRepository->findAllRoomPriceOriginMigration();
        foreach ($roomTypeList as $roomType) {
            $maxNumHour = $roomType->{RoomType::COL_MAX_NUM_HOUR};
            if(is_null($maxNumHour)){
                if(intval($roomType->{RoomType::COL_ADDITIONAL_ORIGIN}) > 0){
                    $maxNumHour = 0;
                }else{
                    $maxNumHour = intval($roomType->{RoomType::COL_FIRST_HOURS});
                }
            }
            $index = ['index' => new stdClass()];
            $pushRoomType = [
                'hotelSn'          => intval($roomType->{RoomType::COL_HOTEL_SN}),
                'roomTypeSn'       => intval($roomType->{RoomType::COL_SN}),
                'status'           => RoomTypeConst::STATUS['ACTIVE'],
                'firstHour'        => intval($roomType->{RoomType::COL_FIRST_HOURS}),
                'additionalHour'   => intval($roomType->{RoomType::COL_ADDITIONAL_HOURS}),
                'firstHourOrigin'  => intval($roomType->{RoomType::COL_FIRST_HOURS_ORIGIN}),
                'additionalOrigin' => intval($roomType->{RoomType::COL_ADDITIONAL_ORIGIN}),
                'overnightOrigin'  => intval($roomType->{RoomType::COL_OVERNIGHT_ORIGIN}),
                'oneDayOrigin'     => intval($roomType->{RoomType::COL_ONE_DAY_ORIGIN}),
                'maxNumHour'       => intval($maxNumHour),
            ];
            $index = json_encode($index);
            $pushRoomType = json_encode($pushRoomType);
            $bulkRoomType[] = $index;
            $bulkRoomType[] = $pushRoomType;
        }
        $this->deleteSyncMutilRoomPriceOrigin();
        $this->insertSyncMutilRoomPriceOrigin($bulkRoomType);
    }

    private function deleteSyncMutilRoomPriceOrigin()
    {
        $headers = [
            'Content-Type'  => 'application/json',
            'Cache-Control' => 'no-cache',
            'Authorization' => 'Basic ' . config('elasticsearch.go.auth'),
        ];
        $options = [
            'base_uri' => config('elasticsearch.go.host'),
            'headers'  => $headers,
        ];

        $client = app('GuzzleClient', [
            'service' => GuzzleClientServiceProvider::SERVICE['ELASTIC_SEARCH'],
        ])($options);
        $body = json_encode([
            "query" => [
                "match_all" => new stdClass(),
            ],
        ]);
        $client->request(
            'POST',
            'go2joy_hotel_origin_price/_delete_by_query',
            [
                'body' => $body,
            ]
        );
    }

    private function insertSyncMutilRoomPriceOrigin($bulkRoomType)
    {
        $headers = [
            'Content-Type'  => 'application/json',
            'Cache-Control' => 'no-cache',
            'Authorization' => 'Basic ' . config('elasticsearch.go.auth'),
        ];
        $options = [
            'base_uri' => config('elasticsearch.go.host'),
            'headers'  => $headers,
        ];
        $client = app('GuzzleClient', [])($options);
        foreach (array_chunk($bulkRoomType, 10000) as $chunk) {
            $bulkRoomType = join("\n", $chunk);
            $client->request(
                'POST',
                'go2joy_hotel_origin_price/_bulk?pretty',
                [
                    'body' => $bulkRoomType . "\n",
                ]
            );
        }
    }
}

