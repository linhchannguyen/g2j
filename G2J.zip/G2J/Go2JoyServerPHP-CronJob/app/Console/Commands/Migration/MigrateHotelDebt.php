<?php

namespace App\Console\Commands\Migration;

use App\Constants\Coupon as CouponConst;
use App\Constants\Promotion as PromotionConst;
use App\Models\Coupon;
use App\Models\Promotion;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;

class MigrateHotelDebt extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'migration:migrate-hotel-debt';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Migrate data for HOTEL_DEBT table.';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return void
     */
    public function handle()
    {
         DB::table('HOTEL_DEBT as hotelDebt')
            ->whereNull('hotelDebt.STATUS')
            ->update([
                'hotelDebt.STATUS' => -1
            ]);
    }
}
