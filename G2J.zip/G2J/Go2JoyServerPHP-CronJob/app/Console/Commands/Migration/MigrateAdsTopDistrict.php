<?php

namespace App\Console\Commands\Migration;

use App\Constants\HotelOnTop as HotelOnTopConst;
use App\Models\District;
use App\Models\HotelOnTop;
use App\Models\HotelOnTopDetail;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;

class MigrateAdsTopDistrict extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'migration:migrate-top-district';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Migrate top district for HOTEL_ON_TOP and HOTEL_ON_TOP_DETAIL table.';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     */
    public function handle()
    {
        $hotelOnTops = DB::table('HOTEL_ON_TOP')->where(HotelOnTop::COL_TYPE, HotelOnTopConst::TYPE['DISTRICT'])
            ->groupBy(HotelOnTop::COL_DISTRICT_SN)
            ->orderBy(HotelOnTop::COL_SN)
            ->get([HotelOnTop::COL_SN, HotelOnTop::COL_DISTRICT_SN]);
        foreach ($hotelOnTops as $value) {
            $hotelOnTopSnList = DB::table('HOTEL_ON_TOP')->where(HotelOnTop::COL_TYPE, HotelOnTopConst::TYPE['DISTRICT'])
                ->where(HotelOnTop::COL_DISTRICT_SN, $value->{HotelOnTop::COL_DISTRICT_SN})
                ->whereNotIn(HotelOnTop::COL_SN, [$value->{HotelOnTop::COL_SN}])
                ->pluck(HotelOnTop::COL_SN)
                ->toArray();
            if (!empty($hotelOnTopSnList)) {
                HotelOnTopDetail::whereIn(HotelOnTopDetail::COL_HOTEL_ON_TOP_SN, $hotelOnTopSnList)
                    ->update([
                        HotelOnTopDetail::COL_HOTEL_ON_TOP_SN => $value->{HotelOnTop::COL_SN}
                    ]);
                HotelOnTop::whereIn(HotelOnTop::COL_SN, $hotelOnTopSnList)->delete();
            }
            $district = District::where(District::COL_SN, $value->{HotelOnTop::COL_DISTRICT_SN})->first([District::COL_NAME]);
            HotelOnTop::where(HotelOnTop::COL_SN, $value->{HotelOnTop::COL_SN})
                ->update([
                    HotelOnTop::COL_TITLE => $district->{District::COL_NAME} ?? "",
                ]);
        }
    }
}
