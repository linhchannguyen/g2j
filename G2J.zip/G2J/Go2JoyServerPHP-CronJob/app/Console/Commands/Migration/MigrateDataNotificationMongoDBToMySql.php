<?php

namespace App\Console\Commands\Migration;

use App\Helpers\DateTimeHelper;
use App\Models\AppNotificationStatistic;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;

class MigrateDataNotificationMongoDBToMySql extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'migration:migrate-data-notification';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Migrate data from MongoDB to MySQL.';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     */
    public function handle()
    {
        $userNotificationDetailList = DB::connection('mongodb')->collection('user_notification_detail')->whereNotNull('app_notification_sn')->get();
        if ($userNotificationDetailList->isNotEmpty()) {
            foreach ($userNotificationDetailList as $userNotificationDetail) {
                AppNotificationStatistic::updateOrCreate([
                    AppNotificationStatistic::COL_APP_USER_SN         => $userNotificationDetail['app_user_sn'],
                    AppNotificationStatistic::COL_APP_NOTIFICATION_SN => $userNotificationDetail['app_notification_sn'],
                ], [
                    AppNotificationStatistic::COL_MOBILE_DEVICE_SN => $userNotificationDetail['mobile_device_sn'],
                    AppNotificationStatistic::COL_VIEW             => $userNotificationDetail['read'],
                    AppNotificationStatistic::COL_CREATE_TIME      => DateTimeHelper::toLocalTime("Y-m-d H:i", $userNotificationDetail['create_time']),
                    AppNotificationStatistic::COL_LAST_UPDATE      => DateTimeHelper::toLocalTime("Y-m-d H:i", $userNotificationDetail['last_update']),
                ]);

            }

        }

    }
}