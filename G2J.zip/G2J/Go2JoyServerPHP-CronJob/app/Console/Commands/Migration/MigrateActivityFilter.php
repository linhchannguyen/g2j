<?php

namespace App\Console\Commands\Migration;

use App\Constants\Staff as StaffConst;
use App\Models\ActivityFilter;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;

class MigrateActivityFilter extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'migration:migrate-activity-filter';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Migrate activity filter ACTIVITY_FILTER table.';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     */
    public function handle()
    {
        $departmentRequest = StaffConst::DEPARTMENT_REQUEST;
        $departmentRequestCondition = StaffConst::DEPARTMENT_REQUEST_CONDITION;
        DB::table('ACTIVITY_FILTER')->delete();
        foreach ($departmentRequest as $key => $value) {
            ActivityFilter::create([
                ActivityFilter::COL_SN => $value + 1,
                ActivityFilter::COL_DEPARTMENT_REQUEST => $key,
                ActivityFilter::COL_ROLE_SN_LIST => json_encode($departmentRequestCondition[$value]['ROLE_SN']),
                ActivityFilter::COL_REGION_LIST => json_encode($departmentRequestCondition[$value]['REGION']),
                ActivityFilter::COL_IDX => $value + 1
            ]);
        }
    }
}
