<?php

namespace App\Console\Commands\Migration;

use App\Constants\DirectDiscountProgram as DirectDiscountProgramConst;
use App\Constants\DirectDiscountProgramActionHistory as DirectDiscountProgramActionHistoryConst;
use App\Constants\DirectDiscountProgramRoomType as DirectDiscountProgramRoomTypeConst;
use App\Constants\Staff as StaffConst;
use App\Models\DirectDiscountProgram;
use App\Models\DirectDiscountProgramHotel;
use App\Models\DirectDiscountProgramRoomType;
use App\Models\DirectDiscountProgramRoomTypeHistory;
use App\Models\RoomPriceAdjustment;
use App\Models\Staff;
use App\Repositories\Interfaces\DirectDiscountProgramActionHistoryRepositoryInterface;
use App\Repositories\Interfaces\DirectDiscountProgramHotelRepositoryInterface;
use App\Repositories\Interfaces\DirectDiscountProgramRoomTypeHistoryRepositoryInterface;
use App\Repositories\Interfaces\DirectDiscountProgramRoomTypeRepositoryInterface;
use App\Repositories\Interfaces\RoomPriceAdjustmentRepositoryInterface;
use Exception;
use Illuminate\Console\Command;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\DB;

class TransferRoomPriceAdjustment extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'migration:transfer-room-price-adjustment';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Transfer Room Price Adjustment type Discount to DirectDiscount Program.';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     */
    public function handle(RoomPriceAdjustmentRepositoryInterface                $roomPriceAdjustmentRepository,
                           DirectDiscountProgramActionHistoryRepositoryInterface $directDiscountProgramActionHistoryRepository
    ) {
        $roomPriceProgramList = $roomPriceAdjustmentRepository->findDataMigrationDirectDiscount();
        foreach ($roomPriceProgramList as $roomPriceProgram) {
            $roomPriceAdjustmentList = $roomPriceAdjustmentRepository->findDataMigrationDirectDiscountByCondition(
                $roomPriceProgram->{RoomPriceAdjustment::AS_HOTEL_SN},
                $roomPriceProgram->{RoomPriceAdjustment::COL_TYPE_APPLY},
                $roomPriceProgram->{RoomPriceAdjustment::COL_SPECIAL_DATE},
                $roomPriceProgram->{RoomPriceAdjustment::COL_START_DATE},
                $roomPriceProgram->{RoomPriceAdjustment::COL_END_DATE},
                $roomPriceProgram->{RoomPriceAdjustment::COL_MONDAY},
                $roomPriceProgram->{RoomPriceAdjustment::COL_TUESDAY},
                $roomPriceProgram->{RoomPriceAdjustment::COL_WEDNESDAY},
                $roomPriceProgram->{RoomPriceAdjustment::COL_THURSDAY},
                $roomPriceProgram->{RoomPriceAdjustment::COL_FRIDAY},
                $roomPriceProgram->{RoomPriceAdjustment::COL_SATURDAY},
                $roomPriceProgram->{RoomPriceAdjustment::COL_SUNDAY},
                $roomPriceProgram->{RoomPriceAdjustment::COL_STAFF_CREATE_SN}
            );

            if (empty($roomPriceProgram->{Staff::COL_USER_ID})) {
                $roomPriceProgram->{DirectDiscountProgram::COL_ACTION_USER_TYPE} = DirectDiscountProgramConst::ACTION_USER_TYPE['GO2JOY_STAFF'];
                $roomPriceProgram->{Staff::COL_USER_ID} = 'system';
                $roomPriceProgram->{RoomPriceAdjustment::COL_STAFF_CREATE_SN} = StaffConst::SYSTEM;
            }
            try {
                DB::connection('mysql')->beginTransaction();
                $directDiscountProgramName = $roomPriceProgram->{RoomPriceAdjustment::AS_HOTEL_NAME};

                $createDirectDiscount = DirectDiscountProgram::create([
                    DirectDiscountProgram::COL_NAME               => $directDiscountProgramName,
                    DirectDiscountProgram::COL_ACTION_USER_TYPE   => $roomPriceProgram->{DirectDiscountProgram::COL_ACTION_USER_TYPE},
                    DirectDiscountProgram::COL_TYPE_APPLY         => $roomPriceProgram->{RoomPriceAdjustment::COL_TYPE_APPLY},
                    DirectDiscountProgram::COL_STATUS             => DirectDiscountProgramConst::STATUS['RUNNING'],
                    DirectDiscountProgram::COL_START_DATE         => $roomPriceProgram->{RoomPriceAdjustment::COL_START_DATE},
                    DirectDiscountProgram::COL_END_DATE           => Carbon::now()->addYear()->lt(Carbon::parse($roomPriceProgram->{RoomPriceAdjustment::COL_END_DATE})) ? Carbon::now()->addYear()->toDateString() : $roomPriceProgram->{RoomPriceAdjustment::COL_END_DATE},
                    DirectDiscountProgram::COL_SPECIAL_DATE       => $roomPriceProgram->{RoomPriceAdjustment::COL_SPECIAL_DATE},
                    DirectDiscountProgram::COL_START_TIME         => null,
                    DirectDiscountProgram::COL_END_TIME           => null,
                    DirectDiscountProgram::COL_MONDAY             => $roomPriceProgram->{RoomPriceAdjustment::COL_MONDAY},
                    DirectDiscountProgram::COL_TUESDAY            => $roomPriceProgram->{RoomPriceAdjustment::COL_TUESDAY},
                    DirectDiscountProgram::COL_WEDNESDAY          => $roomPriceProgram->{RoomPriceAdjustment::COL_WEDNESDAY},
                    DirectDiscountProgram::COL_THURSDAY           => $roomPriceProgram->{RoomPriceAdjustment::COL_THURSDAY},
                    DirectDiscountProgram::COL_FRIDAY             => $roomPriceProgram->{RoomPriceAdjustment::COL_FRIDAY},
                    DirectDiscountProgram::COL_SATURDAY           => $roomPriceProgram->{RoomPriceAdjustment::COL_SATURDAY},
                    DirectDiscountProgram::COL_SUNDAY             => $roomPriceProgram->{RoomPriceAdjustment::COL_SUNDAY},
                    DirectDiscountProgram::COL_CREATED_NAME       => $roomPriceProgram->{Staff::COL_USER_ID},
                    DirectDiscountProgram::COL_CREATED_BY         => $roomPriceProgram->{RoomPriceAdjustment::COL_STAFF_CREATE_SN},
                    DirectDiscountProgram::COL_TOTAL_HOTEL_JOINED => 1,
                ]);
                $actionSn = $directDiscountProgramActionHistoryRepository->createCreatedHistory($createDirectDiscount->{DirectDiscountProgram::COL_SN}, $createDirectDiscount->{DirectDiscountProgram::COL_CREATED_BY}, DirectDiscountProgramActionHistoryConst::ACTION_USER_TYPE['GO2JOY_STAFF'], Carbon::now(), json_encode($createDirectDiscount));

                $this->_createDirectDiscountProgram($actionSn, $createDirectDiscount, $roomPriceAdjustmentList);
                DB::connection('mysql')->commit();
            } catch (Exception $exception) {
                DB::connection('mysql')->rollBack();
                throw $exception;
            }
        }

    }

    private function _createDirectDiscountProgram($actionSn, $createDirectDiscount, $roomPriceAdjustmentList)
    {
        $directDiscountProgramHotelRepository = app(DirectDiscountProgramHotelRepositoryInterface::class);
        $directDiscountProgramRoomTypeRepository = app(DirectDiscountProgramRoomTypeRepositoryInterface::class);
        $directDiscountProgramRoomTypeHistoryRepository = app(DirectDiscountProgramRoomTypeHistoryRepositoryInterface::class);
        $roomPriceAdjustmentRepository = app(RoomPriceAdjustmentRepositoryInterface::class);
        $directDiscountHotel = [];
        $directDiscountRoomType = [];
        $directDiscountRoomTypeHistory = [];
        foreach ($roomPriceAdjustmentList as $index => $roomPriceAdjustment) {
            if (!isset($directDiscountHotel[$roomPriceAdjustment->{DirectDiscountProgram::AS_HOTEL_NAME}])) {
                $createName = $createDirectDiscount->{DirectDiscountProgram::COL_CREATED_NAME};
                if ($createDirectDiscount->{DirectDiscountProgram::COL_ACTION_USER_TYPE} != DirectDiscountProgramConst::ACTION_USER_TYPE['HOTEL_STAFF']) {
                    $createName = DirectDiscountProgramConst::CREATE_NAME['GO2JOY'];
                }
                $directDiscountHotel[$roomPriceAdjustment->{DirectDiscountProgram::AS_HOTEL_SN}] = [
                    DirectDiscountProgramHotel::COL_DIRECT_DISCOUNT_PROGRAM_NAME => $createDirectDiscount->{DirectDiscountProgram::COL_NAME},
                    DirectDiscountProgramHotel::COL_DIRECT_DISCOUNT_PROGRAM_SN   => $createDirectDiscount->{DirectDiscountProgram::COL_SN},
                    DirectDiscountProgramHotel::COL_TYPE_APPLY                   => $createDirectDiscount->{DirectDiscountProgram::COL_TYPE_APPLY},
                    DirectDiscountProgramHotel::COL_STATUS                       => DirectDiscountProgramConst::STATUS['RUNNING'],
                    DirectDiscountProgramHotel::COL_HOTEL_SN                     => $roomPriceAdjustment->{DirectDiscountProgram::AS_HOTEL_SN},
                    DirectDiscountProgramHotel::COL_START_DATE                   => $createDirectDiscount->{DirectDiscountProgram::COL_START_DATE},
                    DirectDiscountProgramHotel::COL_END_DATE                     => $createDirectDiscount->{DirectDiscountProgram::COL_END_DATE},
                    DirectDiscountProgramHotel::COL_SPECIAL_DATE                 => $createDirectDiscount->{DirectDiscountProgram::COL_SPECIAL_DATE},
                    DirectDiscountProgramHotel::COL_START_TIME                   => $createDirectDiscount->{DirectDiscountProgram::COL_START_TIME},
                    DirectDiscountProgramHotel::COL_END_TIME                     => $createDirectDiscount->{DirectDiscountProgram::COL_END_TIME},
                    DirectDiscountProgramHotel::COL_MONDAY                       => $createDirectDiscount->{DirectDiscountProgram::COL_MONDAY},
                    DirectDiscountProgramHotel::COL_TUESDAY                      => $createDirectDiscount->{DirectDiscountProgram::COL_TUESDAY},
                    DirectDiscountProgramHotel::COL_WEDNESDAY                    => $createDirectDiscount->{DirectDiscountProgram::COL_WEDNESDAY},
                    DirectDiscountProgramHotel::COL_THURSDAY                     => $createDirectDiscount->{DirectDiscountProgram::COL_THURSDAY},
                    DirectDiscountProgramHotel::COL_FRIDAY                       => $createDirectDiscount->{DirectDiscountProgram::COL_FRIDAY},
                    DirectDiscountProgramHotel::COL_SATURDAY                     => $createDirectDiscount->{DirectDiscountProgram::COL_SATURDAY},
                    DirectDiscountProgramHotel::COL_SUNDAY                       => $createDirectDiscount->{DirectDiscountProgram::COL_SUNDAY},
                    DirectDiscountProgramHotel::COL_CREATED_NAME                 => $createName,
                ];
            }
            $directDiscountRoomType [] = [
                DirectDiscountProgramRoomType::COL_DIRECT_DISCOUNT_PROGRAM_SN              => $createDirectDiscount->{DirectDiscountProgram::COL_SN},
                DirectDiscountProgramRoomType::COL_STATUS                                  => empty($roomPriceAdjustment->{RoomPriceAdjustment::COL_SN}) ? DirectDiscountProgramRoomTypeConst::STATUS['PENDING'] : DirectDiscountProgramRoomTypeConst::STATUS['AVAILABLE'],
                DirectDiscountProgramRoomType::COL_HOTEL_SN                                => $roomPriceAdjustment->{DirectDiscountProgram::AS_HOTEL_SN},
                DirectDiscountProgramRoomType::COL_HOTEL_NAME                              => $roomPriceAdjustment->{DirectDiscountProgram::AS_HOTEL_NAME},
                DirectDiscountProgramRoomType::COL_HOTEL_CODE                              => $roomPriceAdjustment->{DirectDiscountProgram::AS_HOTEL_CODE},
                DirectDiscountProgramRoomType::COL_ROOM_TYPE_SN                            => $roomPriceAdjustment->{DirectDiscountProgram::AS_ROOM_TYPE_SN},
                DirectDiscountProgramRoomType::COL_ROOM_TYPE_NAME                          => $roomPriceAdjustment->{DirectDiscountProgram::AS_ROOM_TYPE_NAME},
                DirectDiscountProgramRoomType::COL_PRICE_FIRST_HOURS_DISCOUNT_PERCENT      => $this->_calculatePercentDiscount($roomPriceAdjustment->{RoomPriceAdjustment::COL_PRICE_FIRST_HOURS}, $roomPriceAdjustment->{RoomPriceAdjustment::COL_FIRST_HOURS_ORIGIN}),
                DirectDiscountProgramRoomType::COL_PRICE_FIRST_HOURS_AFTER_DISCOUNT        => !empty($roomPriceAdjustment->{RoomPriceAdjustment::COL_PRICE_FIRST_HOURS}) ? $roomPriceAdjustment->{RoomPriceAdjustment::COL_PRICE_FIRST_HOURS} : $roomPriceAdjustment->{RoomPriceAdjustment::COL_FIRST_HOURS_ORIGIN},
                DirectDiscountProgramRoomType::COL_PRICE_ADDITIONAL_HOURS_DISCOUNT_PERCENT => $this->_calculatePercentDiscount($roomPriceAdjustment->{RoomPriceAdjustment::COL_PRICE_ADDITIONAL_HOURS}, $roomPriceAdjustment->{RoomPriceAdjustment::COL_ADDITIONAL_ORIGIN}),
                DirectDiscountProgramRoomType::COL_PRICE_ADDITIONAL_HOURS_AFTER_DISCOUNT   => !empty($roomPriceAdjustment->{RoomPriceAdjustment::COL_PRICE_ADDITIONAL_HOURS}) ? $roomPriceAdjustment->{RoomPriceAdjustment::COL_PRICE_ADDITIONAL_HOURS} : $roomPriceAdjustment->{RoomPriceAdjustment::COL_ADDITIONAL_ORIGIN},
                DirectDiscountProgramRoomType::COL_PRICE_OVERNIGHT_DISCOUNT_PERCENT        => $this->_calculatePercentDiscount($roomPriceAdjustment->{RoomPriceAdjustment::COL_PRICE_OVERNIGHT}, $roomPriceAdjustment->{RoomPriceAdjustment::COL_OVERNIGHT_ORIGIN}),
                DirectDiscountProgramRoomType::COL_PRICE_OVERNIGHT_AFTER_DISCOUNT          => !empty($roomPriceAdjustment->{RoomPriceAdjustment::COL_PRICE_OVERNIGHT}) ? $roomPriceAdjustment->{RoomPriceAdjustment::COL_PRICE_OVERNIGHT} : $roomPriceAdjustment->{RoomPriceAdjustment::COL_OVERNIGHT_ORIGIN},
                DirectDiscountProgramRoomType::COL_PRICE_ONE_DAY_DISCOUNT_PERCENT          => $this->_calculatePercentDiscount($roomPriceAdjustment->{RoomPriceAdjustment::COL_PRICE_ONE_DAY}, $roomPriceAdjustment->{RoomPriceAdjustment::COL_ONE_DAY_ORIGIN}),
                DirectDiscountProgramRoomType::COL_PRICE_ONE_DAY_AFTER_DISCOUNT            => !empty($roomPriceAdjustment->{RoomPriceAdjustment::COL_PRICE_ONE_DAY}) ? $roomPriceAdjustment->{RoomPriceAdjustment::COL_PRICE_ONE_DAY} : $roomPriceAdjustment->{RoomPriceAdjustment::COL_ONE_DAY_ORIGIN},
                DirectDiscountProgramRoomType::COL_FIRST_HOURS_ORIGIN                      => $roomPriceAdjustment->{RoomPriceAdjustment::COL_FIRST_HOURS_ORIGIN},
                DirectDiscountProgramRoomType::COL_ADDITIONAL_ORIGIN                       => $roomPriceAdjustment->{RoomPriceAdjustment::COL_ADDITIONAL_ORIGIN},
                DirectDiscountProgramRoomType::COL_OVERNIGHT_ORIGIN                        => $roomPriceAdjustment->{RoomPriceAdjustment::COL_OVERNIGHT_ORIGIN},
                DirectDiscountProgramRoomType::COL_ONE_DAY_ORIGIN                          => $roomPriceAdjustment->{RoomPriceAdjustment::COL_ONE_DAY_ORIGIN},
            ];

            $directDiscountRoomTypeHistory [] = [
                DirectDiscountProgramRoomTypeHistory::COL_DIRECT_DISCOUNT_PROGRAM_SN                => $createDirectDiscount->{DirectDiscountProgram::COL_SN},
                DirectDiscountProgramRoomTypeHistory::COL_STATUS                                    => empty($roomPriceAdjustment->{RoomPriceAdjustment::COL_SN}) ? DirectDiscountProgramRoomTypeConst::STATUS['PENDING'] : DirectDiscountProgramRoomTypeConst::STATUS['AVAILABLE'],
                DirectDiscountProgramRoomTypeHistory::COL_HOTEL_SN                                  => $roomPriceAdjustment->{DirectDiscountProgram::AS_HOTEL_SN},
                DirectDiscountProgramRoomTypeHistory::COL_DIRECT_DISCOUNT_PROGRAM_ACTION_HISTORY_SN => $actionSn,
                DirectDiscountProgramRoomTypeHistory::COL_HOTEL_NAME                                => $roomPriceAdjustment->{DirectDiscountProgram::AS_HOTEL_NAME},
                DirectDiscountProgramRoomTypeHistory::COL_HOTEL_CODE                                => $roomPriceAdjustment->{DirectDiscountProgram::AS_HOTEL_CODE},
                DirectDiscountProgramRoomTypeHistory::COL_ROOM_TYPE_SN                              => $roomPriceAdjustment->{DirectDiscountProgram::AS_ROOM_TYPE_SN},
                DirectDiscountProgramRoomTypeHistory::COL_ROOM_TYPE_NAME                            => $roomPriceAdjustment->{DirectDiscountProgram::AS_ROOM_TYPE_NAME},
                DirectDiscountProgramRoomTypeHistory::COL_PRICE_FIRST_HOURS_DISCOUNT_PERCENT        => $this->_calculatePercentDiscount($roomPriceAdjustment->{RoomPriceAdjustment::COL_PRICE_FIRST_HOURS}, $roomPriceAdjustment->{RoomPriceAdjustment::COL_FIRST_HOURS_ORIGIN}),
                DirectDiscountProgramRoomTypeHistory::COL_PRICE_FIRST_HOURS_AFTER_DISCOUNT          => !empty($roomPriceAdjustment->{RoomPriceAdjustment::COL_PRICE_FIRST_HOURS}) ? $roomPriceAdjustment->{RoomPriceAdjustment::COL_PRICE_FIRST_HOURS} : $roomPriceAdjustment->{RoomPriceAdjustment::COL_FIRST_HOURS_ORIGIN},
                DirectDiscountProgramRoomTypeHistory::COL_PRICE_ADDITIONAL_HOURS_DISCOUNT_PERCENT   => $this->_calculatePercentDiscount($roomPriceAdjustment->{RoomPriceAdjustment::COL_PRICE_ADDITIONAL_HOURS}, $roomPriceAdjustment->{RoomPriceAdjustment::COL_ADDITIONAL_ORIGIN}),
                DirectDiscountProgramRoomTypeHistory::COL_PRICE_ADDITIONAL_HOURS_AFTER_DISCOUNT     => !empty($roomPriceAdjustment->{RoomPriceAdjustment::COL_PRICE_ADDITIONAL_HOURS}) ? $roomPriceAdjustment->{RoomPriceAdjustment::COL_PRICE_ADDITIONAL_HOURS} : $roomPriceAdjustment->{RoomPriceAdjustment::COL_ADDITIONAL_ORIGIN},
                DirectDiscountProgramRoomTypeHistory::COL_PRICE_OVERNIGHT_DISCOUNT_PERCENT          => $this->_calculatePercentDiscount($roomPriceAdjustment->{RoomPriceAdjustment::COL_PRICE_OVERNIGHT}, $roomPriceAdjustment->{RoomPriceAdjustment::COL_OVERNIGHT_ORIGIN}),
                DirectDiscountProgramRoomTypeHistory::COL_PRICE_OVERNIGHT_AFTER_DISCOUNT            => !empty($roomPriceAdjustment->{RoomPriceAdjustment::COL_PRICE_OVERNIGHT}) ? $roomPriceAdjustment->{RoomPriceAdjustment::COL_PRICE_OVERNIGHT} : $roomPriceAdjustment->{RoomPriceAdjustment::COL_OVERNIGHT_ORIGIN},
                DirectDiscountProgramRoomTypeHistory::COL_PRICE_ONE_DAY_DISCOUNT_PERCENT            => $this->_calculatePercentDiscount($roomPriceAdjustment->{RoomPriceAdjustment::COL_PRICE_ONE_DAY}, $roomPriceAdjustment->{RoomPriceAdjustment::COL_ONE_DAY_ORIGIN}),
                DirectDiscountProgramRoomTypeHistory::COL_PRICE_ONE_DAY_AFTER_DISCOUNT              => !empty($roomPriceAdjustment->{RoomPriceAdjustment::COL_PRICE_ONE_DAY}) ? $roomPriceAdjustment->{RoomPriceAdjustment::COL_PRICE_ONE_DAY} : $roomPriceAdjustment->{RoomPriceAdjustment::COL_ONE_DAY_ORIGIN},
                DirectDiscountProgramRoomTypeHistory::COL_FIRST_HOURS_ORIGIN                        => $roomPriceAdjustment->{RoomPriceAdjustment::COL_FIRST_HOURS_ORIGIN},
                DirectDiscountProgramRoomTypeHistory::COL_ADDITIONAL_ORIGIN                         => $roomPriceAdjustment->{RoomPriceAdjustment::COL_ADDITIONAL_ORIGIN},
                DirectDiscountProgramRoomTypeHistory::COL_OVERNIGHT_ORIGIN                          => $roomPriceAdjustment->{RoomPriceAdjustment::COL_OVERNIGHT_ORIGIN},
                DirectDiscountProgramRoomTypeHistory::COL_ONE_DAY_ORIGIN                            => $roomPriceAdjustment->{RoomPriceAdjustment::COL_ONE_DAY_ORIGIN},
            ];
            $roomPriceAdjustmentRepository->update([
                RoomPriceAdjustment::COL_DIRECT_DISCOUNT_PROGRAM_SN => $createDirectDiscount->{DirectDiscountProgram::COL_SN},
                RoomPriceAdjustment::COL_START_TIME                 => null,
                RoomPriceAdjustment::COL_END_TIME                   => null,
                RoomPriceAdjustment::COL_END_DATE                   => $createDirectDiscount->{DirectDiscountProgram::COL_END_DATE},
            ], $roomPriceAdjustment->{RoomPriceAdjustment::COL_SN});
        }
        $directDiscountProgramHotelRepository->batchInsert($directDiscountHotel);
        $directDiscountProgramRoomTypeRepository->batchInsert($directDiscountRoomType);
        $directDiscountProgramRoomTypeHistoryRepository->batchInsert($directDiscountRoomTypeHistory);

    }

    private function _calculatePercentDiscount($priceDiscount, $priceOrigin)
    {
        if ($priceDiscount > 0 && $priceDiscount != $priceOrigin) {
            return intval(($priceOrigin - $priceDiscount) / ($priceOrigin / 100));
        }

        return 0;
    }
}

