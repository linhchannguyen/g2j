<?php

namespace App\Console\Commands\Migration;

use App\Constants\Hotel as HotelConst;
use App\Constants\UserBooking as UserBookingConst;
use App\Constants\PaymentTransaction as PaymentTransactionConst;
use App\Constants\Coupon as CouponConst;
use App\Constants\Promotion as PromotionConst;
use App\Models\Coupon;
use App\Models\CouponIssued;
use App\Models\Promotion;
use App\Models\UserBooking;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;

class MigrateTotalDiscount extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'migration:migrate-total-discount';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Migrate value column TOTAL_DISCOUNT for PROMOTION table.';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return void
     */
    public function handle()
    {
        $couponList = DB::table('PROMOTION as promotion')
            ->join('COUPON as coupon', 'coupon.PROMOTION_SN', '=', 'promotion.SN')
            ->where('promotion.FORM_OF_SPONSOR', '!=', -1)
            ->get([
                'coupon.SN',
                'coupon.PROMOTION_SN',
            ]);
        foreach ($couponList as $coupon) {
            $totalDiscount = 0;
            $couponIssueds = CouponIssued::where(CouponIssued::COL_COUPON_SN, $coupon->{Coupon::COL_SN})->pluck(CouponIssued::COL_SN)->toArray();
            foreach (array_chunk($couponIssueds, 500) as $couponIssued) {
                DB::table(UserBooking::TABLE_NAME, 'booking')
                    ->join('HOTEL as hotel', 'booking.HOTEL_SN', '=', 'hotel.SN')
                    ->leftJoin('PAYMENT_TRANSACTION as paymentTransaction', 'paymentTransaction.USER_BOOKING_SN', '=', 'booking.SN')
                    ->whereIn('booking.COUPON_ISSUED_SN', $couponIssued)
                    ->where(function ($query) {
                        $query->orWhere('booking.BOOKING_STATUS', UserBookingConst::BOOKING_STATUS['COMPLETED']);
                        $query->orWhere(function ($query1) {
                            $query1->orWhere(function ($query2) {
                                $query2->where('booking.BOOKING_STATUS', '=', UserBookingConst::BOOKING_STATUS['NO_SHOW']);
                                $query2->where('hotel.ORIGIN', '=', HotelConst::ORIGIN['GO2JOY']);
                                $query2->where('booking.PAYMENT_PROVIDER', '!=', UserBookingConst::PAYMENT_PROVIDER['AT_HOTEL']);
                                $query2->where('booking.PREPAY_AMOUNT', '>', 0);
                                $query2->where(function ($query3) {
                                    $query3->orWhere('paymentTransaction.PAYMENT_STATUS', '=', PaymentTransactionConst::PAYMENT_STATUS['SUCCESSFUL']);
                                    $query3->orWhereNull('paymentTransaction.PAYMENT_STATUS');
                                });
                                $query2->where('booking.REFUNDED', '=', 0);
                                $query2->where('booking.CREATE_TIME', '>=', UserBookingConst::DATETIME_RELEASE_NEW_BOOKING_PROCESS);
                            });
                        });
                    })
                    ->selectRaw("
                    booking.SN,
                    booking.GO2JOY_DISCOUNT,
                    booking.HOTEL_DISCOUNT,
                    booking.SPONSOR_DISCOUNT,
                    booking.PROMOTION_DISCOUNT
                ")
                    ->orderBy('booking.SN')
                    ->chunk(500, function ($userBooking) use (&$totalDiscount) {
                        foreach ($userBooking as $value) {
                            $totalG2jDiscount = $value->{UserBooking::COL_GO2JOY_DISCOUNT} ?? 0;
                            $totalHotelDiscount = $value->{UserBooking::COL_HOTEL_DISCOUNT} ?? 0;
                            $totalSponsorDiscount = $value->{UserBooking::COL_SPONSOR_DISCOUNT} ?? 0;
                            $totalPromotionDiscount = $value->{UserBooking::COL_PROMOTION_DISCOUNT} ?? 0;
                            if ($totalG2jDiscount < 0 || $totalHotelDiscount < 0 || $totalSponsorDiscount < 0 || $totalPromotionDiscount < 0) {
                                continue;
                            }
                            $totalDiscount += $totalG2jDiscount + $totalHotelDiscount + $totalSponsorDiscount + $totalPromotionDiscount;
                        }
                    });
            }
            Promotion::where(Promotion::COL_SN, $coupon->{Coupon::COL_PROMOTION_SN})
                ->update([
                    Promotion::COL_TOTAL_DISCOUNT => $totalDiscount
                ]);
        }
    }
}
