<?php

namespace App\Console\Commands\Migration;

use App\Helpers\ConvertHelper;
use App\Models\Hotel;
use App\Models\HotelBusinessInformation;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;

class MigrateHotelBusinessInformation extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'migration:migrate-hotel-business-information';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Migrate hotel business information for HOTEL_BUSINESS_INFORMATION table from HOTEL table.';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     */
    public function handle()
    {
        DB::table('HOTEL as hotel')
        ->leftJoin('HOTEL_BUSINESS_INFORMATION as hotelBusinessInformation', 'hotelBusinessInformation.HOTEL_SN', '=', 'hotel.SN')
        ->whereNull('hotelBusinessInformation.SN')
        ->select([
            'hotel.SN',
            'hotel.TAX_ID',
            'hotel.BUSINESS_LICENSE',
            'hotel.COMPANY_NAME',
            'hotel.COMPANY_ADDRESS',
            'hotel.REP_NAME',
            'hotel.REP_POSITION',
            'hotel.REP_TEL',
            'hotel.REP_EMAIL',
            'hotel.BANK_ACCOUNT',
            'hotel.BANK_NAME',
            'hotel.BANK_BRANCH',
            'hotel.BENEFICIARY',
            'hotel.CREATE_TIME',
            'hotel.LAST_UPDATE',
        ])
        ->orderBy('hotel.SN')
        ->chunk(500, function ($hotels) {
            foreach ($hotels as $hotel) {
                HotelBusinessInformation::create([
                    HotelBusinessInformation::COL_HOTEL_SN => $hotel->{Hotel::COL_SN},
                    HotelBusinessInformation::COL_TAX_ID => $hotel->{Hotel::COL_TAX_ID},
                    HotelBusinessInformation::COL_BUSINESS_LICENSE => $hotel->{Hotel::COL_BUSINESS_LICENSE},
                    HotelBusinessInformation::COL_COMPANY_NAME => $hotel->{Hotel::COL_COMPANY_NAME},
                    HotelBusinessInformation::COL_COMPANY_ADDRESS => $hotel->{Hotel::COL_COMPANY_ADDRESS},
                    HotelBusinessInformation::COL_REP_NAME => $hotel->{Hotel::COL_REP_NAME},
                    HotelBusinessInformation::COL_REP_POSITION => $hotel->{Hotel::COL_REP_POSITION},
                    HotelBusinessInformation::COL_REP_TEL => $hotel->{Hotel::COL_REP_TEL},
                    HotelBusinessInformation::COL_REP_EMAIL => $hotel->{Hotel::COL_REP_EMAIL},
                    HotelBusinessInformation::COL_BANK_ACCOUNT => $hotel->{Hotel::COL_BANK_ACCOUNT} ? ConvertHelper::encryptData($hotel->{Hotel::COL_BANK_ACCOUNT}, $hotel->{Hotel::COL_SN}) : $hotel->{Hotel::COL_BANK_ACCOUNT},
                    HotelBusinessInformation::COL_BANK_NAME => $hotel->{Hotel::COL_BANK_NAME},
                    HotelBusinessInformation::COL_BANK_BRANCH => $hotel->{Hotel::COL_BANK_BRANCH},
                    HotelBusinessInformation::COL_BENEFICIARY => $hotel->{Hotel::COL_BENEFICIARY},
                    HotelBusinessInformation::COL_BANK_CODE => "",
                    HotelBusinessInformation::COL_BUSINESS_TYPE => "",
                    HotelBusinessInformation::COL_TYPE_CARD => "",
                    HotelBusinessInformation::COL_ID_CARD => "",
                    HotelBusinessInformation::COL_WARD_CODE => "",
                    HotelBusinessInformation::COL_CREATE_TIME => $hotel->{Hotel::COL_CREATE_TIME},
                    HotelBusinessInformation::COL_LAST_UPDATE => $hotel->{Hotel::COL_LAST_UPDATE},
                ]);
            }
        });
    }
}
