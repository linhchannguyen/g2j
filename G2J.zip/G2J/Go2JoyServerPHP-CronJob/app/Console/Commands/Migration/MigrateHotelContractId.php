<?php

namespace App\Console\Commands\Migration;

use App\Constants\Hotel as HotelConst;
use App\Models\Hotel;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;

class MigrateHotelContractId extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'migration:migrate-hotel-contract-id';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Migrate value column CONTRACT_ID for HOTEL table.';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return void
     */
    public function handle()
    {
        $hotelList = DB::table('HOTEL as hotel')
            ->join('HOTEL_BUSINESS_INFORMATION as hotelBusinessInformation', 'hotelBusinessInformation.HOTEL_SN', '=', 'hotel.SN')
            ->where('hotel.ORIGIN', HotelConst::ORIGIN['GO2JOY'])
            ->whereNotNull('hotelBusinessInformation.TAX_ID')
            ->get([
                'hotel.SN',
                'hotel.CONTRACT_ID',
                'hotelBusinessInformation.TAX_ID',
            ]);
        foreach ($hotelList as $hotel) {
            $contractId = trim($hotel->{Hotel::COL_CONTRACT_ID});
            $taxId = trim($hotel->{Hotel::COL_TAX_ID});
            if (!empty($contractId) && !empty($taxId)) {
                Hotel::where(Hotel::COL_SN, $hotel->{Hotel::COL_SN})
                    ->update([
                        Hotel::COL_CONTRACT_ID => $contractId . '-' . $taxId
                    ]);
            } else if (empty($contractId) && !empty($taxId)) {
                Hotel::where(Hotel::COL_SN, $hotel->{Hotel::COL_SN})
                    ->update([
                        Hotel::COL_CONTRACT_ID => '//-' . $taxId
                    ]);
            }
        }
    }
}
