<?php

namespace App\Console\Commands\Migration;

use App\Models\Bank;
use App\Models\HotelBusinessInformation;
use Illuminate\Console\Command;

class MigrateEximBank extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'migration:migrate-bank-name-exim-bank';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Migrate value column NAME for BANK table and BANK_NAME for HOTEL_BUSINESS_INFORMATION table.';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return void
     */
    public function handle()
    {
        Bank::where(Bank::COL_CODE, "79305001")
            ->update([
                Bank::COL_NAME => "EXIMBANK - NGÂN HÀNG THƯƠNG MẠI CỔ PHẦN XUẤT NHẬP KHẨU VIỆT NAM"
            ]);
        HotelBusinessInformation::where(HotelBusinessInformation::COL_BANK_CODE, "79305001")
            ->update([
                HotelBusinessInformation::COL_BANK_NAME => "EXIMBANK - NGÂN HÀNG THƯƠNG MẠI CỔ PHẦN XUẤT NHẬP KHẨU VIỆT NAM"
            ]);
    }
}
