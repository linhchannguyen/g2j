<?php

namespace App\Console\Commands\Migration;

use App\Constants\Activity as ActivityConst;
use App\Constants\Promotion as PromotionConst;
use App\Models\Activity;
use App\Models\Promotion;
use Carbon\Carbon;
use Illuminate\Console\Command;

class MigrateCouponSignupWithWaitingStatus extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'migration:migrate-coupon-signup-with-waiting-status';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Migrate data from old Coupon to new phase.';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return void
     */
    public function handle()
    {
        $now = Carbon::parse(now()->format('Y-m-d'));
        $promotionList = Promotion::where(Promotion::COL_STATUS, PromotionConst::STATUS['AWAITING_CONFIRMATION'])
            ->where(Promotion::COL_TYPE, PromotionConst::TYPE['SIGNUP'])
            ->get([
                Promotion::COL_SN,
                Promotion::COL_APPLY_END
            ]);
        foreach ($promotionList as $promotion) {
            $activityWaitingOfPromotion = Activity::where(Activity::COL_TARGET_SN, $promotion->{Promotion::COL_SN})
                ->where(Activity::COL_TYPE, ActivityConst::TYPE['PROMOTION'])
                ->where(Activity::COL_STATUS, ActivityConst::STATUS['WAITING'])
                ->exists();
            $applyEnd = $promotion->{Promotion::COL_APPLY_END} ?? null;
            if (!$activityWaitingOfPromotion && (!empty($applyEnd) && strtotime($applyEnd) < $now->timestamp)) {
                Promotion::where(Promotion::COL_SN, $promotion->{Promotion::COL_SN})->update([Promotion::COL_STATUS => PromotionConst::STATUS['EXPIRED']]);
            }
        }
    }
}
