<?php

namespace App\Console\Commands\Migration;

use App\Constants\MileageHistory as MileageHistoryConst;
use App\Constants\MileagePointExpiration as MileagePointExpirationConst;
use App\Constants\MileagePointHistory as MileagePointHistoryConst;
use App\Constants\MileagePointTransaction as MileagePointTransactionConst;
use App\Constants\MileagePointTransactionHistory as MileagePointTransactionHistoryConst;
use App\Helpers\CommonHelper;
use App\Models\Hotel;
use App\Models\MileageHistory;
use App\Models\MileagePointExpiration;
use App\Models\MileagePointHistory;
use App\Models\MileagePointTransaction;
use App\Models\MileagePointTransactionHistory;
use App\Models\MileageReward;
use App\Models\UserBooking;
use App\Repositories\Interfaces\MileageHistoryRepositoryInterface;
use Exception;
use Illuminate\Console\Command;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\DB;
use stdClass;

class TransferMileageHistory extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'migration:transfer-mileage-history
                            {--appUserSnList=}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Transfer Mileage History to Mileage Point Transaction History.';

    const CUTOFF_TIME = '2022-01-01 00:00:00';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     */
    public function handle(MileageHistoryRepositoryInterface $mileageHistoryRepository)
    {
        $appUserSnList = $this->option('appUserSnList');
        $appUserSnList = explode(',', $appUserSnList);
        $appUserSnList = array_filter($appUserSnList);
        $appUserSnList = array_map('intval', $appUserSnList);

        $mileageHistoryList = $mileageHistoryRepository->findMileageHistoryNotTransferYet(self::CUTOFF_TIME, $appUserSnList);

        foreach ($mileageHistoryList as $mileageHistory) {
            $mileageRewardSn = $mileageHistory->{MileageHistory::COL_MILEAGE_REWARD_SN};

            $userBookingSn = $mileageHistory->{MileagePointTransaction::COL_USER_BOOKING_SN};

            if (empty($userBookingSn)) {
                // Donate by manual
                self::_transferDonateTransaction($mileageHistory);
                continue;
            }

            $userBooking = DB::connection('mysql')
                ->table(UserBooking::TABLE_NAME)
                ->where(UserBooking::COL_SN, $userBookingSn)
                ->first([
                    UserBooking::COL_BOOKING_NO,
                    UserBooking::COL_AMOUNT_FROM_USER,
                    UserBooking::COL_HOTEL_SN,
                    UserBooking::COL_CHECK_IN_DATE_PLAN,
                    UserBooking::COL_TYPE,
                    UserBooking::COL_START_TIME,
                    UserBooking::COL_END_TIME,
                    UserBooking::COL_END_DATE,
                ]);

            $bookingNo = $userBooking->{UserBooking::COL_BOOKING_NO};
            $amountFromUser = $userBooking->{UserBooking::COL_AMOUNT_FROM_USER};
            $hotelSn = $userBooking->{UserBooking::COL_HOTEL_SN};
            $hotel = DB::connection('mysql')
                ->table(Hotel::TABLE_NAME)
                ->where(Hotel::COL_SN, $hotelSn)
                ->first([Hotel::COL_NAME]);
            $hotelName = $hotel->{Hotel::COL_NAME};
            $checkin = CommonHelper::getBookingCheckinDateTime($userBooking);
            $checkout = CommonHelper::getBookingCheckoutDateTime($userBooking);

            if (empty($mileageRewardSn)) {
                self::_transferBookingTransaction($mileageHistory, $bookingNo, $hotelName, $checkin, $checkout, $amountFromUser);
            } else {
                $mileageReward = DB::connection('mysql')
                    ->table(MileageReward::TABLE_NAME)
                    ->where(MileageReward::COL_SN, $mileageRewardSn)
                    ->first([
                        MileageReward::COL_NAME,
                    ]);

                $mileageRewardName = $mileageReward->{MileageReward::COL_NAME};
                self::_transferRewardTransaction($mileageHistory, $mileageRewardName, $bookingNo, $hotelName, $checkin, $checkout, $amountFromUser);
            }
        }
    }

    private function _transferDonateTransaction(stdClass $mileageHistory)
    {
        DB::connection('mysql')->beginTransaction();
        try {
            $type = $mileageHistory->{MileageHistory::COL_TYPE};
            switch ($type) {
                case MileageHistoryConst::TYPE['GET']:
                {
                    $numOfPoint = $mileageHistory->{MileageHistory::COL_NUM_OF_POINT};
                    if ($numOfPoint == 0) {
                        break;
                    }

                    $mileageHistorySn = $mileageHistory->{MileageHistory::COL_SN};
                    $appUserSn = $mileageHistory->{MileageHistory::COL_APP_USER_SN};
                    $typeProgram = MileagePointTransactionHistoryConst::TYPE_PROGRAM['DONATE'];
                    $actualPoint = $numOfPoint;
                    $expectedPoint = $numOfPoint;
                    $createTime = $mileageHistory->{MileageHistory::COL_CREATE_TIME};
                    $lastUpdate = $mileageHistory->{MileageHistory::COL_LAST_UPDATE};
                    $totalActivePoint = null;

                    $mileagePointTransactionHistory = MileagePointTransactionHistory::create([
                        MileagePointTransactionHistory::COL_SN                 => $mileageHistorySn + MileageHistoryConst::TRANSFER_AUTO_INCREMENT_VALUE,
                        MileagePointTransactionHistory::COL_APP_USER_SN        => $appUserSn,
                        MileagePointTransactionHistory::COL_TYPE_PROGRAM       => $typeProgram,
                        MileagePointTransactionHistory::COL_PROGRAM_SN         => null,
                        MileagePointTransactionHistory::COL_USER_BOOKING_SN    => null,
                        MileagePointTransactionHistory::COL_TOTAL_ACTIVE_POINT => $totalActivePoint,
                        MileagePointTransactionHistory::COL_ACTUAL_POINT       => $actualPoint,
                        MileagePointTransactionHistory::COL_EXPECTED_POINT     => $expectedPoint,
                        MileagePointTransactionHistory::COL_STATUS             => MileagePointTransactionHistoryConst::STATUS['ACTIVE'],
                        MileagePointTransactionHistory::COL_CREATE_TIME        => $createTime,
                        MileagePointTransactionHistory::COL_LAST_UPDATE        => $lastUpdate,
                    ]);
                    $mileagePointTransactionHistorySn = $mileagePointTransactionHistory->{MileagePointTransactionHistory::COL_SN};

                    $expiredDate = $mileageHistory->{MileageHistory::COL_EXPIRED_DATE};
                    if (!empty($expiredDate)) {
                        $expiredDate = Carbon::parse($expiredDate);
                    } else {
                        $expiredDate = Carbon::parse($createTime)->addYear();
                    }

                    $expiredHistorySn = $mileageHistory->{MileageHistory::COL_EXPIRED_HISTORY_SN};
                    $usedPoint = $mileageHistory->{MileageHistory::COL_USED_POINT};
                    if (empty($expiredHistorySn) && $numOfPoint > $usedPoint) {
                        $remainingPoint = $numOfPoint - $usedPoint;

                        MileagePointExpiration::create([
                            MileagePointExpiration::COL_MILEAGE_POINT_TRANSACTION_HISTORY_SN => $mileagePointTransactionHistorySn,
                            MileagePointExpiration::COL_APP_USER_SN                          => $appUserSn,
                            MileagePointExpiration::COL_NUM_OF_POINT                         => abs($actualPoint),
                            MileagePointExpiration::COL_REMAINING_POINT                      => abs($remainingPoint),
                            MileagePointExpiration::COL_DAY                                  => $expiredDate->day,
                            MileagePointExpiration::COL_MONTH                                => $expiredDate->month,
                            MileagePointExpiration::COL_YEAR                                 => $expiredDate->year,
                            MileagePointExpiration::COL_PROCESSED                            => MileagePointExpirationConst::PROCESSED['NOT_YET'],
                            MileagePointExpiration::COL_CREATE_TIME                          => $createTime,
                            MileagePointExpiration::COL_LAST_UPDATE                          => $lastUpdate,
                        ]);
                    }

                    MileagePointHistory::create([
                        MileagePointHistory::COL_APP_USER_SN                            => $appUserSn,
                        MileagePointHistory::COL_PROGRAM_NAME                           => MileagePointHistoryConst::DONATE_PROGRAM_NAME,
                        MileagePointHistory::COL_PROGRAM_SN                             => null,
                        MileagePointHistory::COL_BOOKING_NO                             => null,
                        MileagePointHistory::COL_HOTEL_NAME                             => null,
                        MileagePointHistory::COL_CHECKIN                                => null,
                        MileagePointHistory::COL_CHECKOUT                               => null,
                        MileagePointHistory::COL_USER_BOOKING_SN                        => null,
                        MileagePointHistory::COL_TYPE_PROGRAM                           => MileagePointHistoryConst::TYPE_PROGRAM['DONATE'],
                        MileagePointHistory::COL_STATUS                                 => MileagePointHistoryConst::STATUS['ACTIVE'],
                        MileagePointHistory::COL_TOTAL_ACTIVE_POINT                     => $totalActivePoint,
                        MileagePointHistory::COL_ACTUAL_POINT                           => $actualPoint,
                        MileagePointHistory::COL_EXPECTED_POINT                         => $expectedPoint,
                        MileagePointHistory::COL_USER_PAID                              => 0,
                        MileagePointHistory::COL_ACTIVE_TIME_FROM                       => $createTime,
                        MileagePointHistory::COL_ACTIVE_TIME_TO                         => $expiredDate->toDateString(),
                        MileagePointHistory::COL_CLAIM_TIME                             => null,
                        MileagePointHistory::COL_REFUND_TIME                            => null,
                        MileagePointHistory::COL_EXPIRATION_TIME                        => null,
                        MileagePointHistory::COL_MILEAGE_POINT_TRANSACTION_HISTORY_LIST => json_encode([$mileagePointTransactionHistorySn]),
                        MileagePointHistory::COL_CREATE_TIME                            => $createTime,
                        MileagePointHistory::COL_LAST_UPDATE                            => $lastUpdate,
                    ]);

                    break;
                }
                case MileageHistoryConst::TYPE['USE']:
                {
                    // Don't have this case
                    break;
                }
                case MileageHistoryConst::TYPE['EXPIRED']:
                {
                    $numOfPoint = $mileageHistory->{MileageHistory::COL_NUM_OF_POINT};
                    $mileageHistorySn = $mileageHistory->{MileageHistory::COL_SN};
                    $appUserSn = $mileageHistory->{MileageHistory::COL_APP_USER_SN};
                    $typeProgram = MileagePointTransactionHistoryConst::TYPE_PROGRAM['DONATE'];
                    $actualPoint = -$numOfPoint;
                    $expectedPoint = -$numOfPoint;
                    $createTime = $mileageHistory->{MileageHistory::COL_CREATE_TIME};
                    $lastUpdate = $mileageHistory->{MileageHistory::COL_LAST_UPDATE};
                    $totalActivePoint = null;

                    $mileagePointTransactionHistory = MileagePointTransactionHistory::create([
                        MileagePointTransactionHistory::COL_SN                 => $mileageHistorySn + MileageHistoryConst::TRANSFER_AUTO_INCREMENT_VALUE,
                        MileagePointTransactionHistory::COL_APP_USER_SN        => $appUserSn,
                        MileagePointTransactionHistory::COL_TYPE_PROGRAM       => $typeProgram,
                        MileagePointTransactionHistory::COL_PROGRAM_SN         => null,
                        MileagePointTransactionHistory::COL_USER_BOOKING_SN    => null,
                        MileagePointTransactionHistory::COL_TOTAL_ACTIVE_POINT => $totalActivePoint,
                        MileagePointTransactionHistory::COL_ACTUAL_POINT       => $actualPoint,
                        MileagePointTransactionHistory::COL_EXPECTED_POINT     => $expectedPoint,
                        MileagePointTransactionHistory::COL_STATUS             => MileagePointTransactionHistoryConst::STATUS['EXPIRED'],
                        MileagePointTransactionHistory::COL_CREATE_TIME        => $createTime,
                        MileagePointTransactionHistory::COL_LAST_UPDATE        => $lastUpdate,
                    ]);
                    $mileagePointTransactionHistorySn = $mileagePointTransactionHistory->{MileagePointTransactionHistory::COL_SN};

                    $expiredDate = $mileageHistory->{MileageHistory::COL_EXPIRED_DATE};

                    MileagePointExpiration::create([
                        MileagePointExpiration::COL_MILEAGE_POINT_TRANSACTION_HISTORY_SN => $mileagePointTransactionHistory->{MileagePointTransactionHistory::COL_SN},
                        MileagePointExpiration::COL_APP_USER_SN                          => $appUserSn,
                        MileagePointExpiration::COL_NUM_OF_POINT                         => abs($actualPoint),
                        MileagePointExpiration::COL_REMAINING_POINT                      => abs($actualPoint),
                        MileagePointExpiration::COL_DAY                                  => Carbon::parse($expiredDate)->day,
                        MileagePointExpiration::COL_MONTH                                => Carbon::parse($expiredDate)->month,
                        MileagePointExpiration::COL_YEAR                                 => Carbon::parse($expiredDate)->year,
                        MileagePointExpiration::COL_PROCESSED                            => MileagePointExpirationConst::PROCESSED['PROCESSED'],
                        MileagePointExpiration::COL_CREATE_TIME                          => $createTime,
                        MileagePointExpiration::COL_LAST_UPDATE                          => $lastUpdate,
                    ]);

                    MileagePointHistory::create([
                        MileagePointHistory::COL_APP_USER_SN                            => $appUserSn,
                        MileagePointHistory::COL_PROGRAM_NAME                           => null,
                        MileagePointHistory::COL_PROGRAM_SN                             => null,
                        MileagePointHistory::COL_USER_BOOKING_SN                        => null,
                        MileagePointHistory::COL_BOOKING_NO                             => null,
                        MileagePointHistory::COL_HOTEL_NAME                             => null,
                        MileagePointHistory::COL_CHECKIN                                => null,
                        MileagePointHistory::COL_CHECKOUT                               => null,
                        MileagePointHistory::COL_TYPE_PROGRAM                           => null,
                        MileagePointHistory::COL_STATUS                                 => MileagePointHistoryConst::STATUS['EXPIRED'],
                        MileagePointHistory::COL_TOTAL_ACTIVE_POINT                     => $totalActivePoint,
                        MileagePointHistory::COL_ACTUAL_POINT                           => $actualPoint,
                        MileagePointHistory::COL_EXPECTED_POINT                         => $expectedPoint,
                        MileagePointHistory::COL_USER_PAID                              => 0,
                        MileagePointHistory::COL_ACTIVE_TIME_FROM                       => null,
                        MileagePointHistory::COL_ACTIVE_TIME_TO                         => null,
                        MileagePointHistory::COL_CLAIM_TIME                             => null,
                        MileagePointHistory::COL_REFUND_TIME                            => null,
                        MileagePointHistory::COL_EXPIRATION_TIME                        => null,
                        MileagePointHistory::COL_MILEAGE_POINT_TRANSACTION_HISTORY_LIST => json_encode([$mileagePointTransactionHistorySn]),
                        MileagePointHistory::COL_CREATE_TIME                            => $createTime,
                        MileagePointHistory::COL_LAST_UPDATE                            => $lastUpdate,
                    ]);

                    break;
                }
            }
            DB::connection('mysql')->commit();
        } catch (Exception $exception) {
            DB::connection('mysql')->rollBack();
            throw $exception;
        }
    }

    private function _transferBookingTransaction(stdClass $mileageHistory, string $bookingNo, string $hotelName, string $checkin, string $checkout, int $amountFromUser)
    {
        DB::connection('mysql')->beginTransaction();
        try {
            $type = $mileageHistory->{MileageHistory::COL_TYPE};
            switch ($type) {
                case MileageHistoryConst::TYPE['GET']:
                {
                    $numOfPoint = $mileageHistory->{MileageHistory::COL_NUM_OF_POINT};
                    if ($numOfPoint == 0) {
                        break;
                    }

                    $mileageHistorySn = $mileageHistory->{MileageHistory::COL_SN};
                    $appUserSn = $mileageHistory->{MileageHistory::COL_APP_USER_SN};
                    $userBookingSn = $mileageHistory->{MileagePointTransaction::COL_USER_BOOKING_SN};
                    $actualPoint = $numOfPoint;
                    $expectedPoint = $numOfPoint;
                    $createTime = $mileageHistory->{MileageHistory::COL_CREATE_TIME};
                    $lastUpdate = $mileageHistory->{MileageHistory::COL_LAST_UPDATE};
                    $totalActivePoint = null;

                    $mileagePointTransactionHistory = MileagePointTransactionHistory::create([
                        MileagePointTransactionHistory::COL_SN                 => $mileageHistorySn + MileageHistoryConst::TRANSFER_AUTO_INCREMENT_VALUE,
                        MileagePointTransactionHistory::COL_APP_USER_SN        => $appUserSn,
                        MileagePointTransactionHistory::COL_TYPE_PROGRAM       => MileagePointTransactionHistoryConst::TYPE_PROGRAM['BOOKING'],
                        MileagePointTransactionHistory::COL_PROGRAM_SN         => null,
                        MileagePointTransactionHistory::COL_USER_BOOKING_SN    => $userBookingSn,
                        MileagePointTransactionHistory::COL_TOTAL_ACTIVE_POINT => $totalActivePoint,
                        MileagePointTransactionHistory::COL_ACTUAL_POINT       => $actualPoint,
                        MileagePointTransactionHistory::COL_EXPECTED_POINT     => $expectedPoint,
                        MileagePointTransactionHistory::COL_STATUS             => MileagePointTransactionHistoryConst::STATUS['ACTIVE'],
                        MileagePointTransactionHistory::COL_CREATE_TIME        => $createTime,
                        MileagePointTransactionHistory::COL_LAST_UPDATE        => $lastUpdate,
                    ]);
                    $mileagePointTransactionHistorySn = $mileagePointTransactionHistory->{MileagePointTransactionHistory::COL_SN};

                    $expiredDate = $mileageHistory->{MileageHistory::COL_EXPIRED_DATE};
                    if (!empty($expiredDate)) {
                        $expiredDate = Carbon::parse($expiredDate);
                    } else {
                        $expiredDate = Carbon::parse($createTime)->addYear();
                    }

                    $expiredHistorySn = $mileageHistory->{MileageHistory::COL_EXPIRED_HISTORY_SN};
                    $usedPoint = $mileageHistory->{MileageHistory::COL_USED_POINT};
                    if (empty($expiredHistorySn) && $numOfPoint > $usedPoint) {
                        $remainingPoint = $numOfPoint - $usedPoint;

                        MileagePointExpiration::create([
                            MileagePointExpiration::COL_MILEAGE_POINT_TRANSACTION_HISTORY_SN => $mileagePointTransactionHistorySn,
                            MileagePointExpiration::COL_APP_USER_SN                          => $appUserSn,
                            MileagePointExpiration::COL_NUM_OF_POINT                         => abs($actualPoint),
                            MileagePointExpiration::COL_REMAINING_POINT                      => abs($remainingPoint),
                            MileagePointExpiration::COL_DAY                                  => $expiredDate->day,
                            MileagePointExpiration::COL_MONTH                                => $expiredDate->month,
                            MileagePointExpiration::COL_YEAR                                 => $expiredDate->year,
                            MileagePointExpiration::COL_PROCESSED                            => MileagePointExpirationConst::PROCESSED['NOT_YET'],
                            MileagePointExpiration::COL_CREATE_TIME                          => $createTime,
                            MileagePointExpiration::COL_LAST_UPDATE                          => $lastUpdate,
                        ]);
                    }

                    MileagePointHistory::create([
                        MileagePointHistory::COL_APP_USER_SN                            => $appUserSn,
                        MileagePointHistory::COL_PROGRAM_NAME                           => null,
                        MileagePointHistory::COL_PROGRAM_SN                             => null,
                        MileagePointHistory::COL_BOOKING_NO                             => $bookingNo,
                        MileagePointHistory::COL_HOTEL_NAME                             => $hotelName,
                        MileagePointHistory::COL_CHECKIN                                => $checkin,
                        MileagePointHistory::COL_CHECKOUT                               => $checkout,
                        MileagePointHistory::COL_USER_BOOKING_SN                        => $userBookingSn,
                        MileagePointHistory::COL_TYPE_PROGRAM                           => MileagePointHistoryConst::TYPE_PROGRAM['BOOKING'],
                        MileagePointHistory::COL_STATUS                                 => MileagePointHistoryConst::STATUS['ACTIVE'],
                        MileagePointHistory::COL_TOTAL_ACTIVE_POINT                     => $totalActivePoint,
                        MileagePointHistory::COL_ACTUAL_POINT                           => $actualPoint,
                        MileagePointHistory::COL_EXPECTED_POINT                         => $expectedPoint,
                        MileagePointHistory::COL_USER_PAID                              => $amountFromUser,
                        MileagePointHistory::COL_ACTIVE_TIME_FROM                       => $createTime,
                        MileagePointHistory::COL_ACTIVE_TIME_TO                         => $expiredDate->toDateString(),
                        MileagePointHistory::COL_CLAIM_TIME                             => null,
                        MileagePointHistory::COL_REFUND_TIME                            => null,
                        MileagePointHistory::COL_EXPIRATION_TIME                        => $expiredDate->toDateString(),
                        MileagePointHistory::COL_MILEAGE_POINT_TRANSACTION_HISTORY_LIST => json_encode([$mileagePointTransactionHistorySn]),
                        MileagePointHistory::COL_CREATE_TIME                            => $createTime,
                        MileagePointHistory::COL_LAST_UPDATE                            => $lastUpdate,
                    ]);

                    break;
                }
                case MileageHistoryConst::TYPE['USE']:
                {
                    $numOfPoint = $mileageHistory->{MileageHistory::COL_NUM_OF_POINT};
                    $mileageHistorySn = $mileageHistory->{MileageHistory::COL_SN};
                    $appUserSn = $mileageHistory->{MileageHistory::COL_APP_USER_SN};
                    $userBookingSn = $mileageHistory->{MileageHistory::COL_USER_BOOKING_SN};
                    $actualPoint = -$numOfPoint;
                    $expectedPoint = -$numOfPoint;
                    $createTime = $mileageHistory->{MileageHistory::COL_CREATE_TIME};
                    $lastUpdate = $mileageHistory->{MileageHistory::COL_LAST_UPDATE};
                    $totalActivePoint = null;

                    $mileagePointTransactionHistory = MileagePointTransactionHistory::create([
                        MileagePointTransactionHistory::COL_SN                 => $mileageHistorySn + MileageHistoryConst::TRANSFER_AUTO_INCREMENT_VALUE,
                        MileagePointTransactionHistory::COL_APP_USER_SN        => $appUserSn,
                        MileagePointTransactionHistory::COL_TYPE_PROGRAM       => MileagePointTransactionHistoryConst::TYPE_PROGRAM['BOOKING'],
                        MileagePointTransactionHistory::COL_PROGRAM_SN         => null,
                        MileagePointTransactionHistory::COL_USER_BOOKING_SN    => $userBookingSn,
                        MileagePointTransactionHistory::COL_TOTAL_ACTIVE_POINT => $totalActivePoint,
                        MileagePointTransactionHistory::COL_ACTUAL_POINT       => $actualPoint,
                        MileagePointTransactionHistory::COL_EXPECTED_POINT     => $expectedPoint,
                        MileagePointTransactionHistory::COL_STATUS             => MileagePointTransactionHistoryConst::STATUS['USED'],
                        MileagePointTransactionHistory::COL_CREATE_TIME        => $createTime,
                        MileagePointTransactionHistory::COL_LAST_UPDATE        => $lastUpdate,
                    ]);
                    $mileagePointTransactionHistorySn = $mileagePointTransactionHistory->{MileagePointTransactionHistory::COL_SN};

                    MileagePointHistory::create([
                        MileagePointHistory::COL_APP_USER_SN                            => $appUserSn,
                        MileagePointHistory::COL_PROGRAM_NAME                           => null,
                        MileagePointHistory::COL_PROGRAM_SN                             => null,
                        MileagePointHistory::COL_BOOKING_NO                             => $bookingNo,
                        MileagePointHistory::COL_HOTEL_NAME                             => $hotelName,
                        MileagePointHistory::COL_CHECKIN                                => $checkin,
                        MileagePointHistory::COL_CHECKOUT                               => $checkout,
                        MileagePointHistory::COL_USER_BOOKING_SN                        => $userBookingSn,
                        MileagePointHistory::COL_TYPE_PROGRAM                           => MileagePointHistoryConst::TYPE_PROGRAM['BOOKING'],
                        MileagePointHistory::COL_STATUS                                 => MileagePointHistoryConst::STATUS['USED'],
                        MileagePointHistory::COL_TOTAL_ACTIVE_POINT                     => $totalActivePoint,
                        MileagePointHistory::COL_ACTUAL_POINT                           => $actualPoint,
                        MileagePointHistory::COL_EXPECTED_POINT                         => $expectedPoint,
                        MileagePointHistory::COL_USER_PAID                              => 0,
                        MileagePointHistory::COL_ACTIVE_TIME_FROM                       => null,
                        MileagePointHistory::COL_ACTIVE_TIME_TO                         => null,
                        MileagePointHistory::COL_CLAIM_TIME                             => $createTime,
                        MileagePointHistory::COL_REFUND_TIME                            => null,
                        MileagePointHistory::COL_EXPIRATION_TIME                        => null,
                        MileagePointHistory::COL_MILEAGE_POINT_TRANSACTION_HISTORY_LIST => json_encode([$mileagePointTransactionHistorySn]),
                        MileagePointHistory::COL_CREATE_TIME                            => $createTime,
                        MileagePointHistory::COL_LAST_UPDATE                            => $lastUpdate,
                    ]);

                    break;
                }
                case MileageHistoryConst::TYPE['EXPIRED']:
                {
                    $mileageHistorySn = $mileageHistory->{MileageHistory::COL_SN};
                    $appUserSn = $mileageHistory->{MileageHistory::COL_APP_USER_SN};
                    $typeProgram = MileagePointTransactionHistoryConst::TYPE_PROGRAM['BOOKING'];
                    $userBookingSn = $mileageHistory->{MileageHistory::COL_USER_BOOKING_SN};
                    $actualPoint = -$mileageHistory->{MileageHistory::COL_NUM_OF_POINT};
                    $expectedPoint = -$mileageHistory->{MileageHistory::COL_NUM_OF_POINT};
                    $createTime = $mileageHistory->{MileageHistory::COL_CREATE_TIME};
                    $lastUpdate = $mileageHistory->{MileageHistory::COL_LAST_UPDATE};
                    $totalActivePoint = null;

                    $mileagePointTransactionHistory = MileagePointTransactionHistory::create([
                        MileagePointTransactionHistory::COL_SN                 => $mileageHistorySn + MileageHistoryConst::TRANSFER_AUTO_INCREMENT_VALUE,
                        MileagePointTransactionHistory::COL_APP_USER_SN        => $appUserSn,
                        MileagePointTransactionHistory::COL_TYPE_PROGRAM       => $typeProgram,
                        MileagePointTransactionHistory::COL_PROGRAM_SN         => null,
                        MileagePointTransactionHistory::COL_USER_BOOKING_SN    => $userBookingSn,
                        MileagePointTransactionHistory::COL_TOTAL_ACTIVE_POINT => $totalActivePoint,
                        MileagePointTransactionHistory::COL_ACTUAL_POINT       => $actualPoint,
                        MileagePointTransactionHistory::COL_EXPECTED_POINT     => $expectedPoint,
                        MileagePointTransactionHistory::COL_STATUS             => MileagePointTransactionHistoryConst::STATUS['EXPIRED'],
                        MileagePointTransactionHistory::COL_CREATE_TIME        => $createTime,
                        MileagePointTransactionHistory::COL_LAST_UPDATE        => $lastUpdate,
                    ]);
                    $mileagePointTransactionHistorySn = $mileagePointTransactionHistory->{MileagePointTransactionHistory::COL_SN};

                    $expiredDate = $mileageHistory->{MileageHistory::COL_EXPIRED_DATE};

                    MileagePointExpiration::create([
                        MileagePointExpiration::COL_MILEAGE_POINT_TRANSACTION_HISTORY_SN => $mileagePointTransactionHistory->{MileagePointTransactionHistory::COL_SN},
                        MileagePointExpiration::COL_APP_USER_SN                          => $appUserSn,
                        MileagePointExpiration::COL_NUM_OF_POINT                         => abs($actualPoint),
                        MileagePointExpiration::COL_REMAINING_POINT                      => abs($actualPoint),
                        MileagePointExpiration::COL_DAY                                  => Carbon::parse($expiredDate)->day,
                        MileagePointExpiration::COL_MONTH                                => Carbon::parse($expiredDate)->month,
                        MileagePointExpiration::COL_YEAR                                 => Carbon::parse($expiredDate)->year,
                        MileagePointExpiration::COL_PROCESSED                            => MileagePointExpirationConst::PROCESSED['PROCESSED'],
                        MileagePointExpiration::COL_CREATE_TIME                          => $createTime,
                        MileagePointExpiration::COL_LAST_UPDATE                          => $lastUpdate,
                    ]);

                    MileagePointHistory::create([
                        MileagePointHistory::COL_APP_USER_SN                            => $appUserSn,
                        MileagePointHistory::COL_PROGRAM_NAME                           => null,
                        MileagePointHistory::COL_PROGRAM_SN                             => null,
                        MileagePointHistory::COL_USER_BOOKING_SN                        => null,
                        MileagePointHistory::COL_BOOKING_NO                             => null,
                        MileagePointHistory::COL_HOTEL_NAME                             => null,
                        MileagePointHistory::COL_CHECKIN                                => null,
                        MileagePointHistory::COL_CHECKOUT                               => null,
                        MileagePointHistory::COL_TYPE_PROGRAM                           => null,
                        MileagePointHistory::COL_STATUS                                 => MileagePointHistoryConst::STATUS['EXPIRED'],
                        MileagePointHistory::COL_TOTAL_ACTIVE_POINT                     => $totalActivePoint,
                        MileagePointHistory::COL_ACTUAL_POINT                           => $actualPoint,
                        MileagePointHistory::COL_EXPECTED_POINT                         => $expectedPoint,
                        MileagePointHistory::COL_USER_PAID                              => 0,
                        MileagePointHistory::COL_ACTIVE_TIME_FROM                       => null,
                        MileagePointHistory::COL_ACTIVE_TIME_TO                         => null,
                        MileagePointHistory::COL_CLAIM_TIME                             => null,
                        MileagePointHistory::COL_REFUND_TIME                            => null,
                        MileagePointHistory::COL_EXPIRATION_TIME                        => null,
                        MileagePointHistory::COL_MILEAGE_POINT_TRANSACTION_HISTORY_LIST => json_encode([$mileagePointTransactionHistorySn]),
                        MileagePointHistory::COL_CREATE_TIME                            => $createTime,
                        MileagePointHistory::COL_LAST_UPDATE                            => $lastUpdate,
                    ]);

                    break;
                }
            }
            DB::connection('mysql')->commit();
        } catch (Exception $exception) {
            DB::connection('mysql')->rollBack();
            throw $exception;
        }
    }

    private function _transferRewardTransaction(stdClass $mileageHistory, string $mileageRewardName, string $bookingNo, string $hotelName, string $checkin, string $checkout, int $amountFromUser)
    {
        DB::connection('mysql')->beginTransaction();
        try {
            $type = $mileageHistory->{MileageHistory::COL_TYPE};
            switch ($type) {
                case MileageHistoryConst::TYPE['GET']:
                {
                    $numOfPoint = $mileageHistory->{MileageHistory::COL_NUM_OF_POINT};
                    $mileageHistorySn = $mileageHistory->{MileageHistory::COL_SN};
                    $appUserSn = $mileageHistory->{MileageHistory::COL_APP_USER_SN};
                    $mileageRewardSn = $mileageHistory->{MileageHistory::COL_MILEAGE_REWARD_SN};
                    $userBookingSn = $mileageHistory->{MileageHistory::COL_USER_BOOKING_SN};
                    $actualPoint = $numOfPoint;
                    $expectedPoint = $numOfPoint;
                    $createTime = $mileageHistory->{MileageHistory::COL_CREATE_TIME};
                    $lastUpdate = $mileageHistory->{MileageHistory::COL_LAST_UPDATE};
                    $totalActivePoint = null;

                    $mileagePointTransactionHistory = MileagePointTransactionHistory::create([
                        MileagePointTransactionHistory::COL_SN                 => $mileageHistorySn + MileageHistoryConst::TRANSFER_AUTO_INCREMENT_VALUE,
                        MileagePointTransactionHistory::COL_APP_USER_SN        => $appUserSn,
                        MileagePointTransactionHistory::COL_TYPE_PROGRAM       => MileagePointTransactionHistoryConst::TYPE_PROGRAM['REWARD'],
                        MileagePointTransactionHistory::COL_PROGRAM_SN         => $mileageRewardSn,
                        MileagePointTransactionHistory::COL_USER_BOOKING_SN    => $userBookingSn,
                        MileagePointTransactionHistory::COL_TOTAL_ACTIVE_POINT => $totalActivePoint,
                        MileagePointTransactionHistory::COL_ACTUAL_POINT       => $actualPoint,
                        MileagePointTransactionHistory::COL_EXPECTED_POINT     => $expectedPoint,
                        MileagePointTransactionHistory::COL_STATUS             => MileagePointTransactionHistoryConst::STATUS['ACTIVE'],
                        MileagePointTransactionHistory::COL_CREATE_TIME        => $createTime,
                        MileagePointTransactionHistory::COL_LAST_UPDATE        => $lastUpdate,
                    ]);
                    $mileagePointTransactionHistorySn = $mileagePointTransactionHistory->{MileagePointTransactionHistory::COL_SN};

                    $expiredDate = $mileageHistory->{MileageHistory::COL_EXPIRED_DATE};
                    if (!empty($expiredDate)) {
                        $expiredDate = Carbon::parse($expiredDate);
                    } else {
                        $expiredDate = Carbon::parse($createTime)->addYear();
                    }

                    $expiredHistorySn = $mileageHistory->{MileageHistory::COL_EXPIRED_HISTORY_SN};
                    $usedPoint = $mileageHistory->{MileageHistory::COL_USED_POINT};
                    if (empty($expiredHistorySn) && $numOfPoint > $usedPoint) {
                        $remainingPoint = $numOfPoint - $usedPoint;

                        MileagePointExpiration::create([
                            MileagePointExpiration::COL_MILEAGE_POINT_TRANSACTION_HISTORY_SN => $mileagePointTransactionHistorySn,
                            MileagePointExpiration::COL_APP_USER_SN                          => $appUserSn,
                            MileagePointExpiration::COL_NUM_OF_POINT                         => abs($actualPoint),
                            MileagePointExpiration::COL_REMAINING_POINT                      => abs($remainingPoint),
                            MileagePointExpiration::COL_DAY                                  => $expiredDate->day,
                            MileagePointExpiration::COL_MONTH                                => $expiredDate->month,
                            MileagePointExpiration::COL_YEAR                                 => $expiredDate->year,
                            MileagePointExpiration::COL_PROCESSED                            => MileagePointExpirationConst::PROCESSED['NOT_YET'],
                            MileagePointExpiration::COL_CREATE_TIME                          => $createTime,
                            MileagePointExpiration::COL_LAST_UPDATE                          => $lastUpdate,
                        ]);
                    }

                    MileagePointHistory::create([
                        MileagePointHistory::COL_APP_USER_SN                            => $appUserSn,
                        MileagePointHistory::COL_PROGRAM_NAME                           => $mileageRewardName,
                        MileagePointHistory::COL_PROGRAM_SN                             => $mileageRewardSn,
                        MileagePointHistory::COL_BOOKING_NO                             => $bookingNo,
                        MileagePointHistory::COL_HOTEL_NAME                             => $hotelName,
                        MileagePointHistory::COL_CHECKIN                                => $checkin,
                        MileagePointHistory::COL_CHECKOUT                               => $checkout,
                        MileagePointHistory::COL_USER_BOOKING_SN                        => $userBookingSn,
                        MileagePointHistory::COL_TYPE_PROGRAM                           => MileagePointHistoryConst::TYPE_PROGRAM['REWARD'],
                        MileagePointHistory::COL_STATUS                                 => MileagePointHistoryConst::STATUS['ACTIVE'],
                        MileagePointHistory::COL_TOTAL_ACTIVE_POINT                     => $totalActivePoint,
                        MileagePointHistory::COL_ACTUAL_POINT                           => $actualPoint,
                        MileagePointHistory::COL_EXPECTED_POINT                         => $expectedPoint,
                        MileagePointHistory::COL_USER_PAID                              => $amountFromUser,
                        MileagePointHistory::COL_ACTIVE_TIME_FROM                       => $createTime,
                        MileagePointHistory::COL_ACTIVE_TIME_TO                         => $expiredDate->toDateString(),
                        MileagePointHistory::COL_CLAIM_TIME                             => null,
                        MileagePointHistory::COL_REFUND_TIME                            => null,
                        MileagePointHistory::COL_EXPIRATION_TIME                        => $expiredDate->toDateString(),
                        MileagePointHistory::COL_MILEAGE_POINT_TRANSACTION_HISTORY_LIST => json_encode([$mileagePointTransactionHistorySn]),
                        MileagePointHistory::COL_CREATE_TIME                            => $createTime,
                        MileagePointHistory::COL_LAST_UPDATE                            => $lastUpdate,
                    ]);

                    break;
                }
                case MileageHistoryConst::TYPE['USE']:
                {
                    $numOfPoint = $mileageHistory->{MileageHistory::COL_NUM_OF_POINT};
                    $mileageHistorySn = $mileageHistory->{MileageHistory::COL_SN};
                    $appUserSn = $mileageHistory->{MileageHistory::COL_APP_USER_SN};
                    $mileageRewardSn = $mileageHistory->{MileageHistory::COL_MILEAGE_REWARD_SN};
                    $userBookingSn = $mileageHistory->{MileageHistory::COL_USER_BOOKING_SN};
                    $actualPoint = -$numOfPoint;
                    $expectedPoint = -$numOfPoint;
                    $createTime = $mileageHistory->{MileageHistory::COL_CREATE_TIME};
                    $lastUpdate = $mileageHistory->{MileageHistory::COL_LAST_UPDATE};
                    $totalActivePoint = null;

                    $mileagePointTransactionHistory = MileagePointTransactionHistory::create([
                        MileagePointTransactionHistory::COL_SN                 => $mileageHistorySn + MileageHistoryConst::TRANSFER_AUTO_INCREMENT_VALUE,
                        MileagePointTransactionHistory::COL_APP_USER_SN        => $appUserSn,
                        MileagePointTransactionHistory::COL_TYPE_PROGRAM       => MileagePointTransactionHistoryConst::TYPE_PROGRAM['REWARD'],
                        MileagePointTransactionHistory::COL_PROGRAM_SN         => $mileageRewardSn,
                        MileagePointTransactionHistory::COL_USER_BOOKING_SN    => $userBookingSn,
                        MileagePointTransactionHistory::COL_TOTAL_ACTIVE_POINT => $totalActivePoint,
                        MileagePointTransactionHistory::COL_ACTUAL_POINT       => $actualPoint,
                        MileagePointTransactionHistory::COL_EXPECTED_POINT     => $expectedPoint,
                        MileagePointTransactionHistory::COL_STATUS             => MileagePointTransactionHistoryConst::STATUS['USED'],
                        MileagePointTransactionHistory::COL_CREATE_TIME        => $createTime,
                        MileagePointTransactionHistory::COL_LAST_UPDATE        => $lastUpdate,
                    ]);
                    $mileagePointTransactionHistorySn = $mileagePointTransactionHistory->{MileagePointTransactionHistory::COL_SN};

                    MileagePointHistory::create([
                        MileagePointHistory::COL_APP_USER_SN                            => $appUserSn,
                        MileagePointHistory::COL_PROGRAM_NAME                           => $mileageRewardName,
                        MileagePointHistory::COL_PROGRAM_SN                             => $mileageRewardSn,
                        MileagePointHistory::COL_BOOKING_NO                             => $bookingNo,
                        MileagePointHistory::COL_HOTEL_NAME                             => $hotelName,
                        MileagePointHistory::COL_CHECKIN                                => $checkin,
                        MileagePointHistory::COL_CHECKOUT                               => $checkout,
                        MileagePointHistory::COL_USER_BOOKING_SN                        => $userBookingSn,
                        MileagePointHistory::COL_TYPE_PROGRAM                           => MileagePointHistoryConst::TYPE_PROGRAM['REWARD'],
                        MileagePointHistory::COL_STATUS                                 => MileagePointHistoryConst::STATUS['USED'],
                        MileagePointHistory::COL_TOTAL_ACTIVE_POINT                     => $totalActivePoint,
                        MileagePointHistory::COL_ACTUAL_POINT                           => $actualPoint,
                        MileagePointHistory::COL_EXPECTED_POINT                         => $expectedPoint,
                        MileagePointHistory::COL_USER_PAID                              => $amountFromUser,
                        MileagePointHistory::COL_ACTIVE_TIME_FROM                       => null,
                        MileagePointHistory::COL_ACTIVE_TIME_TO                         => null,
                        MileagePointHistory::COL_CLAIM_TIME                             => $createTime,
                        MileagePointHistory::COL_REFUND_TIME                            => null,
                        MileagePointHistory::COL_EXPIRATION_TIME                        => null,
                        MileagePointHistory::COL_MILEAGE_POINT_TRANSACTION_HISTORY_LIST => json_encode([$mileagePointTransactionHistorySn]),
                        MileagePointHistory::COL_CREATE_TIME                            => $createTime,
                        MileagePointHistory::COL_LAST_UPDATE                            => $lastUpdate,
                    ]);

                    break;
                }
                case MileagePointTransactionConst::TYPE['EXPIRED']:
                {
                    $numOfPoint = $mileageHistory->{MileageHistory::COL_NUM_OF_POINT};
                    $mileageHistorySn = $mileageHistory->{MileageHistory::COL_SN};
                    $appUserSn = $mileageHistory->{MileageHistory::COL_APP_USER_SN};
                    $mileageRewardSn = $mileageHistory->{MileageHistory::COL_MILEAGE_REWARD_SN};
                    $userBookingSn = $mileageHistory->{MileageHistory::COL_USER_BOOKING_SN};
                    $actualPoint = -$numOfPoint;
                    $expectedPoint = -$numOfPoint;
                    $createTime = $mileageHistory->{MileageHistory::COL_CREATE_TIME};
                    $lastUpdate = $mileageHistory->{MileageHistory::COL_LAST_UPDATE};
                    $totalActivePoint = null;

                    $mileagePointTransactionHistory = MileagePointTransactionHistory::create([
                        MileagePointTransactionHistory::COL_SN                 => $mileageHistorySn + MileageHistoryConst::TRANSFER_AUTO_INCREMENT_VALUE,
                        MileagePointTransactionHistory::COL_APP_USER_SN        => $appUserSn,
                        MileagePointTransactionHistory::COL_TYPE_PROGRAM       => MileagePointTransactionHistoryConst::TYPE_PROGRAM['REWARD'],
                        MileagePointTransactionHistory::COL_PROGRAM_SN         => $mileageRewardSn,
                        MileagePointTransactionHistory::COL_USER_BOOKING_SN    => $userBookingSn,
                        MileagePointTransactionHistory::COL_TOTAL_ACTIVE_POINT => $totalActivePoint,
                        MileagePointTransactionHistory::COL_ACTUAL_POINT       => $actualPoint,
                        MileagePointTransactionHistory::COL_EXPECTED_POINT     => $expectedPoint,
                        MileagePointTransactionHistory::COL_STATUS             => MileagePointTransactionHistoryConst::STATUS['EXPIRED'],
                        MileagePointTransactionHistory::COL_CREATE_TIME        => $createTime,
                        MileagePointTransactionHistory::COL_LAST_UPDATE        => $lastUpdate,
                    ]);
                    $mileagePointTransactionHistorySn = $mileagePointTransactionHistory->{MileagePointTransactionHistory::COL_SN};

                    $expiredDate = $mileageHistory->{MileageHistory::COL_EXPIRED_DATE};

                    MileagePointExpiration::create([
                        MileagePointExpiration::COL_MILEAGE_POINT_TRANSACTION_HISTORY_SN => $mileagePointTransactionHistory->{MileagePointTransactionHistory::COL_SN},
                        MileagePointExpiration::COL_APP_USER_SN                          => $appUserSn,
                        MileagePointExpiration::COL_NUM_OF_POINT                         => abs($actualPoint),
                        MileagePointExpiration::COL_REMAINING_POINT                      => abs($actualPoint),
                        MileagePointExpiration::COL_DAY                                  => Carbon::parse($expiredDate)->day,
                        MileagePointExpiration::COL_MONTH                                => Carbon::parse($expiredDate)->month,
                        MileagePointExpiration::COL_YEAR                                 => Carbon::parse($expiredDate)->year,
                        MileagePointExpiration::COL_PROCESSED                            => MileagePointExpirationConst::PROCESSED['PROCESSED'],
                        MileagePointExpiration::COL_CREATE_TIME                          => $createTime,
                        MileagePointExpiration::COL_LAST_UPDATE                          => $lastUpdate,
                    ]);

                    MileagePointHistory::create([
                        MileagePointHistory::COL_APP_USER_SN                            => $appUserSn,
                        MileagePointHistory::COL_PROGRAM_NAME                           => null,
                        MileagePointHistory::COL_PROGRAM_SN                             => null,
                        MileagePointHistory::COL_BOOKING_NO                             => null,
                        MileagePointHistory::COL_HOTEL_NAME                             => null,
                        MileagePointHistory::COL_CHECKIN                                => null,
                        MileagePointHistory::COL_CHECKOUT                               => null,
                        MileagePointHistory::COL_USER_BOOKING_SN                        => null,
                        MileagePointHistory::COL_TYPE_PROGRAM                           => null,
                        MileagePointHistory::COL_STATUS                                 => MileagePointHistoryConst::STATUS['EXPIRED'],
                        MileagePointHistory::COL_TOTAL_ACTIVE_POINT                     => $totalActivePoint,
                        MileagePointHistory::COL_ACTUAL_POINT                           => $actualPoint,
                        MileagePointHistory::COL_EXPECTED_POINT                         => $expectedPoint,
                        MileagePointHistory::COL_USER_PAID                              => 0,
                        MileagePointHistory::COL_ACTIVE_TIME_FROM                       => null,
                        MileagePointHistory::COL_ACTIVE_TIME_TO                         => null,
                        MileagePointHistory::COL_CLAIM_TIME                             => null,
                        MileagePointHistory::COL_REFUND_TIME                            => null,
                        MileagePointHistory::COL_EXPIRATION_TIME                        => null,
                        MileagePointHistory::COL_MILEAGE_POINT_TRANSACTION_HISTORY_LIST => json_encode([$mileagePointTransactionHistorySn]),
                        MileagePointHistory::COL_CREATE_TIME                            => $createTime,
                        MileagePointHistory::COL_LAST_UPDATE                            => $lastUpdate,
                    ]);

                    break;
                }
            }

            DB::connection('mysql')->commit();
        } catch (Exception $exception) {
            DB::connection('mysql')->rollBack();
            throw $exception;
        }
    }
}

