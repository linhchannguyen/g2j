<?php

namespace App\Console\Commands\Migration;

use App\Constants\Globals\QueueName;
use App\Constants\RoomPriceAdjustment as RoomPriceAdjustmentConst;
use App\Constants\RoomType as RoomTypeConst;
use App\Jobs\ElasticSearch\SyncRoomPriceAdjustmentJob;
use App\Models\RoomPriceAdjustment;
use App\Models\RoomType;
use App\Repositories\Interfaces\RoomPriceAdjustmentRepositoryInterface;
use App\Repositories\MySQL\RoomPriceAdjustmentRepository;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;

class TransferForHotelAllDayPrice extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'migration:transfer-for-hotel-all-day-price';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Transfer For Hotel All Day Price.';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     */
    public function handle(RoomPriceAdjustmentRepositoryInterface $roomPriceAdjustmentRepository)
    {
        $roomPriceAdjustmentList = $roomPriceAdjustmentRepository->findAllRoomPriceAdjustmentMigration();
        foreach ($roomPriceAdjustmentList as $roomPriceAdjustment) {
            //Sync Data RoomPrice Adjustment
            $syncRoomPriceAdjustmentJob = new SyncRoomPriceAdjustmentJob(json_encode([
                'sn'          => $roomPriceAdjustment->{RoomType::COL_SN},
                'hotelSn'     => $roomPriceAdjustment->{RoomType::COL_HOTEL_SN},
                'typeApply'   => $roomPriceAdjustment->{RoomPriceAdjustment::COL_TYPE_APPLY},
                'startDate'   => $roomPriceAdjustment->{RoomPriceAdjustment::COL_START_DATE},
                'endDate'     => $roomPriceAdjustment->{RoomPriceAdjustment::COL_END_DATE},
                'specialDate' => $roomPriceAdjustment->{RoomPriceAdjustment::COL_SPECIAL_DATE},
                'maxHour'     => $roomPriceAdjustment->{RoomType::COL_MAX_NUM_HOUR},
            ]));
            dispatch($syncRoomPriceAdjustmentJob)->onQueue(QueueName::ROOM_PRICING_SYNCING);

        }
    }
}

