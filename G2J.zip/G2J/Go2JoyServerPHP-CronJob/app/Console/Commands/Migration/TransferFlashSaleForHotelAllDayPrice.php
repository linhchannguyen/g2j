<?php

namespace App\Console\Commands\Migration;

use App\Constants\Globals\QueueName as QueueNameConst;
use App\Jobs\ElasticSearch\SyncRoomPriceFlashSaleJob;
use App\Models\RoomType;
use App\Repositories\Interfaces\RoomTypeRepositoryInterface;
use Illuminate\Console\Command;

class TransferFlashSaleForHotelAllDayPrice extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'migration:transfer-flash-sale-for-hotel-all-day-price';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Transfer Flash Sale For Hotel All Day Price.';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     */
    public function handle(RoomTypeRepositoryInterface $roomTypeRepository)
    {
        $roomTypeList = $roomTypeRepository->findAllRoomFlashSaleMigration();
        foreach ($roomTypeList as $roomType) {
            //Sync Data Room FlashSale
            $syncRoomPriceFlashSaleJob = new SyncRoomPriceFlashSaleJob(json_encode([
                'sn'              => $roomType->{RoomType::COL_SN},
                'hotelSn'         => $roomType->{RoomType::COL_HOTEL_SN},
                'date'            => $roomType->{RoomType::COL_START_DATE_FLASH_SALE},
                'removeFlashSale' => false,
                'priceFlashSale'  => intval($roomType->{RoomType::COL_PRICE_FLASH_SALE}),
                'bookCount'       => $roomType->{RoomType::COL_BOOK_COUNT},
                'numOfRoom'       => $roomType->{RoomType::COL_NUM_OF_ROOM},
                'overnightOrigin' => intval($roomType->{RoomType::COL_OVERNIGHT_ORIGIN}),
            ]));
            dispatch($syncRoomPriceFlashSaleJob)->onQueue(QueueNameConst::ROOM_PRICING_SYNCING);
        }
    }
}

