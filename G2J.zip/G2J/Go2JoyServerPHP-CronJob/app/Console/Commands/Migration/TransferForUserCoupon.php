<?php

namespace App\Console\Commands\Migration;

use App\Helpers\ConvertHelper;
use App\Models\CouponIssued;
use App\Repositories\Interfaces\AppUserRepositoryInterface;
use App\Repositories\Interfaces\CouponIssuedRepositoryInterface;
use App\Repositories\Interfaces\PromotionRepositoryInterface;
use App\Services\Common\ElasticSearchService;
use Illuminate\Console\Command;
use stdClass;

class TransferForUserCoupon extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'migration:transfer-for-user-coupon';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Transfer Coupon For User Coupon.';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     */
    public function handle(ElasticSearchService            $elasticSearchService,
                           PromotionRepositoryInterface    $promotionRepository,
                           CouponIssuedRepositoryInterface $couponIssuedRepository,
                           AppUserRepositoryInterface      $appUserRepository
    ) {
        $couponSnListCanApplyStr = [];
        $arrayUserHasCoupon = [];
        $couponSnList = $promotionRepository->findAllPromotionCanApply();
        $userSnList = $couponIssuedRepository->findAllCouponIssuedMigration();
        $userSnListTotal = $appUserRepository->findAllUserActiveMigration()->pluck('SN')->toArray();
        if (!empty($couponSnList)) {
            $couponSnListCanApplyStr = implode(ConvertHelper::COMMA, $couponSnList->pluck('SN')->toArray());
        }
        $bulkUserCoupon = [];
        foreach ($userSnList as $couponIssued) {
                $group = md5($couponIssued->{CouponIssued::AS_COUPON_SN_LIST});
                $index = ['index' => new stdClass()];
                $arrayUserHasCoupon[] = $couponIssued->{CouponIssued::COL_APP_USER_SN};
                $pushUserCoupon = [
                    'userSn'               => $couponIssued->{CouponIssued::COL_APP_USER_SN},
                    'group'                => $group,
                    'couponSnList'         => $couponIssued->{CouponIssued::AS_COUPON_SN_LIST},
                    'couponSnListCanApply' => $couponSnListCanApplyStr,
                ];
                $index = json_encode($index);
                $pushUserCoupon = json_encode($pushUserCoupon);
                $bulkUserCoupon[] = $index;
                $bulkUserCoupon[] = $pushUserCoupon;
            }
        $elasticSearchService->deleteUserCoupon($userSnList->pluck('APP_USER_SN')->toArray());
        $elasticSearchService->insertUserCoupon($bulkUserCoupon);

        $arrayUserNonCoupon = array_diff($userSnListTotal, $arrayUserHasCoupon);
        foreach (array_chunk($arrayUserNonCoupon, 500) as $chunk) {
            $bulkUserCoupon = [];
            foreach ($chunk as $userSn) {
                $group = md5("");
                $index = ['index' => new stdClass()];
                $pushUserCoupon = [
                    'userSn'               => $userSn,
                    'group'                => $group,
                    'couponSnList'         => "",
                    'couponSnListCanApply' => $couponSnListCanApplyStr,
                ];
                $index = json_encode($index);
                $pushUserCoupon = json_encode($pushUserCoupon);
                $bulkUserCoupon[] = $index;
                $bulkUserCoupon[] = $pushUserCoupon;
            }
            $elasticSearchService->deleteUserCoupon($chunk);
            $elasticSearchService->insertUserCoupon($bulkUserCoupon);

        }
    }
}

