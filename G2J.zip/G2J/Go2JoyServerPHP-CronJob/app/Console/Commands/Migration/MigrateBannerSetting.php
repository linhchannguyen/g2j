<?php

namespace App\Console\Commands\Migration;

use App\Constants\BannerSetting as BannerSettingConst;
use App\Constants\Hotel as HotelConst;
use App\Constants\MileageHistory as MileageHistoryConst;
use App\Constants\MileagePointExpiration as MileagePointExpirationConst;
use App\Constants\MileagePointHistory as MileagePointHistoryConst;
use App\Constants\MileagePointTransaction as MileagePointTransactionConst;
use App\Constants\MileagePointTransactionHistory as MileagePointTransactionHistoryConst;
use App\Constants\Setting as SettingConst;
use App\Helpers\CommonHelper;
use App\Models\BannerSetting;
use App\Models\Hotel;
use App\Models\MileageHistory;
use App\Models\MileagePointExpiration;
use App\Models\MileagePointHistory;
use App\Models\MileagePointTransaction;
use App\Models\MileagePointTransactionHistory;
use App\Models\MileageReward;
use App\Models\Setting;
use App\Models\UserBooking;
use App\Repositories\Interfaces\MileageHistoryRepositoryInterface;
use Exception;
use Hamcrest\Core\Set;
use Illuminate\Console\Command;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\DB;
use stdClass;

class MigrateBannerSetting extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'migration:migrate-banner-setting';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Migrate banner setting from SETTING table to BANNER_SETTING table.';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     */
    public function handle()
    {
        $setting = Setting::where(Setting::COL_HOTEL_SN, HotelConst::GO2JOY)
            ->where(Setting::COL_COMMON_NO, SettingConst::COMMON_TYPE['BANNER_POPUP'])
            ->where(Setting::COL_CLASS_NO, SettingConst::CLASS_NO['01'])
            ->first([
                Setting::COL_NUMDATA1,
            ]);
        $typeDisplay = intval($setting->getOriginalValue(Setting::COL_NUMDATA1));

        // Insert banner setting for App
        BannerSetting::create([
            BannerSetting::COL_TYPE         => BannerSettingConst::TYPE['APP'],
            BannerSetting::COL_TYPE_DISPLAY => $typeDisplay,
        ]);

        // Insert banner setting for Web
        BannerSetting::create([
            BannerSetting::COL_TYPE         => BannerSettingConst::TYPE['WEB'],
            BannerSetting::COL_TYPE_DISPLAY => $typeDisplay,
        ]);
    }
}

