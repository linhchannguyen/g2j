<?php


namespace App\Console\Commands\Daily\RunAt12Hour;


use App\Helpers\LoggingHelper;
use App\Services\Web\SA\HotelService;
use Carbon\Carbon;
use Illuminate\Console\Command;

class UpdateDailyTopSearchToday extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'UpdateDailyTopSearchToday';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Cron job for Daily 12H';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     */
    public function handle(HotelService $hotelService)
    {
        LoggingHelper::logFunction('START JOB: UPDATE TOP SEARCH TODAY');
        $hotelService->updateDailyTopSearchToday();
        LoggingHelper::logFunction('END JOB: UPDATE TOP SEARCH TODAY');
    }

}
