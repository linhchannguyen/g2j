<?php


namespace App\Console\Commands\Daily\RunAt23Hour;

use App\Actions\Cheating\DailyReportOfSuspectedHotelCheating;
use App\Helpers\LoggingHelper;
use Illuminate\Console\Command;

class ReportOfSuspectedHotelCheating extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'DailyReportOfSuspectedHotelCheating';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Cron job for Daily 23H30';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     */
    public function handle(DailyReportOfSuspectedHotelCheating $dailyReportOfSuspectedHotelCheating)
    {
        $date = now()->format('Y-m-d');
        LoggingHelper::logFunction('START JOB: DAILY REPORT OF SUSPECTED HOTEL CHEATING');
        $dailyReportOfSuspectedHotelCheating->handle($date);
        LoggingHelper::logFunction('END JOB: DAILY REPORT OF SUSPECTED HOTEL CHEATING');
    }
}
