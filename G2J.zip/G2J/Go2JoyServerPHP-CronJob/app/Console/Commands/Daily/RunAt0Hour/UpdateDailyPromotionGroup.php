<?php


namespace App\Console\Commands\Daily\RunAt0Hour;


use App\Helpers\LoggingHelper;
use App\Services\Web\SA\PromotionGroupService;
use Exception;
use Illuminate\Console\Command;

class UpdateDailyPromotionGroup extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'daily:update-daily-promotion-group';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Update daily promotion group';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     * @param PromotionGroupService $promotionGroupService
     */
    public function handle(PromotionGroupService $promotionGroupService)
    {
        LoggingHelper::logFunction('START JOB: UPDATE DAILY PROMOTION GROUP STATUS');
        try {
            $promotionGroupService->updateDailyPromotionGroup();
        } catch (Exception $e) {
            LoggingHelper::logFunction('ERROR JOB: UPDATE DAILY PROMOTION GROUP STATUS - ' . $e->getMessage());
        }
        LoggingHelper::logFunction('END JOB: UPDATE DAILY PROMOTION GROUP STATUS');
    }
}