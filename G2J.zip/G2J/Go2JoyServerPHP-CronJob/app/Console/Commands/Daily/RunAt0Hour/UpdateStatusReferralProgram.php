<?php

namespace App\Console\Commands\Daily\RunAt0Hour;

use App\Helpers\LoggingHelper;
use App\Services\Web\SA\CouponIssuedService;
use App\Services\Web\SA\ReferralService;
use Exception;
use Illuminate\Console\Command;

class UpdateStatusReferralProgram extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'UpdateStatusReferralProgram';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Cron job for 0H';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    public function handle(ReferralService $referralService)
    {
        LoggingHelper::logFunction('START JOB: UPDATE STATUS REFERRAL PROGRAM');
        try {
            $referralService->updateStatusReferralProgram();
        } catch (Exception $e) {
            LoggingHelper::logFunction('ERROR JOB: UPDATE STATUS REFERRAL PROGRAM - ' . $e->getMessage());
        }
        LoggingHelper::logFunction('END JOB:UPDATE STATUS REFERRAL PROGRAM');
    }
}
