<?php

namespace App\Console\Commands\Daily\RunAt0Hour;

use App\Constants\DirectDiscountProgram as DirectDiscountProgramConst;
use App\Constants\DirectDiscountProgramActionHistory as DirectDiscountProgramActionHistoryConst;
use App\Constants\Staff as StaffConst;
use App\Helpers\ConvertHelper;
use App\Models\DirectDiscountProgram;
use App\Models\DirectDiscountProgramHotel;
use App\Models\DirectDiscountProgramRoomType;
use App\Models\DirectDiscountProgramRoomTypeHistory;
use App\Repositories\Interfaces\DirectDiscountProgramActionHistoryRepositoryInterface;
use App\Repositories\Interfaces\DirectDiscountProgramHotelRepositoryInterface;
use App\Repositories\Interfaces\DirectDiscountProgramRepositoryInterface;
use App\Repositories\Interfaces\DirectDiscountProgramRoomTypeHistoryRepositoryInterface;
use App\Repositories\Interfaces\DirectDiscountProgramRoomTypeRepositoryInterface;
use Exception;
use Illuminate\Console\Command;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\DB;

class ProcessDirectDiscountProgram extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'daily:process-direct-discount-program';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'ProcessDirectDiscountProgram';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    public function handle()
    {
        $directDiscountProgramRepository = app(DirectDiscountProgramRepositoryInterface::class);
        $directDiscountProgramHotelRepository = app(DirectDiscountProgramHotelRepositoryInterface::class);
        $directDiscountProgramRoomTypeRepository = app(DirectDiscountProgramRoomTypeRepositoryInterface::class);
        $directDiscountProgramActionHistoryRepository = app(DirectDiscountProgramActionHistoryRepositoryInterface::class);

        $now = Carbon::now()->startOfDay();
        $directDiscountProgramSnRunningList = [];
        $directDiscountProgramRunningList = DB::connection('mysql')
            ->table(DirectDiscountProgram::TABLE_NAME)
            ->where(DirectDiscountProgram::COL_STATUS, '=', DirectDiscountProgramConst::STATUS['RUNNING'])
            ->select([
                DirectDiscountProgram::COL_SN,
                DirectDiscountProgram::COL_TYPE_APPLY,
                DirectDiscountProgram::COL_START_DATE,
                DirectDiscountProgram::COL_END_DATE,
                DirectDiscountProgram::COL_SPECIAL_DATE,
            ])->get();
        foreach ($directDiscountProgramRunningList as $directDiscountProgramRunning) {
            if ($directDiscountProgramRunning->{DirectDiscountProgram::COL_TYPE_APPLY} == DirectDiscountProgramConst::TYPE_APPLY['DAY_OF_WEEK']) {
                $endDate = Carbon::parse($directDiscountProgramRunning->{DirectDiscountProgram::COL_END_DATE})->endOfDay();
                if ($endDate->gte($now)) {
                    $directDiscountProgramSnRunningList[] = $directDiscountProgramRunning->{DirectDiscountProgram::COL_SN};
                }
            } else {
                $specialDate = $directDiscountProgramRunning->{DirectDiscountProgram::COL_SPECIAL_DATE};
                if (!empty($specialDate)) {
                    $arr = ConvertHelper::toArray($specialDate);
                    foreach ($arr as $s) {
                        $specDate = Carbon::parse($s)->startOfDay();
                        if ($specDate->greaterThanOrEqualTo($now)) {
                            $directDiscountProgramSnRunningList[] = $directDiscountProgramRunning->{DirectDiscountProgram::COL_SN};
                            break;
                        }
                    }
                }
            }
        }
        $directDiscountProgramList = $directDiscountProgramRunningList->pluck(DirectDiscountProgram::COL_SN)->toArray();
        $directDiscountProgramSnExpiredList = array_diff($directDiscountProgramList, $directDiscountProgramSnRunningList);
        try {
            DB::connection('mysql')->beginTransaction();
            foreach ($directDiscountProgramSnExpiredList as $directDiscountProgramSnExpired) {
                $directDiscountProgram = DirectDiscountProgram::where(DirectDiscountProgram::COL_SN, $directDiscountProgramSnExpired)->first([
                    DirectDiscountProgram::COL_SN,
                    DirectDiscountProgram::COL_NAME,
                    DirectDiscountProgram::COL_STATUS,
                    DirectDiscountProgram::COL_TYPE_APPLY,
                    DirectDiscountProgram::COL_START_DATE,
                    DirectDiscountProgram::COL_END_DATE,
                    DirectDiscountProgram::COL_SPECIAL_DATE,
                    DirectDiscountProgram::COL_START_TIME,
                    DirectDiscountProgram::COL_END_TIME,
                    DirectDiscountProgram::COL_MONDAY,
                    DirectDiscountProgram::COL_TUESDAY,
                    DirectDiscountProgram::COL_WEDNESDAY,
                    DirectDiscountProgram::COL_THURSDAY,
                    DirectDiscountProgram::COL_FRIDAY,
                    DirectDiscountProgram::COL_SATURDAY,
                    DirectDiscountProgram::COL_SUNDAY,
                    DirectDiscountProgram::COL_CREATED_NAME,
                    DirectDiscountProgram::COL_CREATED_BY,
                    DirectDiscountProgram::COL_UPDATED_NAME,
                    DirectDiscountProgram::COL_UPDATED_BY,
                ]);
                $directDiscountProgramRepository->update([
                    DirectDiscountProgram::COL_STATUS => DirectDiscountProgramConst::STATUS['EXPIRED'],
                ], $directDiscountProgram->{DirectDiscountProgram::COL_SN});
                $actionSn = $directDiscountProgramActionHistoryRepository->createExpiredHistory($directDiscountProgram->{DirectDiscountProgram::COL_SN}, StaffConst::SYSTEM, DirectDiscountProgramActionHistoryConst::ACTION_USER_TYPE['SYSTEM'], Carbon::now(), json_encode($directDiscountProgram));
                $directDiscountRoomTypeList = $directDiscountProgramRoomTypeRepository->findDirectDiscountProgramRoomTypeActive($directDiscountProgram->{DirectDiscountProgram::COL_SN});
                $directDiscountProgramHotelRepository->updateWhere([
                    DirectDiscountProgram::COL_STATUS => DirectDiscountProgramConst::STATUS['EXPIRED'],
                ], [
                    DirectDiscountProgramHotel::COL_DIRECT_DISCOUNT_PROGRAM_SN => $directDiscountProgram->{DirectDiscountProgram::COL_SN},
                    DirectDiscountProgramHotel::COL_STATUS                     => DirectDiscountProgramConst::STATUS['RUNNING'],
                ]);
                $this->_createDirectDiscountRoomTypeHistory($actionSn, $directDiscountRoomTypeList);
                DB::connection('mysql')->commit();
            }
        } catch (Exception $e) {
            DB::connection('mysql')->rollBack();
            throw $e;
        }
    }

    private function _createDirectDiscountRoomTypeHistory($actionSn, $directDiscountRoomTypeList)
    {
        $directDiscountProgramRoomTypeHistoryRepository = app(DirectDiscountProgramRoomTypeHistoryRepositoryInterface::class);
        $directDiscountRoomTypeHistory = [];
        foreach ($directDiscountRoomTypeList as $directDiscountRoomType){
            $directDiscountRoomTypeHistory [] = [
                DirectDiscountProgramRoomTypeHistory::COL_DIRECT_DISCOUNT_PROGRAM_SN                => $directDiscountRoomType->{DirectDiscountProgramRoomType::COL_DIRECT_DISCOUNT_PROGRAM_SN},
                DirectDiscountProgramRoomTypeHistory::COL_DIRECT_DISCOUNT_PROGRAM_ACTION_HISTORY_SN => $actionSn,
                DirectDiscountProgramRoomTypeHistory::COL_STATUS                                    => $directDiscountRoomType->{DirectDiscountProgramRoomType::COL_STATUS},
                DirectDiscountProgramRoomTypeHistory::COL_HOTEL_SN                                  => $directDiscountRoomType->{DirectDiscountProgramRoomType::COL_HOTEL_SN},
                DirectDiscountProgramRoomTypeHistory::COL_HOTEL_NAME                                => $directDiscountRoomType->{DirectDiscountProgramRoomType::COL_HOTEL_NAME},
                DirectDiscountProgramRoomTypeHistory::COL_HOTEL_CODE                                => $directDiscountRoomType->{DirectDiscountProgramRoomType::COL_HOTEL_CODE},
                DirectDiscountProgramRoomTypeHistory::COL_ROOM_TYPE_SN                              => $directDiscountRoomType->{DirectDiscountProgramRoomType::COL_ROOM_TYPE_SN},
                DirectDiscountProgramRoomTypeHistory::COL_ROOM_TYPE_NAME                            => $directDiscountRoomType->{DirectDiscountProgramRoomType::COL_ROOM_TYPE_NAME},
                DirectDiscountProgramRoomTypeHistory::COL_PRICE_FIRST_HOURS_DISCOUNT_PERCENT        => $directDiscountRoomType->{DirectDiscountProgramRoomType::COL_PRICE_FIRST_HOURS_DISCOUNT_PERCENT},
                DirectDiscountProgramRoomTypeHistory::COL_PRICE_FIRST_HOURS_AFTER_DISCOUNT          => $directDiscountRoomType->{DirectDiscountProgramRoomType::COL_PRICE_FIRST_HOURS_AFTER_DISCOUNT},
                DirectDiscountProgramRoomTypeHistory::COL_PRICE_ADDITIONAL_HOURS_DISCOUNT_PERCENT   => $directDiscountRoomType->{DirectDiscountProgramRoomType::COL_PRICE_ADDITIONAL_HOURS_DISCOUNT_PERCENT},
                DirectDiscountProgramRoomTypeHistory::COL_PRICE_ADDITIONAL_HOURS_AFTER_DISCOUNT     => $directDiscountRoomType->{DirectDiscountProgramRoomType::COL_PRICE_ADDITIONAL_HOURS_AFTER_DISCOUNT},
                DirectDiscountProgramRoomTypeHistory::COL_PRICE_OVERNIGHT_DISCOUNT_PERCENT          => $directDiscountRoomType->{DirectDiscountProgramRoomType::COL_PRICE_OVERNIGHT_DISCOUNT_PERCENT},
                DirectDiscountProgramRoomTypeHistory::COL_PRICE_OVERNIGHT_AFTER_DISCOUNT            => $directDiscountRoomType->{DirectDiscountProgramRoomType::COL_PRICE_OVERNIGHT_AFTER_DISCOUNT},
                DirectDiscountProgramRoomTypeHistory::COL_PRICE_ONE_DAY_DISCOUNT_PERCENT            => $directDiscountRoomType->{DirectDiscountProgramRoomType::COL_PRICE_ONE_DAY_DISCOUNT_PERCENT},
                DirectDiscountProgramRoomTypeHistory::COL_PRICE_ONE_DAY_AFTER_DISCOUNT              => $directDiscountRoomType->{DirectDiscountProgramRoomType::COL_PRICE_ONE_DAY_AFTER_DISCOUNT},
                DirectDiscountProgramRoomTypeHistory::COL_FIRST_HOURS_ORIGIN                        => $directDiscountRoomType->{DirectDiscountProgramRoomType::COL_FIRST_HOURS_ORIGIN},
                DirectDiscountProgramRoomTypeHistory::COL_ADDITIONAL_ORIGIN                         => $directDiscountRoomType->{DirectDiscountProgramRoomType::COL_ADDITIONAL_ORIGIN},
                DirectDiscountProgramRoomTypeHistory::COL_OVERNIGHT_ORIGIN                          => $directDiscountRoomType->{DirectDiscountProgramRoomType::COL_OVERNIGHT_ORIGIN},
                DirectDiscountProgramRoomTypeHistory::COL_ONE_DAY_ORIGIN                            => $directDiscountRoomType->{DirectDiscountProgramRoomType::COL_ONE_DAY_ORIGIN},
            ];
        }
        $directDiscountProgramRoomTypeHistoryRepository->batchInsert($directDiscountRoomTypeHistory);
    }
}