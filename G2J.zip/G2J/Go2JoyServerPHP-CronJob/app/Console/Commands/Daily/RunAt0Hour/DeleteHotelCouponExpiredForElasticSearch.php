<?php

namespace App\Console\Commands\Daily\RunAt0Hour;

use App\Services\Common\ElasticSearchService;
use Illuminate\Console\Command;
use Psr\SimpleCache\InvalidArgumentException;

class DeleteHotelCouponExpiredForElasticSearch extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'delete-hotel-coupon-expired-for-elastic-search';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Cron job for delete hotel coupon expired for elastic search';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @param ElasticSearchService $elasticSearchService
     *
     * @throws InvalidArgumentException
     */
    public function handle(ElasticSearchService $elasticSearchService)
    {
        $elasticSearchService->deleteHotelCouponExpired();
    }
}