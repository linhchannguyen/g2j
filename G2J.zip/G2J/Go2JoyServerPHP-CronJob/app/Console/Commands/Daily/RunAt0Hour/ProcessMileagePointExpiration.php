<?php

namespace App\Console\Commands\Daily\RunAt0Hour;

use App\Constants\MileagePointExpiration as MileagePointExpirationConst;
use App\Constants\MileagePointHistory as MileagePointHistoryConst;
use App\Constants\MileagePointTransactionHistory as MileagePointTransactionHistoryConst;
use App\Helpers\LoggingHelper;
use App\Models\AppUser;
use App\Models\MileagePointExpiration;
use App\Models\MileagePointHistory;
use App\Models\MileagePointTransactionHistory;
use Exception;
use Illuminate\Console\Command;
use Illuminate\Support\Arr;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\DB;
use Psr\SimpleCache\InvalidArgumentException;

class ProcessMileagePointExpiration extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'daily:process-mileage-point-expiration';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Process Mileage Point Expiration';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return void
     * @throws Exception|InvalidArgumentException
     */
    public function handle()
    {
        $now = Carbon::now();
        $mileagePointExpirationList = DB::connection('mysql')
            ->table(MileagePointExpiration::TABLE_NAME)
            ->where(function($query) use ($now) {
                $query->orWhere(MileagePointExpiration::COL_YEAR, '<', $now->year);
                $query->orWhere(function($query1) use ($now) {
                    $query1->where(MileagePointExpiration::COL_YEAR, '=', $now->year);
                    $query1->where(MileagePointExpiration::COL_MONTH, '<', $now->month);
                });
                $query->orWhere(function($query1) use ($now) {
                    $query1->where(MileagePointExpiration::COL_YEAR, '=', $now->year);
                    $query1->where(MileagePointExpiration::COL_MONTH, '=', $now->month);
                    $query1->where(MileagePointExpiration::COL_DAY, '<=', $now->day);
                });
            })
            ->where(MileagePointExpiration::COL_PROCESSED, '=', MileagePointExpirationConst::PROCESSED['NOT_YET'])
            ->select([
                MileagePointExpiration::COL_SN,
                MileagePointExpiration::COL_MILEAGE_POINT_TRANSACTION_HISTORY_SN,
                MileagePointExpiration::COL_APP_USER_SN,
                MileagePointExpiration::COL_NUM_OF_POINT,
                MileagePointExpiration::COL_REMAINING_POINT,
            ])
            ->get();

        $appUserSnList = $mileagePointExpirationList->pluck(MileagePointExpiration::COL_APP_USER_SN)->toArray();
        $createMileagePointHistoryDataList = [];

        DB::connection('mysql')->beginTransaction();
        try {
            foreach ($mileagePointExpirationList as $mileagePointExpiration) {
                $remainingPoint = $mileagePointExpiration->{MileagePointExpiration::COL_REMAINING_POINT};
                $mileagePointExpirationSn = $mileagePointExpiration->{MileagePointExpiration::COL_SN};
                if ($remainingPoint == 0) {
                    MileagePointExpiration::where(MileagePointExpiration::COL_SN, '=', $mileagePointExpirationSn)
                        ->update([
                            MileagePointExpiration::COL_PROCESSED => MileagePointExpirationConst::PROCESSED['PROCESSED']
                        ]);
                    continue;
                }

                $mileagePointTransactionHistorySn = $mileagePointExpiration->{MileagePointExpiration::COL_MILEAGE_POINT_TRANSACTION_HISTORY_SN};
                $mileagePointTransactionHistory = MileagePointTransactionHistory::where(MileagePointTransactionHistory::COL_SN, $mileagePointTransactionHistorySn)
                    ->first([
                        MileagePointTransactionHistory::COL_APP_USER_SN,
                        MileagePointTransactionHistory::COL_TYPE_PROGRAM,
                        MileagePointTransactionHistory::COL_PROGRAM_SN,
                        MileagePointTransactionHistory::COL_USER_BOOKING_SN,
                    ]);
                $appUserSn = $mileagePointTransactionHistory->{MileagePointTransactionHistory::COL_APP_USER_SN};
                $typeProgram = $mileagePointTransactionHistory->{MileagePointTransactionHistory::COL_TYPE_PROGRAM};
                $programSn = $mileagePointTransactionHistory->{MileagePointTransactionHistory::COL_PROGRAM_SN};
                $userBookingSn = $mileagePointTransactionHistory->{MileagePointTransactionHistory::COL_USER_BOOKING_SN};

                $appUser = AppUser::lockForUpdate()
                    ->where(AppUser::COL_SN, $appUserSn)
                    ->first([
                        AppUser::COL_MILEAGE_AMOUNT,
                        AppUser::COL_MILEAGE_EXPIRED,
                        AppUser::COL_MILEAGE_EARNED,
                    ]);

                $mileageAmount = $appUser->{AppUser::COL_MILEAGE_AMOUNT};
                $mileageExpired = $appUser->{AppUser::COL_MILEAGE_EXPIRED};

                $numOfPoint = $mileagePointExpiration->{MileagePointExpiration::COL_NUM_OF_POINT};
                $totalActivePoint = $mileageAmount - $remainingPoint;
                $mileagePointTransactionHistory = MileagePointTransactionHistory::create([
                    MileagePointTransactionHistory::COL_APP_USER_SN        => $appUserSn,
                    MileagePointTransactionHistory::COL_TYPE_PROGRAM       => $typeProgram,
                    MileagePointTransactionHistory::COL_PROGRAM_SN         => $programSn,
                    MileagePointTransactionHistory::COL_USER_BOOKING_SN    => $userBookingSn,
                    MileagePointTransactionHistory::COL_TOTAL_ACTIVE_POINT => $totalActivePoint,
                    MileagePointTransactionHistory::COL_ACTUAL_POINT       => -$remainingPoint,
                    MileagePointTransactionHistory::COL_EXPECTED_POINT     => -$numOfPoint,
                    MileagePointTransactionHistory::COL_STATUS             => MileagePointTransactionHistoryConst::STATUS['EXPIRED'],
                ]);
                $mileagePointTransactionHistorySn = $mileagePointTransactionHistory->{MileagePointTransactionHistory::COL_SN};

                $now = Carbon::now();
                $createMileagePointHistoryData = [
                    MileagePointHistory::COL_APP_USER_SN                            => $appUserSn,
                    MileagePointHistory::COL_PROGRAM_NAME                           => null,
                    MileagePointHistory::COL_PROGRAM_SN                             => null,
                    MileagePointHistory::COL_BOOKING_NO                             => null,
                    MileagePointHistory::COL_HOTEL_NAME                             => null,
                    MileagePointHistory::COL_CHECKIN                                => null,
                    MileagePointHistory::COL_CHECKOUT                               => null,
                    MileagePointHistory::COL_USER_BOOKING_SN                        => null,
                    MileagePointHistory::COL_TYPE_PROGRAM                           => null,
                    MileagePointHistory::COL_STATUS                                 => MileagePointHistoryConst::STATUS['EXPIRED'],
                    MileagePointHistory::COL_TOTAL_ACTIVE_POINT                     => $totalActivePoint,
                    MileagePointHistory::COL_ACTUAL_POINT                           => -$remainingPoint,
                    MileagePointHistory::COL_EXPECTED_POINT                         => -$numOfPoint,
                    MileagePointHistory::COL_USER_PAID                              => 0,
                    MileagePointHistory::COL_ACTIVE_TIME_FROM                       => null,
                    MileagePointHistory::COL_ACTIVE_TIME_TO                         => null,
                    MileagePointHistory::COL_CLAIM_TIME                             => null,
                    MileagePointHistory::COL_REFUND_TIME                            => null,
                    MileagePointHistory::COL_EXPIRATION_TIME                        => $now,
                    MileagePointHistory::COL_MILEAGE_POINT_TRANSACTION_HISTORY_LIST => json_encode([$mileagePointTransactionHistorySn]),
                    MileagePointHistory::COL_CREATE_TIME                            => $now,
                    MileagePointHistory::COL_LAST_UPDATE                            => $now,
                ];

                $filtered = Arr::where($appUserSnList, function($value, $key) use ($appUserSn) {
                    return $value == $appUserSn;
                });
                $_createMileagePointHistoryData = $createMileagePointHistoryDataList[$appUserSn] ?? null;
                if (empty($filtered)) {
                    // Not have any record need process based on $appUserSnList in next element of array
                    if (empty($_createMileagePointHistoryData)) {
                        // Not have any record with same $appUserSn before in $createMileagePointHistoryDataList => insert
                        MileagePointHistory::create($createMileagePointHistoryData);
                    } else {
                        // Have record with same $appUserSn before in $createMileagePointHistoryDataList => recalculate => insert
                        $_createMileagePointHistoryData[MileagePointHistory::COL_TOTAL_ACTIVE_POINT] = $mileageAmount;
                        $_createMileagePointHistoryData[MileagePointHistory::COL_ACTUAL_POINT] += $createMileagePointHistoryData[MileagePointHistory::COL_ACTUAL_POINT];
                        $_createMileagePointHistoryData[MileagePointHistory::COL_EXPECTED_POINT] += $createMileagePointHistoryData[MileagePointHistory::COL_EXPECTED_POINT];

                        $_mileagePointTransactionHistoryList = json_decode($_createMileagePointHistoryData[MileagePointHistory::COL_MILEAGE_POINT_TRANSACTION_HISTORY_LIST], true);
                        $mileagePointTransactionHistoryList = json_decode($createMileagePointHistoryData[MileagePointHistory::COL_MILEAGE_POINT_TRANSACTION_HISTORY_LIST], true);
                        $mileagePointTransactionHistoryListMerged = array_merge($_mileagePointTransactionHistoryList, $mileagePointTransactionHistoryList);
                        $_createMileagePointHistoryData[MileagePointHistory::COL_MILEAGE_POINT_TRANSACTION_HISTORY_LIST] = json_encode($mileagePointTransactionHistoryListMerged);

                        MileagePointHistory::create($_createMileagePointHistoryData);
                    }
                } else {
                    // Have any record need process based on $appUserSnList in next element of array
                    if (empty($_createMileagePointHistoryData)) {
                        // Not have any record with same $appUserSn before in $createMileagePointHistoryDataList => push into
                        $createMileagePointHistoryDataList[$appUserSn] = $createMileagePointHistoryData;
                    } else {
                        // Have record with same $appUserSn before in $createMileagePointHistoryDataList => recalculate => push into
                        $_createMileagePointHistoryData[MileagePointHistory::COL_TOTAL_ACTIVE_POINT] = $mileageAmount;
                        $_createMileagePointHistoryData[MileagePointHistory::COL_ACTUAL_POINT] += $createMileagePointHistoryData[MileagePointHistory::COL_ACTUAL_POINT];
                        $_createMileagePointHistoryData[MileagePointHistory::COL_EXPECTED_POINT] += $createMileagePointHistoryData[MileagePointHistory::COL_EXPECTED_POINT];

                        $_mileagePointTransactionHistoryList = json_decode($_createMileagePointHistoryData[MileagePointHistory::COL_MILEAGE_POINT_TRANSACTION_HISTORY_LIST], true);
                        $mileagePointTransactionHistoryList = json_decode($createMileagePointHistoryData[MileagePointHistory::COL_MILEAGE_POINT_TRANSACTION_HISTORY_LIST], true);
                        $mileagePointTransactionHistoryListMerged = array_merge($_mileagePointTransactionHistoryList, $mileagePointTransactionHistoryList);
                        $_createMileagePointHistoryData[MileagePointHistory::COL_MILEAGE_POINT_TRANSACTION_HISTORY_LIST] = json_encode($mileagePointTransactionHistoryListMerged);

                        $createMileagePointHistoryDataList[$appUserSn] = $_createMileagePointHistoryData;
                    }
                }

                foreach ($appUserSnList as $index => $value) {
                    if ($value == $appUserSn) {
                        unset($appUserSnList[$index]);
                        break;
                    }
                }

                $mileageAmount = $mileageAmount - $remainingPoint;
                $mileageExpired = $mileageExpired + $remainingPoint;
                AppUser::where(AppUser::COL_SN, $appUserSn)
                    ->update([
                        AppUser::COL_MILEAGE_AMOUNT  => $mileageAmount,
                        AppUser::COL_MILEAGE_EXPIRED => $mileageExpired,
                    ]);

                MileagePointExpiration::where(MileagePointExpiration::COL_SN, '=', $mileagePointExpirationSn)
                    ->update([
                        MileagePointExpiration::COL_PROCESSED => MileagePointExpirationConst::PROCESSED['PROCESSED']
                    ]);
            }

            foreach ($createMileagePointHistoryDataList as $appUserSn => $createMileagePointHistoryData) {
                MileagePointHistory::create($createMileagePointHistoryData);
            }

            DB::connection('mysql')->commit();

        } catch (Exception $exception) {
            LoggingHelper::logException($exception);
            DB::connection('mysql')->rollBack();
        }
    }
}
