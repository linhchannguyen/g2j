<?php

namespace App\Console\Commands\Daily\RunAt0Hour;

use App\Helpers\LoggingHelper;
use App\Services\Web\SA\HotelOnTopService;
use Exception;
use Illuminate\Console\Command;

class UpdateDailyTopDistrct extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'UpdateDailyTopDistrct';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Cron job for 0H';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     * @param HotelOnTopService $hotelOnTopService
     */
    public function handle(HotelOnTopService $hotelOnTopService)
    {
        LoggingHelper::logFunction('START JOB: UPDATE DAILY TOP DISTRICT STATUS');
        try {
            $hotelOnTopService->updateDailyTopDistrict();
        } catch (Exception $e) {
            LoggingHelper::logFunction('ERROR JOB: UPDATE DAILY TOP DISTRICT STATUS - ' . $e->getMessage());
        }
        LoggingHelper::logFunction('END JOB: UPDATE DAILY TOP DISTRICT STATUS');
    }
}
