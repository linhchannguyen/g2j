<?php


namespace App\Console\Commands\Daily\RunAt0Hour;


use App\Helpers\LoggingHelper;
use App\Services\Web\SA\PopupService;
use Exception;
use Illuminate\Console\Command;

class UpdateDailyShowPopupHistory extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'UpdateDailyShowPopupHistory';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Cron job for 0H';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     * @param PopupService $popupService
     */
    public function handle(PopupService $popupService)
    {
        //LoggingHelper::logDailyJob('0 Hour', 'START JOB: UPDATE DAILY SHOW POPUP HISTORY');
        try {
            $popupService->updateDailyShowPopupHistory();
        } catch (Exception $e) {
            //LoggingHelper::logDailyJob('0 Hour', 'ERROR JOB: UPDATE DAILY SHOW POPUP HISTORY - ' . $e->getMessage());
        }
        //LoggingHelper::logDailyJob('0 Hour', 'END JOB: UPDATE DAILY SHOW POPUP HISTORY');
    }
}