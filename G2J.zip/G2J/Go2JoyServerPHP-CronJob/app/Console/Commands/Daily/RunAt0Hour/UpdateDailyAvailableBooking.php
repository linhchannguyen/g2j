<?php

namespace App\Console\Commands\Daily\RunAt0Hour;

use App\Constants\Globals\QueueName;
use App\Constants\Hotel as HotelConst;
use App\Helpers\LoggingHelper;
use App\Jobs\Background\UpdateDailyAvailableBookingJob;
use App\Repositories\Interfaces\HotelDisplayRuleRepositoryInterface;
use Exception;
use Illuminate\Console\Command;

class UpdateDailyAvailableBooking extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'daily:update-daily-available-booking {--hotelSn=}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Cron job for update daily available booking in HOTEL_DISPLAY_RULE table';

    /** @var HotelDisplayRuleRepositoryInterface */
    private $hotelDisplayRuleRepository;

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
        $this->hotelDisplayRuleRepository = app(HotelDisplayRuleRepositoryInterface::class);
    }

    public function handle()
    {
        $hotelSn = $this->option('hotelSn');
        $hotelSnList = $hotelSn ? array($hotelSn) : [];
        LoggingHelper::logFunction('START JOB: UPDATE DAILY AVAILABLE BOOKING');
        try {
            $hotelDisplayRuleList = $this->hotelDisplayRuleRepository->findHotelDisplayRuleHasLockDailyList($hotelSnList, HotelConst::ORIGIN['GO2JOY']);
            $hotelDisplayRuleChunks = $hotelDisplayRuleList->chunk(50)->toArray();
            foreach ($hotelDisplayRuleChunks as $hotelDisplayRuleList) {
                dispatch(new UpdateDailyAvailableBookingJob($hotelDisplayRuleList))->onQueue(QueueName::BACK_GROUND);
            }
        } catch (Exception $e) {
            LoggingHelper::logFunction('ERROR JOB: UPDATE DAILY AVAILABLE BOOKING - ' . $e->getMessage());
        }
        LoggingHelper::logFunction('END JOB: UPDATE DAILY AVAILABLE BOOKING');
    }
}