<?php


namespace App\Console\Commands\Daily\RunAt6Hour;


use App\Helpers\LoggingHelper;
use App\Services\Web\SA\BannerService;
use Exception;
use Illuminate\Console\Command;

class UpdateDailyBannerExpired extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'UpdateDailyBannerExpired';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Cron job for 6H';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     * @param BannerService $bannerService
     */
    public function handle(BannerService $bannerService)
    {
        LoggingHelper::logFunction('START JOB: UPDATE DAILY BANNER EXPIRED');
        try {
            $bannerService->updateDailyBannerExpired();
        } catch (Exception $e) {
            LoggingHelper::logFunction('ERROR JOB: UPDATE DAILY BANNER EXPIRED - ' . $e->getMessage());
        }
        LoggingHelper::logFunction('END JOB: UPDATE DAILY DAILY BANNER EXPIRED');
    }
}