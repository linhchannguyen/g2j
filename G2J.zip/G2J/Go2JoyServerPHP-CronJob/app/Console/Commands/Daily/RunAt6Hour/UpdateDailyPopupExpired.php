<?php


namespace App\Console\Commands\Daily\RunAt6Hour;


use App\Helpers\LoggingHelper;
use App\Services\Web\SA\PopupService;
use Exception;
use Illuminate\Console\Command;

class UpdateDailyPopupExpired extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'UpdateDailyPopupExpired';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Cron job for 6H';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     * @param PopupService $popupService
     */
    public function handle(PopupService $popupService)
    {
        LoggingHelper::logFunction('START JOB: UPDATE DAILY POPUP EXPIRED');
        try {
            $popupService->updateDailyPopupExpired();
        } catch (Exception $e) {
            LoggingHelper::logFunction( 'ERROR JOB: UPDATE DAILY POPUP EXPIRED - ' . $e->getMessage());
        }
        LoggingHelper::logFunction('END JOB: UPDATE DAILY DAILY POPUP EXPIRED');
    }
}