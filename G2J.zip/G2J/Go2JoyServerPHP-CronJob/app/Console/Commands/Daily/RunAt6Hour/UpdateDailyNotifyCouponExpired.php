<?php


namespace App\Console\Commands\Daily\RunAt6Hour;


use App\Helpers\LoggingHelper;
use App\Services\Web\SA\PromotionService;
use Exception;
use Illuminate\Console\Command;

class UpdateDailyNotifyCouponExpired extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'UpdateDailyNotifyCouponExpired';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Cron job for 6H';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     * @param PromotionService $promotionService
     */
    public function handle(PromotionService $promotionService)
    {
        LoggingHelper::logFunction('START JOB: UPDATE DAILY NOTIFY COUPON EXPIRED');
        try {
            $promotionService->updateDailyNotifyCouponExpired();
        } catch (Exception $e) {
            LoggingHelper::logFunction( 'ERROR JOB: UPDATE DAILY NOTIFY COUPON EXPIRED - ' . $e->getMessage());
        }
        LoggingHelper::logFunction('END JOB: UPDATE DAILY DAILY NOTIFY COUPON EXPIRED');
    }
}