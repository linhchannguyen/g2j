<?php


namespace App\Console\Commands\Daily\RunAt6Hour;


use App\Helpers\LoggingHelper;
use App\Services\Web\SA\RoomTypeService;
use Exception;
use Illuminate\Console\Command;

class UpdateDailyRefreshSoldOutToday extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'UpdateDailyRefreshSoldOutToday';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Cron job for 6H';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     * @param RoomTypeService $roomTypeService
     */
    public function handle(RoomTypeService $roomTypeService)
    {
        LoggingHelper::logFunction('START JOB: UPDATE DAILY REFRESH SOLD OUT TODAY');
        try {
            $roomTypeService->updateDailyRefreshSoldOutToday();
        } catch (Exception $e) {
            LoggingHelper::logFunction('ERROR JOB: UPDATE DAILY REFRESH SOLD OUT TODAY - ' . $e->getMessage());
        }
        LoggingHelper::logFunction('END JOB: UPDATE DAILY DAILY REFRESH SOLD OUT TODAY');
    }
}