<?php

namespace App\Console\Commands\Daily\RunAt6Hour;

use App\Helpers\LoggingHelper;
use App\Services\Web\HA\RoomTypeService;
use Exception;
use Illuminate\Console\Command;

class UpdateDailyRefreshInstantLock extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'UpdateDailyRefreshInstantLock';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Cron job for 6H';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @param RoomTypeService $roomTypeService
     */
    public function handle(RoomTypeService $roomTypeService)
    {
        LoggingHelper::logFunction( 'START JOB: UPDATE DAILY REFRESH INSTANT LOCK');
        try {
            $roomTypeService->updateDailyRefreshInstantLock();
        } catch (Exception $e) {
            LoggingHelper::logFunction( 'ERROR JOB: UPDATE DAILY REFRESH INSTANT LOCK - ' . $e->getMessage());
        }
        LoggingHelper::logFunction('END JOB: UPDATE DAILY DAILY REFRESH INSTANT LOCK');
    }
}