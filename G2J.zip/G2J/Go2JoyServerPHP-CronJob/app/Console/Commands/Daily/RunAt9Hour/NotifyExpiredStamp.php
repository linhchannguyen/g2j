<?php

namespace App\Console\Commands\Daily\RunAt9Hour;

use App\Helpers\LoggingHelper;
use App\Services\Web\SA\PromotionService;
use Exception;
use Illuminate\Console\Command;

class NotifyExpiredStamp extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'NotifyExpiredStamp';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Cron job for Notify Expired Stamp at 9 Hour';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    public function handle(PromotionService $promotionService)
    {
        LoggingHelper::logFunction('START JOB: NOTIFY EXPIRED STAMP');
        try {
            $promotionService->notifyExpiredStamp();
        } catch (Exception $exception) {
            LoggingHelper::logFunction('ERROR JOB: NOTIFY EXPIRED STAMP ' . $exception->getMessage());
        }
        LoggingHelper::logFunction('END JOB: NOTIFY EXPIRED STAMP');

    }
}