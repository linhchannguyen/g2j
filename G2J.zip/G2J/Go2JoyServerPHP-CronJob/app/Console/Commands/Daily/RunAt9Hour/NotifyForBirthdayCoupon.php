<?php

namespace App\Console\Commands\Daily\RunAt9Hour;

use App\Helpers\LoggingHelper;
use App\Services\Web\SA\PromotionService;
use Exception;
use Illuminate\Console\Command;

class NotifyForBirthdayCoupon extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'NotifyForBirthdayCoupon';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Cron job for Notify For Birthday Coupon at 9 Hour';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    public function handle(PromotionService $promotionService)
    {
        LoggingHelper::logFunction('START JOB: NOTIFY FOR BIRTHDAY COUPON');
        try {
            $promotionService->notifyForBirthdayCoupon();
        } catch (Exception $exception) {
            LoggingHelper::logFunction('ERROR JOB: NOTIFY FOR BIRTHDAY COUPON ' . $exception->getMessage());
        }
        LoggingHelper::logFunction('END JOB: NOTIFY FOR BIRTHDAY COUPON');

    }
}