<?php

namespace App\Console\Commands\Daily\RunAt9Hour;

use App\Helpers\LoggingHelper;
use App\Services\Web\SA\InviteFriendService;
use Exception;
use Illuminate\Console\Command;

class UpdateInviteFriendStatus extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'UpdateInviteFriendStatus';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Cron job for Update Invite Friend Status at 9 Hour';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    public function handle(InviteFriendService $inviteFriendService)
    {
        LoggingHelper::logFunction('START JOB: UPDATE INVITE FRIEND STATUS');
        try {
            $inviteFriendService->updateInviteFriendStatus();
        } catch (Exception $exception) {
            LoggingHelper::logFunction('ERROR JOB: UPDATE INVITE FRIEND STATUS ' . $exception->getMessage());
        }
        LoggingHelper::logFunction('END JOB: UPDATE INVITE FRIEND STATUS');
    }
}