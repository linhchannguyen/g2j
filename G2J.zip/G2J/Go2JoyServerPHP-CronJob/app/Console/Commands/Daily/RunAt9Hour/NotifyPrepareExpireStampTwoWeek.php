<?php

namespace App\Console\Commands\Daily\RunAt9Hour;

use App\Constants\StampIssued as StampIssuedConst;
use App\Helpers\LoggingHelper;
use App\Services\Web\SA\PromotionService;
use Exception;
use Illuminate\Console\Command;

class NotifyPrepareExpireStampTwoWeek extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'NotifyPrepareExpireStampTwoWeek';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Cron job for Notify Prepare Expire Stamp TwoWeek at 9 Hour';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    public function handle(PromotionService $promotionService)
    {
        LoggingHelper::logFunction('START JOB: NOTIFY PREPARE EXPIRE STAMP TWO WEEK');
        try {
            $promotionService->notifyPrepareExpireStamp(StampIssuedConst::RANGE_OF_DAYS['TWO_WEEK'],
                StampIssuedConst::EXPIRED_TIME['TWO_WEEK']);
        } catch (Exception $exception) {
            LoggingHelper::logFunction( 'ERROR JOB:  NOTIFY PREPARE EXPIRE STAMP TWO WEEK ' . $exception->getMessage());
        }
        LoggingHelper::logFunction('END JOB:  NOTIFY PREPARE EXPIRE STAMP TWO WEEK');

    }
}