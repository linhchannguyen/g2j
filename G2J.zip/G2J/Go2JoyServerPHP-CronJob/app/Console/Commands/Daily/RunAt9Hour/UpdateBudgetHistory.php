<?php

namespace App\Console\Commands\Daily\RunAt9Hour;

use App\Helpers\LoggingHelper;
use App\Services\Web\SA\InviteFriendService;
use Exception;
use Illuminate\Console\Command;

class UpdateBudgetHistory extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'daily:update-budget-history';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Update budget history';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    public function handle(InviteFriendService $inviteFriendService)
    {
        LoggingHelper::logFunction('START JOB: UPDATE BUDGET HISTORY');
        try {
            $inviteFriendService->updateBudgetHistory();
        } catch (Exception $exception) {
            LoggingHelper::logFunction('ERROR JOB:  UPDATE BUDGET HISTORY ' . $exception->getMessage());
        }
        LoggingHelper::logFunction('END JOB: UPDATE BUDGET HISTORY');

    }
}