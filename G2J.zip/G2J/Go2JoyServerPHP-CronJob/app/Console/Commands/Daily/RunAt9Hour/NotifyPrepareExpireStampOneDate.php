<?php

namespace App\Console\Commands\Daily\RunAt9Hour;

use App\Constants\StampIssued as StampIssuedConst;
use App\Helpers\LoggingHelper;
use App\Services\Web\SA\PromotionService;
use Exception;
use Illuminate\Console\Command;

class NotifyPrepareExpireStampOneDate extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'NotifyPrepareExpireStampOneDate';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Cron job for Notify Prepare Expire Stamp One Date at 9 Hour';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    public function handle(PromotionService $promotionService)
    {
        LoggingHelper::logFunction('START JOB: NOTIFY PREPARE EXPIRE STAMP ONE DATE');
        try {
            $promotionService->notifyPrepareExpireStamp(StampIssuedConst::RANGE_OF_DAYS['ONE_DATE'], StampIssuedConst::EXPIRED_TIME['ONE_DATE']);
        } catch (Exception $exception) {
            LoggingHelper::logFunction('ERROR JOB: NOTIFY PREPARE EXPIRE STAMP ONE DATE ' . $exception->getMessage());
        }
        LoggingHelper::logFunction('END JOB: NOTIFY PREPARE EXPIRE STAMP ONE DATE');

    }
}