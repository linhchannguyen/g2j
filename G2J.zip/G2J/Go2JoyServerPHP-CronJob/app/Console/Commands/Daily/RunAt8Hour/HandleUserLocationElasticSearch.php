<?php

namespace App\Console\Commands\Daily\RunAt8Hour;

use App\Constants\Globals\Slack as SlackConst;
use App\Helpers\CommonHelper;
use App\Helpers\ConvertHelper;
use App\Helpers\LoggingHelper;
use App\Models\Country;
use App\Models\District;
use App\Models\Province;
use App\Providers\GuzzleClientServiceProvider;
use App\Repositories\Interfaces\CountryRepositoryInterface;
use App\Repositories\Interfaces\DistrictRepositoryInterface;
use App\Repositories\Interfaces\ProvinceRepositoryInterface;
use Exception;
use Illuminate\Console\Command;

class HandleUserLocationElasticSearch extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'handle-user-location-elastic-search';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Cron job for handle user location elastic search can not geocoding';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    const NOMINATIM_BASE_URI = 'https://nominatim.openstreetmap.org';

    public function handle()
    {
        $addressCanNotGeocoding = $this->getUserLocationCanNotGeocoding();
        foreach ($addressCanNotGeocoding as $addressCannot) {
            $location = $addressCannot['_source']['location'];
            $addressResult = $this->_handleAddress($location['lat'],  $location['lon']);
            if(($addressResult['canNotGeocoding'] && $addressResult['internalLocation']) || (!$addressResult['canNotGeocoding']) && $addressResult['internalLocation'] && (empty($addressResult['provinceName'])) || empty($addressResult['districtName'])){
                LoggingHelper::toSlack(SlackConst::CHANNEL['GEOCODING_MONITOR'], 'ERROR_JOB_INTERNAL_LOCATION_CAN_NOT_GEOCODING: '.' address:' . $addressResult['fullAddress']  . ' lat:' . $location['lat'] . ' - long:' . $location['lon']);
            }
            $this->updateUserLocationCanNotGeocoding($addressCannot['_id'], $addressResult, $location['lat'], $location['lon']);
        }

    }

    public function getUserLocationCanNotGeocoding()
    {
        $addressCanNotGeocoding = [];
        try {
            $headers = [
                'Content-Type'  => 'application/json',
                'Cache-Control' => 'no-cache',
                'Authorization' => 'Basic ' . config('elasticsearch.auth'),
            ];
            $options = [
                'base_uri' => config('elasticsearch.host'),
                'headers'  => $headers,
                'timeout'  => 30,
            ];

            $client = app('GuzzleClient', [
                'service' => GuzzleClientServiceProvider::SERVICE['ELASTIC_SEARCH'],
            ])($options);

            $dataJson = json_encode([
                "query" => [
                    "bool" => [
                        "must" => [
                            [
                                "match" => [
                                    "canNotGeocoding" => true,

                                ],
                            ], [
                                "match" => [
                                    "internalLocation" => true,
                                ],
                            ],

                        ],
                    ],
                ],
                "from"  => 0,
                "size"  => 500,
            ]);

            $responseUserLocation = $client->request(
                'GET',
                'go2joy_user_location/_search',
                [
                    'body' => $dataJson . "\n",
                ]
            );
            $resultUserLocation = (string)$responseUserLocation->getBody() ? json_decode((string)$responseUserLocation->getBody(), true) : [];
            if (isset($resultUserLocation['hits']['hits'])) {
                $addressCanNotGeocoding = $resultUserLocation['hits']['hits'];
            }
        } catch (Exception $exception) {
            LoggingHelper::logException($exception);
        }

        return $addressCanNotGeocoding;
    }

    public function updateUserLocationCanNotGeocoding($id, $addressResult, $latitude, $longitude)
    {
        try {
            $headers = [
                'Content-Type'  => 'application/json',
                'Cache-Control' => 'no-cache',
                'Authorization' => 'Basic ' . config('elasticsearch.auth'),
            ];
            $options = [
                'base_uri' => config('elasticsearch.host'),
                'headers'  => $headers,
            ];

            $client = app('GuzzleClient', [
                'service' => GuzzleClientServiceProvider::SERVICE['ELASTIC_SEARCH'],
            ])($options);
            $dataJson = json_encode([
                'doc' => [
                    'address'          => $addressResult['fullAddress'],
                    'districtSn'       => $addressResult['districtSn'],
                    'districtName'     => $addressResult['districtName'],
                    'provinceName'     => $addressResult['provinceName'],
                    'provinceSn'       => $addressResult['provinceSn'],
                    'canNotGeocoding'  => $addressResult['canNotGeocoding'],
                    'internalLocation' => $addressResult['internalLocation'],
                    'location'         => [
                        'lat' => $latitude,
                        'lon' => $longitude,
                    ],
                ],
            ]);

            $client->request(
                'POST',
                'go2joy_user_location/_update/' . $id,
                [
                    'body' => $dataJson . "\n",
                ]
            );

        } catch (Exception $exception) {
            LoggingHelper::logException($exception);
        }
    }

    private function _handleAddress($lat, $lon)
    {
        $address = ""; // Remove address because always using lat,long
        $latitude = $lat;
        $longitude = $lon;
        $provinceSn = 0;
        $countrySn = 0;
        $districtSn = 0;
        $fullAddress = "";

        $provinceName = null;
        $districtName = null;
        $canNotGeocoding = false;

        list($address, $fullAddress, $internalLocation) = $this->_reverseGeocodingNominatim($latitude, $longitude);

        // Process the address to detect Province SN, District SN
        $countryRepository = app(CountryRepositoryInterface::class);
        $provinceRepository = app(ProvinceRepositoryInterface::class);
        $districtRepository = app(DistrictRepositoryInterface::class);
        if (strpos($address, ',') > -1) { // Address contain ',' character
            $address = preg_replace('/^(?:(?:([A-Z+0-9])*(\s))?)/', '', $address);
            $address = str_replace([
                'tỉnh',
                'Tỉnh',
                'tinh',
                'Tinh',
                'Town',
                'Province',
                'thành phố',
                'Thành Phố',
                'thanh pho',
                'Thành phố',
                'County',
                'Tp.',
                'tp.',
                'Tx.',
                'TP.',
                'Q.',
                'City',
                'TX.',
                'Thị xã',
                'Xã',
                'tx.',
                'Huyen',
                'Huyện',
                'huyen',
                'huyện',
            ], '', $address);
            $addressList = array_reverse(explode(",", strtolower($address)));
            foreach ($addressList as $value) {
                if ($countrySn == 0) {
                    $country = $countryRepository->findLike(Country::COL_NAME_CODE, trim($value))->first();
                    if ($country) {
                        $countrySn = $country->{Country::COL_SN};
                    }
                    continue;
                }
                if ($provinceSn == 0) {
                    $value = preg_replace('/[0-9]+/', '', $value);
                    $province = $provinceRepository->findLike(Province::COL_NAME_CODE, trim($value))->first();
                    if ($province) {
                        $provinceSn = $province->{Province::COL_SN};
                        $provinceName = $province->{Province::COL_NAME};
                        if ($countrySn == 0) {
                            $countrySn = $province->{Province::COL_COUNTRY_SN};
                        }
                        continue;
                    }
                }
                if ($districtSn == 0) {
                    if (!empty($provinceSn)) {
                        $valueCheck = trim(str_replace(['District', 'district', 'Quận', 'quận'], '', $value));
                        if (!is_numeric($valueCheck)) {
                            $value = $valueCheck;
                        }
                    }
                    $district = $districtRepository->findDistrictByNameAndProvinceSn(trim($value), $provinceSn);
                    if ($district) {
                        $districtSn = $district->{District::COL_SN};
                        $districtName = $district->{District::COL_NAME};
                    }
                }
            }
        } else {
            if ($countrySn == 0) {
                $countryList = $countryRepository->all();
                foreach ($countryList as $country) {
                    $countrySplit = explode(",", $country->{Country::COL_NAME_CODE});
                    foreach ($countrySplit as $countryCode) {
                        $provinceCodeTrim = trim($countryCode);
                        if ($provinceCodeTrim && strpos(strtolower($address), strtolower($provinceCodeTrim)) > -1) {
                            $countrySn = $country->{Country::COL_SN};
                            break;
                        }
                    }
                    if ($countrySn != 0) {
                        break;
                    }
                }
            }
            if ($provinceSn == 0) {
                $provinceList = $provinceRepository->all();
                foreach ($provinceList as $province) {
                    $provinceSplit = explode(",", $province->{Province::COL_NAME_CODE});
                    foreach ($provinceSplit as $provinceCode) {
                        $provinceCodeTrim = trim($provinceCode);
                        if ($provinceCodeTrim && strpos(strtolower($address), strtolower($provinceCodeTrim)) > -1) {
                            $provinceSn = $province->{Province::COL_SN};
                            $provinceName = $province->{Province::COL_NAME};
                            if ($countrySn == 0) {
                                $countrySn = $province->{Province::COL_COUNTRY_SN};
                            }
                            break;
                        }
                    }
                    if ($provinceSn != 0) {
                        break;
                    }
                }
            }
            if ($districtSn == 0) {
                $districtList = $districtRepository->all();
                foreach ($districtList as $district) {
                    $districtSplit = explode(",", $district->{District::COL_NAME_CODE});
                    foreach ($districtSplit as $districtCode) {
                        $districtCodeTrim = trim($districtCode);
                        if ($districtCodeTrim && strpos(strtolower($address), strtolower($districtCodeTrim)) > -1) {
                            $districtSn = $district->{District::COL_SN};
                            $districtName = $district->{District::COL_NAME};
                            break;
                        }
                    }
                    if ($districtSn != 0) {
                        break;
                    }
                }
            }
        }

        if ($provinceSn == 0) {
            if ($districtSn > 0) {
                // Based on District SN to find out Province SN
                $district = $districtRepository->findProvinceByDistrictSn($districtSn);
                $provinceSn = $district->{District::COL_PROVINCE_SN};
                $provinceName = $district->{District::ALIAS_PROVINCE_NAME};
                $districtSn = $district->{District::COL_SN};
                $districtName = $district->{District::ALIAS_DISTRICT_NAME};
                $countrySn = 1;  // Only Vietnam
            }
        }
        if ($districtSn == 0 && strlen($address) > 0) {
            $addressList = array_reverse(explode(".", $address));
            foreach ($addressList as $value) {
                $district = $districtRepository->findDistrictByNameAndProvinceSn(trim($value), $provinceSn);
                if ($district) {
                    $provinceSn = $district->{District::COL_PROVINCE_SN};
                    $provinceName = $district->{District::ALIAS_PROVINCE_NAME};
                    $districtSn = $district->{District::COL_SN};
                    $districtName = $district->{District::COL_NAME};
                    $countrySn = 1;  // Only Vietnam
                    break;
                }
            }
        }
        if ($provinceSn == 0) {
            if ($districtSn == 0) {
                $districtSn = 1;
                $provinceName = 'Hồ Chí Minh';
                $provinceSn = 1;
                $districtName = 'Tân Bình';
                $countrySn = 1;
                $canNotGeocoding = true;
            }
        }

        return [
            'countrySn'        => $countrySn,
            'provinceSn'       => $provinceSn,
            'provinceName'     => $provinceName,
            'districtSn'       => $districtSn,
            'districtName'     => $districtName,
            'canNotGeocoding'  => $canNotGeocoding,
            'fullAddress'      => $fullAddress,
            'internalLocation' => $internalLocation,
        ];
    }

    private function _reverseGeocodingNominatim($lat, $lng)
    {
        $address = [];
        $fullAddress = '';
        $internalLocation = false;
        $nominatimAPI = '/reverse?lat=%s&lon=%s&format=json';
        $nominatim = sprintf($nominatimAPI, $lat, $lng);
        try {
            $headers = [
                'Content-Type'  => 'application/json',
                'Cache-Control' => 'no-cache',
            ];
            $options = [
                'base_uri' => self::NOMINATIM_BASE_URI,
                'headers'  => $headers,
                'timeout'  => 30,
            ];

            $client = app('GuzzleClient', [
                'service'  => GuzzleClientServiceProvider::SERVICE['INTEGRATION'],
            ])($options);
            $response = $client->request(
                'GET', $nominatim
            );
            $response = (string)$response->getBody() ? json_decode((string)$response->getBody(), true) : [];
            if (!empty($response)) {
                $fullAddress = $response['display_name'];
                $addressGeocoding = $response['address'];

                if(isset($addressGeocoding['city_district'])){
                    $address[] = $addressGeocoding['city_district'];
                }
                if(isset($addressGeocoding['borough'])){
                    $address[] = $addressGeocoding['borough'];
                }
                if(isset($addressGeocoding['island'])){
                    $address[] = $addressGeocoding['island'];
                }
                if(isset($addressGeocoding['archipelago'])){
                    $address[] = $addressGeocoding['archipelago'];
                }
                if(isset($addressGeocoding['district'])){
                    $address[] = $addressGeocoding['district'];
                }
                if( isset($addressGeocoding['county'])){
                    $address[] = $addressGeocoding['county'];
                }
                if( isset($addressGeocoding['suburb'])){
                    $address[] = $addressGeocoding['suburb'];
                }
                if( isset($addressGeocoding['town'])){
                    $address[] = $addressGeocoding['town'];
                }
                if(isset($addressGeocoding['city'])){
                    $address[] = $addressGeocoding['city'];
                }
                if(isset($addressGeocoding['state'])){
                    $address[] = $addressGeocoding['state'];
                }
                if(isset($addressGeocoding['country_code']) && strcmp($addressGeocoding['country_code'],'vn') == 0){
                    $address[] = $addressGeocoding['country'];
                    $internalLocation = true;
                }

            }
        } catch (Exception $exception) {
            LoggingHelper::logFunction('LOG_JOB_HANDLE_LOCATION: ' . $exception);
            LoggingHelper::toSlack(SlackConst::CHANNEL['GEOCODING_MONITOR'], 'ERROR_JOB_HANDLE_LOCATION: ' . ' lat:' . $lat . ' - long:' . $lng);
        }

        return [implode(',', $address), $fullAddress, $internalLocation];
    }
}
