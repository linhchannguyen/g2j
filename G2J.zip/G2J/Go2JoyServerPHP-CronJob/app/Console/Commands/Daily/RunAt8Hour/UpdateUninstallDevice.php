<?php

namespace App\Console\Commands\Daily\RunAt8Hour;

use App\Helpers\LoggingHelper;
use App\Services\Web\SA\MobileDeviceService;
use Exception;
use Illuminate\Console\Command;

class UpdateUninstallDevice extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'UpdateUninstallDevice';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Cron job for Update Uninstall Device at 8 Hour';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    public function handle(MobileDeviceService $mobileDeviceService)
    {
        LoggingHelper::logFunction('START JOB:UPDATE UNINSTALL DEVICE');
        try {
            $mobileDeviceService->updateUninstallDevice();
        } catch (Exception $exception) {
            LoggingHelper::logFunction('ERROR JOB:UPDATE UNINSTALL DEVICE ' . $exception->getMessage());
        }
        LoggingHelper::logFunction('END JOB:UPDATE UNINSTALL DEVICE');

    }
}