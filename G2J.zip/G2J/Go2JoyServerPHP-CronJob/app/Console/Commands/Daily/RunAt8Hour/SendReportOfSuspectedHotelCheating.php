<?php

namespace App\Console\Commands\Daily\RunAt8Hour;

use App\Actions\Cheating\SendDailyReportCheating;
use Illuminate\Console\Command;

class SendReportOfSuspectedHotelCheating extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'SendDailyReportOfSuspectedHotelCheating';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Cron job for Send Report Of Suspected Hotel Cheating  at 8 Hour';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    public function handle(SendDailyReportCheating $sendDailyReportCheating)
    {
        $sendDailyReportCheating->handle();
    }
}
