<?php


namespace App\Console\Commands\Daily\RunAt3Hour;


use App\Helpers\LoggingHelper;
use App\Services\Web\SA\RoomTypeService;
use Exception;
use Illuminate\Console\Command;

class UpdateDailyRoomTypeHasPromotionExpired extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'UpdateDailyRoomTypeHasPromotionExpired';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Cron job for 3H';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     * @param RoomTypeService $hotelService
     */
    public function handle(RoomTypeService $hotelService)
    {
        LoggingHelper::logFunction('START JOB: UPDATE DAILY ROOM TYPE HAS PROMOTION');
        try {
            $hotelService->updateDailyRoomTypeHasPromotionExpired();
        } catch (Exception $e) {
            LoggingHelper::logFunction( 'ERROR JOB: UPDATE DAILY ROOM TYPE HAS PROMOTION - ' . $e->getMessage());
        }
        LoggingHelper::logFunction( 'END JOB: UPDATE DAILY DAILY ROOM TYPE HAS PROMOTION');
    }
}