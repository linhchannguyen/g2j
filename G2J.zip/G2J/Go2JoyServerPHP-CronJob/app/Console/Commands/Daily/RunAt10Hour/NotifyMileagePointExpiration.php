<?php

namespace App\Console\Commands\Daily\RunAt10Hour;

use App\Constants\Globals\Common;
use App\Constants\Globals\FcmNotification as FcmNotificationConst;
use App\Constants\Globals\QueueName as QueueNameConst;
use App\Constants\Globals\UserNotification as UserNotificationConst;
use App\Helpers\ConvertHelper;
use App\Helpers\LoggingHelper;
use App\Jobs\Notification\PushNotificationJob;
use App\Models\MileagePointExpiration;
use App\Repositories\Interfaces\MileagePointExpirationRepositoryInterface;
use App\Services\Common\NotificationService;
use Exception;
use Illuminate\Console\Command;
use Illuminate\Support\Carbon;

class NotifyMileagePointExpiration extends Command
{
    const NUM_DAYS = 7;// Days push notify prepare mileage point expiration

    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'daily:notify-mileage-point-expiration';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'NotifyMileagePointExpiration';

    protected $mileagePointExpirationRepository;

    protected $notificationService;

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->mileagePointExpirationRepository = app(MileagePointExpirationRepositoryInterface::class);
        $this->notificationService = app(NotificationService::class);
        parent::__construct();
    }

    public function handle()
    {
        $prepareDate = Carbon::now()->addDays(self::NUM_DAYS);
        $mileagePointExpirationList = $this->mileagePointExpirationRepository->findMileagePointPrepareExpirationByDate($prepareDate);
        $title = ConvertHelper::getMessage(UserNotificationConst::MGS_NOTIFICATION, 'title.point.reward.expired');
        $body = ConvertHelper::getMessage(UserNotificationConst::MGS_NOTIFICATION, 'point.reward.expired');
        try {
            foreach ($mileagePointExpirationList as $mileagePointExpiration) {
                $informationList = [
                    'point' => $mileagePointExpiration->{MileagePointExpiration::VAR_TOTAL_EXPIRE},
                ];
                //Push notification
                $pushNotificationJob = new PushNotificationJob($mileagePointExpiration->{MileagePointExpiration::COL_APP_USER_SN},
                    [], $title, $body, $informationList, FcmNotificationConst::NOTI_MILEAGE_POINT, Common::GO2JOY, true, null, null, null, null);
                dispatch($pushNotificationJob->onQueue(QueueNameConst::NOTIFICATION));

            }
        } catch (Exception $exception) {
            LoggingHelper::logException($exception);
        }

    }
}