<?php


namespace App\Console\Commands\Daily\RunAt2Hour;


use App\Helpers\LoggingHelper;
use App\Services\Web\SA\StampService;
use Exception;
use Illuminate\Console\Command;

class UpdateDailyRegisterStampSuspendOrEnd extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'UpdateDailyRegisterStampSuspendOrEnd';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Cron job for 2H';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     * @param StampService $stampService
     */
    public function handle(StampService $stampService)
    {
        LoggingHelper::logFunction('START JOB: UPDATE DAILY REGISTER STAMP');
        try {
            $stampService->updateDailyRegisterStampSuspendOrEnd();
        } catch (Exception $e) {
            LoggingHelper::logFunction('ERROR JOB: UPDATE DAILY REGISTER STAMP - ' . $e->getMessage());
        }
        LoggingHelper::logFunction('END JOB: UPDATE DAILY REGISTER STAMP');
    }
}