<?php


namespace App\Console\Commands\Daily\RunAt2Hour;


use App\Helpers\LoggingHelper;
use App\Services\Web\SA\UserStampService;
use Exception;
use Illuminate\Console\Command;

class UpdateDailyStampIssuedToExpired extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'UpdateDailyStampIssuedToExpired';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Cron job for 2H';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     * @param UserStampService $userStampService
     */
    public function handle(UserStampService $userStampService)
    {
        LoggingHelper::logFunction( 'START JOB: UPDATE DAILY USER STAMP EXPIRED');
        try {
            $userStampService->updateDailyStampIssuedToExpired();
        } catch (Exception $e) {
            LoggingHelper::logFunction('ERROR JOB: UPDATE DAILY USER STAMP EXPIRED - ' . $e->getMessage());
        }
        LoggingHelper::logFunction( 'END JOB: UPDATE DAILY USER STAMP EXPIRED');
    }
}