<?php

namespace App\Console\Commands\Daily\RunAt2Hour;

use App\Helpers\LoggingHelper;
use App\Services\Web\SA\ReferralService;
use Exception;
use Illuminate\Console\Command;

class DeleteReferralProgramAppUserWhenExpired extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'delete-referral-program-app-user-when-expired';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Cron job for 2H';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @param ReferralService $referralService
     */
    public function handle(ReferralService $referralService)
    {
        LoggingHelper::logFunction('START JOB: DELETE REFERRAL PROGRAM APP USER WHEN PROGRAM EXPIRED');
        try {
            $referralService->deleteReferralProgramAppUserWhenExpired();
        } catch (Exception $e) {
            LoggingHelper::logFunction( 'ERROR JOB: DELETE REFERRAL PROGRAM APP USER WHEN PROGRAM EXPIRED - ' . $e->getMessage());
        }
        LoggingHelper::logFunction('END JOB: DELETE REFERRAL PROGRAM APP USER WHEN PROGRAM EXPIRED');
    }
}
