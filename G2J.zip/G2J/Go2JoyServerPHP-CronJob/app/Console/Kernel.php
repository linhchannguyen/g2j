<?php

namespace App\Console;

use App\Console\Commands\Adhoc\GenerateAdjustedBookingTransactions;
use App\Console\Commands\Adhoc\RemoveDayUseRoomOfAgoda;
use App\Console\Commands\Adhoc\ReportBookingAutocomplete;
use App\Console\Commands\AgodaTestingEnvironmentSetup;
use App\Console\Commands\Audit\TotalHotelStatisticOfDistrict;
use App\Console\Commands\CacheSchedulerRunning;
use App\Console\Commands\Daily\RunAt0Hour\ProcessDirectDiscountProgram;
use App\Console\Commands\Daily\RunAt0Hour\DeleteHotelCouponExpiredForElasticSearch;
use App\Console\Commands\Daily\RunAt0Hour\ProcessMileagePointExpiration;
use App\Console\Commands\Daily\RunAt0Hour\RecoverAutoCheckInAgodaBookingJob;
use App\Console\Commands\Daily\RunAt0Hour\UpdateDailyAvailableBooking;
use App\Console\Commands\Daily\RunAt0Hour\UpdateDailyLuckWheel;
use App\Console\Commands\Daily\RunAt0Hour\UpdateViewsForElasticSearch;
use App\Console\Commands\Daily\RunAt10Hour\NotifyMileagePointExpiration;
use App\Console\Commands\Daily\RunAt6Hour\UpdateDailyRefreshInstantLock;
use App\Console\Commands\Daily\RunAt8Hour\HandleUserLocationElasticSearch;
use App\Console\Commands\GarbageCollection;
use App\Console\Commands\Daily\RunAt0Hour\UpdateDailyCouponIssuedExperied;
use App\Console\Commands\Daily\RunAt0Hour\UpdateDailyPromotion;
use App\Console\Commands\Daily\RunAt0Hour\UpdateDailyRoomPriceAdjustment;
use App\Console\Commands\Daily\RunAt0Hour\UpdateDailyShowPopupHistory;
use App\Console\Commands\Daily\RunAt0Hour\UpdateDailyTopDistrct;
use App\Console\Commands\Daily\RunAt0Hour\UpdateStatusReferralProgram;
use App\Console\Commands\Daily\RunAt12Hour\UpdateDailyTopSearchToday;
use App\Console\Commands\Daily\RunAt23Hour\ReportOfSuspectedHotelCheating;
use App\Console\Commands\Daily\RunAt2Hour\UpdateDailyRegisterStampSuspendOrEnd;
use App\Console\Commands\Daily\RunAt2Hour\UpdateDailyStampIssuedToExpired;
use App\Console\Commands\Daily\RunAt2Hour\UpdateDailyStatusForMileagePoint;
use App\Console\Commands\Daily\RunAt2Hour\UpdateDailyTempToNotYetCoupon;
use App\Console\Commands\Daily\RunAt3Hour\UpdateDailyHotelStatus;
use App\Console\Commands\Daily\RunAt3Hour\UpdateDailyNumOfNewReviewForHotel;
use App\Console\Commands\Daily\RunAt3Hour\UpdateDailyRoomTypeHasPromotionExpired;
use App\Console\Commands\Daily\RunAt6Hour\UpdateDailyBannerExpired;
use App\Console\Commands\Daily\RunAt6Hour\UpdateDailyLockRoomSetting;
use App\Console\Commands\Daily\RunAt6Hour\UpdateDailyNotifyCouponExpired;
use App\Console\Commands\Daily\RunAt6Hour\UpdateDailyPopupExpired;
use App\Console\Commands\Daily\RunAt6Hour\UpdateDailyRefreshNotiFS;
use App\Console\Commands\Daily\RunAt6Hour\UpdateDailyRefreshSoldOutToday;
use App\Console\Commands\Daily\RunAt8Hour\SendReportOfSuspectedHotelCheating;
use App\Console\Commands\Daily\RunAt8Hour\UpdateUninstallDevice;
use App\Console\Commands\Daily\RunAt9Hour\NotifyExpiredStamp;
use App\Console\Commands\Daily\RunAt9Hour\NotifyForBirthdayCoupon;
use App\Console\Commands\Daily\RunAt9Hour\NotifyForSuspendStamp;
use App\Console\Commands\Daily\RunAt9Hour\NotifyPrepareExpireStampOneDate;
use App\Console\Commands\Daily\RunAt9Hour\NotifyPrepareExpireStampTwoWeek;
use App\Console\Commands\Daily\RunAt9Hour\UpdateInviteFriendStatus;
use App\Console\Commands\Hourly\ProcessHourlyRoomPriceAdjustment;
use App\Console\Commands\Hourly\ProcessHourlyUpdateRoomPriceOriginAgoda;
use App\Console\Commands\Hourly\UpdateHourlyBuildNotifyFlashSale;
use App\Console\Commands\Hourly\UpdateHourlyCheckInLocation;
use App\Console\Commands\Hourly\UpdateHourlyFlashSale;
use App\Console\Commands\Hourly\UpdateHourlyHotelOnTop;
use App\Console\Commands\Hourly\UpdateHourlySecondSplash;
use App\Console\Commands\Hourly\UpdateHourlySendNotifyForUserBookingByStampNotCheckin;
use App\Console\Commands\index;
use App\Console\Commands\Integration\Agoda\FetchHotel;
use App\Console\Commands\Integration\Agoda\GroupHotel;
use App\Console\Commands\Integration\Agoda\ImportHotel;
use App\Console\Commands\Integration\Agoda\ImportHotelFacility;
use App\Console\Commands\Integration\Agoda\ImportHotelImage;
use App\Console\Commands\Integration\Agoda\ImportRoomType;
use App\Console\Commands\Integration\Agoda\ImportRoomTypeFacility;
use App\Console\Commands\Integration\Agoda\PullArea;
use App\Console\Commands\Integration\Agoda\PullCity;
use App\Console\Commands\Integration\Agoda\PullHotel;
use App\Console\Commands\Integration\Agoda\PullHotelFacility;
use App\Console\Commands\Integration\Agoda\PullHotelImage;
use App\Console\Commands\Integration\Agoda\PullRoomType;
use App\Console\Commands\Integration\Agoda\PullRoomTypeFacility;
use App\Console\Commands\Integration\Agoda\RefreshHotelDisplayFilter;
use App\Console\Commands\Integration\Agoda\RefreshRoomPriceToday;
use App\Console\Commands\Integration\Agoda\RefreshUpdatedHotelInfoDaily;
use App\Console\Commands\Integration\Agoda\UpdateRoomPriceOneDay;
use App\Console\Commands\Minute\HandleAwaitingCheckinBookingPayAtHotel;
use App\Console\Commands\Minute\HandleAwaitingCheckinBookingPayInAdvance;
use App\Console\Commands\Minute\HandleAwaitingUserConfirmationBooking;
use App\Console\Commands\Minute\HandleCreatedBooking;
use App\Console\Commands\Minute\HandleFailedPaymentV2;
use App\Console\Commands\Minute\HandlePendingPaymentV2;
use App\Console\Commands\Minute\HandlePendingRefundPoint;
use App\Console\Commands\Minute\HandlePendingRewardPoint;
use App\Console\Commands\Minute\PostArticle;
use App\Console\Commands\MinuteSendNotification;
use App\Console\Commands\PubSub\CreateUserStatistic;
use App\Console\Commands\PubSub\SubscribeToLoggingTopic;
use App\Console\Commands\PubSub\SubscribeToNewSignUpTopic;
use App\Console\Commands\PubSub\UpdateUserStatistic;
use App\Console\Commands\SearchingEngine\RetrySyncData;
use App\Console\Commands\SearchingEngine\RetrySyncHotelData;
use App\Console\Commands\SearchingEngine\RetrySyncHotelDisplayRuleData;
use App\Console\Commands\SearchingEngine\RetrySyncRoomTypeData;
use App\Console\Commands\SearchingEngine\SyncData;
use App\Console\Commands\SearchingEngine\SyncHotelData;
use App\Console\Commands\SearchingEngine\SyncHotelDisplayRuleData;
use App\Console\Commands\SearchingEngine\SyncRoomTypeData;
use App\Console\Commands\Snapshot\UpdateUserAccess;
use App\Console\Commands\Snapshot\ViewHotelDetail;
use App\Console\Commands\TwiceDaily\TrackingUpdateBookingStatus;
use App\Console\Commands\Weekly\DeleteAmplitudeChangeBookingStatus;
use App\Console\Commands\Weekly\ReportReferralProgram;
use App\Constants\Globals\Environment as EnvironmentConst;
use Illuminate\Console\Scheduling\Schedule;
use Illuminate\Foundation\Console\Kernel as ConsoleKernel;

class Kernel extends ConsoleKernel
{
    /**
     * The environments
     *
     * @var array
     */
    protected $environments = [
        EnvironmentConst::PRODUCTION,
        EnvironmentConst::UAT,
        EnvironmentConst::STAGING,
        EnvironmentConst::DEVELOP,
    ];

    const WEEKDAYS = array(
        'SUNDAY'    => 0,
        'MONDAY'    => 1,
        'TUESDAY'   => 2,
        'WEDNESDAY' => 3,
        'THURSDAY'  => 4,
        'FRIDAY'    => 5,
        'SATURDAY'  => 6,
    );

    /**
     * The Artisan commands provided by your application.
     *
     * @var array
     */
    protected $commands = [
        index::class,

        #region Adhoc
        GenerateAdjustedBookingTransactions::class,
        #endregion Adhoc

        #region Audit
        TotalHotelStatisticOfDistrict::class,
        #endregion Audit

        #region Snapshot
        ViewHotelDetail::class,
        #endregion Snapshot

        #region Integration
        GroupHotel::class,
        RefreshHotelDisplayFilter::class,
        UpdateRoomPriceOneDay::class,
        PullCity::class,
        PullArea::class,
        FetchHotel::class,
        PullHotel::class,
        ImportHotel::class,
        PullHotelFacility::class,
        ImportHotelFacility::class,
        PullHotelImage::class,
        ImportHotelImage::class,
        PullRoomType::class,
        ImportRoomType::class,
        PullRoomTypeFacility::class,
        ImportRoomTypeFacility::class,
        #endregion Integration
    ];

    /**
     * Define the application's command schedule.
     *
     * @param Schedule $schedule
     * @return void
     */
    protected function schedule(Schedule $schedule)
    {
        $schedule->command('horizon:snapshot')->everyFiveMinutes();

        $this->go2joyCommands($schedule);

        $this->integrationCommands($schedule);
    }

    /**
     * Register the commands for the application.
     *
     * @return void
     */
    protected function commands()
    {
        $this->load(__DIR__ . '/Commands');

        require base_path('routes/console.php');
    }

    /**
     * All commands of Go2Joy
     * @param Schedule $schedule
     *
     * @return void
     */
    protected function go2joyCommands(Schedule $schedule)
    {
        if (config('go2joy.allow_running_command')) {
            $this->minuteCommands($schedule);

            $this->hourlyCommands($schedule);

            $this->dailyCommands($schedule);

            $this->weeklyCommands($schedule);

            //$this->pubsubCommands($schedule);

            $this->adhocCommands($schedule);

            //$this->searchingCommands($schedule);

            $this->twiceDailyCommands($schedule);
        }
    }

    /**
     * All commands of twice daily
     * @param Schedule $schedule
     *
     * @return void
     */
    protected function twiceDailyCommands(Schedule $schedule)
    {
        $schedule->command(TrackingUpdateBookingStatus::class)->environments($this->environments)->twiceDaily(0, 12)->withoutOverlapping();
    }

    /**
     * All commands of minute
     * @param Schedule $schedule
     *
     * @return void
     */
    protected function minuteCommands(Schedule $schedule)
    {
        $schedule->command(HandlePendingRefundPoint::class)->environments($this->environments)->everyMinute()->withoutOverlapping();
        $schedule->command(HandlePendingRewardPoint::class)->environments($this->environments)->everyMinute()->withoutOverlapping();
        $schedule->command(MinuteSendNotification::class)->environments($this->environments)->everyTwoMinutes()->withoutOverlapping();
        $schedule->command(ViewHotelDetail::class)->environments($this->environments)->everyFifteenMinutes()->withoutOverlapping();
        $schedule->command(UpdateUserAccess::class)->environments($this->environments)->everyFiveMinutes()->withoutOverlapping();
        $schedule->command(CacheSchedulerRunning::class)->environments($this->environments)->everyMinute();
        $schedule->command(PostArticle::class)->environments($this->environments)->everyMinute();
        $schedule->command(HandleFailedPaymentV2::class)->environments($this->environments)->everyMinute()->withoutOverlapping();
        $schedule->command(HandlePendingPaymentV2::class)->environments($this->environments)->everyMinute()->withoutOverlapping();
        $schedule->command(HandleCreatedBooking::class)->environments($this->environments)->everyMinute()->withoutOverlapping();
        $schedule->command(HandleAwaitingCheckinBookingPayInAdvance::class)->environments($this->environments)->everyMinute()->withoutOverlapping();
        $schedule->command(HandleAwaitingCheckinBookingPayAtHotel::class)->environments($this->environments)->everyMinute()->withoutOverlapping();
        $schedule->command(HandleAwaitingUserConfirmationBooking::class)->environments($this->environments)->everyMinute()->withoutOverlapping();
    }

    /**
     * All commands of hourly
     * @param Schedule $schedule
     *
     * @return void
     */
    protected function hourlyCommands(Schedule $schedule)
    {
        $schedule->command(UpdateHourlyBuildNotifyFlashSale::class)->environments($this->environments)->hourly()->withoutOverlapping();
        $schedule->command(UpdateHourlyCheckInLocation::class)->environments($this->environments)->hourly()->withoutOverlapping();
        $schedule->command(UpdateHourlyFlashSale::class)->environments($this->environments)->hourly()->withoutOverlapping();
        $schedule->command(UpdateHourlyHotelOnTop::class)->environments($this->environments)->hourly()->withoutOverlapping();
        $schedule->command(UpdateHourlySecondSplash::class)->environments($this->environments)->hourly()->withoutOverlapping();
        $schedule->command(UpdateHourlySendNotifyForUserBookingByStampNotCheckin::class)->environments($this->environments)->hourly()->withoutOverlapping();
        //Only run update price from 01:00 to 23:00 except 00:00 because UpdateDailyRoomPriceAdjustment running
        $schedule->command(ProcessHourlyRoomPriceAdjustment::class)->environments($this->environments)->hourly()->between('01:00','23:00')->withoutOverlapping();
        $schedule->command(ProcessHourlyUpdateRoomPriceOriginAgoda::class)->environments($this->environments)->hourly()->withoutOverlapping();

    }

    /**
     * All commands of daily
     * @param Schedule $schedule
     *
     * @return void
     */
    protected function dailyCommands(Schedule $schedule)
    {
        #region 0h
        $schedule->command(ProcessMileagePointExpiration::class)->environments($this->environments)->daily();
        $schedule->command(TotalHotelStatisticOfDistrict::class)->environments($this->environments)->daily();
        $schedule->command(GarbageCollection::class)->environments($this->environments)->daily();
        $schedule->command(RecoverAutoCheckInAgodaBookingJob::class)->environments($this->environments)->daily();
        $schedule->command(UpdateDailyCouponIssuedExperied::class)->environments($this->environments)->dailyAt('00:01');
        $schedule->command(UpdateDailyPromotion::class)->environments($this->environments)->dailyAt('00:01')->onSuccess(function () {
            $this->call('daily:update-daily-promotion-group');
        });
        $schedule->command(UpdateDailyLuckWheel::class)->environments($this->environments)->dailyAt('00:01');
        $schedule->command(UpdateDailyRoomPriceAdjustment::class)->environments($this->environments)->dailyAt('00:01');
        $schedule->command(UpdateDailyShowPopupHistory::class)->environments($this->environments)->dailyAt('00:01');
        $schedule->command(UpdateStatusReferralProgram::class)->environments($this->environments)->dailyAt('00:01');
        $schedule->command(UpdateViewsForElasticSearch::class)->environments($this->environments)->dailyAt('00:01');
        $schedule->command(UpdateDailyAvailableBooking::class)->environments($this->environments)->dailyAt('00:01');
        $schedule->command(ProcessDirectDiscountProgram::class)->environments($this->environments);
        $schedule->command(DeleteHotelCouponExpiredForElasticSearch::class)->environments($this->environments)->dailyAt('00:01');
        $schedule->command(UpdateDailyTopDistrct::class)->environments($this->environments)->dailyAt('00:01');

        #endregion 0h

        #region 2h
        $schedule->command(UpdateDailyRegisterStampSuspendOrEnd::class)->environments($this->environments)->dailyAt('02:00');
        $schedule->command(UpdateDailyStampIssuedToExpired::class)->environments($this->environments)->dailyAt('02:00');
        $schedule->command(UpdateDailyStatusForMileagePoint::class)->environments($this->environments)->dailyAt('02:00');
        $schedule->command(UpdateDailyTempToNotYetCoupon::class)->environments($this->environments)->dailyAt('02:00');
        #endregion 2h

        #region 3h
        $schedule->command(UpdateDailyHotelStatus::class)->environments($this->environments)->dailyAt('03:00');
        $schedule->command(UpdateDailyNumOfNewReviewForHotel::class)->environments($this->environments)->dailyAt('03:00');
        $schedule->command(UpdateDailyRoomTypeHasPromotionExpired::class)->environments($this->environments)->dailyAt('03:00');
        #endregion 3h

        #region 6h
        $schedule->command(UpdateDailyBannerExpired::class)->environments($this->environments)->dailyAt('06:00');
        $schedule->command(UpdateDailyLockRoomSetting::class)->environments($this->environments)->dailyAt('06:00');
        $schedule->command(UpdateDailyNotifyCouponExpired::class)->environments($this->environments)->dailyAt('06:00');
        $schedule->command(UpdateDailyPopupExpired::class)->environments($this->environments)->dailyAt('06:00');
        $schedule->command(UpdateDailyRefreshNotiFS::class)->environments($this->environments)->dailyAt('06:00');
        $schedule->command(UpdateDailyRefreshSoldOutToday::class)->environments($this->environments)->dailyAt('06:00');
        $schedule->command(UpdateDailyRefreshInstantLock::class)->environments($this->environments)->dailyAt('06:00');
        #endregion 6h

        #region 8h
        $schedule->command(UpdateUninstallDevice::class)->environments($this->environments)->dailyAt('08:00');
        $schedule->command(HandleUserLocationElasticSearch::class)->environments($this->environments)->dailyAt('08:00');
        if (config('cheating.enable_cheat')) {
            $schedule->command(SendReportOfSuspectedHotelCheating::class)->environments($this->environments)->dailyAt('08:00');
        }
        #endregion 8h

        #region 9h
        $schedule->command(UpdateInviteFriendStatus::class)->environments($this->environments)->dailyAt('09:00')->onSuccess(function () {
            $this->call('daily:update-budget-history');
        });
        $schedule->command(NotifyForBirthdayCoupon::class)->environments($this->environments)->dailyAt('09:00');
        $schedule->command(NotifyExpiredStamp::class)->environments($this->environments)->dailyAt('09:00');
        $schedule->command(NotifyPrepareExpireStampOneDate::class)->environments($this->environments)->dailyAt('09:00');
        $schedule->command(NotifyPrepareExpireStampTwoWeek::class)->environments($this->environments)->dailyAt('09:00');
        $schedule->command(NotifyForSuspendStamp::class)->environments($this->environments)->dailyAt('09:00');
        #endregion 9h

        #region 10h
        $schedule->command(NotifyMileagePointExpiration::class)->environments($this->environments)->dailyAt('10:00');
        #endregion 10h

        #region 12h
        $schedule->command(UpdateDailyTopSearchToday::class)->environments($this->environments)->daily()->at('12:00');
        #endregion 12h
        
        #region 23h
        if (config('cheating.enable_cheat')) {
            $schedule->command(ReportOfSuspectedHotelCheating::class)->environments($this->environments)->dailyAt('23:30');
        }
        #endregion 23h
    }

    /**
     * All commands of weekly
     * @param Schedule $schedule
     *
     * @return void
     */
    protected function weeklyCommands(Schedule $schedule)
    {
        $schedule->command(ReportReferralProgram::class)->environments($this->environments)->weeklyOn(self::WEEKDAYS['MONDAY'], '14:00');
        $schedule->command(DeleteAmplitudeChangeBookingStatus::class)->environments($this->environments)->weeklyOn(self::WEEKDAYS['MONDAY'], '04:00');
    }

    /**
     * All commands of searching
     * @param Schedule $schedule
     *
     * @return void
     */
    protected function searchingCommands(Schedule $schedule)
    {
        $schedule->command(SyncData::class)->environments($this->environments)->everyTwoMinutes()->withoutOverlapping(10);
        $schedule->command(SyncHotelData::class)->environments($this->environments)->everyTwoMinutes()->withoutOverlapping(10);
        $schedule->command(SyncHotelDisplayRuleData::class)->environments($this->environments)->everyTwoMinutes()->withoutOverlapping(10);
        $schedule->command(SyncRoomTypeData::class)->environments($this->environments)->everyTwoMinutes()->withoutOverlapping(10);

        $schedule->command(RetrySyncData::class)->environments($this->environments)->everyFiveMinutes()->withoutOverlapping(15);
        $schedule->command(RetrySyncHotelData::class)->environments($this->environments)->everyFiveMinutes()->withoutOverlapping(15);
        $schedule->command(RetrySyncHotelDisplayRuleData::class)->environments($this->environments)->everyFiveMinutes()->withoutOverlapping(15);
        $schedule->command(RetrySyncRoomTypeData::class)->environments($this->environments)->everyFiveMinutes()->withoutOverlapping(15);
    }

    /**
     * All commands of pubsub
     * @param Schedule $schedule
     *
     * @return void
     */
    protected function pubsubCommands(Schedule $schedule)
    {
        $schedule->command(SubscribeToNewSignUpTopic::class)->environments($this->environments)->cron('* * * * *')->withoutOverlapping();
        $schedule->command(SubscribeToLoggingTopic::class)->environments($this->environments)->cron('* * * * *')->withoutOverlapping();
        $schedule->command(CreateUserStatistic::class)->environments($this->environments)->cron('* * * * *')->withoutOverlapping();
        $schedule->command(UpdateUserStatistic::class)->environments($this->environments)->cron('* * * * *')->withoutOverlapping();
    }

    /**
     * All commands of adhoc
     * @param Schedule $schedule
     *
     * @return void
     */
    protected function adhocCommands(Schedule $schedule)
    {
        $schedule->command(ReportBookingAutocomplete::class, ['--phase=1'])->environments($this->environments)->monthlyOn(15, '00:00:00')->withoutOverlapping();
        $schedule->command(ReportBookingAutocomplete::class, ['--phase=2'])->environments($this->environments)->lastDayOfMonth('23:59:59')->withoutOverlapping();
        $schedule->command(RemoveDayUseRoomOfAgoda::class)->environments($this->environments)->daily()->withoutOverlapping();
    }

    /**
     * All commands of integration
     * @param Schedule $schedule
     *
     * @return void
     */
    protected function integrationCommands(Schedule $schedule)
    {
        #region Agoda
        if (config('agoda.config.allowRefreshContent')) {
            $schedule->command(PullCity::class)->when(function() {
                    return now()->weekOfYear % 2 == 0;
                })
                ->at('01:00')
                ->days([self::WEEKDAYS['TUESDAY']])
                ->timezone(config('app.timezone'))
                ->runInBackground()
                ->then(function() {
                    $this->call('integration:agoda:pull-area');
                });

            $schedule->command(FetchHotel::class)->when(function() {
                    return now()->weekOfYear % 2 == 0;
                })
                ->at('01:00')
                ->days([self::WEEKDAYS['TUESDAY']])
                ->timezone(config('app.timezone'))
                ->runInBackground();

            $schedule->command(PullHotel::class)
                ->everyFiveMinutes()
                ->withoutOverlapping()
                ->timezone(config('app.timezone'))
                ->runInBackground();

            $schedule->command(ImportHotel::class)
                ->everyFiveMinutes()
                ->withoutOverlapping()
                ->timezone(config('app.timezone'))
                ->runInBackground()
                ->then(function() {
                    $this->call('integration:agoda:group-hotel');
                });

            $schedule->command(PullHotelFacility::class)
                ->everyFiveMinutes()
                ->withoutOverlapping()
                ->timezone(config('app.timezone'))
                ->runInBackground();

            $schedule->command(ImportHotelFacility::class)
                ->everyFiveMinutes()
                ->withoutOverlapping()
                ->timezone(config('app.timezone'))
                ->runInBackground();

            $schedule->command(PullHotelImage::class)
                ->everyFiveMinutes()
                ->withoutOverlapping()
                ->timezone(config('app.timezone'))
                ->runInBackground();

            $schedule->command(ImportHotelImage::class)
                ->everyFiveMinutes()
                ->withoutOverlapping()
                ->timezone(config('app.timezone'))
                ->runInBackground();

            $schedule->command(PullRoomType::class)
                ->everyFiveMinutes()
                ->withoutOverlapping()
                ->timezone(config('app.timezone'))
                ->runInBackground();

            $schedule->command(ImportRoomType::class)
                ->everyFiveMinutes()
                ->withoutOverlapping()
                ->timezone(config('app.timezone'))
                ->runInBackground();

            $schedule->command(PullRoomTypeFacility::class)
                ->everyFiveMinutes()
                ->withoutOverlapping()
                ->timezone(config('app.timezone'))
                ->runInBackground();

            $schedule->command(ImportRoomTypeFacility::class)
                ->everyFiveMinutes()
                ->withoutOverlapping()
                ->timezone(config('app.timezone'))
                ->runInBackground();

            $schedule->command(RefreshHotelDisplayFilter::class)
                ->everyFiveMinutes()
                ->withoutOverlapping()
                ->timezone(config('app.timezone'))
                ->runInBackground();

            $schedule->command(RefreshHotelDisplayFilter::class, ['--force', '--retry'])
                ->everyFiveMinutes()
                ->withoutOverlapping()
                ->timezone(config('app.timezone'))
                ->runInBackground();

            $schedule->command(RefreshUpdatedHotelInfoDaily::class)
                ->daily()
                ->timezone(config('app.timezone'))
                ->runInBackground();
        }

        if (config('agoda.config.allowRefreshRoomPriceToday')) {
            $schedule->command(RefreshRoomPriceToday::class)
                ->dailyAt('01:00')
                ->timezone(config('app.timezone'))
                ->runInBackground();

            $schedule->command(UpdateRoomPriceOneDay::class)
                ->everyTwoMinutes()
                ->withoutOverlapping()
                ->timezone(config('app.timezone'))
                ->runInBackground();

            $schedule->command(UpdateRoomPriceOneDay::class, ['--force', '--retry', '--doing'])
                ->everyFiveMinutes()
                ->withoutOverlapping()
                ->timezone(config('app.timezone'))
                ->runInBackground();

            $schedule->command(UpdateRoomPriceOneDay::class, ['--force', '--retry', '--noDataFound'])
                ->everyFiveMinutes()
                ->withoutOverlapping()
                ->timezone(config('app.timezone'))
                ->runInBackground();
        }
        #endregion Agoda

        #region Agoda (Testing Environment)
        if (!app()->environment(EnvironmentConst::PRODUCTION)) {
            $schedule->command(AgodaTestingEnvironmentSetup::class)
                ->dailyAt('01:00')
                ->days([self::WEEKDAYS['TUESDAY']])
                ->timezone(config('app.timezone'))
                ->runInBackground();
        }
        #endregion Agoda (Testing Environment)
    }
}
