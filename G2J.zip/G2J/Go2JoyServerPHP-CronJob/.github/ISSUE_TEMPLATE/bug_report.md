---
name: Bug report
about: Create a report to help us improve
title: "[BUG] "
labels: BUG
assignees: ''

---

> If it is a bug caused by a structural problem of the product, you need to create a 'Feature Improvement' Issue card and work from the requirements document and UI/UX design.

**Describe the bug**
A clear and concise description of what the bug is.

**Related links**
Request link : Ex. Bitrix24 link
Requirement file link : Ex. Google spread sheets link
Other links :
Ex. Wireframe design link, References link

**To Reproduce**
Steps to reproduce the behavior:
1. Go to '...'
2. Click on '....'
3. Scroll down to '....'
4. See error

**Expected behavior**
A clear and concise description of what you expected to happen.

**Screenshots**
If applicable, add screenshots to help explain your problem.

**Desktop (please complete the following information):**
 - OS: [e.g. Windows, Mac]
 - Browser [e.g. chrome, safari]
 - Version [e.g. 22]

**Smartphone (please complete the following information):**
 - Device: [e.g. iPhone6]
 - OS: [e.g. iOS8.1]
 - Browser [e.g. stock browser, safari]
 - Browser Version [e.g. 22]
 - App Version [e.g 1.0.0]

**Additional context**
Add any other context about the problem here.

***

**Test result**
> Each person in charge checks the test results.
- [ ] **Developer** : *As a result of reproducing, the bug is fixed.*
- [ ] **Tester** : *As a result of reproducing, the bug is fixed.*
- [ ] **Manager** : *As a result of reproducing, the bug is fixed.*
