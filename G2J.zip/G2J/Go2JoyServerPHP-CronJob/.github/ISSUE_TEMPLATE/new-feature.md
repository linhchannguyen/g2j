---
name: New Feature
about: Add new feature
title: "[New Feature] "
labels: New feature
assignees: ''

---

**Title**
Ex. TOP hotel on Hotel Collection

**Description**
Ex. Allow to setup 10 TOP Hotel on hotel collection 

**Related links**
Request link : Ex. Bitrix24 link
Requirement file link : Ex. Google spread sheets link
Other links :
Ex. Wireframe design link, References link
> If planning and design have not been completed yet, this document can be revised prior to development.
If the planning and design have changed since the start of development, 'mention' the developer and convey the changed content in the comments

**Additional context**
Add any other context or screenshots about the feature request here.

***

**Test case**
> Be sure to add a test case document link for testing.
If there is no test case document, please write a reason.

link :

**Test result**
> Each person in charge checks the test results.
> In the case of Backend, the Manager also check the Tester.
- [ ] **Developer** : *There is no problem as a result of the test.*
- [ ] **Tester** : *There is no problem as a result of the test.*
- [ ] **Manager** : *There is no problem as a result of the test.*
